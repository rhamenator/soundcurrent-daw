$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$root=Join-Path $env:USERPROFILE 'soundcurrent-media-review-7b67b539a149'
$deploy=Join-Path $root 'deploy'
if(Test-Path -LiteralPath $deploy) {throw 'Fresh deploy exists'}
Expand-Archive -LiteralPath (Join-Path $root 'deploy.zip') -DestinationPath $deploy
$manifest=Get-Content -Raw -LiteralPath (Join-Path $root 'deploy-manifest.json') | ConvertFrom-Json
foreach($file in $manifest.files) {
 $path=Join-Path $deploy $file.path
 if((Get-Item -LiteralPath $path).Length -ne $file.bytes -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $file.sha256) {throw 'Deploy bytes differ'}
}
$env:PATH=$deploy+';'+$env:PATH
& python.exe (Join-Path $root 'qualify-media.py') --dll (Join-Path $deploy 'sndfile.dll') --sha256 2f50a0b47e46407bf9d3d34f95dd58289356020331ebd989a0c0a924a57fb6e7 --output (Join-Path $root 'media-observation')
if($LASTEXITCODE -ne 0) {throw 'Native media review failed'}
& python.exe (Join-Path $root 'qualify-helpers.py') --source (Join-Path $root 'source') --deploy $deploy --collection (Join-Path $root 'collection.json') --build-inputs (Join-Path $root 'build-inputs.json') --output (Join-Path $root 'helper-observation')
if($LASTEXITCODE -ne 0) {throw 'Native helper review failed'}
