from pathlib import Path
import argparse,ctypes as c,hashlib,json,math,struct,sys,os
p=argparse.ArgumentParser();p.add_argument('--dll',type=Path,required=True);p.add_argument('--sha256',required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
assert sys.platform=='win32','Native Windows execution required'
dll=a.dll.resolve();out=a.output.resolve();assert not out.exists();out.mkdir()
sha=lambda data:hashlib.sha256(data).hexdigest()
assert sha(dll.read_bytes())==a.sha256
lib=c.CDLL(str(dll));kernel=c.WinDLL('kernel32',use_last_error=True)
kernel.GetModuleFileNameW.argtypes=[c.c_void_p,c.c_wchar_p,c.c_uint];kernel.GetModuleFileNameW.restype=c.c_uint
buf=c.create_unicode_buffer(32768);assert kernel.GetModuleFileNameW(lib._handle,buf,len(buf))>0
loaded=Path(buf.value).resolve();assert loaded==dll and sha(loaded.read_bytes())==a.sha256
class Info(c.Structure):
 _fields_=[('frames',c.c_int64),('samplerate',c.c_int),('channels',c.c_int),('format',c.c_int),('sections',c.c_int),('seekable',c.c_int)]
lib.sf_wchar_open.argtypes=[c.c_wchar_p,c.c_int,c.POINTER(Info)];lib.sf_wchar_open.restype=c.c_void_p
lib.sf_close.argtypes=[c.c_void_p];lib.sf_close.restype=c.c_int
lib.sf_seek.argtypes=[c.c_void_p,c.c_int64,c.c_int];lib.sf_seek.restype=c.c_int64
for f in [lib.sf_readf_float,lib.sf_writef_float]:f.argtypes=[c.c_void_p,c.POINTER(c.c_float),c.c_int64];f.restype=c.c_int64
lib.sf_version_string.argtypes=[];lib.sf_version_string.restype=c.c_char_p
assert lib.sf_version_string()==b'libsndfile-1.2.2'
frames=8192;channels=2;rate=48000
raw=b''.join(struct.pack('<f',1.8*math.sin(2*math.pi*(440+channel*290)*frame/rate)) for frame in range(frames) for channel in range(channels))
array=(c.c_float*(frames*channels)).from_buffer_copy(raw)
records=[]
for kind,major in [('wav',0x010000),('rf64',0x220000)]:
 path=out/('owned-ete-été-Κиїв.'+kind);info=Info(0,rate,channels,major|6,0,0)
 handle=lib.sf_wchar_open(str(path),0x20,c.byref(info));assert handle
 try:assert lib.sf_writef_float(handle,array,frames)==frames
 finally:assert lib.sf_close(handle)==0
 encoded=path.read_bytes();assert encoded[:4]==(b'RIFF' if kind=='wav' else b'RF64')
 info=Info();handle=lib.sf_wchar_open(str(path),0x10,c.byref(info));assert handle
 try:
  assert (info.frames,info.samplerate,info.channels,info.format)==(frames,rate,channels,major|6)
  read=(c.c_float*(frames*channels))();assert lib.sf_readf_float(handle,read,frames)==frames
  decoded=bytes(read);assert decoded==raw
  assert lib.sf_seek(handle,257,0)==257
  fragment=(c.c_float*(37*channels))();assert lib.sf_readf_float(handle,fragment,37)==37
  assert bytes(fragment)==raw[257*channels*4:(257+37)*channels*4]
 finally:assert lib.sf_close(handle)==0
 records.append({'format':kind,'frames':frames,'channels':channels,'rate':rate,'pcmSha256':sha(decoded),'fileSha256':sha(encoded),'peakLinear':max(abs(v) for v in read),'unicodePath':path.name,'allSamplesExact':True,'seek257Exact':True})
bad=out/'invalid.wav';bad.write_bytes(b'not an audio file');info=Info();assert not lib.sf_wchar_open(str(bad),0x10,c.byref(info))
report={'nativePlatform':sys.platform,'pid':os.getpid(),'loadedDll':str(loaded),'dllSha256':a.sha256,'version':lib.sf_version_string().decode(),'records':records,'invalidHeaderRefused':True,'nativeAudio':False,'installerQualified':False}
(out/'media-qualification.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print('Native DLL: WAV/RF64 float samples, headroom, seek, Unicode and invalid-header refusal verified')
