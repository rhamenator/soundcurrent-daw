from pathlib import Path
import subprocess,json,hashlib,struct,math,uuid,sys,datetime
import argparse
import ctypes as c,time
parser=argparse.ArgumentParser()
parser.add_argument('--source',type=Path,required=True)
parser.add_argument('--deploy',type=Path,required=True)
parser.add_argument('--collection',type=Path,required=True)
parser.add_argument('--build-inputs',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args()
assert sys.platform=='win32', 'Actual native Windows helper qualification required'
source=args.source.resolve();build=args.deploy.resolve();root=args.output.resolve()
collection=json.loads(args.collection.read_text(encoding='utf-8-sig'))
head=collection['sourceCommit'];tree=collection['sourceTree']
assert collection['nativePlatform']=='win32' and collection['sourceInputsUnchanged'] is True
assert not root.exists();root.mkdir()
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=source,text=True).strip()
inputs=json.loads(args.build_inputs.read_text(encoding='utf-8-sig'))
assert inputs['sourceCommit']==head and inputs['sourceTree']==tree
manifest={row['name']:row['sha256'] for row in inputs['files']}
for n,h in manifest.items():assert digest(source/n)==h,n
assert subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=source,text=True).strip()==tree
for name in ['sc-import-inspect-worker.exe','sc-approved-wave-probe.exe','sc-media-import-worker.exe','sc-stretch-render-worker.exe']:
 assert digest(build/name)==collection['deploymentFiles'][name]['sha256']
(root/'build-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf-8')
records=[]
def loaded_media(pid):
 kernel=c.WinDLL('kernel32',use_last_error=True);psapi=c.WinDLL('psapi',use_last_error=True)
 kernel.OpenProcess.argtypes=[c.c_uint,c.c_int,c.c_uint];kernel.OpenProcess.restype=c.c_void_p
 kernel.CloseHandle.argtypes=[c.c_void_p];kernel.CloseHandle.restype=c.c_int
 psapi.EnumProcessModulesEx.argtypes=[c.c_void_p,c.POINTER(c.c_void_p),c.c_uint,c.POINTER(c.c_uint),c.c_uint];psapi.EnumProcessModulesEx.restype=c.c_int
 psapi.GetModuleFileNameExW.argtypes=[c.c_void_p,c.c_void_p,c.c_wchar_p,c.c_uint];psapi.GetModuleFileNameExW.restype=c.c_uint
 handle=kernel.OpenProcess(0x410,False,pid);assert handle
 try:
  until=time.monotonic()+2
  while time.monotonic()<until:
   modules=(c.c_void_p*1024)();needed=c.c_uint()
   if psapi.EnumProcessModulesEx(handle,modules,c.sizeof(modules),c.byref(needed),3):
    assert needed.value<=c.sizeof(modules)
    for module in modules[:needed.value//c.sizeof(c.c_void_p)]:
     path=c.create_unicode_buffer(32768)
     if psapi.GetModuleFileNameExW(handle,module,path,len(path)) and Path(path.value).name.lower()=='sndfile.dll':
      dll=Path(path.value).resolve();assert dll==build/'sndfile.dll'
      actual=digest(dll);assert actual==collection['deploymentFiles']['sndfile.dll']['sha256']
      return {'path':str(dll),'sha256':actual,'pid':pid}
   time.sleep(.025)
  raise RuntimeError('No observed deployed media DLL in waiting worker')
 finally:kernel.CloseHandle(handle)
def child(name,args,input=None):
 exe=build/name;before=digest(exe);p=subprocess.Popen([str(exe),*map(str,args)],stdin=subprocess.PIPE if input is not None else None,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 modules=None
 try:
  if input is not None:modules=loaded_media(p.pid)
  stdout,stderr=p.communicate(input,timeout=25)
 except BaseException:
  p.kill();p.communicate(timeout=5);raise
 (root/(name+'.stdout')).write_bytes(stdout);(root/(name+'.stderr')).write_bytes(stderr)
 assert p.returncode==0 and not stderr,(name,p.returncode,stderr)
 assert digest(exe)==before
 report=json.loads(stdout);assert report['workerPid']==p.pid,(name,report)
 record={'sourceCommit':head,'pid':p.pid,'reportedPid':report['workerPid'],'exitCode':p.returncode,'exeSha256':before,'protocol':report['protocol'],'nativePlatform':sys.platform,'nativeAudio':False,'sourceTree':tree}
 records.append({'name':name,'command':p.args,'record':record,'report':report,'loadedMedia':modules});return report,record
frames=8192;payload=b''.join(struct.pack('<f',1.8*math.sin(2*math.pi*(440+ch*290)*f/48000)) for f in range(frames) for ch in range(2));fmt=struct.pack('<HHIIHH',3,2,48000,384000,8,32);body=b'WAVEfmt '+struct.pack('<I',16)+fmt+b'data'+struct.pack('<I',len(payload))+payload;wave=b'RIFF'+struct.pack('<I',len(body))+body
(root/'audio.wav').write_bytes(wave)
raw=b'<REAPER_PROJECT 0.1 7.82\n SAMPLERATE 48000 1\n <TRACK\n  <ITEM\n   <SOURCE WAVE\n    FILE "audio.wav"\n   >\n  >\n >\n>\n';(root/'owned.rpp').write_bytes(raw)
report,record=child('sc-import-inspect-worker.exe',['--rpp-properties',root/'owned.rpp','--memory-bytes','4194304']);assert report['complete'] is True and report['source']['sha256']==hashlib.sha256(raw).hexdigest()
(root/'inspection-worker-qualification.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
encoded=json.dumps(report,ensure_ascii=True,separators=(',',':')).encode();bundle=root/'owned.scinspect';bundle.write_bytes(b'SCIBND01'+struct.pack('<QQQ',len(raw),len(encoded),record['pid'])+raw+encoded+hashlib.sha256(encoded).hexdigest().encode())
property=next(i for i,p in enumerate(report['preview']['properties']) if p['id']==20)
report,record=child('sc-approved-wave-probe.exe',['--desktop-check','--root',root,'--relative','audio.wav','--maximum-bytes','1048576']);assert report['complete'] and report['sourceSha256']==hashlib.sha256(wave).hexdigest() and report['frames']==8192 and report['channels']==2 and report['peakLinear']>1
(root/'media-worker-qualification.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
destination=root/'copied';destination.mkdir();operation=str(uuid.uuid4())
report,record=child('sc-media-import-worker.exe',['--commit','--bundle',bundle,'--property',property,'--root',root,'--relative','audio.wav','--destination',destination,'--operation',operation,'--selection','original','--maximum-bytes','1048576']);assert report['committed'] and report['phase']==2 and report['sessionAssetPublished'] is False and (destination/operation/'media.wav').read_bytes()==wave
request={'schema':'sc-media-copy-request-v1','recover':True,'operation':operation,'bundle':'','root':'','destination':str(destination),'expected':'','maximumBytes':1048576,'selectedFilename':False}
report,record=child('sc-media-import-worker.exe',['--desktop','--memory-bytes','67108864'],json.dumps(request).encode());assert report['protocol']=='sc-media-copy-v1' and report['committed'] and report['phase']==2 and report['sessionAssetPublished'] is False
receipt=json.loads(report['receipt']);assert receipt['sourceSha256']==receipt['stagedSha256']==hashlib.sha256(wave).hexdigest() and receipt['frames']==8192 and receipt['channels']==2 and receipt['sourceRootsPersisted'] is False
record.update({k:report[k] for k in ['phase','committed','sessionAssetPublished','operation']});(root/'copy-worker-qualification.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
assert (destination/operation/'media.wav').read_bytes()==wave and (root/'audio.wav').read_bytes()==wave
(root/'helper-records.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
for n,h in manifest.items():assert digest(source/n)==h,n
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=source,text=True).strip()
print('native_helper_receipts: actual inspection/probe/copy/recovery PID/source/executable/protocol/audio hashes verified; no audio endpoint')
