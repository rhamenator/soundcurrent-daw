from pathlib import Path
import os,ctypes,time,subprocess,json,hashlib,signal
r=Path('.cache/recovery-preview-qualification').resolve();app=Path('.cache/p250-app').resolve();project=app/'project-été-Κиїв'
installed=json.loads((r/'user-installation.json').read_text());binary=Path(installed['installation'])/'usr/bin/soundcurrent-daw'
assert ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)==0
with (app/'reopen-xvfb-display.txt').open('w') as display,(app/'reopen-xvfb.log').open('w') as log:
 server=subprocess.Popen(['Xvfb','-displayfd',str(display.fileno()),'-screen','0','1280x900x24','-nolisten','tcp'],stdout=log,stderr=subprocess.STDOUT,pass_fds=(display.fileno(),))
 pid=None
 try:
  end=time.monotonic()+5
  while not (app/'reopen-xvfb-display.txt').read_text().strip():
   assert server.poll() is None and time.monotonic()<end
   time.sleep(.05)
  xdisplay=':'+(app/'reopen-xvfb-display.txt').read_text().strip()
  env=dict(os.environ,DISPLAY=xdisplay,XDG_CONFIG_HOME=str(app/'isolated-preferences'),SOUNDCURRENT_DAW_LANGUAGE='en',QT_QPA_PLATFORM='xcb',PIPEWIRE_REMOTE='sc-menu-no-server')
  with (app/'reopen-isolated-app.log').open('w') as f:subprocess.run(['gtk-launch','soundcurrent-daw-preview',str(project)],env=env,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=10)
  end=time.monotonic()+8
  while time.monotonic()<end:
   for p in Path('/proc').iterdir():
    if not p.name.isdecimal():continue
    try:
     if (p/'exe').resolve()==binary and str(project).encode() in (p/'cmdline').read_bytes():pid=int(p.name);break
    except (OSError,RuntimeError):pass
   if pid:break
   time.sleep(.05)
  assert pid
  window=None
  while time.monotonic()<end:
   result=subprocess.run(['xdotool','search','--all','--onlyvisible','--pid',str(pid),'--name','^SoundCurrent DAW'],env=env,capture_output=True,text=True)
   if result.returncode==0:window=result.stdout.splitlines()[0];break
   time.sleep(.05)
  assert window
  subprocess.run(['import','-window',window,str(app/'reopen-isolated-opened.png')],env=env,check=True,timeout=8)
  d={'pid':pid,'window':window,'display':xdisplay,'binary':str(binary),'project':str(project),'virtual_display':True,'menu_launcher':'soundcurrent-daw-preview','source_head':installed['source_head'],'physical_audio':False}
  (app/'reopen-isolated-launch.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
  end=time.monotonic()+300
  while time.monotonic()<end:
   result,status=os.waitpid(pid,os.WNOHANG)
   if result:
    d['exit_code']=os.waitstatus_to_exitcode(status);(app/'reopen-isolated-launch.json').write_text(json.dumps(d,indent=2)+'\n');print('Menu app exit '+str(d['exit_code']),flush=True);pid=None;break
   time.sleep(.1)
 finally:
  if pid:
   os.kill(pid,signal.SIGTERM);os.waitpid(pid,0)
  server.terminate();server.wait(timeout=5)
