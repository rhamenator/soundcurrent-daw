from pathlib import Path
import datetime,hashlib,json,subprocess
r=Path('.cache/recovery-preview-qualification');pkg=Path('.cache/p250-package-20261013064632').resolve()
receipt=json.loads((pkg/'receipt.json').read_text());source=pkg/'extracted'
dest=Path.home()/'.local/opt/soundcurrent-daw/previews'/receipt['version'];launcher=Path.home()/'.local/share/applications/soundcurrent-daw-preview.desktop'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files={str(p.relative_to(source)):sha(p) for p in source.rglob('*') if p.is_file()}
assert all(not (dest/n).is_symlink() and sha(dest/n)==h for n,h in files.items())
binary=dest/'usr/bin/soundcurrent-daw';assert sha(binary)==receipt['packaged_executable_sha256']
original=launcher.read_text();expected='Exec='+str(binary)+' %f'
assert expected in original and 'Name=SoundCurrent DAW Preview\n' in original
(r/'unquoted-launcher.desktop.txt').write_text(original)
launcher.write_text(original.replace(expected,'Exec="'+str(binary)+'" %f'));launcher.chmod(0o644)
subprocess.run(['desktop-file-validate',str(launcher)],check=True)
subprocess.run(['update-desktop-database',str(launcher.parent)],check=True)
d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_head':receipt['source_head'],'version':receipt['version'],'package_receipt_sha256':sha(pkg/'receipt.json'),'installation':str(dest),'launcher':str(launcher),'launcher_sha256':sha(launcher),'payload_sha256':files,'all_copied_payload_bytes_match':True,'per_user_installation':True,'system_package_installation':False,'menu_launch_qualified':False,'physical_audio_qualified':False,'desktop_file_validation':True,'initial_unquoted_exec_refusal_retained':True}
(r/'user-installation.json').write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps({k:d[k] for k in ['version','installation','launcher','all_copied_payload_bytes_match','desktop_file_validation']}))
