from pathlib import Path
import argparse, datetime, hashlib, json, shutil, subprocess
args=argparse.ArgumentParser()
args.add_argument('package_dir',type=Path)
a=args.parse_args()
pkg=a.package_dir.resolve();receipt=json.loads((pkg/'receipt.json').read_text())
assert receipt['status']=='prepared-local-preview' and receipt['all_extracted_payload_bytes_match']
assert receipt['offscreen_startup_help_version']
source=pkg/'extracted';dest=Path.home()/'.local/opt/soundcurrent-daw/previews'/receipt['version']
launcher=Path.home()/'.local/share/applications/soundcurrent-daw-preview.desktop'
assert not dest.exists() and not dest.is_symlink() and not launcher.exists() and not launcher.is_symlink()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
shutil.copytree(source,dest,copy_function=shutil.copy2)
files={str(p.relative_to(source)):sha(p) for p in source.rglob('*') if p.is_file()}
assert all(not (dest/n).is_symlink() and sha(dest/n)==h for n,h in files.items())
binary=dest/'usr/bin/soundcurrent-daw';icon=dest/'usr/share/icons/hicolor/scalable/apps/soundcurrent-daw.svg'
assert sha(binary)==receipt['packaged_executable_sha256']
text=(dest/'usr/share/applications/soundcurrent-daw.desktop').read_text()
text=text.replace('Name=SoundCurrent DAW\n','Name=SoundCurrent DAW Preview\n')
text=text.replace('Exec=soundcurrent-daw %f','Exec="'+str(binary)+'" %f').replace('TryExec=soundcurrent-daw','TryExec='+str(binary)).replace('Icon=soundcurrent-daw','Icon='+str(icon))
launcher.parent.mkdir(parents=True,exist_ok=True)
with launcher.open('x') as stream:stream.write(text)
launcher.chmod(0o644)
subprocess.run(['desktop-file-validate',str(launcher)],check=True)
if shutil.which('update-desktop-database'):subprocess.run(['update-desktop-database',str(launcher.parent)],check=True)
r={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_head':receipt['source_head'],'version':receipt['version'],'package_receipt_sha256':sha(pkg/'receipt.json'),'installation':str(dest),'launcher':str(launcher),'launcher_sha256':sha(launcher),'payload_sha256':files,'all_copied_payload_bytes_match':True,'per_user_installation':True,'system_package_installation':False,'menu_launch_qualified':False,'physical_audio_qualified':False}
(Path(__file__).resolve().parent/'user-installation.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:r[k] for k in ['version','installation','launcher','all_copied_payload_bytes_match']}))
