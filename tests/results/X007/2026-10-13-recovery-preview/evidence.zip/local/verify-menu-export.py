from pathlib import Path
import json,hashlib,struct,math
r=Path('.cache/p250-app');root=r/'project-été-Κиїв';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def wave(path):
 b=path.read_bytes();assert b[:4] in (b'RIFF',b'RF64') and b[8:12]==b'WAVE';at=12;fmt=None;data=None;ds64=None
 while at+8<=len(b):
  tag,size=struct.unpack_from('<4sI',b,at);at+=8
  if tag==b'data' and size==0xffffffff:assert ds64;size=ds64[1]
  chunk=b[at:at+size];assert len(chunk)==size;at+=size+(size&1)
  if tag==b'ds64':ds64=struct.unpack_from('<QQQ',chunk)
  if tag==b'fmt ':
   fmt=struct.unpack_from('<HHIIHH',chunk)
   if fmt[0]==65534:assert struct.unpack_from('<I',chunk,24)[0]==3
  if tag==b'data':assert data is None;data=chunk
 assert at==len(b) and fmt and data is not None and fmt[0] in (3,65534) and fmt[1]==1 and fmt[2]==48000 and fmt[5]==32
 return fmt,struct.unpack('<'+'f'*(len(data)//4),data)
s=json.loads((root/'project.json').read_text());asset=s['assets'][0];fi,raw=wave(root/asset['path']);fo,actual=wave(r/'menu-export.wav')
assert len(raw)==len(actual)==480000 and all(math.isfinite(x) for x in raw+actual)
expected=list(raw)
for band in s['tracks'][0]['processors'][0]['bands']:
 if band['gainDb']==0:continue
 w=2*math.pi*band['frequencyHz']/48000;A=10**(band['gainDb']/40);alpha=math.sin(w)/(2*band['q']);a0=1+alpha/A
 b0=(1+alpha*A)/a0;b1=-2*math.cos(w)/a0;b2=(1-alpha*A)/a0;a1=-2*math.cos(w)/a0;a2=(1-alpha/A)/a0
 x1=x2=y1=y2=0.0
 for i,x in enumerate(expected):
  y=b0*x+b1*x1+b2*x2-a1*y1-a2*y2;x2=x1;x1=x;y2=y1;y1=y;expected[i]=y
maximum=max(abs(a-b) for a,b in zip(actual,expected));assert maximum<1e-6,maximum
before=json.loads((r/'project-before-live.json').read_text());after={str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file()};assert set(after)-set(before)=={'project.previous.json'} and not set(before)-set(after) and all(after[n]==h for n,h in before.items()) and after['project.previous.json']==before['project.json']
q={'frames':len(actual),'sample_rate':48000,'channels':1,'float_bits':32,'maximum_independent_direct_form_I_error':maximum,'sample_peak':max(map(abs,actual)),'over_full_scale_samples':sum(abs(x)>1 for x in actual),'raw_sha256':sha(root/asset['path']),'export_sha256':sha(r/'menu-export.wav'),'existing_project_media_unchanged_after_save_export':True,'save_created_matching_previous_backup':True,'project_file_sha256':after,'oracle':'RBJ peaking coefficients, independent Python direct form I; processes actual raw asset, no copied engine code','physical_audio':False}
(r/'export-qualification.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps({k:q[k] for k in ['frames','maximum_independent_direct_form_I_error','sample_peak','existing_project_media_unchanged_after_save_export']}))
