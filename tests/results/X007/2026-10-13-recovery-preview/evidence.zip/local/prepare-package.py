from pathlib import Path
import datetime,json,subprocess
root=Path.cwd();r=root/'.cache/recovery-preview-qualification'
sequence=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d%H%M%S')
output=root/('.cache/p250-package-'+sequence)
argv=['python3','tools/package_linux_preview.py','--build-dir',str(r/'linux'),'--qualification',str(r/'native-linux-test-qualification.json'),'--stretch-worker-qualification',str(r/'native-v4-worker.json'),'--protected-warp-qualification',str(r/'native-v5-worker.json'),'--output',str(output),'--preview-sequence',sequence,'--previous-version','0.1.0~preview.20261010165009.5300010ab521']
(r/'package-invocation.json').write_text(json.dumps({'sequence':sequence,'output':str(output),'argv':argv},indent=2)+'\n')
print(json.dumps({'sequence':sequence,'output':str(output)}),flush=True)
result=subprocess.run(argv)
raise SystemExit(result.returncode)
