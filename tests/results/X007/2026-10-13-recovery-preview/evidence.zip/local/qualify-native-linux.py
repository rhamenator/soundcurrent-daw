from pathlib import Path
import subprocess,json,hashlib,datetime,os
root=Path.cwd();out=root/'.cache/recovery-preview-qualification';build=out/'linux';report=out/'native-linux-test-qualification.json'
assert not report.exists()
git=lambda *a:subprocess.check_output(['git',*a],text=True,cwd=root).strip()
assert not git('status','--porcelain')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
names=git('ls-files').splitlines()
ext={'.cpp','.cc','.c','.cxx','.hpp','.h','.hxx','.cmake','.py','.qrc','.qm','.ts'}
inputs=[n for n in names if Path(n).suffix in ext or n in ['CMakeLists.txt','LICENSE','THIRD-PARTY-NOTICES.md','reuse/equipment/provenance.json'] or n.startswith('ui/translations/')]
executables=['soundcurrent-daw','sc-import-inspect-worker','sc-approved-wave-probe','sc-media-import-worker','sc-stretch-render-worker','sc-stretch-artifact-tests','sc-protected-warp-probe','sc-native-panel-tests','sc-pipewire-ui-fixture','sc-original-recording-tests','sc-localization-tests','sc-export-tests','sc-session-tests','sc-media-staging-tests','sc-wave-validation-tests','sc-project-import-state-tests','sc-media-transaction-tests']
r={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_head':git('rev-parse','HEAD'),'source_tree':git('rev-parse','HEAD^{tree}'),'source_sha256':{n:sha(root/n) for n in inputs},'executable_sha256':{n:sha(build/n) for n in executables},'build_cache_sha256':sha(build/'CMakeCache.txt'),'native_audio':False,'physical_audio':False,'vm_started':False,'system_installation':False,'full_quality_qualified':False,'all_europe_qualified':False}
r['scope']='Selected current-source preview workflows; not the full test suite or physical hardware qualification'
r['selected_tests']=['original-raw-recording', 'desktop-native-recording-panel', 'desktop-localization', 'daw-translation-catalogs', 'session-state', 'verified-media-staging', 'offline-export', 'offline-export-media-policy', 'approved-wave-content', 'approved-wave-probe', 'stretch-worker-workflows', 'protected-warp-worker-workflows', 'project-import-state', 'media-provenance-transaction', 'preview-package-provenance', 'protected-warp-package-inputs']
r['command']=['ctest','--test-dir',str(build),'--output-on-failure','--parallel','1','-R','^('+ '|'.join(r['selected_tests']) +')$']
with (out/'native-linux-tests.log').open('w') as f:child=subprocess.Popen(r['command'],cwd=root,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,QT_QPA_PLATFORM='offscreen',SC_STRETCH_WORKER_QUALIFICATION=str(out/'native-v4-worker.json'),SC_PROTECTED_WARP_QUALIFICATION=str(out/'native-v5-worker.json')));r['pid']=child.pid;r['exit_code']=child.wait()
r['ended_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
assert git('rev-parse','HEAD')==r['source_head'] and git('rev-parse','HEAD^{tree}')==r['source_tree'] and not git('status','--porcelain')
assert all(sha(root/n)==h for n,h in r['source_sha256'].items()) and all(sha(build/n)==h for n,h in r['executable_sha256'].items())
r['input_hashes_unchanged_after_test']=True;r['log_sha256']=sha(out/'native-linux-tests.log')
report.write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:r[k] for k in ['source_head','source_tree','pid','exit_code','input_hashes_unchanged_after_test','native_audio']}))
raise SystemExit(r['exit_code'])
