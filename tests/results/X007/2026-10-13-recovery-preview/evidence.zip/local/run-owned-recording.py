from pathlib import Path
import os,subprocess,tempfile,time,json,hashlib
r=Path('.cache/recovery-preview-qualification');cfg=(r/'private-recording-pipewire.conf').resolve()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
exe=(r/'linux/sc-pipewire-owned-recording-fixture').resolve()
git=lambda *a:subprocess.check_output(['git',*a],text=True).strip()
binding={'sourceCommit':git('rev-parse','HEAD'),'sourceTree':git('rev-parse','HEAD^{tree}'),'fixtureSha256':sha(exe)}
assert not git('status','--porcelain')
jobs=(r/'recording-jobs').resolve();jobs.mkdir(mode=0o700)
with tempfile.TemporaryDirectory(prefix='sc-recording-owned-native-pw-') as directory:
 os.chmod(directory,0o700);env=dict(os.environ,PIPEWIRE_RUNTIME_DIR=directory,XDG_RUNTIME_DIR=directory,PIPEWIRE_REMOTE='pipewire-0',SC_OWNED_PIPEWIRE_RECORDING='1',TMPDIR=str(jobs))
 with (r/'recording-owned-daemon.log').open('w') as log:
  daemon=subprocess.Popen(['pipewire','-c',str(cfg)],env=env,stdout=log,stderr=subprocess.STDOUT)
  try:
   for _ in range(100):
    if daemon.poll() is not None:raise RuntimeError('Private daemon exited before socket readiness')
    if (Path(directory)/'pipewire-0').is_socket():break
    time.sleep(.02)
   else:raise RuntimeError('Private socket did not become ready')
   before=json.loads(subprocess.check_output(['pw-dump'],env=env,timeout=5));(r/'recording-before.json').write_text(json.dumps(before,indent=2)+'\n')
   assert [o['info']['props']['node.name'] for o in before if o['type']=='PipeWire:Interface:Node']==['Dummy-Driver']
   argv=['nice','-n','15','ionice','-c','2','-n','7',str(exe)]
   with (r/'recording-owned-runtime.log').open('w') as out:result=subprocess.run(argv,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=20)
   after=json.loads(subprocess.check_output(['pw-dump'],env=env,timeout=5));(r/'recording-after.json').write_text(json.dumps(after,indent=2)+'\n')
   assert [o['info']['props']['node.name'] for o in after if o['type']=='PipeWire:Interface:Node']==['Dummy-Driver']
   assert binding['sourceCommit']==git('rev-parse','HEAD') and binding['sourceTree']==git('rev-parse','HEAD^{tree}') and binding['fixtureSha256']==sha(exe) and not git('status','--porcelain')
   (r/'recording-owned-runtime.json').write_text(json.dumps({**binding,'argv':argv,'fixtureExit':result.returncode,'privateDaemonPid':daemon.pid,'socketOwnerOnly':True,'configurationSha256':hashlib.sha256(cfg.read_bytes()).hexdigest(),'physicalDevices':False,'modules':'protocol-native/access(owner-only socket)/spa-node-factory/client-node/link-factory; dummy driver only','parentEnvironmentUnchanged':True},indent=2)+'\n')
   if result.returncode:raise RuntimeError('Owned native fixture failed; original log retained')
  finally:
   daemon.terminate()
   try:daemon.wait(timeout=5)
   except subprocess.TimeoutExpired:daemon.kill();daemon.wait(timeout=5)
print('Private daemon native fixture passed; owned daemon joined, no physical device routes')
