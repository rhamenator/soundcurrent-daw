from pathlib import Path
import os,shutil,time,subprocess,json,hashlib
r=Path('.cache/recovery-preview-qualification').resolve();app=Path('.cache/p250-app').resolve();app.mkdir()
source=Path(Path('.cache/p250-normal/latest-path.txt').read_text().strip())/'project'
project=app/'project-été-Κиїв';shutil.copytree(source,project)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
installed=json.loads((r/'user-installation.json').read_text());binary=Path(installed['installation'])/'usr/bin/soundcurrent-daw'
files={str(p.relative_to(project)):sha(p) for p in project.rglob('*') if p.is_file()}
(app/'project-before.json').write_text(json.dumps(files,indent=2)+'\n')
env=dict(os.environ,XDG_CONFIG_HOME=str(app/'preferences'),SOUNDCURRENT_DAW_LANGUAGE='en',QT_QPA_PLATFORM='xcb',PIPEWIRE_REMOTE='sc-menu-no-server')
with (app/'menu-launch.log').open('w') as f:subprocess.run(['gtk-launch','soundcurrent-daw-preview',str(project)],env=env,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=10)
end=time.monotonic()+8;pid=None
while time.monotonic()<end:
 for p in Path('/proc').iterdir():
  if not p.name.isdecimal():continue
  try:
   if (p/'exe').resolve()==binary and str(project).encode() in (p/'cmdline').read_bytes():pid=int(p.name);break
  except (OSError,RuntimeError):pass
 if pid:break
 time.sleep(.1)
assert pid,'Packaged app process did not start from menu'
window=None
while time.monotonic()<end:
 result=subprocess.run(['xdotool','search','--onlyvisible','--pid',str(pid),'--name','^SoundCurrent DAW'],capture_output=True,text=True)
 if result.returncode==0 and result.stdout.strip():window=result.stdout.splitlines()[0];break
 time.sleep(.1)
assert window,'Visible packaged menu window absent'
assert sha(Path('/proc')/str(pid)/'exe')==installed['payload_sha256']['usr/bin/soundcurrent-daw']
subprocess.run(['import','-window',window,str(app/'menu-opened.png')],check=True,timeout=8)
d={'source_head':installed['source_head'],'version':installed['version'],'pid':pid,'window':window,'project':str(project),'binary':str(binary),'menu_launch_qualified':True,'running_binary_sha256':sha(binary),'private_preferences':True,'nonexistent_pipewire_remote':True,'physical_audio':False,'project_before_sha256':files}
(app/'menu-launch.json').write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps({k:d[k] for k in ['pid','window','project','menu_launch_qualified']}))
