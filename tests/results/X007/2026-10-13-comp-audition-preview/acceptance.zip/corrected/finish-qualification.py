from pathlib import Path
import subprocess,json,datetime,hashlib
root=Path.cwd();r=root/'.cache/take-preview-linux-fixed';git=lambda *a:subprocess.check_output(['git',*a],text=True).strip()
head=git('rev-parse','HEAD');tree=git('rev-parse','HEAD^{tree}');assert head=='1a3b2022cffa45fbe2040ef251ed1d57b7856213' and not git('status','--porcelain')
cmds=[['python3',str(r/'qualify-native-linux.py')],['python3','tools/run_native_loop_preview.py','--build-dir',str(root/'.cache/take-preview-linux/build'),'--output-dir','.cache/p259n','--mode','normal'],['python3',str(r/'run-owned-recording.py')]]
rows=[]
for i,argv in enumerate(cmds):
 with (r/('qualification-%d.log'%i)).open('w') as f:
  child=subprocess.Popen(argv,stdout=f,stderr=subprocess.STDOUT);rc=child.wait()
 rows.append({'source_head':head,'source_tree':tree,'argv':argv,'pid':child.pid,'exit_code':rc,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
 (r/'qualification-commands.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('Qualification',i,'PID',child.pid,'exit',rc,flush=True)
 if rc:raise SystemExit(rc)
assert head==git('rev-parse','HEAD') and tree==git('rev-parse','HEAD^{tree}') and not git('status','--porcelain')
sequence=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d%H%M%S');output=root/('.cache/p259-package-'+sequence)
argv=['python3','tools/package_linux_preview.py','--build-dir',str(root/'.cache/take-preview-linux/build'),'--qualification',str(r/'native-linux-test-qualification.json'),'--stretch-worker-qualification',str(r/'native-v4-worker.json'),'--protected-warp-qualification',str(r/'native-v5-worker.json'),'--output',str(output),'--preview-sequence',sequence,'--previous-version','0.1.0~preview.20261013064632.5a2046905c77']
(r/'package-invocation.json').write_text(json.dumps({'sequence':sequence,'output':str(output),'argv':argv},indent=2)+'\n')
with (r/'package-run.log').open('w') as f:
 child=subprocess.Popen(argv,stdout=f,stderr=subprocess.STDOUT);rc=child.wait()
rows.append({'source_head':head,'source_tree':tree,'argv':argv,'pid':child.pid,'exit_code':rc});(r/'qualification-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print('Package exit',rc,flush=True);raise SystemExit(rc)
