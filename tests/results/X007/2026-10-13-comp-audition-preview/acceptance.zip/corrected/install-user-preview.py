from pathlib import Path
import argparse,datetime,hashlib,json,os,shutil,subprocess
p=argparse.ArgumentParser();p.add_argument('package_dir',type=Path);a=p.parse_args()
r=Path(__file__).resolve().parent;pkg=a.package_dir.resolve();receipt=json.loads((pkg/'receipt.json').read_text())
assert receipt['status']=='prepared-local-preview' and receipt['all_extracted_payload_bytes_match'] and receipt['offscreen_startup_help_version']
assert json.loads((r/'app/workflow-qualification.json').read_text())['passed']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=pkg/'extracted';dest=Path.home()/'.local/opt/soundcurrent-daw/previews'/receipt['version']
launcher=Path.home()/'.local/share/applications/soundcurrent-daw-preview.desktop';previous=launcher.with_name('soundcurrent-daw-preview-previous.desktop')
assert launcher.is_file() and not launcher.is_symlink() and not dest.exists() and not previous.exists()
old=launcher.read_bytes();(r/'previous-launcher.desktop.txt').write_bytes(old)
assert b'20261013064632.5a2046905c77' in old
shutil.copytree(source,dest,copy_function=shutil.copy2)
files={str(p.relative_to(source)):sha(p) for p in source.rglob('*') if p.is_file()}
assert all(not (dest/n).is_symlink() and sha(dest/n)==h for n,h in files.items())
binary=dest/'usr/bin/soundcurrent-daw';icon=dest/'usr/share/icons/hicolor/scalable/apps/soundcurrent-daw.svg'
assert sha(binary)==receipt['packaged_executable_sha256']
text=(dest/'usr/share/applications/soundcurrent-daw.desktop').read_text().replace('Name=SoundCurrent DAW\n','Name=SoundCurrent DAW Preview\n').replace('Exec=soundcurrent-daw %f','Exec="'+str(binary)+'" %f').replace('TryExec=soundcurrent-daw','TryExec='+str(binary)).replace('Icon=soundcurrent-daw','Icon='+str(icon))
tmp=launcher.with_name('soundcurrent-daw-preview-candidate.desktop')
assert not tmp.exists()
tmp.write_text(text);tmp.chmod(0o644)
subprocess.run(['desktop-file-validate',str(tmp)],check=True)
previous.write_bytes(old.replace(b'Name=SoundCurrent DAW Preview\n',b'Name=SoundCurrent DAW Preview (previous)\n'));previous.chmod(0o644)
subprocess.run(['desktop-file-validate',str(previous)],check=True)
assert launcher.read_bytes()==old
os.replace(tmp,launcher)
if shutil.which('update-desktop-database'):subprocess.run(['update-desktop-database',str(launcher.parent)],check=True)
out={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_head':receipt['source_head'],'version':receipt['version'],'package_receipt_sha256':sha(pkg/'receipt.json'),'installation':str(dest),'launcher':str(launcher),'launcher_sha256':sha(launcher),'previous_launcher':str(previous),'previous_exact_launcher_sha256':hashlib.sha256(old).hexdigest(),'previous_version_preserved':True,'payload_sha256':files,'all_copied_payload_bytes_match':True,'per_user_installation':True,'system_package_installation':False,'menu_launch_qualified':False,'physical_audio_qualified':False}
(r/'user-installation.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ['version','installation','launcher','previous_launcher']}))
