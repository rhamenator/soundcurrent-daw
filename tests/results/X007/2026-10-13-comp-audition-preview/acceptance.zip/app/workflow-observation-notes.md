# Actual desktop observation notes

Owned private Xvfb/PipeWire only; no physical endpoint, user audio route or VM.

The first dialog search omitted xdotool --all, so PID/name predicates matched the
main window as well; the first capture shows the modal as an obscured area.
The corrected search combines actual PID, visible state and exact title.

At the initial 391x247 size, the longer handles explanation was clipped. Resizing
the actual dialog to 560x320 made the full explanation visible. This remains a
responsive-layout follow-up; it is not a claimed tested fix to product code.

The first keyboard Return/Save sequence left handles unchecked and the dialog open.
After reselecting the checkbox, an actual OK-button click applied the transition.
The immediate Ctrl+S attempt did not save in this window-manager-free display;
File -> Save did. Original failure screenshots and saved project states remain.
The later Undo/Redo/Save/export/Quit actions use actual visible menu items.

Two direct packaged processes completed Save/export and reopen/export with exit0.
A third process launched through gtk-launch from the installed Applications entry
also exited0 following File -> Quit. Its final xdotool command returned a broken-X
connection as the supervising runner immediately joined its private Xvfb after
actual exit0; the application itself did not fail or require forced termination.

Native Wayland keyboard/window-manager interaction, small-display dialog text,
physical audition, clean system package lifecycle and sustained recording remain
separate qualification gates. These observations are not full UI/parity acceptance.
