from pathlib import Path
import json,hashlib,struct,math,copy
r=Path(__file__).resolve().parent;root=r/'project-été-Κиїв';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def wave(path):
 b=path.read_bytes();assert b[:4] in (b'RIFF',b'RF64') and b[8:12]==b'WAVE';at=12;fmt=None;data=None;ds64=None
 while at+8<=len(b):
  tag,size=struct.unpack_from('<4sI',b,at);at+=8
  if tag==b'data' and size==0xffffffff:assert ds64;size=ds64[1]
  chunk=b[at:at+size];assert len(chunk)==size;at+=size+(size&1)
  if tag==b'ds64':ds64=struct.unpack_from('<QQQ',chunk)
  if tag==b'fmt ':
   fmt=struct.unpack_from('<HHIIHH',chunk)
   if fmt[0]==65534:assert struct.unpack_from('<I',chunk,24)[0]==3
  if tag==b'data':assert data is None;data=chunk
 assert at==len(b) and fmt and data is not None and fmt[0] in (3,65534) and fmt[1]==1 and fmt[2]==48000 and fmt[5]==32
 return struct.unpack('<'+'f'*(len(data)//4),data)
load=lambda n:json.loads((r/n).read_text())
initial=load('initial-project.json');applied=load('applied-project.json');undone=load('undone-project.json');redone=load('redone-project.json');reopened=json.loads((root/'project.json').read_text())
assert undone==initial and redone==applied and reopened==applied
expected=copy.deepcopy(initial);clips=expected['tracks'][0]['clips'];clips[0]['lengthFrames']=240120;clips[0]['processing']['fadeOut']={'startFrame':239880,'endFrame':240120,'curve':'equal-power','shape':1.0};clips[1]['startFrame']=239880;clips[1]['sourceFrame']=239880;clips[1]['lengthFrames']=240120;clips[1]['processing']['fadeIn']={'startFrame':0,'endFrame':240,'curve':'equal-power','shape':1.0}
assert applied==expected
assert (root/'project.json').read_bytes()==(r/'redone-project.json').read_bytes()
assert (root/'project.previous.json').read_bytes()==(r/'undone-project.json').read_bytes()
for a in initial['assets']:assert sha(root/a['path'])==a['sha256']
a,b=(wave(root/x['path']) for x in initial['assets']);actual=wave(r/'first-export.wav');again=wave(r/'reopen-export.wav');assert len(a)==len(b)==len(actual)==len(again)==480000 and all(math.isfinite(x) for x in a+b+actual+again)
assert actual==again and (r/'first-export.wav').read_bytes()==(r/'reopen-export.wav').read_bytes()
# Independent equal-power law over the selected 240-sample transition, then
# direct-form-I EQ. Uses actual owned PCM and project settings, no engine calls.
expected=list(a[:239880])+[a[239880+i]*math.cos(i*math.pi/(2*239))+b[239880+i]*math.sin(i*math.pi/(2*239)) for i in range(240)]+list(b[240120:])
for band in applied['tracks'][0]['processors'][0]['bands']:
 if band['gainDb']==0:continue
 w=2*math.pi*band['frequencyHz']/48000;A=10**(band['gainDb']/40);alpha=math.sin(w)/(2*band['q']);a0=1+alpha/A
 b0=(1+alpha*A)/a0;b1=-2*math.cos(w)/a0;b2=(1-alpha*A)/a0;a1=-2*math.cos(w)/a0;a2=(1-alpha/A)/a0;x1=x2=y1=y2=0.0
 for i,x in enumerate(expected):
  y=b0*x+b1*x1+b2*x2-a1*y1-a2*y2;x2=x1;x1=x;y2=y1;y1=y;expected[i]=y
maximum=max(abs(x-y) for x,y in zip(actual,expected));assert maximum<1e-6,maximum
launches=[load('first-launch.json'),load('reopen-launch.json')];assert all(x['exit_code']==0 for x in launches) and len({x['pid'] for x in launches})==2
assert load('audition-preservation.json')['files_unchanged_before_explicit_save']
q={'passed':True,'source_head':launches[0]['source_head'],'running_executable_sha256':launches[0]['running_executable_sha256'],'normal_exit_codes':[x['exit_code'] for x in launches],'application_pids':[x['pid'] for x in launches],'frames':480000,'channels':1,'sample_rate':48000,'maximum_independent_crossfade_direct_form_I_error':maximum,'sample_peak':max(map(abs,actual)),'over_full_scale_samples':sum(abs(x)>1 for x in actual),'export_sha256':sha(r/'first-export.wav'),'reopened_export_sha256':sha(r/'reopen-export.wav'),'repeated_export_byte_equality':True,'undo_redo_semantic_equality':True,'exact_comp_geometry_processing_and_provenance':True,'retained_lanes_unchanged':True,'raw_sha256':{a['path']:sha(root/a['path']) for a in initial['assets']},'reopened_project_bytes_unchanged':True,'explicit_save_previous_backup_matches_undone':True,'audition_did_not_modify_files':True,'audition_prepared_without_endpoint_or_play':True,'private_xvfb':True,'physical_audio':False,'full_parity':False}
(r/'workflow-qualification.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps(q,indent=2))
