from pathlib import Path
import subprocess,json,hashlib
r=Path('.cache/pipewire-monitor-render');f=json.loads((r/'frozen-inputs.json').read_text());head=f['source'];prefix=['nice','-n','15','ionice','-c','2','-n','7'];objects={}
sources=['src/pipewire_monitor_render.cpp','tests/pipewire_monitor_render_tests.cpp','tests/native_monitor_recording_tests.cpp','src/native_monitor_recording.cpp','ui/wasapi_native_monitor_controller.cpp']
for n,src in enumerate(sources):
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head and not subprocess.check_output(['git','status','--porcelain'],text=True)
 for x in f['selectedInputs']:assert hashlib.sha256(Path(x['path']).read_bytes()).hexdigest()==x['checkoutSha256']
 obj=r/('windows-current-'+str(n)+'.obj');cmd=prefix+['x86_64-w64-mingw32-g++','-std=c++20','-O2','-Wall','-Wextra','-Wpedantic','-Wconversion','-DSC_NATIVE_STARTUP_STATE','-Iinclude','-Isrc','-Iui','-isystem','third_party','-isystem','third_party/libsndfile','-c',src,'-o',str(obj)]
 with (r/('windows-compile-'+str(n)+'.log')).open('w') as out:p=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
 if p.returncode:raise SystemExit('Windows current object '+str(n)+' failed; original retained')
 assert 'warning:' not in (r/('windows-compile-'+str(n)+'.log')).read_text()
 objects[src]={'argv':cmd,'bytes':obj.stat().st_size,'sha256':hashlib.sha256(obj.read_bytes()).hexdigest()}
(r/'windows-qualification.json').write_text(json.dumps({'source':head,'tree':f['tree'],'objects':objects,'sdkAdapterCompiled':True,'nativeWindowsLinkExecuted':False,'nativeWindowsRuntimeExecuted':False,'physicalEndpointsTested':False},indent=2)+'\n');print('Five current Windows objects warning-free, including genuine SDK adapter; no link/runtime claim',flush=True)
