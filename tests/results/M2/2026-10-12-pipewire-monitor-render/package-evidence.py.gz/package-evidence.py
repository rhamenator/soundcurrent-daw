from pathlib import Path
import hashlib,json,gzip,subprocess
r=Path('.cache/pipewire-monitor-render');d=Path('tests/results/M2/2026-10-12-pipewire-monitor-render');d.mkdir(parents=True,exist_ok=True)
f=json.loads((r/'frozen-inputs.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
for x in f['selectedInputs']:assert sha(Path(x['path']).read_bytes())==x['checkoutSha256']
members={}
def put(name,b):
 p=d/(name+'.gz');p.parent.mkdir(parents=True,exist_ok=True);z=gzip.compress(b,mtime=0);p.write_bytes(z)
 members[name+'.gz']={'bytes':len(z),'sha256':sha(z),'originalBytes':len(b),'originalSha256':sha(b)}
for name in ['frozen-inputs.json','source-delta.diff','configure.log','release-build.log','release-tests.log','regression-build.log','final-build.log','final-tests.log','final-return-build.log','final-return-tests.log','final-sdk-build.log','sanitizer-configure.log','sanitizer-build.log','sanitizer-tests.log','owned-runtime.log','owned-runtime.json','owned-wrapper.log','owned-daemon.log','final-owned-wrapper.log','sanitizer-owned-runtime.log','sanitizer-owned-runtime.json','sanitizer-owned-wrapper.log','sanitizer-owned-daemon.log','private-pipewire.conf','run-owned.py','run-owned-sanitizer.py','run-capture-regression.py','windows-qualification.json','windows-qualification.log','freeze-inputs.py','qualify-windows.py','retain159.py']:
 put(name,(r/name).read_bytes())
for p in r.glob('windows-compile-*.log'):put(p.name,p.read_bytes())
for folder in ['initial-render-test-format-warning','capture-regression-cycle-gap']:
 for p in sorted((r/folder).iterdir()):
  if p.is_file():put(folder+'/'+p.name,p.read_bytes())
for p in sorted((r/'pr159-review').iterdir()):
 if p.is_file() and p.suffix in ['.json','.log']:put('preceding-pr159/'+p.name,p.read_bytes())
put('preceding-pr159/tested-merge.json',Path('.cache/pipewire-monitor-capture/pr159-tested-merge.json').read_bytes())
hashes={}
for profile in ['release','sanitizer']:
 p=r/profile;put(profile+'-CMakeCache.txt',(p/'CMakeCache.txt').read_bytes());put(profile+'-LastTest.log',(p/'Testing/Temporary/LastTest.log').read_bytes());put(profile+'-generated-commands.log',subprocess.check_output(['ninja','-C',str(p),'-t','commands']))
 files=list(p.glob('*.a'))+[q for q in p.glob('sc-*-tests') if q.is_file()]+list(p.glob('sc-pipewire-monitor-*-fixture'))
 hashes[profile]={str(q.relative_to(p)):{'bytes':q.stat().st_size,'sha256':sha(q.read_bytes())} for q in files}
put('build-output-hashes.json',json.dumps(hashes,indent=2).encode())
commands={'releaseRegex':'^(pipewire-monitor-planar-render|pipewire-monitor-planar-capture|native-buffer-acquisition|monitor-output-bank|original-monitor-clock-handoffs|native-monitor-startup)$','finalReturnRegex':'^pipewire-monitor-planar-render$','sanitizerRegex':'^(pipewire-monitor-planar-render|pipewire-monitor-planar-capture|native-buffer-acquisition)$','ctestArgs':['--output-on-failure','--parallel','1'],'sanitizerEnvironment':{'ASAN_OPTIONS':'detect_leaks=0:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'},'priority':['nice','-n','15','ionice','-c','2','-n','7'],'privateDaemonWrappers':['run-owned.py','run-owned-sanitizer.py','run-capture-regression.py'],'windows':'Exact argv/hash receipts in windows-qualification.json'}
put('qualification-commands.json',json.dumps(commands,indent=2).encode());put('package-evidence.py',Path(__file__).read_bytes())
summary={'implementation':f['source'],'tree':f['tree'],'sourceInputs':len(f['selectedInputs']),'release':{'passed':6,'tests':6,'seconds':19.62,'finalRenderSuitePassed':True,'finalRenderChecks':30443},'sanitizers':{'passed':3,'tests':3,'seconds':.08,'leakDetection':False},'ownedRender':{'releasePassed':True,'sanitizerPassed':True,'monitorFramesEach':96123,'sinkBitChecksEach':288369,'finalPaddingFrames':133,'exactNativeQueueResult':0,'auditedCallbackAllocateFreeLock':0,'physicalDevices':False},'captureRegression':{'passed':False,'acceptedRawAndMonitorFrames':49408,'failure':'Cycle194->196, native position skip512 for256frame quanta; correct immutable refusal; precise scheduling/overhead cause unresolved','unchangedRetryPerformed':False},'windows':json.loads((r/'windows-qualification.json').read_text()),'precedingCi':{'pr':159,'run':38298826349,'head':'6e2057650abfd5051b543e53c97914fe14799ba0','linux':'145/433.28s success','desktop':'20/83.21s success','cross':'success','native':'Executed72 tests;71passed; finite native startup failed original5s wait at44100 mono->stereo; no output published','originalOwnerDiagnostics':'All three completed20takes; earlier158 failure still unresolved'},'currentDiagnosticChange':'Test-only independent SDK stage/packet/coordinate observations, sampled before cancellation. No deadline/pacing/buffer/gate changes. Not a root-cause fix.','payloadPolicy':'Text/log/configuration/metadata and local binary hash receipts only; no executable/library/object/audio/ZIP','members':members}
(d/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for name,row in members.items():
 b=(d/name).read_bytes();assert sha(b)==row['sha256'];raw=gzip.decompress(b);assert sha(raw)==row['originalSha256'] and len(raw)==row['originalBytes']
print('Verified',len(members),'bound text/log/metadata members; all801 qualified inputs unchanged')
