from pathlib import Path
import hashlib,json,gzip,subprocess,shutil
r=Path('.cache/native-take-admission');dest=Path('tests/results/M2/2026-10-12-native-take-admission');dest.mkdir(parents=True,exist_ok=True)
f=json.loads((r/'frozen-inputs.json').read_text())
for x in f['selectedInputs']:assert hashlib.sha256(Path(x['path']).read_bytes()).hexdigest()==x['checkoutSha256']
sha=lambda b:hashlib.sha256(b).hexdigest()
members={}
def put(name,b):
 out=gzip.compress(b,mtime=0);(dest/(name+'.gz')).write_bytes(out)
 members[name+'.gz']={'bytes':len(out),'sha256':sha(out),'originalBytes':len(b),'originalSha256':sha(b)}
for name in ['frozen-inputs.json','source-delta.diff','configure.log','development-build.log','development-tests.log','full-release-build.log','full-release-tests.log','sanitizer-configure.log','sanitizer-build.log','sanitizer-tests.log','sanitizer-panel-offscreen-tests.log','localization-check.log','localization-refusals.log','windows-qualification.json','windows-qualification.log','qualify-windows.py','freeze-inputs.py']:
 put(name,(r/name).read_bytes())
for p in sorted(r.glob('windows-compile-*.log')):put(p.name,p.read_bytes())
builds={}
for profile in ['development','sanitizer']:
 p=r/profile;put(profile+'-CMakeCache.txt',(p/'CMakeCache.txt').read_bytes());put(profile+'-LastTest.log',(p/'Testing/Temporary/LastTest.log').read_bytes())
 put(profile+'-generated-commands.log',subprocess.check_output(['ninja','-C',str(p),'-t','commands']))
 # Hash the relevant executable/dependency closure; do not upload binary payloads.
 targets=['sc-native-original-recording-tests','sc-native-panel-tests','sc-session-tests','sc-stretch-state-tests','sc-clip-processing-tests']
 binaryPaths=list(p.glob('*.a'))+[p/t for t in targets]
 if (p/'soundcurrent-daw').exists():binaryPaths.append(p/'soundcurrent-daw')
 entries={str(q.relative_to(p)):{'bytes':q.stat().st_size,'sha256':sha(q.read_bytes())} for q in binaryPaths}
 builds[profile]=entries
put('build-output-hashes.json',json.dumps(builds,indent=2).encode())
shutil.copytree(r/'runtime-packet-staging',dest/'preceding-pr157',dirs_exist_ok=True)
summary={'implementation':f['source'],'tree':f['tree'],'sourceInputs':len(f['selectedInputs']),'release':{'tests':144,'passed':144,'seconds':175.35},'sanitizers':{'initialTests':5,'passed':4,'guiFailedBeforeWorkflow':'GTK theme nothrow-new vs test-only delete/free; report retained','offscreenGuiPassed':True,'offscreenSeconds':11.42,'allocDeallocMismatchEnabled':True,'leakDetection':False},'localization':{'catalogs':34,'keys':984,'drafts':3168,'nativeReview':0,'uiQualified':0},'windows':json.loads((r/'windows-qualification.json').read_text()),'precedingCi':'PR157 has 3 successful jobs / Linux canceled at job envelope; predates this implementation','payloadPolicy':'No executable/library/object/audio/ZIP payloads','members':members}
(dest/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for name,row in members.items():
 b=(dest/name).read_bytes();assert sha(b)==row['sha256'];raw=gzip.decompress(b);assert len(raw)==row['originalBytes'] and sha(raw)==row['originalSha256']
print('Verified',len(members),'current text/log packet members; binaries hashed locally only')
