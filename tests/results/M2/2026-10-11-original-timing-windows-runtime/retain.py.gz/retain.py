from pathlib import Path
import json,hashlib,gzip,subprocess,re
p=Path('.cache/parent-interruption-timing/runtime-ci-review');out=Path('tests/results/M2/2026-10-11-original-timing-windows-runtime');b=json.loads(Path('.cache/parent-interruption-timing/pr150-tested-merge.json').read_text());run=json.loads((p/'run.json').read_text());jobs=json.loads((p/'jobs.json').read_text());assert run['id']==38189943303 and run['head_sha']==b['head'] and run['status']=='completed' and run['conclusion']=='success'
paths=[p/'retain.py',p/'run.json',p/'jobs.json',p/'artifacts.json',p/'selected-members.json',p/'native-selected-members.json',Path('.cache/parent-interruption-timing/pr150-tested-merge.json')];bindings={}
assert len(jobs['jobs'])==4
for j in jobs['jobs']:
 assert j['status']=='completed' and j['conclusion']=='success' and j['head_sha']==b['head'] and j['run_id']==run['id'];f=p/('job-'+str(j['id'])+'.log');raw=f.read_bytes();s=raw.decode('utf-8-sig');assert b['mergeRef'] in s and b['head'] in s and b['base'] in s;paths.append(f);bindings[str(j['id'])]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'conclusion':j['conclusion']}
for n,x in b['files'].items():assert hashlib.sha256(subprocess.check_output(['git','show',b['mergeRef']+':'+n])).hexdigest()==x['sha256']
for meta,name in [('selected-members.json','desktop-artifact.zip'),('native-selected-members.json','native-artifact.zip')]:
 m=json.loads((p/meta).read_text());assert hashlib.sha256((p/name).read_bytes()).hexdigest()==m['zipSha256']
 for x in m['selected']:
  f=p/x['file'];assert hashlib.sha256(f.read_bytes()).hexdigest()==x['sha256'];paths.append(f)
log=(p/'native--Testing_Temporary_LastTest.log').read_text();assert log.count('manual_case begin=')==log.count('manual_case end=')==22 and log.count('native_desktop_controller ')==3
for n in range(1,4):
 assert 'original_concurrent_owner_diagnostic completed20takes; original5sdeadline; native_audio=false' in (p/('native--manual-owner-'+str(n)+'-stdout.log')).read_text()
 s=(p/('native--manual-owner-'+str(n)+'-stderr.log')).read_text();assert s.count('manual_case begin=')==s.count('manual_case end=')==1 and 'manual_check_failure' not in s
assert '100% tests passed out of 71' in (p/'job-114620324749.log').read_text()
summaryTiming={}
for x in json.loads((p/'selected-members.json').read_text())['selected']:
 if x['member'].endswith('-observation-timing.json'):
  t=json.loads((p/x['file']).read_text());assert t['format']=='sc-parent-observation-timing' and len(t['events'])<=128;summaryTiming[x['member']]={'eventCount':len(t['events']),'spans':t['spans']}
assert len(summaryTiming)==4
out.mkdir(exist_ok=False);members={}
for f in paths:
 raw=f.read_bytes();data=gzip.compress(raw,mtime=0);n=f.name+'.gz';assert n not in members;(out/n).write_bytes(data);members[n]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'originalBytes':len(raw),'originalSha256':hashlib.sha256(raw).hexdigest(),'lossless':True}
summary={'pr':150,'run':run['id'],'head':b['head'],'base':b['base'],'testedMerge':b['mergeRef'],'tree':b['tree'],'changedBlobBindings':len(b['files']),'qualifiedInputCount':780,'terminalJobBindings':bindings,'native71SuitesPassed':True,'nativeOriginal22ManualCasesCompleted':True,'nativeThreeOriginalStandaloneCompletions':True,'desktop19SuitesPassed':True,'originalFourInterruptionCasesPassed':True,'originalTimingSpans':summaryTiming,'linux143SuitesPassed':True,'priorWatchdogTimeoutCauseResolved':False,'priorManualTimeoutOrFlushStallCauseResolved':False,'newCommandAdmissionExecutedByThisRun':False,'physicalEndpointsTested':False,'binariesOrMediaIncluded':False}
raw=(json.dumps(summary,indent=2)+'\n').encode();(out/'summary.json').write_bytes(raw);members['summary.json']={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()};(out/'manifest.json').write_text(json.dumps({'members':members,'scope':'PR150 original all-four-green logs and tested source bindings; original native/manual completion and Windows interruption timings; original artifact logs/JSON only; no ZIP/binaries/audio'},indent=2)+'\n');print('Retained150 actual original timings',len(members),'bound files',sum(f.stat().st_size for f in out.iterdir()),'bytes')
