// SPDX-License-Identifier: GPL-3.0-only
#include <soundcurrent/pipewire_monitor_recording.hpp>
#include "media_io.hpp"
#include "rt_audit.hpp"
#include <sndfile.h>
#include <array>
#include <bit>
#include <cmath>
#include <iostream>
#include <thread>
#include <fstream>
#include <cstdlib>
using namespace soundcurrent::daw;
namespace {
unsigned checks=0;
void check(bool b,const char *why){++checks;if(!b)throw std::runtime_error(why);}
template<class F>auto rt(F f){rt_audit::Guard guard;return f();}
float sample(std::uint64_t n){return float(3*std::sin(double(n%48)*2*3.141592653589793/48));}
struct Temp {std::filesystem::path root=std::filesystem::temp_directory_path()/std::filesystem::path(u8"sc-pw-owner-é-")/Id::generate().str();
    Temp(){std::filesystem::create_directories(root);ProjectStore(root).save(makeOneTrackSession("Owned native","Raw"));}
    ~Temp(){if(std::uncaught_exceptions()){std::cerr<<"Retained owner fixture "<<root.generic_string()<<'\n';
        if(const auto *target=std::getenv("SC_NATIVE_OWNER_FAILURE_EVIDENCE"))try{const std::filesystem::path folder(target);std::filesystem::create_directories(folder);const auto name="pw-owner-"+Id::generate().str()+"-failure.log";
            std::ofstream f(folder/name,std::ios::binary);const auto path=root.generic_u8string();f<<"preserved_failure_project=";f.write(reinterpret_cast<const char *>(path.data()),std::streamsize(path.size()));f<<'\n';}catch(...){}
        return;}std::error_code e;std::filesystem::remove_all(root,e);}
};
struct Shared {std::atomic<unsigned> joins{0},retired{0};std::atomic<bool> auditBad{false};std::vector<float> output;};
class Simulated final : public PipeWireMonitorStreams {
    PreparedPipeWireMonitorRoute &route_;std::shared_ptr<Shared> shared_;
    PreparedPipeWireMonitorCapture capture_;PreparedPipeWireMonitorRender render_;
    std::thread captureThread_,renderThread_;std::atomic<bool> cs_{false},rs_{false};
    const std::chrono::steady_clock::time_point epoch_=std::chrono::steady_clock::now();
    const unsigned fail_;bool cj_=false,rj_=false;
    DeviceBlockClock clock(unsigned n) const {return {100000+std::uint64_t(n)*480,480,4000000000ULL+std::uint64_t(n)*10000000,19,n+4,1,48000,-37,false,false};}
    void audit(){const auto a=rt_audit::counts;if(a.cppAllocate || a.cppFree || a.cAllocate || a.cFree || a.blockingLock)shared_->auditBad=true;}
    void captureLoop(){rt_audit::reset();std::array<float,480> samples;std::array<const float *,1> planes{samples.data()};
        const std::array<PipeWirePortLeaseResult,1> returned{{{PipeWireBufferStatus::Ready,true,0}}};
        for(unsigned n=0;!cs_.load() && n<1000;++n){std::this_thread::sleep_until(epoch_+std::chrono::milliseconds(n*10));if(cs_.load())break;
            auto c=clock(n);for(unsigned k=0;k<480;++k)samples[k]=sample(std::uint64_t(n)*480+k);
            if(fail_==3 && n==25)c.rateDenominator=44100;
            const auto code=rt([&]{return capture_.process(c,planes,480);});rt([&]{capture_.completeCycle({c,true,returned,{}});});
            if(code!=PipeWireCaptureCode::Accepted)break;
        }audit();}
    void renderLoop(){rt_audit::reset();std::array<float,480> left{},right{};std::array<float *,2> planes{left.data(),right.data()};
        const std::array<PipeWirePortLeaseResult,2> returned{{{PipeWireBufferStatus::Ready,true,0},{PipeWireBufferStatus::Ready,true,0}}};
        for(unsigned n=0;!rs_.load() && n<1000;++n){std::this_thread::sleep_until(epoch_+std::chrono::milliseconds(n*10));if(rs_.load())break;
            const auto c=clock(n);const auto before=route_.output().deliveredFrames();
            const auto code=rt([&]{return render_.process(c,planes,480,now());});rt([&]{render_.completeCycle({c,true,{},returned});});
            const auto frames=route_.output().deliveredFrames()-before;
            for(unsigned k=0;k<frames;++k){shared_->output.push_back(left[k]);shared_->output.push_back(right[k]);}
            if(code==PipeWireRenderCode::Fault || code==PipeWireRenderCode::Stopped || render_.contentComplete())break;
        }audit();}
  public:
    Simulated(PreparedPipeWireMonitorRoute &r,std::shared_ptr<Shared> s,unsigned fail):route_(r),shared_(std::move(s)),
        capture_(r.capture(),r.clocks(),r.captureOptions()),render_(r.output(),r.clocks(),r.renderOptions()),fail_(fail){shared_->output.reserve(10000);}
    ~Simulated(){joinCapture();joinRender();++shared_->retired;}
    std::vector<AudioPort> ports() const override{return {};}
    void connect(const std::vector<AudioPort> &,const std::vector<AudioPort> &) override{}
    void activateCapture() override{if(fail_==2)throw ProjectError(ErrorCode::Io,"Injected capture activation");captureThread_=std::thread([this]{captureLoop();});}
    void activateRender() override{if(fail_==1)throw ProjectError(ErrorCode::Io,"Injected render activation");renderThread_=std::thread([this]{renderLoop();});}
    std::optional<Qpc100ns> now() noexcept override{const auto ns=std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-epoch_).count();return Qpc100ns{40000000+std::uint64_t(ns)/100};}
    void requestCaptureStop() noexcept override{cs_=true;capture_.requestStop();}
    void requestRenderStop() noexcept override{rs_=true;render_.requestStop();}
    void joinCapture() noexcept override{if(cj_)return;requestCaptureStop();if(captureThread_.joinable())captureThread_.join();capture_.finishAfterJoin();cj_=true;++shared_->joins;}
    void joinRender() noexcept override{if(rj_)return;requestRenderStop();if(renderThread_.joinable())renderThread_.join();render_.finishAfterJoin();rj_=true;++shared_->joins;}
    bool renderComplete() const noexcept override{return render_.contentComplete();}
    bool unavailable() const noexcept override{return bool(capture_.firstUnavailable() || render_.firstUnavailable());}
    std::optional<PipeWireCaptureFault> captureFault() const noexcept override{return capture_.firstFault();}
    std::optional<PipeWireRenderFault> renderFault() const noexcept override{return render_.firstFault();}
    std::optional<PipeWireCaptureEnd> captureEndAfterJoin() const noexcept override{return capture_.endAfterJoin();}
    std::optional<PipeWireRenderEnd> renderEndAfterJoin() const noexcept override{return render_.endAfterJoin();}
};
PipeWireMonitorRecordingOptions options(const Temp &t){const auto p=ProjectStore(t.root).load();PipeWireMonitorRecordingOptions o;
    o.declared.raw.project=p.id;o.declared.raw.track=p.tracks.front().id;o.declared.raw.identity={11,31,7};o.declared.raw.layout={LayoutKind::Mono,1};o.declared.raw.maximumPacketFrames=480;
    o.declared.renderChannels=2;o.declared.maximumRenderFrames=480;o.route.inputCapacityFrames=32768;o.route.monitorSlots=8;o.route.rawSlots=8;
    o.route.channelMap=MonitorChannelMap{1,2,{{0,0,1},{0,1,-.5}}};MonitorEqSpec eq;eq.track=o.declared.raw.track;eq.settings.bands.push_back({Id::generate(),1000,-6,1});o.route.equalizer=eq;return o;
}
PipeWireMonitorStreamFactory factory(std::shared_ptr<Shared> s,unsigned fail=0){return [s,fail](auto &route){return std::make_unique<Simulated>(route,s,fail);};}
void original(const PipeWireRecordingPrefix &p){media_io::File file(p.raw.source,false);SF_INFO info{};
    std::unique_ptr<SNDFILE,decltype(&sf_close)> audio(sf_open_fd(file.descriptor(),SFM_READ,&info,SF_FALSE),sf_close);check(bool(audio),"Raw media open failed");
    std::array<float,480> block;std::uint64_t at=0;
    while(at<p.raw.committedFrames){const auto count=std::min<std::uint64_t>(480,p.raw.committedFrames-at);check(sf_readf_float(audio.get(),block.data(),sf_count_t(count))==sf_count_t(count),"Raw media short");
        for(unsigned n=0;n<count;++n)check(std::bit_cast<unsigned>(block[n])==std::bit_cast<unsigned>(sample(at+n)),"Raw recording changed by EQ/map/native owners");
        at+=count;}
}
void workflow(){Temp t;auto o=options(t);auto shared=std::make_shared<Shared>();ResourceLedger ledger(64*1024*1024);o.route.resources=ledger;
    {PipeWireMonitorRecording owner(t.root,factory(shared),o);check(ledger.usage().reservedBytes>0,"Aggregate route not charged");owner.activate();
        check(owner.requestStopAt({2400})==MonitorControlCode::Accepted,"Owner horizon admission failed");
        const auto until=std::chrono::steady_clock::now()+std::chrono::seconds(8);bool ready=false;
        while(!(ready=owner.service()) && std::chrono::steady_clock::now()<until)std::this_thread::sleep_for(std::chrono::milliseconds(1));
        const auto observed=owner.progress();
        if(!ready || observed.rawFrames<48000)std::cerr<<"owner_observation ready="<<ready<<" raw="<<observed.rawFrames<<" monitor="<<observed.monitorInputFrames<<" copied="<<observed.copiedSourceFrames<<" published="<<observed.publishedMonitorFrames<<" delivered="<<observed.deliveredMonitorFrames<<" processing_done="<<observed.processingDone<<" disk_done="<<observed.diskDone<<'\n';
        const auto result=ready?owner.wait():owner.cancelAndWait();
        if(result.processingFault)std::cerr<<"processing_fault="<<int(result.processingFault->cause)<<'\n';
        if(result.capture && result.capture->fault)std::cerr<<"capture_fault="<<int(result.capture->fault->cause)<<'\n';
        if(result.fanoutFault)std::cerr<<"fanout_fault side="<<int(result.fanoutFault->side)<<" cause="<<int(result.fanoutFault->cause)<<" raw_accepted="<<result.fanoutFault->rawPacketAccepted<<" monitor_accepted="<<result.fanoutFault->monitorPacketAccepted<<'\n';
        if(result.render && result.render->fault)std::cerr<<"render_fault="<<int(result.render->fault->cause)<<'\n';
        if(result.terminalFailure)try{std::rethrow_exception(result.terminalFailure);}catch(const std::exception &e){std::cerr<<"terminal_failure="<<e.what()<<'\n';}
        check(ready && result.disposition==PipeWireRecordingDisposition::Recorded && result.prefix && result.prefix->finalized,"Owned recording did not complete stored prefix");
        check(result.terminalStored && !result.terminalFailure,"Joined outcome not durably stored");
        const auto stored=inspectPipeWireRecordingState(owner.jobDirectory(),o.declared);
        check(stored.terminal && stored.outcome && stored.outcome->disposition==PipeWireStoredDisposition::Recorded &&
              encodeMonitorEq(*stored.intent.processing.equalizer,48000,2)==encodeMonitorEq(*o.route.equalizer,48000,2) &&
              stored.outcome->startup==result.startup && stored.outcome->capture->acceptedRawFrames==result.capture->acceptedRawFrames,
              "Reopened route/EQ/startup/native outcome changed");
        check(result.prefix->monitorQueuedFrames==2400 && shared->output.size()==4800 && result.capture->callbacksJoined && result.render->callbacksJoined,"Native finite extents/joins wrong");
        original(*result.prefix);double energy=0;for(unsigned n=960;n<2400;++n){const auto l=shared->output[n*2],r=shared->output[n*2+1];energy+=double(l)*l;check(std::abs(r+.5*l)<.001,"Native monitor matrix mismatch");}
        check(std::abs(std::sqrt(energy/1440)-3*std::pow(10.,-6./20.)/std::sqrt(2.))<.01,"Native monitor EQ response mismatch");
        MonitorControlReceipt receipt;check(owner.receiveStopReceipt(receipt)==MonitorControlCode::Ready && receipt.result==MonitorControlResult::Planned,"Applied Stop receipt missing");
        check(shared->joins==2 && !shared->auditBad,"Callback owner join/audit failed");}
    check(shared->retired==1 && ledger.usage().reservedBytes==0,"Owners/aggregate credit not retired");
}
void failures(){
    for(unsigned fail=0;fail<4;++fail){Temp t;auto o=options(t);auto s=std::make_shared<Shared>();
        {PipeWireMonitorRecording owner(t.root,factory(s,fail),o);
            if(fail==1 || fail==2){bool caught=false;try{owner.activate();}catch(const ProjectError &){caught=true;}check(caught,"Injected activation did not fail");
                const auto r=owner.cancelAndWait();check(r.disposition==PipeWireRecordingDisposition::Failed && r.activationFailure && r.prefix,"Activation rollback lost checkpoint");
                check(r.terminalStored && inspectPipeWireRecordingState(owner.jobDirectory()).outcome->activationFailure,"Activation failure was not stored");}
            else if(fail==0){const auto r=owner.cancelAndWait();check(r.disposition==PipeWireRecordingDisposition::Cancelled && r.prefix && !r.prefix->raw.committedFrames,"Prepared cancellation wrong");
                check(r.terminalStored && inspectPipeWireRecordingState(owner.jobDirectory()).outcome->disposition==PipeWireStoredDisposition::Cancelled,"Empty cancellation not stored");}
            else {owner.activate();const auto until=std::chrono::steady_clock::now()+std::chrono::seconds(3);
                while(!owner.service() && std::chrono::steady_clock::now()<until)std::this_thread::sleep_for(std::chrono::milliseconds(1));
                const auto r=owner.cancelAndWait();check(r.disposition==PipeWireRecordingDisposition::Failed && r.capture && r.capture->fault && r.capture->fault->cause==PipeWireCaptureCause::RateChanged && r.prefix,"Native rate fault lost raw prefix/original result");
                check(r.terminalStored && inspectPipeWireRecordingState(owner.jobDirectory()).outcome->capture->fault->cause==PipeWireCaptureCause::RateChanged,"Native rate fault not stored");}}
        check(s->joins==2 && s->retired==1 && !s->auditBad,"Failure rollback abandoned native callbacks");
    }
    Temp t;auto o=options(t);auto s=std::make_shared<Shared>();o.journal.boundary=[](auto b){if(b==PipeWireJournalBoundary::RawAppended)throw ProjectError(ErrorCode::Io,"Injected disk failure");};
    PipeWireMonitorRecording owner(t.root,factory(s),o);owner.activate();const auto until=std::chrono::steady_clock::now()+std::chrono::seconds(3);
    while(!owner.service() && std::chrono::steady_clock::now()<until)std::this_thread::sleep_for(std::chrono::milliseconds(1));
    const auto r=owner.cancelAndWait();check(r.disposition==PipeWireRecordingDisposition::Failed && r.diskFailure && r.prefix && !r.prefix->raw.committedFrames,"Interrupted paired append invented committed audio");
    check(r.terminalStored && inspectPipeWireRecordingState(owner.jobDirectory()).outcome->diskFailure,"Disk failure not stored with original common prefix");
}
}
int main(){try{workflow();failures();std::cout<<checks<<" owned PipeWire recording checks passed;actual native-role/processing/disk threads, finite EQ/map/raw checkpoint, cancel/fault/rollback;SDK=false, physical=false, durable terminal state verified\n";return 0;
}catch(const std::exception &e){std::cerr<<"Check "<<checks<<": "<<e.what()<<'\n';return 1;}}
