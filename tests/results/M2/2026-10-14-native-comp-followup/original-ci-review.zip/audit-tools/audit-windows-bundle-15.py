from pathlib import Path,PurePosixPath
import argparse,hashlib,json,subprocess,zipfile,tarfile,io
p=argparse.ArgumentParser();p.add_argument('archive',type=Path);p.add_argument('head');p.add_argument('output',type=Path);a=p.parse_args();sha=lambda b:hashlib.sha256(b).hexdigest()
z=zipfile.ZipFile(a.archive);names=z.namelist();assert len(names)==len(set(names))
for n in names:
 q=PurePosixPath(n);assert not q.is_absolute() and '..' not in q.parts and '\\' not in n
load=lambda n:json.loads(z.read(n));c=load('collection.json');inputs=load('build-inputs.json');assert c['sourceCommit']==inputs['sourceCommit']==a.head
assert c['sourceTree']==inputs['sourceTree']==subprocess.check_output(['git','rev-parse',a.head+'^{tree}'],text=True).strip()
for n,h in c['artifacts'].items():
 b=z.read(n);assert len(b)==h['bytes'] and sha(b)==h['sha256'],n
pins=json.loads(Path('research/windows-preview-dependencies.json').read_text())['files'];payload=c['deploymentFiles'];assert len(payload)==15
for n,h in payload.items():
 b=z.read('deploy/'+n);assert len(b)==h['bytes'] and sha(b)==h['sha256']
 if n in pins:assert len(b)==pins[n]['bytes'] and sha(b)==pins[n]['sha256']
for n in ['media-build-review/sndfile-build-sndfile.dll','media-build-review/sndfile-repeat-sndfile.dll']:
 b=z.read(n);assert len(b)==pins['sndfile.dll']['bytes'] and sha(b)==pins['sndfile.dll']['sha256']
expected=set(subprocess.check_output(['git','ls-tree','-r','--name-only',a.head],text=True).splitlines());expected={n for n in expected if not n.startswith('tests/results/')}
rows=inputs['files'];assert {r['name'] for r in rows}==expected
tar=tarfile.open(fileobj=io.BytesIO(z.read('application-build-source.tar.gz')),mode='r:gz');members=tar.getmembers();assert len(members)==len(rows) and all(m.isfile() for m in members)
assert {m.name for m in members}=={'soundcurrent-daw/'+r['name'] for r in rows}
for row in rows:assert sha(tar.extractfile('soundcurrent-daw/'+row['name']).read())==row['sha256']
for row in rows:
 b=subprocess.check_output(['git','-c','core.autocrlf=true','cat-file','--filters',a.head+':'+row['name']],timeout=5)
 assert sha(b)==row['sha256'],row['name']
assert not c['productDependencyMismatches'] and c['productDependenciesQualified']
q={'source_head':a.head,'source_tree':c['sourceTree'],'archive_bytes':a.archive.stat().st_size,'archive_sha256':sha(a.archive.read_bytes()),'archive_entries':len(names),'deployment_files':len(payload),'source_files_verified_against_git_windows_checkout_filters':len(rows),'all_corresponding_source_archive_bytes_match_native_snapshot':True,'checkout_filter':'actual bounded git -c core.autocrlf=true cat-file --filters; no ad hoc byte normalization','all_collection_artifact_hashes_verified':True,'dependency_mismatches':[],'two_media_builds_match_reviewed_pin':True,'sndfile_sha256':pins['sndfile.dll']['sha256'],'main_window_qualified':c['mainWindowQualified'],'native_audio_qualified':c['nativeAudioQualified'],'installer_prepared':c['installerPrepared'],'audit_platform':'Linux independent byte/source audit; not native execution'}
a.output.write_text(json.dumps(q,indent=2)+'\n');print(json.dumps(q,indent=2))
