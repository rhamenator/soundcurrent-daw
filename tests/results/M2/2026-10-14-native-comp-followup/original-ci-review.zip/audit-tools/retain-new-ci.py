from pathlib import Path
import argparse,subprocess,json,hashlib,zipfile
p=argparse.ArgumentParser();p.add_argument('run',type=int);p.add_argument('head');p.add_argument('root',type=Path);a=p.parse_args()
prefix='repos/rhamenator/soundcurrent-daw/actions/'
def request(endpoint):return subprocess.check_output(['gh','api',prefix+endpoint])
runBytes=request(f'runs/{a.run}');run=json.loads(runBytes)
assert run['head_sha']==a.head and run['status']=='completed','Retain terminal original run only'
a.root.mkdir(parents=True,exist_ok=True)
def save(name,data):
    path=a.root/name
    if path.exists():assert path.read_bytes()==data,name
    else:path.write_bytes(data)
def fetch(endpoint,name):
    path=a.root/name
    if not path.exists():
        temporary=path.with_suffix(path.suffix+'.partial')
        with temporary.open('wb') as f:subprocess.run(['gh','api',prefix+endpoint],stdout=f,check=True)
        temporary.replace(path)
    return path
if not (a.root/'run-api.json').exists():save('run-api.json',runBytes)
jobs=json.loads(fetch(f'runs/{a.run}/jobs?per_page=100','jobs-api.json').read_bytes())
assert jobs['total_count']==len(jobs['jobs'])==6
for j in jobs['jobs']:
    assert j['status']=='completed'
    fetch(f"jobs/{j['id']}",f"job-{j['id']}-api.json")
    fetch(f"jobs/{j['id']}/logs",f"job-{j['id']}.log")
artifacts=json.loads(fetch(f'runs/{a.run}/artifacts?per_page=100','artifacts-api.json').read_bytes())
assert artifacts['total_count']==len(artifacts['artifacts'])
rows=[]
for item in artifacts['artifacts']:
    assert not item['expired']
    fetch(f"artifacts/{item['id']}",f"artifact-{item['id']}-api.json")
    path=fetch(f"artifacts/{item['id']}/zip",f"artifact-{item['id']}.zip")
    digest=hashlib.file_digest(path.open('rb'),'sha256').hexdigest()
    assert path.stat().st_size==item['size_in_bytes'] and 'sha256:'+digest==item['digest']
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        pngs=[dict(path=n,sha256=hashlib.sha256(z.read(n)).hexdigest()) for n in z.namelist() if n.endswith('.png')]
        rows.append(dict(id=item['id'],name=item['name'],bytes=path.stat().st_size,sha256=digest,entries=len(z.namelist()),pngs=pngs))
receipt=dict(run=a.run,head=a.head,conclusion=run['conclusion'],jobs=[dict(id=j['id'],name=j['name'],conclusion=j['conclusion']) for j in jobs['jobs']],artifacts=rows,allAvailableOriginalArchivesRetained=True,allFullLogsRetained=True)
save('retention.json',(json.dumps(receipt,indent=2)+'\n').encode())
print(json.dumps(dict(run=a.run,conclusion=run['conclusion'],jobs=len(jobs['jobs']),artifacts=len(rows))))
