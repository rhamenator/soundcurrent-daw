from pathlib import Path,PurePosixPath
import json,zipfile,hashlib,re
root=Path('.cache/comp-repeat-ui/pr194-history-review')
sha=lambda b:hashlib.sha256(b).hexdigest()
run=json.loads((root/'run-api.json').read_text());assert run['status']=='completed' and run['head_sha']=='42813e436767409d6e976e35f5cfbe03392b025e'
jobs=json.loads((root/'jobs-api.json').read_text())['jobs'];assert len(jobs)==6
logs=[]
for j in jobs:
 raw=(root/f"job-{j['id']}.log").read_bytes();lines=raw.decode('utf-8',errors='replace').splitlines()
 logs.append(dict(id=j['id'],name=j['name'],conclusion=j['conclusion'],bytes=len(raw),sha256=sha(raw),testSummary=[x for x in lines if 'tests passed' in x],testFailures=[x for x in lines if '***Failed' in x or '***Timeout' in x or 'operation was canceled' in x]))
artifacts=json.loads((root/'artifacts-api.json').read_text())['artifacts'];rows=[];reports=[];plans=[]
for item in artifacts:
 path=root/f"artifact-{item['id']}.zip";raw=path.read_bytes();assert len(raw)==item['size_in_bytes'] and 'sha256:'+sha(raw)==item['digest']
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None;names=z.namelist();assert len(set(names))==len(names);pngs=[]
  for n in names:
   p=PurePosixPath(n);assert not p.is_absolute() and '..' not in p.parts and '\\' not in n
   if n.lower().endswith('.png'):
    b=z.read(n);pngs.append(dict(path=n,sha256=sha(b),bytes=len(b)));out=root/'pngs'/str(item['id'])/n;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b)
   if re.search(r'comp-(regeneration-source|regeneration-history|paired-history|repeat|span-v2|transition-ui|assembly-ui|assembly-controller)-evidence/run-[^/]+/report.json$',n):reports.append(dict(artifact=item['name'],path=n,report=json.loads(z.read(n))))
  if item['name'].startswith('linux-synthetic-test-log-'):
   planName=next(n for n in names if n.endswith('ci-shard-plan.json'));inventoryName=next(n for n in names if n.endswith('ci-test-inventory.json'))
   plan=json.loads(z.read(planName));inventory=json.loads(z.read(inventoryName));expected=sorted(t['name'] for t in inventory['tests'])
   assigned=[n for shard in plan['shards'] for n in shard['names']];assert sorted(assigned)==expected and len(assigned)==len(set(assigned))
   assert plan['inventoryCount']==len(expected) and plan['selectedCount']==len(plan['shards'][plan['shard']]['names'])
   plans.append(dict(artifact=item['name'],plan=plan,inventory=expected))
  rows.append(dict(id=item['id'],name=item['name'],bytes=len(raw),sha256=sha(raw),entries=len(names),pngs=pngs))
assert len(plans)==2 and {p['plan']['shard'] for p in plans}=={0,1}
assert plans[0]['inventory']==plans[1]['inventory'] and plans[0]['plan']['shards']==plans[1]['plan']['shards']
linuxComplete=all(p['plan'].get('exitCode')==0 for p in plans) and all(j['conclusion']=='success' for j in jobs if j['name'].startswith('Linux '))
out=dict(run=run['id'],head=run['head_sha'],conclusion=run['conclusion'],jobs=logs,artifacts=rows,allAvailableOriginalArtifactsRetained=True,allSixFullJobLogsRetained=True,pngCount=sum(len(a['pngs']) for a in rows),linuxInventoryCount=len(plans[0]['inventory']),linuxPartitionCompleteAndDisjoint=True,linuxAllChecksPassed=linuxComplete,reportPaths=[{k:v for k,v in row.items() if k!='report'} for row in reports],nativeFollowup=json.loads((root/'native-copy-failure.json').read_text()),desktopBudgetFollowup=json.loads((root/'desktop-budget-followup.json').read_text()),qualityAdmission=False)
(root/'audit.json').write_text(json.dumps(out,indent=2)+'\n');(root/'selected-reports.json').write_text(json.dumps(reports,indent=2)+'\n');(root/'linux-partitions.json').write_text(json.dumps(plans,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['jobs','artifacts','reportPaths','nativeFollowup']}))
