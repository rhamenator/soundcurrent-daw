from pathlib import Path
import json,hashlib,ctypes,struct,sys
sys.path.insert(0,'tests')
from verify_pipewire_manual_trace import signal_bits
class Info(ctypes.Structure):
 _fields_=[('frames',ctypes.c_int64),('samplerate',ctypes.c_int),('channels',ctypes.c_int),('format',ctypes.c_int),('sections',ctypes.c_int),('seekable',ctypes.c_int)]
lib=ctypes.CDLL('libsndfile.so.1');lib.sf_open.argtypes=[ctypes.c_char_p,ctypes.c_int,ctypes.POINTER(Info)];lib.sf_open.restype=ctypes.c_void_p
lib.sf_readf_float.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_float),ctypes.c_int64];lib.sf_readf_float.restype=ctypes.c_int64
lib.sf_close.argtypes=[ctypes.c_void_p]
root=Path('.cache/native-startup-observation-47/original-project');s=json.loads((root/'project.json').read_text());ids={t['id']:n-1 for n,t in enumerate(s['tracks']) if n}
rows=[]
for p in (root/'media').glob('*/journal.json'):
 j=json.loads(p.read_text());n=ids.get(j['trackId'])
 if n is None or not j['committedFrames'] or j['recoveredFrom'] is not None:continue
 file=p.parent/'take.wav';info=Info();handle=lib.sf_open(bytes(file),0x10,ctypes.byref(info));assert handle and info.channels==1
 data=(ctypes.c_float*info.frames)();count=lib.sf_readf_float(handle,data,info.frames);lib.sf_close(handle);assert count==info.frames==j['committedFrames']
 channel=n*7%32;origin=j['timingOrigin']['devicePosition']-j['inputLatencyFrames']
 bits=[struct.unpack('<I',struct.pack('<f',x))[0] for x in data]
 mismatch=sum(b!=signal_bits(origin+f,channel) for f,b in enumerate(bits))
 shifted={str(shift):sum(b!=signal_bits(origin+f+shift,channel) for f,b in enumerate(bits)) for shift in [-256,256]} if mismatch else {}
 rows.append({'lane':n,'source_channel':channel,'frames':info.frames,'journal_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'media_sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'expected_first_device_frame':origin,'unshifted_mismatches':mismatch,'diagnostic_shift_mismatches':shifted})
r={'original_only':True,'replay':False,'compensation_applied':False,'lanes':sorted(rows,key=lambda x:x['lane']),'positive_lanes':len(rows),'samples':sum(x['frames'] for x in rows),'sample_matches_do_not_establish_root_cause':True}
(root.parent/'independent-original-full-raw-analysis.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'positive_lanes':len(rows),'samples':r['samples'],'mismatched_lanes':[x for x in rows if x['unshifted_mismatches']]}))
