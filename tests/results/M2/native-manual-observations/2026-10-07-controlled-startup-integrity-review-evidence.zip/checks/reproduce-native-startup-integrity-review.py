from pathlib import Path
import hashlib,json,zipfile,sys
sys.path.insert(0,str(Path('tests').resolve()))
import native_startup_portability_tests as test
root=Path('.cache/native-startup-integrity-review-original');assert not root.exists();root.mkdir()
source=Path('tests/native_startup_portability_tests.py');(root/source.name).write_bytes(source.read_bytes())
archive=Path('tests/results/M2/native-manual-observations/2026-10-07-controlled-startup-evidence.zip')
with zipfile.ZipFile(archive) as z:payload={n:z.read(n) for n in z.namelist()}
cases={}
for name in ['self-consistent-replacement','unmanifested-member','duplicate-member']:
 changed=payload.copy()
 if name=='self-consistent-replacement':
  key='upstream-source-assessment-manifest.json';changed[key]+=b'\n'
  m=json.loads(changed['manifest.json']);m['payload_files'][key]=hashlib.sha256(changed[key]).hexdigest()
  changed['manifest.json']=(json.dumps(m,indent=2)+'\n').encode()
 if name=='unmanifested-member':changed['unexpected.txt']=b'Unrecorded archive member\n'
 path=root/(name+'.zip')
 with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for n,b in changed.items():z.writestr(n,b)
  if name=='duplicate-member':z.writestr('manifest.json',changed['manifest.json'])
 result=test.run(path)
 assert result['relocated_pair_qualified'] and result['relocated_mutations_refused']==21
 cases[name]={'original_wrongly_accepted':True,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'result':result}
(root/'manifest.json').write_text(json.dumps({'scope':'Analysis-tool integrity review reproduction; no native audio or original ZIP changed','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'cases':cases},indent=2)+'\n')
print(json.dumps(cases,indent=2))
