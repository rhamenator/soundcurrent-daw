#include <pipewire/filter.h>
#include <spa/node/io.h>
#include <array>
#include <cstdint>
#include <cstdio>
constexpr unsigned maximumPorts=64;
struct Query {
    unsigned port = UINT32_MAX, frames = 0, buffer = UINT32_MAX;
    unsigned ioId = 0, ioBytes = 0, ioBuffer = UINT32_MAX;
    unsigned liveBuffers = 0, bufferChanges = 0, maximumBytes = 0;
    int ioStatus = 0;
    bool ioKnown = false, returned = false, knownBuffer = false;
    bool apiSuppressed = false;
    unsigned sdkDequeues = 0, sdkQueues = 0, nativeSlot = UINT32_MAX, acquisitionStatus = 0;
    unsigned extentBytes = 0, chunkOffset = 0, chunkBytes = 0, chunkFlags = 0, dataFlags = 0;
    int chunkStride = 0, queueResult = INT32_MIN;
    pw_buffer *nativeBuffer = nullptr; // Callback-local identity, never serialized.
    bool nativeReturned = false, nativeKnown = false, queueMatched = false;
};
struct Row {
    spa_io_clock clock{};
    unsigned calls = 0;
    bool clockKnown = false;
    std::array<Query, maximumPorts> queries;
};

int main(){std::printf("query=%zu row=%zu rows_per_filter=%zu all_four_row_arrays=%zu\n",sizeof(Query),sizeof(Row),sizeof(Row)*8192,sizeof(Row)*8192*4);}
