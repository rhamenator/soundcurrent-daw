// SPDX-License-Identifier: GPL-3.0-only
// Read-only offline examination of an ORIGINAL failed manual fixture's sink prefix.
// Uses the same prepared graph and parameter contract as its original full oracle.
#include <soundcurrent/mix.hpp>
#include <soundcurrent/project_store.hpp>
#include <nlohmann/json.hpp>
#include <sndfile.h>
#include <algorithm>
#include <array>
#include <cmath>
#include <iostream>
using namespace soundcurrent::daw;
namespace {
constexpr Frame start = 137;
constexpr std::array<std::array<Frame, 2>, 3> ranges{{{48150, 48238}, {48254, 48848},
                                                   {144168, 192164}}};
float signal(std::uint64_t at, unsigned channel) {
    auto value = at ^ ((std::uint64_t(channel) + 1) * 0x9e3779b97f4a7c15ULL);
    value = (value ^ (value >> 30)) * 0xbf58476d1ce4e5b9ULL;
    value = (value ^ (value >> 27)) * 0x94d049bb133111ebULL;
    value ^= value >> 31;
    return float(std::int32_t(value >> 40) - 0x800000) * 0x1p-22f;
}
void check(bool ok, const char *message) {
    if (!ok)
        throw std::runtime_error(message);
}
} // namespace
int main(int argc, char **argv) {
    try {
        check(argc == 4, "Usage: analyzer ORIGINAL_PROJECT ORIGINAL_SINK_WAV DEVICE_ANCHOR");
        const auto s = ProjectStore(argv[1]).load();
        check(s.tracks.size() == 33 && s.assets.size() == 1, "Original session inventory differs");
        for (unsigned n = 0; n < 33; ++n) {
            const auto &eq = s.tracks[n].eq;
            check(eq.enabled && eq.bands.size() == 1 &&
                      eq.bands[0].frequencyHz == 730 + n * 19 &&
                      eq.bands[0].gainDb == (n % 2 ? -3 : 5) && eq.bands[0].q == 1,
                  "Original fixture EQ contract differs");
        }
        SF_INFO info{};
        auto *file = sf_open(argv[2], SFM_READ, &info);
        check(file && info.frames == 226304 && info.channels == 2 && info.samplerate == 48000 &&
                  (info.format & SF_FORMAT_TYPEMASK) == SF_FORMAT_RF64 &&
                  (info.format & SF_FORMAT_SUBMASK) == SF_FORMAT_FLOAT,
              "Original sink extent/format differs");
        std::vector<float> data(std::size_t(info.frames) * 2);
        check(sf_readf_float(file, data.data(), info.frames) == info.frames, "Sink read incomplete");
        check(sf_close(file) == 0, "Sink close failed");
        const auto anchor = std::stoull(argv[3]);
        MixPlan plan{{LayoutKind::Stereo, 2}, {}};
        for (unsigned n = 0; n < 33; ++n)
            plan.tracks.push_back({s.tracks[n].id, {{0, n % 2, n % 3 ? .125 : -.25}}});
        MixConfig c;
        c.startFrame = start;
        c.generation = 73;
        c.maximumFrames = 2048;
        c.memoryBudgetBytes = 64 * 1024 * 1024;
        PreparedMixGraph oracle(s, plan, c);
        auto altered = s;
        altered.tracks[0].eq.bands[0].gainDb = -2;
        const ParameterAddress address{s.tracks[0].id, s.tracks[0].eq.id,
                                       s.tracks[0].eq.bands[0].id, BandParameter::GainDb};
        check(oracle.submit(oracle.parameterEvent(altered, address, start + 96017)) ==
                  SubmitStatus::Accepted,
              "Original parameter event refused");
        std::array<std::array<float, 127>, 33> inputs{};
        std::array<const float *, 33> views{};
        std::array<MixInput, 33> planes{};
        for (unsigned n = 0; n < 33; ++n) {
            views[n] = inputs[n].data();
            planes[n] = {&views[n], 1};
        }
        std::array<std::array<float, 127>, 2> outputs{};
        std::array<float *, 2> out{outputs[0].data(), outputs[1].data()};
        double maximum = 0, peak = 0;
        std::uint64_t mismatches = 0;
        Frame firstMismatch = -1;
        for (Frame offset = 0; offset < info.frames;) {
            const auto count = std::uint32_t(std::min<Frame>(127, info.frames - offset));
            for (unsigned f = 0; f < count; ++f) {
                const auto frame = start + offset + f;
                inputs[0][f] = float(double(frame % 53 - 26) * .0625);
                const bool recording = std::any_of(ranges.begin(), ranges.end(), [&](auto r) {
                    return frame >= r[0] && frame < r[1];
                });
                for (unsigned lane = 0; lane < 32; ++lane) {
                    constexpr std::uint64_t latencies[]{4097, 0, 41, 200};
                    const bool live = lane % 3 == 1 || (lane % 3 == 2 && recording);
                    const auto device = anchor + std::uint64_t(frame - start);
                    inputs[lane + 1][f] = live && device >= latencies[lane % 4]
                                             ? signal(device - latencies[lane % 4], lane * 7 % 32)
                                             : 0.f;
                }
            }
            check(oracle.process(planes, out, count).status == ProcessStatus::Ok,
                  "Offline original oracle failed");
            for (unsigned f = 0; f < count; ++f)
                for (unsigned channel = 0; channel < 2; ++channel) {
                    const auto actual = data[std::size_t(offset + f) * 2 + channel];
                    const auto difference = std::abs(double(actual) - outputs[channel][f]);
                    check(std::isfinite(difference), "Nonfinite prefix sample");
                    maximum = std::max(maximum, difference);
                    peak = std::max(peak, std::abs(double(actual)));
                    if (difference > 1e-6) {
                        ++mismatches;
                        if (firstMismatch < 0)
                            firstMismatch = start + offset + f;
                    }
                }
            offset += count;
        }
        std::cout << nlohmann::json{{"observation", 48}, {"original_only", true},
                                  {"native_replay", false}, {"compensation_applied", false},
                                  {"sink_frames", info.frames},
                                  {"output_prefix_samples_verified", info.frames * 2},
                                  {"output_prefix_qualified", mismatches == 0 && peak > 1},
                                  {"maximum_sample_difference", maximum}, {"output_peak", peak},
                                  {"mismatched_samples", mismatches},
                                  {"first_mismatch_engine_frame", firstMismatch},
                                  {"runtime_timing_qualified", false},
                                  {"full_target_output_qualified", false}}
                         .dump(2)
                  << '\n';
        return mismatches == 0 && peak > 1 ? 0 : 1;
    } catch (const std::exception &e) {
        std::cerr << e.what() << '\n';
        return 1;
    }
}
