from pathlib import Path
import json, hashlib, ctypes, struct, sys
sys.path.insert(0, 'tests')
from verify_pipewire_manual_trace import signal_bits

root = Path('.cache/native-acquisition-observation-48')
manifest = json.loads((root / 'manifest.json').read_text())
def unchanged():
    for name, expected in manifest['payload_files'].items():
        assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, name
unchanged()
project = root / 'original-run/Manual recording — Ελληνικά'
session = json.loads((project / 'project.json').read_text())
ids = {t['id']: n for n, t in enumerate(session['tracks'][1:])}
class Info(ctypes.Structure):
    _fields_ = [('frames', ctypes.c_int64), ('samplerate', ctypes.c_int),
                ('channels', ctypes.c_int), ('format', ctypes.c_int),
                ('sections', ctypes.c_int), ('seekable', ctypes.c_int)]
lib = ctypes.CDLL('libsndfile.so.1')
lib.sf_open.argtypes = [ctypes.c_char_p, ctypes.c_int, ctypes.POINTER(Info)]
lib.sf_open.restype = ctypes.c_void_p
lib.sf_readf_float.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_float), ctypes.c_int64]
lib.sf_readf_float.restype = ctypes.c_int64
lib.sf_close.argtypes = [ctypes.c_void_p]
ranges = [(48150, 48238), (48254, 48848), (144168, 192164)]
rows, anchors, groups = [], set(), [set() for _ in ranges]
for p in (project / 'media').glob('*/journal.json'):
    j = json.loads(p.read_text())
    lane = ids.get(j['trackId'])
    if lane is None:
        continue
    delay = [4097, 0, 41, 200][lane % 4]
    begin = j['startFrame'] - delay
    group = next(i for i, (a, b) in enumerate(ranges) if begin == a)
    assert lane not in groups[group]
    groups[group].add(lane)
    assert j['inputLatencyFrames'] == delay and j['channels'] == 1
    assert j['committedFrames'] == ranges[group][1] - begin
    assert j['phase'] == 'finalized' and j['recoveredFrom'] is None
    assert j['rejectedFrames'] == j['observedInvalidInputSamples'] == 0
    origin = j['timingOrigin']
    assert origin['backend'] == 2 and origin['clockId'] == 35
    assert origin['generation'] == 73 and origin['rateNumerator'] == 1 and origin['rateDenominator'] == 48000
    anchors.add(origin['devicePosition'] - j['startFrame'] + 137)
    file = p.parent / 'take.wav'
    info = Info()
    handle = lib.sf_open(bytes(file), 0x10, ctypes.byref(info))
    assert handle and info.channels == 1 and info.samplerate == 48000
    assert info.frames == j['committedFrames'] and info.format & 0x0fff0000 == 0x220000 and info.format & 0xffff == 6
    data = (ctypes.c_float * info.frames)()
    assert lib.sf_readf_float(handle, data, info.frames) == info.frames
    assert lib.sf_close(handle) == 0
    bits = [struct.unpack('<I', struct.pack('<f', x))[0] for x in data]
    channel = lane * 7 % 32
    first = origin['devicePosition'] - delay
    mismatches = sum(b != signal_bits(first + f, channel) for f, b in enumerate(bits))
    rows.append(dict(group=group, lane=lane, source_channel=channel, frames=info.frames,
                     latency=delay, raw_start=j['startFrame'], device_origin=origin['devicePosition'],
                     unshifted_mismatches=mismatches,
                     journal_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),
                     media_sha256=hashlib.sha256(file.read_bytes()).hexdigest()))
assert all(g == set(range(32)) for g in groups) and len(rows) == 96 and len(anchors) == 1
assert sum(r['frames'] for r in rows) == 1557696
unchanged()
result = dict(observation=48, original_only=True, replay=False, compensation_applied=False,
              raw_samples_verified=sum(r['frames'] for r in rows),
              full_raw_qualified=not any(r['unshifted_mismatches'] for r in rows),
              playback_device_anchor=next(iter(anchors)), original_payloads_unchanged=True,
              runtime_timing_qualified=False, output_verification_performed_here=False,
              lanes=sorted(rows, key=lambda r: (r['group'], r['lane'])))
(root / 'independent-original-full-raw-analysis.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'lanes'}))
