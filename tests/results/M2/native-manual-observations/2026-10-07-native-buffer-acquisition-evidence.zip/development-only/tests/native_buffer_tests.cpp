// SPDX-License-Identifier: GPL-3.0-only
#include "pipewire_buffer.hpp"
#include "rt_audit.hpp"
#include <spa/utils/type.h>
#include <array>
#include <cerrno>
#include <limits>
#include <stdexcept>
using namespace soundcurrent::daw::native;
namespace {
void check(bool value) {
    if (!value)
        throw std::runtime_error("Native buffer ownership/capacity contract failed");
}
struct Provider {
    std::array<float, 12> guarded{};
    spa_chunk chunk{};
    spa_data data{};
    spa_buffer backing{};
    pw_buffer buffer{};
    spa_io_buffers io{};
    Port port;
    unsigned dequeues = 0, queues = 0, protocolErrors = 0;
    bool held = false, failQueue = false, unavailable = false;
    explicit Provider(bool input = false) {
        guarded.fill(19.f);
        chunk.size = 8 * sizeof(float);
        chunk.stride = sizeof(float);
        data.type = SPA_DATA_MemPtr;
        data.flags = SPA_DATA_FLAG_READWRITE;
        data.data = guarded.data() + 2;
        data.maxsize = 8 * sizeof(float);
        data.chunk = &chunk;
        backing.n_datas = 1;
        backing.datas = &data;
        buffer.buffer = &backing;
        io.status = input ? SPA_STATUS_HAVE_DATA : SPA_STATUS_NEED_DATA;
        io.buffer_id = 0;
        port.key = this;
        port.input = input;
        ioChanged(port, SPA_IO_Buffers, &io, sizeof(io));
    }
    bool guardsIntact() const {
        return guarded[0] == 19.f && guarded[1] == 19.f && guarded[10] == 19.f &&
               guarded[11] == 19.f;
    }
};
void auditClean() {
    const auto &c = rt_audit::counts;
    check(!c.cppAllocate && !c.cppFree && !c.cAllocate && !c.cFree && !c.blockingLock);
}
void deferred(Provider &p) {
    const auto before = p.dequeues;
    Buffer b;
    rt_audit::reset();
    {
        rt_audit::Guard guard;
        b = sc_pw_acquire_buffer(&p.port, 8);
    }
    check(b.status == Acquisition::Unavailable && !b.owned && !b.samples && p.dequeues == before);
    auditClean();
}
void ready(Provider &p, unsigned frames = 8, unsigned offset = 0) {
    Buffer b;
    const auto queuesBefore = p.queues;
    rt_audit::reset();
    {
        rt_audit::Guard guard;
        b = sc_pw_acquire_buffer(&p.port, frames);
    }
    auditClean();
    check(b.status == Acquisition::Ready && b.owned == &p.buffer &&
          b.samples == p.guarded.data() + 2 + offset && p.held && p.queues == queuesBefore);
    for (unsigned n = 0; n < frames; ++n)
        b.samples[n] = float(n + 1);
    bool returned;
    rt_audit::reset();
    {
        rt_audit::Guard guard;
        returned = sc_pw_release_buffer(&p.port, &b);
    }
    auditClean();
    check(returned && !b.owned && !b.samples && !p.held && p.queues == queuesBefore + 1 &&
          !p.protocolErrors && p.guardsIntact());
    check(sc_pw_release_buffer(&p.port, &b) && p.queues == queuesBefore + 1);
}
} // namespace
extern "C" pw_buffer *pw_filter_dequeue_buffer(void *key) {
    auto &p = *static_cast<Provider *>(key);
    ++p.dequeues;
    if (p.unavailable)
        return nullptr;
    if (p.held)
        ++p.protocolErrors;
    p.held = true;
    return &p.buffer;
}
extern "C" int pw_filter_queue_buffer(void *key, pw_buffer *buffer) {
    auto &p = *static_cast<Provider *>(key);
    ++p.queues;
    if (!p.held || buffer != &p.buffer)
        ++p.protocolErrors;
    p.held = false;
    return p.failQueue ? -EIO : 0;
}
int main() {
    Provider p;
    ready(p);
    check(p.chunk.offset == 0 && p.chunk.size == 8 * sizeof(float) &&
          p.chunk.stride == sizeof(float));
    ioChanged(p.port, SPA_IO_Buffers, nullptr, 0);
    deferred(p);
    ioChanged(p.port, SPA_IO_Buffers, &p.io, sizeof(p.io) - 1);
    deferred(p);
    ioChanged(p.port, SPA_IO_AsyncBuffers, &p.io, sizeof(p.io));
    deferred(p);
    ioChanged(p.port, SPA_IO_Buffers, &p.io, sizeof(p.io));
    for (auto status : {SPA_STATUS_HAVE_DATA, SPA_STATUS_STOPPED, SPA_STATUS_DRAINED, -EIO}) {
        p.io.status = status;
        deferred(p);
    }
    p.io.status = SPA_STATUS_OK;
    ready(p);
    p.io.status = SPA_STATUS_NEED_DATA;
    p.unavailable = true;
    deferred(p); // SDK has no free buffer, despite valid IO.
    p.unavailable = false;
    ready(p);
    Provider input(true);
    input.chunk.offset = 2 * sizeof(float);
    input.chunk.size = 6 * sizeof(float);
    ready(input, 6, 2);
    input.io.status = SPA_STATUS_NEED_DATA;
    deferred(input);
    input.io.status = SPA_STATUS_HAVE_DATA;
    input.io.buffer_id = SPA_ID_INVALID;
    deferred(input);
    input.io.buffer_id = 0;
    ready(input, 6, 2);
    // Every invalid shape is refused before exposing a view. Its native lease
    // remains owned until return, and bounded sentinel samples remain untouched.
    for (unsigned which = 0; which < 13; ++which) {
        Provider bad(which >= 8);
        switch (which) {
        case 0:
            bad.data.maxsize = 7 * sizeof(float);
            break;
        case 1:
            bad.data.data = nullptr;
            break;
        case 2:
            bad.data.chunk = nullptr;
            break;
        case 3:
            bad.backing.datas = nullptr;
            break;
        case 4:
            bad.backing.n_datas = 0;
            break;
        case 5:
            bad.backing.n_datas = 2;
            break;
        case 6:
            bad.data.flags = SPA_DATA_FLAG_READABLE;
            break;
        case 7:
            bad.data.data = reinterpret_cast<std::byte *>(bad.guarded.data()) + 1;
            break;
        case 8:
            bad.chunk.offset = bad.data.maxsize;
            break;
        case 9:
            bad.chunk.size = 7 * sizeof(float);
            break;
        case 10:
            bad.chunk.stride = 8;
            break;
        case 11:
            bad.chunk.flags = SPA_CHUNK_FLAG_CORRUPTED;
            break;
        case 12:
            bad.data.flags = SPA_DATA_FLAG_WRITABLE;
            break;
        }
        Buffer b;
        bool returned;
        rt_audit::reset();
        {
            rt_audit::Guard guard;
            b = sc_pw_acquire_buffer(&bad.port, 8);
        }
        auditClean();
        check(b.status == Acquisition::Invalid && b.owned == &bad.buffer && !b.samples &&
              bad.queues == 0 && bad.held);
        rt_audit::reset();
        {
            rt_audit::Guard guard;
            returned = sc_pw_release_buffer(&bad.port, &b);
        }
        auditClean();
        check(returned && bad.queues == 1 && !bad.held && !bad.protocolErrors &&
              bad.guardsIntact());
        for (auto value : bad.guarded)
            check(value == 19.f);
        if (which == 0)
            check(bad.chunk.size == 0 && bad.chunk.flags == SPA_CHUNK_FLAG_EMPTY);
    }
    const auto before = p.dequeues;
    check(sc_pw_acquire_buffer(nullptr, 8).status == Acquisition::Invalid);
    check(sc_pw_acquire_buffer(&p.port, 0).status == Acquisition::Invalid);
    check(sc_pw_acquire_buffer(&p.port, std::numeric_limits<unsigned>::max()).status ==
          Acquisition::Invalid);
    check(p.dequeues == before);
    p.failQueue = true;
    auto lease = sc_pw_acquire_buffer(&p.port, 8);
    check(!sc_pw_release_buffer(&p.port, &lease) && !lease.owned && !p.protocolErrors);
}
