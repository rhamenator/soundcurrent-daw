import sys,traceback
from pathlib import Path
root=Path('.cache/native-startup-review-evidence-extracted').resolve()
sys.path.insert(0,str(Path('tests').resolve()))
import verify_native_startup_pair as verifier
import native_startup_verifier_tests as mutations
read_text=Path.read_text
original_path='/home/rich/dev/soundcurrent-daw/.cache/sc-manual-fault-native-01yzdvmq/'
def relocated_read(path,*args,**kwargs):
 if str(path).startswith(original_path):raise FileNotFoundError('Archived receipt temporary path unavailable on relocated machine: '+str(path))
 return read_text(path,*args,**kwargs)
Path.read_text=relocated_read
for name,module in [('pair',verifier),('mutations',mutations)]:
 sys.argv=[module.__file__,'--original',str(root/'original47/original-project'),
  '--counterfactual-receipt',str(root/'joined-checks/native-startup-defer-native.json'),
  '--original-raw-analysis',str(root/'original47/independent-original-full-raw-analysis.json'),
  '--output',str(root/(name+'-unexpected-output.json'))]
 try:module.main()
 except FileNotFoundError:
  print('Reproduced '+name+' failure before source edits')
  traceback.print_exc()
 else:raise AssertionError('Relocated-path failure did not reproduce')
