from pathlib import Path
import datetime, hashlib, json, os, shutil, subprocess, sys
root=Path.cwd()
label, mode, count=sys.argv[1:]
folder=root/'.cache'/label
folder.mkdir()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def snapshot():
 raw=subprocess.check_output(['pw-dump'], text=True)
 data=json.loads(raw)
 return raw, data
def links(data):
 return sorted((v['id'], json.dumps(v.get('info',{}).get('props',{}), sort_keys=True)) for v in data if v['type']=='PipeWire:Interface:Link')
def defaults(data):
 return [v.get('metadata') for v in data if v['type']=='PipeWire:Interface:Metadata' and v.get('props',{}).get('metadata.name')=='default']
raw,before=snapshot(); (folder/'pipewire-before-private.json').write_text(raw)
compiled=[]
for directory in ['src','include','ui','tests']:
 for p in (root/directory).rglob('*'):
  if p.is_file() and p.suffix in ['.hpp','.cpp','.qrc']:
   relative=p.relative_to(root); dest=folder/'frozen-source'/relative; dest.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(p,dest); compiled.append((str(relative),sha(p)))
for name in ['CMakeLists.txt','third_party/nlohmann/json.hpp','third_party/libsndfile/sndfile.h']:
 p=root/name
 if p.exists():
  dest=folder/'frozen-source'/name; dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest);compiled.append((name,sha(p)))
exe=root/'.cache/build-desktop-release/sc-pipewire-manual-panel-fixture'
shutil.copy2(exe,folder/exe.name)
host_commands=subprocess.check_output(['ps','-eo','comm='],text=True).splitlines()
counts={name:host_commands.count(name) for name in ['cc1plus','ninja','cmake','ctest']}
manifest={'label':label,'parent_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'mode':mode,'arms':int(count),'host_context':{'process_counts':counts,'online_cpus':os.cpu_count(),'load_average':os.getloadavg(),'owned_related_build_handles_terminal_before_native':True,'unrelated_processes_modified':False},'source_sha256':dict(compiled),'executable_sha256':sha(exe),'source_frozen_before_launch':True,'binary_retained':True,'owned_project':str(folder/'project'),'prior_goal_turn':'progress: previous goal continuation completed PR21 and verified source backups; the intervening user reply restated the existing X006 target; revalidated current clean source before native qualification'}
(folder/'launch.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Launching',label,mode,count,flush=True)
with (folder/'stdout.log').open('w') as out, (folder/'stderr.log').open('w') as err:
 result=subprocess.run([str(folder/exe.name),str(folder/'project'),mode,count], stdout=out,stderr=err,env={**os.environ,'QT_QPA_PLATFORM':'offscreen'})
raw,after=snapshot();(folder/'pipewire-after-private.json').write_text(raw)
remaining=[v for v in after if v['type']=='PipeWire:Interface:Node' and v.get('info',{}).get('props',{}).get('node.name','').startswith('sc-daw-fixture-manual-panel-')]
manifest.update(exit_code=result.returncode,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),defaults_unchanged=defaults(before)==defaults(after),preexisting_links_unchanged=links(before)==links(after),owned_nodes_removed=not remaining)
manifest['original_artifacts']={str(p.relative_to(folder)): {'sha256':sha(p),'bytes':p.stat().st_size} for p in folder.rglob('*') if p.is_file() and 'frozen-source' not in p.parts and p.name not in [exe.name,'launch.json','pipewire-before-private.json','pipewire-after-private.json']}
(folder/'launch.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:manifest[k] for k in ['label','exit_code','defaults_unchanged','preexisting_links_unchanged','owned_nodes_removed']}),flush=True)
print((folder/'stderr.log').read_text()[-1000:])
summary=folder/'project/native-manual-panel.json'
if summary.exists():
 v=json.loads(summary.read_text()); print(json.dumps({k:v.get(k) for k in ['passed','raw_samples_verified','output_samples_verified','maximum_output_difference','output_peak','parameter_receipts']}))
if result.returncode or not manifest['defaults_unchanged'] or not manifest['preexisting_links_unchanged'] or not manifest['owned_nodes_removed']:sys.exit(1)
