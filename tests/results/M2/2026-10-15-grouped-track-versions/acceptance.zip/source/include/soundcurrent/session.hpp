// SPDX-License-Identifier: GPL-3.0-only
#pragma once
#include <array>
#include <cstdint>
#include <deque>
#include <optional>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>
#include <variant>
#include <utility>
#include <unordered_map>
#include <limits>
#include <memory>

namespace soundcurrent::daw {
using Frame = std::int64_t;
enum class ErrorCode {
    InvalidId,
    InvalidState,
    UnsupportedSchema,
    InvalidParameter,
    Io,
    MissingMedia,
    MediaMismatch,
    Canceled,
    ResourceLimit
};

class ProjectError : public std::runtime_error {
  public:
    ProjectError(ErrorCode code, const std::string &diagnostic)
        : std::runtime_error(diagnostic), code_(code) {}
    ErrorCode code() const noexcept {
        return code_;
    }

  private:
    ErrorCode code_;
};

// Trusted control-side budgets, never read from project files. Charges bound
// owned payload and validation work; allocator overhead/RSS is measured separately.
struct StateBudget {
    std::size_t memoryBudgetBytes = 64 * 1024 * 1024;
};
class ResourceLimitError : public ProjectError {
  public:
    ResourceLimitError(std::string resource, std::size_t required, std::size_t available,
                       bool overflow = false)
        : ProjectError(ErrorCode::ResourceLimit,
                       overflow ? resource + " payload size arithmetic overflow"
                                : resource + " needs at least " + std::to_string(required) +
                                      " bytes; budget is " + std::to_string(available) + " bytes"),
          resource_(std::move(resource)), required_(required), available_(available),
          overflow_(overflow) {}
    bool arithmeticOverflow() const noexcept {
        return overflow_;
    }
    const std::string &resource() const noexcept {
        return resource_;
    }
    std::size_t requiredBytes() const noexcept {
        return required_;
    }
    std::size_t availableBytes() const noexcept {
        return available_;
    }

  private:
    std::string resource_;
    std::size_t required_, available_;
    bool overflow_;
};
class PayloadCharge {
  public:
    PayloadCharge(std::string resource, std::size_t budget)
        : resource_(std::move(resource)), budget_(budget) {}
    void add(std::size_t count, std::size_t unit = 1) {
        if (unit && count > (std::numeric_limits<std::size_t>::max() - bytes_) / unit)
            throw ResourceLimitError(resource_, std::numeric_limits<std::size_t>::max(), budget_,
                                     true);
        bytes_ += count * unit;
        if (bytes_ > budget_)
            throw ResourceLimitError(resource_, bytes_, budget_);
    }
    std::size_t bytes() const noexcept {
        return bytes_;
    }

  private:
    std::string resource_;
    std::size_t budget_, bytes_ = 0;
};

class Id {
  public:
    explicit Id(std::string value);
    static Id generate(); // Control thread only: calls the operating-system RNG.
    const std::string &str() const noexcept {
        return value_;
    }
    bool operator==(const Id &) const = default;

  private:
    std::string value_;
};
enum class LayoutKind { Mono, Stereo, Discrete };
struct ChannelLayout {
    LayoutKind kind = LayoutKind::Mono;
    std::uint32_t channels = 1;
    bool operator==(const ChannelLayout &) const = default;
};
struct ChannelPortIntent {
    std::string deviceIdentity, portIdentity, mediaClass;
    bool input = false; // Endpoint receives audio (output/monitor destination).
    bool operator==(const ChannelPortIntent &) const = default;
};
struct RouteIntent {
    std::string backendId; // Stable machine identifier, never a translated label.
    std::string portIdentity;
    // v1.0 opaque identities remain intact; v1.1 uses ordered channel slots.
    std::vector<std::optional<ChannelPortIntent>> ports;
    bool operator==(const RouteIntent &) const = default;
};
struct ChannelMix {
    std::uint32_t source = 0, destination = 0;
    double gain = 1;
    bool operator==(const ChannelMix &) const = default;
};
struct TrackMix {
    Id track;
    std::vector<ChannelMix> channels;
    bool operator==(const TrackMix &) const = default;
};
struct MixPlan {
    ChannelLayout output;
    std::vector<TrackMix> tracks;
    bool operator==(const MixPlan &) const = default;
};
struct MasterBus {
    Id id = Id::generate();
    MixPlan plan;
    RouteIntent output;
    bool operator==(const MasterBus &) const = default;
};
struct EqBand {
    Id id = Id::generate();
    double frequencyHz = 1000;
    double gainDb = 0;
    double q = 1;
    bool operator==(const EqBand &) const = default;
};
struct EqSettings {
    Id id = Id::generate();
    bool enabled = true;
    std::vector<EqBand> bands;
    bool operator==(const EqSettings &) const = default;
};
enum class ClipFadeCurve { Linear = 0, EqualPower = 1, Smoothstep = 2 };
struct ClipFade {
    // Clip-relative frame window [startFrame,endFrame). Signed anchors preserve
    // the exact original envelope when a clip is cropped/split. 0,0 disables.
    Frame startFrame = 0, endFrame = 0;
    ClipFadeCurve curve = ClipFadeCurve::Linear;
    double shape = 1;
    bool operator==(const ClipFade &) const = default;
};
struct ClipProcessing {
    double gainDb = 0;
    bool muted = false, polarityInverted = false;
    ClipFade fadeIn, fadeOut;
    bool operator==(const ClipProcessing &) const = default;
};
void validateClipProcessing(const ClipProcessing &);
// Control only, strong exception guarantee; shift clip-relative fade anchors by
// consumed project frames, independently of the clip's source sample rate.
void shiftClipProcessing(ClipProcessing &, Frame consumedFrames);
struct SourcePosition {
    Frame frame = 0;
    std::uint64_t fraction = 0, denominator = 1;
    bool operator==(const SourcePosition &) const = default;
};
struct CompHandlePoint {
    SourcePosition raw, output;
    bool operator==(const CompHandlePoint &) const = default;
};
enum class CompProcessingDomain { ExistingMedia=0, PhysicalArtifact=1, ProjectAfterSrc=2 };
// Exact physical-frame offsets from the retained nominal raw origin.
struct WarpAnchor {
    Id id = Id::generate();
    SourcePosition source, output;
    bool operator==(const WarpAnchor &) const = default;
};
struct WarpProtection {
    Frame before=256, after=2048, halo=64, minimumNonunityGap=64;
    bool operator==(const WarpProtection &) const = default;
};
struct WarpSettings {
    std::string mode="transient-protected-v1";
    WarpProtection protection;
    std::vector<WarpAnchor> markers;
    bool operator==(const WarpSettings &) const = default;
};
struct ClipSourceTiming {
    // Exact source fraction; length/start/fade anchors use project frames.
    std::uint64_t fraction = 0, denominator = 1;
    bool operator==(const ClipSourceTiming &) const = default;
};
struct ClipPlaybackRate {
    // Exact speed multiplier, 1/4..4; pitch follows speed. Components 1..4000.
    // Independent pitch-preserving stretching uses a separate processor/state.
    std::uint32_t numerator = 1, denominator = 1;
    bool operator==(const ClipPlaybackRate &) const = default;
};
void validateClipPlaybackRate(const ClipPlaybackRate &);
struct StretchSettings {
    // Independent duration multiplier and pitch in stable integer milli-cents.
    std::uint32_t timeNumerator = 1, timeDenominator = 1;
    std::int32_t pitchMilliCents = 0;
    bool formantPreserved = false;
    bool operator==(const StretchSettings &) const = default;
};
struct StretchContext {
    // Real neighboring frames at the physical source rate; never inferred.
    Frame before = 0, after = 0;
    bool operator==(const StretchContext &) const = default;
};
struct ClipStretchAnchor {
    Id sourceAssetId = Id::generate();
    std::string sourceSha256;
    SourcePosition sourceOrigin;
    Frame sourceFrames = 0;
    StretchSettings settings;
    std::string renderKey;
    // Persisted algorithm identity; legacy 1.12 projects retain their R3 assets.
    std::string processor = "soundcurrent.stretch-rubberband4-r3-positioned-v2";
    // Presence opts into a separately versioned nominal visible-crop map,
    // including an explicitly selected zero-context region.
    std::optional<StretchContext> context;
    std::optional<WarpSettings> warp;
    // The clip addresses derived audio; this anchor always addresses raw audio.
    // Split/crop/duplicate retain it and move only the derived source position.
    bool operator==(const ClipStretchAnchor &) const = default;
};
struct ClipTakeOrigin {
    Id trackId, laneId, clipId; // Retained source; survives moves between tracks.
    bool operator==(const ClipTakeOrigin &) const = default;
};
struct ClipCompHandleWindow {
    Id baseAssetId = Id::generate(); // Original nominal artifact, retained unchanged.
    std::string baseSha256, renderKey;
    Frame prefixFrames=0, suffixFrames=0; // At the artifact's physical rate.
    bool operator==(const ClipCompHandleWindow &) const = default;
};
struct Clip {
    Id id = Id::generate();
    Id assetId = Id::generate();
    Frame startFrame = 0;
    Frame sourceFrame = 0;
    Frame lengthFrames = 0;
    ClipProcessing processing;
    ClipSourceTiming sourceTiming;
    ClipPlaybackRate playbackRate;
    std::optional<ClipStretchAnchor> stretch = {};
    std::optional<ClipTakeOrigin> takeOrigin = {};
    std::optional<ClipCompHandleWindow> compHandles = {};
    bool operator==(const Clip &) const = default;
};
struct TakeLane {
    Id id = Id::generate(), groupId = Id::generate();
    std::string name;
    // Original recording transport range in project-rate frames, before each
    // track's input delay. Device-clock origins remain in the raw media journal.
    // This range is independent of the lane clips' later project positions.
    Frame captureStartFrame = 0, captureEndFrame = 0;
    std::vector<Clip> clips; // Inactive. Only explicit comp copies are audible.
    bool operator==(const TakeLane &) const = default;
};
// Only Track::clips is audible. Retained takes and processor/routing state are
// shared by every arrangement. Inactive versions own distinct clip identities.
struct TrackVersionIdentity {
    Id id = Id::generate();
    std::string name;
    std::optional<Id> groupId; // Shared across tracks, at most once per track.
    bool operator==(const TrackVersionIdentity &) const = default;
};
struct TrackVersion {
    TrackVersionIdentity identity;
    std::vector<Clip> clips;
    bool operator==(const TrackVersion &) const = default;
};
enum class RecordingMonitor { Off, PostEq, AutoRecording };
constexpr bool validRecordingMonitor(RecordingMonitor mode) noexcept {
    return mode == RecordingMonitor::Off || mode == RecordingMonitor::PostEq ||
           mode == RecordingMonitor::AutoRecording;
}
struct Track {
    Id id = Id::generate();
    std::string name;
    ChannelLayout layout;
    RouteIntent input;
    RouteIntent output;
    RouteIntent monitor;
    RecordingMonitor monitoring = RecordingMonitor::Off;
    Frame inputLatencyFrames = 0; // Declared capture delay, 0..60 seconds at project rate.
    EqSettings eq;
    std::vector<Clip> clips;
    std::vector<TakeLane> takeLanes;
    std::optional<TrackVersionIdentity> activeVersion;
    std::vector<TrackVersion> inactiveVersions;
    bool operator==(const Track &) const = default;
};
// Portable evidence only. These paths never grant access to original sources.
struct ProjectEvidenceFile {
    std::string relativePath, sha256;
    std::uint64_t bytes = 0;
    bool operator==(const ProjectEvidenceFile &) const = default;
};
struct Asset {
    Id id = Id::generate();
    std::string relativePath; // Canonical UTF-8 with '/' separators on every OS.
    std::string sha256;
    std::uint32_t sampleRate = 48000;
    ChannelLayout layout;
    Frame frames = 0;
    std::vector<ProjectEvidenceFile> nativeEvidence = {}; // Bound original capture/native journals and artifacts; empty for non-native assets.
    bool operator==(const Asset &) const = default;
};
struct PunchSettings {
    bool enabled = false;
    Frame startFrame = 0, endFrame = 0; // Desired project frames, before input latency.
    bool operator==(const PunchSettings &) const = default;
};
struct LoopSettings {
    bool enabled = false;
    Frame startFrame = 0, endFrame = 0; // Half-open saved project range.
    bool operator==(const LoopSettings &) const = default;
};
struct ImportedMediaOrigin {
    Id assetId = Id::generate(), operation = Id::generate();
    std::uint64_t sourceProperty = 0;
    ProjectEvidenceFile receipt;
    bool operator==(const ImportedMediaOrigin &) const = default;
};
struct ImportedProjectSource {
    Id id = Id::generate();
    std::string adapterId, sourceSha256;
    std::uint64_t sourceBytes = 0;
    ProjectEvidenceFile inspection;
    std::vector<ImportedMediaOrigin> media;
    bool operator==(const ImportedProjectSource &) const = default;
};
// Trusted project-owned reference to immutable comp selection sidecars. The
// digest is never learned from the sidecar on recovery. No playback activation.
struct CompPairSelectionReference {
    Id operation;
    std::string selectionSha256;
    bool operator==(const CompPairSelectionReference &) const = default;
};
// Reserved candidate identities and trusted immutable request bytes. These do
// not activate audio. Adoption must consume reservations in the same edit.
struct CompAssemblyReference {
    Id operation, selectionOperation;
    std::string requestSha256;
    std::array<std::optional<Id>, 2> outputs;
    bool operator==(const CompAssemblyReference &) const = default;
};
// Immutable provenance of an assembled artifact. The two clip values are
// historical snapshots, not additional active timeline objects/identities.
struct CompPlaybackSourceData {
    Clip original, playback;
    Asset raw, base, rendered;
    std::optional<Asset> nominal;
    CompProcessingDomain domain=CompProcessingDomain::ExistingMedia;
    std::uint32_t projectRate=0;
    Frame prefixFrames=0, suffixFrames=0;
    SourcePosition expandedOrigin;
    std::uint32_t expandedNumerator=1, expandedDenominator=1;
    std::vector<CompHandlePoint> rawMap;
    bool operator==(const CompPlaybackSourceData &) const = default;
};
struct CompPlaybackSourceState {
    CompAssemblyReference assembly; // Historical intent, not a reservation.
    unsigned side=0;
    std::string selectionSha256;
    CompPlaybackSourceData source;
    bool operator==(const CompPlaybackSourceState &) const = default;
};
struct Session {
    Id id = Id::generate();
    std::string name;
    std::uint32_t sampleRate = 48000;
    Frame playheadFrame = 0;
    Frame exportStartFrame = 0;
    Frame exportEndFrame = 0;
    std::vector<Track> tracks;
    std::vector<Asset> assets;
    std::optional<MasterBus> master;
    PunchSettings punch;
    LoopSettings loop;
    std::vector<ImportedProjectSource> imports;
    std::vector<CompPairSelectionReference> compPairSelections;
    std::vector<CompAssemblyReference> compAssemblies;
    std::vector<CompPlaybackSourceState> compPlaybackSources;
    bool operator==(const Session &) const = default;
};
bool validUtf8(std::string_view text) noexcept;
void validateRelativeMediaPath(std::string_view path);
void validateImportedProjectSource(const ImportedProjectSource &);
std::size_t sessionPayloadBytes(const Session &, StateBudget = {});
void validate(const Session &session, StateBudget = {});
// Preparation-only immutable borrow: do not mutate/destroy the session while
// this validated index exists. No public unchecked validation bypass.
class ValidatedSession {
  public:
    explicit ValidatedSession(const Session &, StateBudget = {});
    const Session &session() const noexcept {
        return session_;
    }
    const Track &track(const Id &) const;
    const Asset &asset(const Id &) const;
    const ImportedProjectSource &importedSource(const Id &) const;

  private:
    const Session &session_;
    std::unordered_map<std::string_view, const Track *> tracks_;
    std::unordered_map<std::string_view, const Asset *> assets_;
    std::unordered_map<std::string_view, const ImportedProjectSource *> imports_;
};
struct TakeAudition { Id track, lane; bool operator==(const TakeAudition &) const = default; };
// Transient control-side playback model. Never publish through project/history.
Session makeTakeAudition(const Session &, const TakeAudition &, StateBudget = {});
Session makeOneTrackSession(std::string name, std::string trackName,
                           std::uint32_t sampleRate = 48000);
Track makeAudioTrack(std::string name, ChannelLayout layout, std::uint32_t sampleRate);
// Control-thread edits, addressed by stable identity. A batch is all-or-nothing.
struct AddCompPairSelection { CompPairSelectionReference value; };
struct RemoveCompPairSelection { Id operation; };
struct AddCompAssembly { CompAssemblyReference value; };
struct RemoveCompAssembly { Id operation; };
struct InsertTrack {
    Track track;
    std::optional<Id> before;
};
struct RemoveTrack {
    Id track;
};
struct RenameTrack {
    Id track;
    std::string name;
};
struct MoveTrack {
    Id track;
    std::optional<Id> before;
};
struct InsertClip {
    Id track;
    Clip clip;
    std::optional<Id> before;
};
struct InsertNativeTake {
    Id track;
    Asset asset;
    Clip clip; // Explicit project placement, never inferred recording alignment.
};
struct RemoveClip {
    Id track, clip;
};
struct SetClipRange {
    Id track, clip;
    Frame start, source, length;
};
struct CropClip {
    Id track, clip;
    Frame start, consumedProjectFrames, length;
};
struct SetClipProcessing {
    Id track, clip;
    ClipProcessing value;
};
// Atomic outgoing/incoming fade edit in one shared project-frame window.
// Existing clip geometry/media and the opposite fades remain unchanged.
struct SetClipCrossfade {
    Id track, outgoing, incoming;
    Frame startFrame = 0, endFrame = 0;
    ClipFadeCurve curve = ClipFadeCurve::Linear;
};
// Extend two ordered retained-take fragments only within their retained source
// handles, then apply paired fades in one undoable transaction.
struct PrepareCompTransition {
    Id track, outgoing, incoming;
    Frame startFrame = 0, endFrame = 0;
    ClipFadeCurve curve = ClipFadeCurve::Linear;
};
struct SetClipPlaybackRate {
    Id track, clip;
    ClipPlaybackRate value;
};
struct ApplyClipStretch {
    Id track, clip;
    Clip expected; // Reject stale asynchronous results before any model mutation.
    Asset source, rendered;
    ClipStretchAnchor value;
};
struct CompHandleReplacement {
    Clip expected;
    Asset current, raw, nominal, rendered;
    ClipCompHandleWindow window;
};
// Artifacts must be independently verified before submitting this model edit.
struct ApplyCompHandlePair {
    PrepareCompTransition transition;
    std::optional<CompHandleReplacement> outgoing, incoming;
};
// Caller verifies owned files and current workspace/epoch before submission.
// Consumes one request and adopts both fragments atomically; no file deletion.
struct CompAssemblySourceIdentity {
    Clip clip, retained;
    Asset raw, base, retainedAsset;
    std::optional<Asset> nominal;
};
class CompAssemblyDependencies;
struct ApplyCompAssembly {
    PrepareCompTransition transition;
    CompAssemblyReference expectedReference;
    CompPairSelectionReference expectedSelection;
    std::array<CompAssemblySourceIdentity,2> expected;
    std::array<std::optional<CompPlaybackSourceData>,2> sources;
    std::shared_ptr<const CompAssemblyDependencies> dependencies;
};
struct MoveClip {
    Id from, to, clip;
    Frame start;
    std::optional<Id> before;
};
struct SplitClip {
    Id track, clip, rightId;
    Frame position;
};
struct SetMaster {
    std::optional<MasterBus> value;
};
struct SetPunch {
    PunchSettings value;
};
struct SetLoop {
    LoopSettings value;
};
struct SetInputLatency {
    Id track;
    Frame frames;
};
struct InsertTakeLane {
    Id track;
    TakeLane lane;
    std::optional<Id> before;
};
struct RemoveTakeLane { Id track, lane; };
struct RenameTakeLane { Id track, lane; std::string name; };
struct MoveTakeLane { Id track, lane; std::optional<Id> before; };
struct SelectTakeRegion {
    Id track, lane;
    Frame startFrame = 0, endFrame = 0; // Fully covered project region [start,end).
};
// First creation names the previously implicit arrangement with previousName.
// Creation activates the new arrangement; duplicate=false starts with no clips.
struct CreateTrackVersion { Id track; std::string name, previousName; bool duplicate = true; };
struct SwitchTrackVersion { Id track, version; };
struct RenameTrackVersion { Id track, version; std::string name; };
// Active deletion is refused: switch to a retained version explicitly first.
struct RemoveTrackVersion { Id track, version; };
struct CreateTrackVersions {
    std::vector<Id> tracks;
    std::string name, previousName;
    bool duplicate = true;
};
struct LinkActiveTrackVersions { std::vector<Id> tracks; std::string previousName; };
enum class TrackVersionGroupAction { Activate, Rename, Remove };
struct EditTrackVersionGroup {
    std::vector<Id> tracks;
    Id group;
    TrackVersionGroupAction action = TrackVersionGroupAction::Activate;
    std::string name;
};
using SessionEdit =
    std::variant<AddCompAssembly, RemoveCompAssembly, AddCompPairSelection, RemoveCompPairSelection, InsertTrack, RemoveTrack, RenameTrack, MoveTrack, InsertClip, InsertNativeTake, RemoveClip,
                 SetClipRange, CropClip, SetClipProcessing, SetClipCrossfade, PrepareCompTransition, SetClipPlaybackRate, ApplyClipStretch, ApplyCompHandlePair, ApplyCompAssembly, MoveClip, SplitClip, SetMaster, SetPunch, SetLoop, SetInputLatency,
                 InsertTakeLane, RemoveTakeLane, RenameTakeLane, MoveTakeLane, SelectTakeRegion, CreateTrackVersion, SwitchTrackVersion, RenameTrackVersion, RemoveTrackVersion, CreateTrackVersions, LinkActiveTrackVersions, EditTrackVersionGroup>;
void applySessionEdits(Session &, const std::vector<SessionEdit> &, StateBudget = {});
enum class RouteTarget { Input, Output, Monitor, Master };
struct RouteAddress {
    Id trackId;
    RouteTarget target;
    bool operator==(const RouteAddress &) const = default;
};
struct RouteChannelPatch {
    std::uint32_t channel = 0;
    std::string backendId;
    std::optional<ChannelPortIntent> port;
};
const RouteIntent &routeValue(const Session &, const RouteAddress &);
RouteIntent patchedRouteValue(const Session &, const RouteAddress &, const RouteChannelPatch &);
void setRouteValue(Session &, const RouteAddress &, const RouteIntent &, StateBudget = {});
RecordingMonitor monitoringValue(const Session &, const Id &trackId);
void setMonitoringValue(Session &, const Id &trackId, RecordingMonitor);

enum class BandParameter { FrequencyHz, GainDb, Q };
struct ParameterAddress {
    Id trackId;
    Id processorId;
    Id bandId;
    BandParameter parameter;
    bool operator==(const ParameterAddress &) const = default;
};
struct ParameterDescriptor {
    std::string_view stableId;
    double minimum;
    double maximum;
    std::string_view unit;
};
ParameterDescriptor descriptor(BandParameter parameter);
double parameterValue(const Session &, const ParameterAddress &);
void setParameterValue(Session &, const ParameterAddress &, double value);

// Semantic control-thread gestures. No audio processing and no RT-safe claim.
struct HistoryBudget {
    std::size_t retainedBytes = 32 * 1024 * 1024;
    std::size_t operationBytes = 256 * 1024 * 1024;
    std::size_t maximumCommands = 256;
    bool operator==(const HistoryBudget &) const = default;
};
struct HistoryResources {
    std::size_t undoCommands = 0, redoCommands = 0, retainedBytes = 0, activeBytes = 0;
    std::size_t operationPeakBytes = 0;
    std::uint64_t evictedCommands = 0;
    bool operator==(const HistoryResources &) const = default;
};
void validateHistoryBudget(const HistoryBudget &);
class EditHistory {
  public:
    explicit EditHistory(Session &session, StateBudget budget = {}, HistoryBudget history = {});
    const HistoryBudget &resourceBudget() const noexcept {
        return historyBudget_;
    }
    HistoryResources resources() const;
    // Refuses reductions below retained usage; never discards existing Undo/Redo.
    void configure(HistoryBudget);
    // Controller preflight includes an unrelated pending gesture before committing it.
    std::size_t checkAdopt(const Session &) const;
    std::size_t checkRoute(const RouteAddress &, const RouteIntent &) const;
    std::size_t checkMonitoring(const Id &, RecordingMonitor) const;
    std::size_t checkBegin(const ParameterAddress &) const;
    std::size_t checkUpdate() const;
    std::size_t checkCommit() const;
    // Record a successful controller operation using its earlier read-only preflight.
    void acceptPreflight(std::size_t declaredBytes) noexcept;
    void begin(const ParameterAddress &);
    void update(double value);
    void commit();
    void cancel();
    // Read-only target after committing a pending gesture, for publication admission.
    std::optional<Session> previewTransfer(bool forward, std::size_t *declaredPeak = nullptr) const;
    bool undo();
    bool redo();
    bool route(const RouteAddress &, const RouteIntent &);
    bool monitoring(const Id &trackId, RecordingMonitor);
    bool structural(const std::vector<SessionEdit> &);
    // Verified canonical media admission only; this does no disk verification.
    bool adopt(const Session &);

  private:
    struct ParameterChange {
        ParameterAddress address;
        double before;
        double after;
    };
    struct RouteChange {
        RouteAddress address;
        RouteIntent before, after;
    };
    struct MonitoringChange {
        Id trackId;
        RecordingMonitor before, after;
    };
    template <class T> struct ObjectChange {
        Id id;
        std::optional<T> before, after;
    };
    struct StructureChange {
        std::vector<ObjectChange<Track>> tracks;
        std::vector<ObjectChange<Asset>> assets;
        std::vector<Id> trackOrderBefore, trackOrderAfter, assetOrderBefore, assetOrderAfter;
        std::optional<std::pair<Frame, Frame>> exportEnd;
        std::optional<std::pair<std::optional<MasterBus>, std::optional<MasterBus>>> master;
        std::optional<std::pair<PunchSettings, PunchSettings>> punch;
        std::optional<std::pair<LoopSettings, LoopSettings>> loop;
        std::optional<std::pair<std::vector<CompPairSelectionReference>, std::vector<CompPairSelectionReference>>> compPairSelections;
        std::optional<std::pair<std::vector<CompAssemblyReference>, std::vector<CompAssemblyReference>>> compAssemblies;
        std::optional<std::pair<std::vector<CompPlaybackSourceState>, std::vector<CompPlaybackSourceState>>> compPlaybackSources;
    };
    using Change = std::variant<ParameterChange, RouteChange, MonitoringChange, StructureChange>;
    struct Entry {
        Change change;
        std::size_t bytes;
    };
    static std::size_t weight(const Change &);
    StructureChange difference(const Session &) const;
    std::size_t checkOperation(std::size_t candidateBytes, const Session &, bool pending = true,
                               std::size_t extraBytes = 0) const;
    std::size_t checkCandidate(const Change &, const Session &) const;
    void retain(Change, const Session &);
    Session proposed(const Change &, bool forward) const;
    bool transfer(bool forward);
    Session &session_;
    StateBudget budget_;
    HistoryBudget historyBudget_;
    std::size_t retainedBytes_ = 0, operationPeakBytes_ = 0;
    std::uint64_t evictedCommands_ = 0;
    std::optional<ParameterChange> active_;
    std::deque<Entry> undo_, redo_;
};
} // namespace soundcurrent::daw
