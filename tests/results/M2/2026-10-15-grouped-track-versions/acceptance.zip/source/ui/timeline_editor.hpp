// SPDX-License-Identifier: GPL-3.0-only
#pragma once
#include <soundcurrent/resource_ledger.hpp>
#include "session_list_model.hpp"
#include "timeline_view.hpp"
#include <QGroupBox>
#include <QCoreApplication>
#include <functional>
#include <memory>
class QListView;

class QLineEdit;
class QComboBox;
class QSpinBox;
class QPushButton;
class QLabel;
class QSlider;
class QDoubleSpinBox;
class QCheckBox;
namespace soundcurrent::daw::ui {
class SessionListModel;
class TimelineView;
class TimelineEditor : public QGroupBox {
    Q_DECLARE_TR_FUNCTIONS(TimelineEditor)
  public:
    explicit TimelineEditor(QWidget *parent = nullptr, ResourceLedger = ResourceLedger{});
    struct Prepared;
    std::shared_ptr<Prepared> prepareModel(std::shared_ptr<const Session>, std::uint64_t epoch,
                                           bool editable, std::filesystem::path root = {}) const;
    void commitModel(std::shared_ptr<Prepared>);
    std::optional<Id> preparedTrack(const std::shared_ptr<Prepared> &) const;
    void editing(bool);
    void shutdownWaveforms() { view_->shutdownWaveforms(); }
    bool waveformsClosed() const { return view_->waveformsClosed(); }
    std::size_t resourceBytes() const;
    std::function<bool(std::shared_ptr<const Session>, std::optional<Id>)> selectionAdmission;
    ~TimelineEditor() override;
    std::function<bool(std::vector<SessionEdit>)> submit;
    std::function<void()> selectionChanged;
    std::function<void(Id, Id)> pitchStretchRequested;
    std::function<bool(PrepareCompTransition,Frame,std::uint64_t)> compRenderRequested;
    std::function<bool(Id, Id, std::uint64_t)> takeAuditionRequested;
    void updateModel(std::shared_ptr<const Session>, std::uint64_t epoch, bool editable, std::filesystem::path root = {});
    std::optional<Id> selectedTrack() const {
        return track_;
    }
    std::optional<Id> selectedClip() const {
        return clip_;
    }
    bool selectTrack(const Id &);

  private:
    std::shared_ptr<Prepared> prepare(std::shared_ptr<const Session>, std::uint64_t, bool,
                                      std::optional<Id>, std::optional<Id>, bool, std::filesystem::path) const;
    bool select(std::optional<Id>, std::optional<Id>);
    ResourceLedger versionMemory_;
    std::shared_ptr<const Session> model_;
    std::uint64_t epoch_ = 0;
    std::filesystem::path root_;
    bool editable_ = false, refreshing_ = false;
    std::optional<Id> track_, clip_, pendingTrack_;
    QListView *tracks_;
    TimelineView *view_;
    SessionListModel *trackList_, *destinations_, *assets_, *clipList_, *takeList_;
    QComboBox *takes_;
    QLineEdit *takeName_, *compStart_, *compEnd_;
    QCheckBox *compGroup_;
    QLabel *compSource_;
    std::optional<Id> take_;
    const TakeLane *takeLane() const;
    void refreshTake(bool force);
    void editCrossfade();
    void editTrackVersions();
    QLineEdit *name_, *start_, *source_, *length_, *split_, *consumed_;
    QLabel *sourceTiming_;
    QComboBox *layout_, *destination_, *asset_, *clips_;
    QSpinBox *channels_;
    QSlider *zoom_;
    QDoubleSpinBox *clipGain_, *fadeInShape_, *fadeOutShape_, *clipRate_;
    ClipPlaybackRate displayedRate_;
    QCheckBox *clipMuted_, *clipInverted_;
    QLineEdit *fadeInStart_, *fadeInEnd_, *fadeOutStart_, *fadeOutEnd_;
    QComboBox *fadeInCurve_, *fadeOutCurve_;
    QLabel *status_;
    std::vector<QPushButton *> mutations_;
    const Track *track() const;
    const Clip *clip() const;
    void refresh(bool forceFields = false, bool redraw = true,
                 std::optional<QString> destination = {}, std::optional<QString> asset = {},
                 bool forceProcessing = false, bool forceRate = false);
    void draw();
    void mutate(std::vector<SessionEdit>);
    void operation(const std::function<void()> &);
    Frame frame(QLineEdit *, bool allowSigned = false) const;
};
} // namespace soundcurrent::daw::ui
