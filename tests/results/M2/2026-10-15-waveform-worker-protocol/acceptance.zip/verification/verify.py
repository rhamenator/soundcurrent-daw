import subprocess,json,os,time
from pathlib import Path
root=Path('.cache/waveform-protocol-342')
rows=[]
for label,build in [('release','.cache/take-preview-linux/build'),('asan-ubsan','.cache/waveform-core-341/asan')]:
 env=os.environ.copy()
 extra={} if label=='release' else {'ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'}
 env.update(extra)
 for phase,cmd in [('build',['cmake','--build',build,'--parallel','1','--target','sc-waveform-protocol-tests','sc-waveform-worker','sc-waveform-tests','sc-wave-validation-tests']),('tests',['ctest','--test-dir',build,'-R','^(waveform-source-pyramid|waveform-reply-protocol|waveform-worker-workflows|approved-wave-content)$','--output-on-failure','-V'])]:
  argv=['nice','-n','15','ionice','-c','3']+cmd
  start=time.monotonic()
  with (root/(label+'-final-'+phase+'.log')).open('wb') as out:
   result=subprocess.run(argv,stdout=out,stderr=subprocess.STDOUT,env=env)
  rows.append(dict(label=label,phase=phase,argv=argv,environment=extra,exitCode=result.returncode,seconds=time.monotonic()-start))
  (root/'verification-commands.json').write_text(json.dumps(rows,indent=2)+'\n')
  print(label,phase,result.returncode,flush=True)
  if result.returncode: raise SystemExit(result.returncode)
