from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path('.cache/waveform-protocol-342')
out=Path('tests/results/M2/2026-10-15-waveform-worker-protocol');out.mkdir(parents=True,exist_ok=True)
source=['include/soundcurrent/waveform.hpp','include/soundcurrent/waveform_protocol.hpp','src/waveform_protocol.cpp','tools/waveform_worker.cpp','tests/waveform_protocol_tests.cpp','tests/waveform_worker_tests.py','CMakeLists.txt','.github/workflows/ci.yml']
files={}
for name in source:files['source/'+name]=Path(name).read_bytes()
for path in sorted(root.glob('*.log')):files['logs/'+path.name]=path.read_bytes()
for name in ['verification-commands.json','verify.py','archive.py']:files['verification/'+name]=(root/name).read_bytes()
for path in sorted((root/'preceding-ci').glob('*')):files['preceding-ci/'+path.name]=path.read_bytes()
for path in sorted(Path('/tmp/sc-waveform-worker-lywrnjp0').iterdir()):files['original-failed-fixture/'+path.name]=path.read_bytes()
binaries={}
for label,build in [('release',Path('.cache/take-preview-linux/build')),('asan-ubsan',Path('.cache/waveform-core-341/asan'))]:
 files['build/'+label+'/CMakeCache.txt']=(build/'CMakeCache.txt').read_bytes()
 files['build/'+label+'/commands.txt']=subprocess.check_output(['ninja','-C',str(build),'-t','commands','sc-waveform-worker','sc-waveform-protocol-tests','sc-waveform-tests','sc-wave-validation-tests'])
 for name in ['sc-waveform-worker','sc-waveform-protocol-tests','sc-waveform-tests','sc-wave-validation-tests','libsc-waveform.a']:
  path=build/name
  with path.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
  binaries[label+'/'+name]=dict(bytes=path.stat().st_size,sha256=digest)
files['verification/binary-hashes.json']=(json.dumps(binaries,indent=2)+'\n').encode()
files['verification/tracked.patch']=subprocess.check_output(['git','diff','--','.github/workflows/ci.yml','CMakeLists.txt','include/soundcurrent/waveform.hpp'])
base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
index={name:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest()) for name,data in files.items()}
files['payload-index.json']=(json.dumps(index,indent=2)+'\n').encode()
archive=out/'acceptance.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name,data in files.items():z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,expected in index.items():
  data=z.read(name);assert len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256']
manifest=dict(archive=archive.name,bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),entries=len(files),baseHead=base,testedWorkingTreeSource={n:index['source/'+n] for n in source},protocolChecks=21060,workerCases=53,sourceChecks=164507,existingWaveChecks=20956,releasePassed=True,asanUbsanPassed=True,nativeWindowsQualified=False,uiIntegrated=False,binariesIncluded=False,precedingCiRun=38801059137,precedingCiTerminal=False,precedingFailure='desktop-comp-assembly-apply: Old opening applied into new owner')
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:manifest[k] for k in ['bytes','sha256','entries','baseHead']}))
