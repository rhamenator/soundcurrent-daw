from pathlib import Path
import json,shutil,hashlib,uuid,sys
sys.path.insert(0,str(Path('tests').resolve()))
from worker_observation import observe,diagnostic
r=Path('.cache/installed-short-comp-322').resolve();source=r/'app/project-été-Κиїв';target=r/'portable-replay/project-été-Κиїв';assert not target.exists();shutil.copytree(source,target)
original=json.loads((r/'worker-probe/result.json').read_text());args=original['args'];worker=Path('.cache/take-preview-linux/build/sc-comp-span-worker').resolve();args[0]=str(worker);args[2]=str(target);args[4]=str(target/'media/comp-spans')
request=json.loads((source/'media/comp-requests/bae921a7-15df-4dda-8e2a-dee4cc595b25.json').read_text());request['executor']['buildSha256']=hashlib.sha256(worker.read_bytes()).hexdigest();request['operation']=str(uuid.uuid4());body=json.dumps(request);args[-1]=hashlib.sha256(body.encode()).hexdigest();(target/'diagnostic-request.json').write_text(body)
history={str(p.relative_to(target)):hashlib.sha256(p.read_bytes()).hexdigest() for p in target.glob('media/**/complete.json')};ready=[]
def packet(line):
 x=json.loads(line)
 if x.get('event')=='ready':
  assert x['operation']==request['operation'] and x['requestDigest']==args[-1];ready.append(x);(target/'media/comp-spans'/request['operation']/'start.request').write_text('Owned portability diagnostic start\n')
result=observe(args,body,packet,timeout=65);(r/'portable-replay/result.json').write_text(diagnostic(result));print(diagnostic(result),flush=True)
assert result.returncode==0 and len(ready)==1 and not result.observation_timed_out and not result.retirement_pending
assert history=={n:hashlib.sha256((target/n).read_bytes()).hexdigest() for n in history}
assert (source/'project.json').read_bytes()==(target/'project.json').read_bytes()
(r/'portable-replay/verification.json').write_text(json.dumps(dict(passed=True,originalHistoryMarkersUnchanged=True,projectUnchanged=True,newWorkerSha256=request['executor']['buildSha256'],diagnosticOnly=True,installedUIQualified=False),indent=2)+'\n')
