from pathlib import Path
import json,shutil,subprocess,hashlib,time
r=Path(__file__).resolve().parent;source=r/'app/project-été-Κиїв';target=r/'worker-probe/project-été-Κиїв';assert not target.exists();shutil.copytree(source,target)
pair=json.loads((source/'media/comp-pairs/b11cbea0-e82b-4d23-896f-fb2469acc2da.json').read_text());child=pair['children'][0];policy=pair['policy'];exe=Path('/home/rich/.local/opt/soundcurrent-daw/previews/0.1.0~preview.20261015124133.258016450f93/usr/bin/sc-comp-span-worker');assert hashlib.sha256(exe.read_bytes()).hexdigest()==pair['workerSha256']
request=(target/'media/comp-requests'/(child['operation']+'.json')).read_bytes();assert hashlib.sha256(request).hexdigest()==child['requestDigest']
args=[str(exe),'--project-root',str(target),'--jobs-root',str(target/'media/comp-spans'),'--memory-mib',str(policy['memoryBytes']//1048576),'--maximum-source-bytes',str(policy['maximumSourceBytes']),'--maximum-output-bytes',str(policy['maximumOutputBytes']),'--deadline-ms',str(policy['deadlineMilliseconds']),'--request-sha256',child['requestDigest']]
started=time.monotonic();p=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
canceled=False
try:out,err=p.communicate(request,timeout=10)
except subprocess.TimeoutExpired:
 job=target/'media/comp-spans'/child['operation']
 assert job.is_dir(),'Diagnostic still live before job readiness; preserve process'
 (job/'cancel.request').write_text('Owned diagnostic cancellation after ready observation\n');canceled=True
 out,err=p.communicate(timeout=10)
(r/'worker-probe/stdout.txt').write_bytes(out);(r/'worker-probe/stderr.txt').write_bytes(err)
report={'args':args,'pid':p.pid,'exit':p.returncode,'elapsed':time.monotonic()-started,'canceledAfterReady':canceled,'stdoutBytes':len(out),'stderr':err.decode(errors='replace')};(r/'worker-probe/result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
