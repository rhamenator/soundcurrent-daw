from access import *
import threading,hashlib
click(find('Select a clip','combo box'));subprocess.run(['xdotool','key','Home','Down','Down','Return'],check=True);time.sleep(.2)
click(find('Use retained-take handles','check box'));time.sleep(.1)
click(find('Render extended processed handles (preview)','check box'));time.sleep(.1)
assert Atspi.EditableText.set_text_contents(find('Start (project frames)','text'),'13968')
assert Atspi.EditableText.set_text_contents(find('End (project frames, exclusive)','text'),'14032')
click(find('Equal gain · linear','combo box'));subprocess.run(['xdotool','key','End','Return'],check=True);time.sleep(.2)
snapshot('render-settings')
workers={};stop=threading.Event();started=time.monotonic()
def observe():
 while not stop.wait(.025):
  try:
   ids=Path('/proc',str(d['pid']),'task',str(d['pid']),'children').read_text().split()
   for pid in ids:
    if pid in workers:continue
    try:
     exe=Path('/proc',pid,'exe').resolve();cmd=Path('/proc',pid,'cmdline').read_bytes().replace(b'\0',b' ').decode()
     if exe.name.startswith('sc-'):
      workers[pid]={'pid':int(pid),'exe':str(exe),'sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'command':cmd,'firstObservedMilliseconds':int(1000*(time.monotonic()-started))}
    except (OSError,UnicodeDecodeError):pass
  except OSError:pass
thread=threading.Thread(target=observe);thread.start();report={'deadlineSeconds':30,'passed':False}
try:
 click(find('Save and render','button'))
 deadline=time.monotonic()+30
 while time.monotonic()<deadline:
  buttons=[a for path,a in walk(root) if a.get_name()=='Review rendered transition' and a.get_role_name()=='button']
  if len(buttons)==1 and buttons[0].get_state_set().contains(Atspi.StateType.ENABLED):break
  time.sleep(.2)
 else:raise TimeoutError('Installed transition did not finish within 30s')
 report['renderMilliseconds']=int(1000*(time.monotonic()-started));snapshot('render-completed')
 click(buttons[0]);time.sleep(.4)
 snapshot('review-open');report['passed']=True
finally:
 stop.set();thread.join();report['workers']=list(workers.values())
 for w in report['workers']:w['retired']=not Path('/proc',str(w['pid'])).exists()
 (base/'render-observation.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report))
