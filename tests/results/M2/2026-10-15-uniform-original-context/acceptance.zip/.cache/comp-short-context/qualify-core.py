from pathlib import Path
import subprocess,json,hashlib,time,tempfile
base=Path('.cache/comp-short-context');repo=Path.cwd()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],text=True)
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
source={str(p):sha(p) for p in [Path('src/comp_uniform_context.cpp'),Path('include/soundcurrent/comp_uniform_context.hpp'),Path('tests/comp_uniform_context_tests.cpp'),Path('CMakeLists.txt')]}
results=[]
for mode,build,pattern in [('Release',Path('.cache/comp-pair-recovery/build'),'^(comp-uniform-original-context|comp-uniform-span-render)$'),('Debug',Path('.cache/comp-history-sharing/build-debug'),'^comp-uniform-original-context$')]:
 root=Path(tempfile.mkdtemp(prefix='qualified-core-'+mode+'-',dir=base));commands=[]
 command=['cmake','--build',str(build),'--parallel','1','--target','sc-comp-uniform-context-tests','sc-comp-span-render-tests'];commands.append(command)
 with (root/'build.log').open('w') as out:subprocess.run(command,stdout=out,stderr=subprocess.STDOUT,check=True)
 binary=build/'sc-comp-uniform-context-tests';before=sha(binary)
 evidence=build/'comp-uniform-context-evidence';existing=set(evidence.glob('run-*'))
 command=['ctest','--test-dir',str(build),'-R',pattern,'--output-on-failure','--parallel','1'];commands.append(command);start=time.monotonic()
 with (root/'ctest.log').open('w') as out:result=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 seconds=time.monotonic()-start
 receipt=dict(configuration=mode,sourceHead=head,sourceHashes=source,commands=commands,exitCode=result.returncode,seconds=seconds,binary=str(binary),binarySha256=before,binaryUnchanged=before==sha(binary),sourceUnchanged=all(sha(Path(p))==v for p,v in source.items()),newRuns=[str(p) for p in sorted(set(evidence.glob('run-*'))-existing)])
 (root/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');results.append(receipt)
 print(json.dumps(dict(configuration=mode,exitCode=result.returncode,seconds=seconds,receipt=str(root/'receipt.json'))),flush=True)
 assert result.returncode==0 and receipt['binaryUnchanged'] and receipt['sourceUnchanged']
command=['x86_64-w64-mingw32-g++','-std=c++20','-Wall','-Wextra','-Wpedantic','-fno-fast-math','-fsyntax-only','-Iinclude','-Isrc','-isystem','third_party','-isystem','third_party/rubberband','src/comp_uniform_context.cpp','tests/comp_uniform_context_tests.cpp']
with (base/'core-mingw.log').open('w') as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
(base/'core-qualification.json').write_text(json.dumps(dict(sourceHead=head,rows=results,mingwCommand=command,mingwExitCode=r.returncode,nativeRuntime=False,workerIntegration=False),indent=2)+'\n');assert r.returncode==0
