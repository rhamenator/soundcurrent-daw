from pathlib import Path
import json,hashlib,gzip,subprocess
p=Path('.cache/native-monitor-controller/runtime-ci-review');out=Path('tests/results/M2/2026-10-11-native-controller-windows-runtime');b=json.loads(Path('.cache/native-monitor-controller/pr149-tested-merge.json').read_text());run=json.loads((p/'run.json').read_text());jobs=json.loads((p/'jobs.json').read_text());assert run['id']==38187386783 and run['head_sha']==b['head'] and run['status']=='completed' and run['conclusion']=='failure'
paths=[p/'retain.py',p/'run.json',p/'jobs.json',p/'artifacts.json',p/'native-artifact-selected.json',Path('.cache/native-monitor-controller/pr149-tested-merge.json')];bindings={}
assert len(jobs['jobs'])==4
for j in jobs['jobs']:
 assert j['status']=='completed' and j['head_sha']==b['head'] and j['run_id']==run['id'];f=p/('job-'+str(j['id'])+'.log');raw=f.read_bytes();text=raw.decode('utf-8-sig');assert b['mergeRef'] in text and b['head'] in text and b['base'] in text;paths.append(f);bindings[str(j['id'])]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'conclusion':j['conclusion']}
for n,x in b['files'].items():assert hashlib.sha256(subprocess.check_output(['git','show',b['mergeRef']+':'+n])).hexdigest()==x['sha256']
m=json.loads((p/'native-artifact-selected.json').read_text());assert hashlib.sha256((p/'native-artifact.zip').read_bytes()).hexdigest()==m['zipSha256']
for x in m['selected']:
 f=p/x['file'];assert hashlib.sha256(f.read_bytes()).hexdigest()==x['sha256'];paths.append(f)
log=(p/'Testing_Temporary_LastTest.log').read_text();assert log.count('native_desktop_controller ')==3 and log.count('owned_native_recording source_rate=')==6 and '5919255 composed native monitor startup checks passed; guarded allocate/free/lock=0' in log
for n in range(1,4):assert 'original_concurrent_owner_diagnostic completed20takes; original5sdeadline; native_audio=false' in (p/('manual-owner-'+str(n)+'-stdout.log')).read_text() and not (p/('manual-owner-'+str(n)+'-stderr.log')).read_bytes()
assert 'manual-recording-control ................***Timeout  60.11 sec' in (p/'job-114612558889.log').read_text()
assert 'UI changed: run tools/localization.py --update' in (p/'job-114612558915.log').read_text()
out.mkdir(exist_ok=False);members={}
for f in paths:
 raw=f.read_bytes();data=gzip.compress(raw,mtime=0);n=f.name+'.gz';assert n not in members;(out/n).write_bytes(data);members[n]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'originalBytes':len(raw),'originalSha256':hashlib.sha256(raw).hexdigest(),'lossless':True}
summary={'pr':149,'run':run['id'],'head':b['head'],'base':b['base'],'testedMerge':b['mergeRef'],'tree':b['tree'],'changedBlobBindings':len(b['files']),'qualifiedInputCount':702,'terminalJobBindings':bindings,'nativeControllerCasesPassed':True,'native70CTestPassedOneTimeout':True,'nativeFailedSuite':'manual-recording-control','outerOriginalTimeoutSeconds':60,'observedTimeoutSeconds':60.11,'nativeThreeOriginalStandaloneCompletions':True,'desktop19SuitesPassed':True,'linux141PassedTwoCatalogFailures':True,'linuxFailureCause':'UI source inventory did not include three new native controller source files','previousDesktopWatchdogCauseResolved':False,'nativeManualTimeoutCauseResolved':False,'binariesOrMediaIncluded':False,'physicalAudioQualified':False}
raw=(json.dumps(summary,indent=2)+'\n').encode();(out/'summary.json').write_bytes(raw);members['summary.json']={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()};(out/'manifest.json').write_text(json.dumps({'members':members,'scope':'PR149 original terminal failures and actual Windows controller execution; all four original job logs/eight artifact logs/exact tested source and artifact bindings; no ZIP/binary/audio'},indent=2)+'\n');print('Retained149 actual controller Windows execution plus original failures',len(members),'bound files',sum(f.stat().st_size for f in out.iterdir()),'bytes')
