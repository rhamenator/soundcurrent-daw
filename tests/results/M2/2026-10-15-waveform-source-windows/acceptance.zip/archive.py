from pathlib import Path
import hashlib,json,subprocess,zipfile
r=Path(__file__).resolve().parent;repo=r.parents[1]
out=repo/'tests/results/M2/2026-10-15-waveform-source-windows';out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
parent='36013b79d713c86a1c10da4f765ec337573e0d57'
paths=subprocess.check_output(['git','diff','--name-only',parent,head],text=True).splitlines()
assert paths and all(p.startswith(('include/','src/','tools/','ui/','tests/')) and not p.startswith('tests/results/') for p in paths)
files={}
for n in ['build.log','build-final.log','build-test-refresh.log','ctest.log','release-LastTest.log','sanitizer-build.log','sanitizer-ctest.log','sanitizer-LastTest.log','integration-build.log','integration-ctest.log','integration-LastTest.log','ci-observation.json','ci-latest.json','archive.py','window-final.png']:
 files[n]=(r/n).read_bytes()
for n in ['integration-ctest.log','sanitizer-ctest.log']:assert b'100% tests passed' in files[n]
files['source.patch']=subprocess.check_output(['git','diff','--binary',parent,head])
for p in paths:files['source/'+p]=(repo/p).read_bytes()
builds={}
for directory,label in [('.cache/take-preview-linux/build','release'),('.cache/build-desktop-sanitized','sanitizer')]:
 builds[label]={}
 for n in ['sc-waveform-worker','sc-waveform-tests','sc-waveform-protocol-tests','sc-waveform-controller-tests','sc-waveform-cache-tests','sc-timeline-waveform-tests']+(['sc-studio-waveform-tests','sc-gui-resource-tests','sc-timeline-ui-tests'] if label=='release' else []):
  p=repo/directory/n
  builds[label][n]=dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(p.open('rb'),'sha256').hexdigest())
files['tested-builds.json']=(json.dumps(builds,indent=2)+'\n').encode()
files['commands.txt']=b'''All builds: nice -n 15 ionice -c 3 cmake --build BUILD --parallel 1 --target TARGETS
Release BUILD: .cache/take-preview-linux/build
Release TARGETS: sc-waveform-tests sc-waveform-protocol-tests sc-waveform-worker sc-waveform-controller-tests sc-waveform-cache-tests sc-timeline-waveform-tests sc-studio-waveform-tests sc-gui-resource-tests sc-timeline-ui-tests
Release: SC_WINDOW_WAVEFORM_CAPTURE=.../window-final.png nice -n 15 ionice -c 3 ctest --test-dir BUILD --parallel 1 --output-on-failure -R '^(waveform-source-pyramid|waveform-reply-protocol|waveform-worker-workflows|desktop-waveform-controller|desktop-waveform-cache|desktop-timeline-waveforms|desktop-studio-waveforms|desktop-gui-resources|desktop-timeline)$'
Sanitizer BUILD: .cache/build-desktop-sanitized
Sanitizer TARGETS: same first six Release targets.
Sanitizer: ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 nice -n 15 ionice -c 3 ctest --test-dir BUILD --parallel 1 --output-on-failure -R '^(waveform-source-pyramid|waveform-reply-protocol|waveform-worker-workflows|desktop-waveform-controller|desktop-waveform-cache|desktop-timeline-waveforms)$'
Sanitizer compiler flags: -fsanitize=address,undefined -fno-omit-frame-pointer -fPIC (Debug)
The initial build/release logs precede final additions; integration-* and sanitizer-* are the final acceptance runs. No VM/physical audio. No native Windows execution claim.
'''
index={n:dict(bytes=len(b),sha256=sha(b)) for n,b in files.items()}
files['payload-manifest.json']=(json.dumps(index,indent=2)+'\n').encode()
p=out/'acceptance.zip'
with zipfile.ZipFile(p,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,b in files.items():z.writestr(n,b)
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 for n,v in index.items():assert len(z.read(n))==v['bytes'] and sha(z.read(n))==v['sha256']
report=dict(archive=p.name,bytes=p.stat().st_size,sha256=sha(p.read_bytes()),entries=len(files),sourceHead=head,sourceParent=parent,sourceFiles=len(paths),releaseSuites=9,sanitizerSuites=6,asanUbsanLeakDetection=True,isolatedWorkerCases=117,sourceChannelsTested=[1,2,8,257,1024],croppedRenderedWindow=True,sourceFrames=262144,cropFirst=120001,cropFrames=1000,denseSources=72,densePeakReservedBytes=183701472,windowWireVersion=2,wholeSourceValidationStillRequired=True,nativeWindowsQualified=False,installedPreviewsChanged=False,physicalAudio=False,fullSuiteParity=False)
(out/'manifest.json').write_text(json.dumps(report,indent=2)+'\n')
(out/'window.png').write_bytes(files['window-final.png']);print(json.dumps(report))
