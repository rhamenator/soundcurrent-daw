from pathlib import Path
import json,subprocess,shlex,hashlib,shutil
r=Path('.cache/native-recording-panel');f=json.loads((r/'frozen-inputs.json').read_text());prior=Path('.cache/native-command-admission');old=json.loads((prior/'frozen-inputs.json').read_text());q=json.loads((prior/'corrected-qualified-profiles.json').read_text());head=f['source'];prefix=['nice','-n','15','ionice','-c','2','-n','7'];profiles={};commands=[]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
changed=set(subprocess.check_output(['git','diff','--name-only',old['source'],head],text=True).splitlines())
for x in old['selectedInputs']:
 if x['path'] not in changed:assert sha(x['path'])==x['checkoutSha256']
def checked():
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head and not subprocess.check_output(['git','status','--porcelain'],text=True)
 for x in f['selectedInputs']:assert sha(x['path'])==x['checkoutSha256']
for label,ctype,flags in [('release','Release',''),('sanitizer','Debug','-fsanitize=address,undefined -fno-omit-frame-pointer'),('tsan','Debug','-fsanitize=thread -fno-omit-frame-pointer -O1')]:
 b=(r/('qualified-'+label)).resolve();objects={};archives={};reused={};private={}
 def run(stage,argv,cwd=None):
  checked();cmd=prefix+argv;commands.append({'profile':label,'stage':stage,'argv':cmd,'cwd':str(cwd or Path.cwd())});(r/'qualification-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
  with (r/(label+'-'+stage+'.log')).open('w') as out:p=subprocess.run(cmd,cwd=cwd,stdout=out,stderr=subprocess.STDOUT)
  if p.returncode:raise SystemExit(label+' '+stage+' failed; original retained')
 print('Starting',label,flush=True)
 assert sha(prior/('corrected-'+label)/'sc-native-monitor-startup-tests')==q['profiles'][label]['exeSha256']
 run('configure',['cmake','-S','.','-B',str(b),'-G','Ninja','-DCMAKE_BUILD_TYPE='+ctype,'-DSC_BUILD_DESKTOP=ON','-DSC_BUILD_MEDIA=ON','-DCMAKE_CXX_FLAGS='+flags,'-DCMAKE_EXE_LINKER_FLAGS='+flags])
 gen=subprocess.check_output(['ninja','-C',str(b),'-t','commands','sc-native-panel-tests','sc-native-monitor-startup-tests'],text=True);(r/(label+'-generated-commands.txt')).write_text(gen)
 for line in gen.splitlines():
  if ' -c ' not in line:continue
  a=shlex.split(line);obj=a[a.index('-o')+1]
  if any(x in obj for x in ['sc-ui-native-recording.dir/','sc-native-monitor-controller.dir/','sc-native-panel-tests.dir/','tests/native_monitor_recording_tests.cpp.o']):
   (b/obj).parent.mkdir(parents=True,exist_ok=True);run('compile-'+str(len(objects)),a,b);assert 'warning:' not in (r/(label+'-compile-'+str(len(objects))+'.log')).read_text();objects[obj]={'bytes':(b/obj).stat().st_size,'sha256':sha(b/obj)}
 assert len(objects)==5
 for target in ['sc-ui-native-recording','sc-native-monitor-controller']:
  name='lib'+target+'.a';run(target+'-archive',['ar','r',name,*[n for n in objects if target+'.dir/' in n]],b);run(target+'-index',['ranlib',name],b);private[name]=sha(b/name)
 for i,line in enumerate(x for x in gen.splitlines() if ' -o sc-native-panel-tests ' in x or ' -o sc-native-monitor-startup-tests ' in x):
  a=shlex.split(line)[2:-2]
  for n,x in enumerate(a):
   if x.endswith('.a') and not Path(x).is_absolute() and x not in private:
    rec=q['profiles'][label]['readOnlyArchives'][x];assert sha(rec['path'])==rec['sha256'];a[n]=rec['path'];archives[x]=rec
   if x.endswith('.o') and x not in objects:
    rec=q['profiles'][label]['readOnlyObjects'][x];assert sha(rec['path'])==rec['sha256'];a[n]=rec['path'];reused[x]=rec
  run('link-'+str(i),a,b)
 run('tests',['env','QT_QPA_PLATFORM=offscreen','ctest','--test-dir',str(b),'-R','^(desktop-native-recording-panel|native-monitor-startup)$','--output-on-failure','--no-tests=error'])
 assert '100% tests passed, 0 tests failed out of 2' in (r/(label+'-tests.log')).read_text();shutil.copyfile(b/'Testing/Temporary/LastTest.log',r/(label+'-LastTest.log'));shutil.copyfile(b/'CMakeCache.txt',r/(label+'-CMakeCache.txt'))
 log=(r/(label+'-LastTest.log')).read_text();assert 'native_panel finite=true visible_eq_effect=true' in log and 'active_close_async=true' in log and 'guarded allocate/free/lock=0' in log
 for x in archives.values():assert sha(x['path'])==x['sha256']
 profiles[label]={'objects':objects,'privateArchives':private,'readOnlyArchives':archives,'readOnlyObjects':reused,'exeHashes':{n:sha(b/n)for n in ['sc-native-panel-tests','sc-native-monitor-startup-tests']}}
 (r/'qualified-profiles.json').write_text(json.dumps({'source':head,'tree':f['tree'],'sourceInputs':len(f['selectedInputs']),'profiles':profiles,'windowsRuntimeExecuted':False},indent=2)+'\n');print('Passed',label,flush=True)
print('All three panel profiles passed',flush=True)
