from pathlib import Path
import json,hashlib,gzip,subprocess,re,shutil
r=Path('.cache/native-recording-panel');out=Path('tests/results/M2/2026-10-11-native-recording-panel');f=json.loads((r/'frozen-inputs.json').read_text());q=json.loads((r/'qualified-profiles.json').read_text());w=json.loads((r/'windows-qualification.json').read_text());t=json.loads((r/'tsan-scope.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==f['source'] and subprocess.check_output(['git','status','--porcelain'],text=True).splitlines()==['?? tests/results/M2/2026-10-11-command-admission-windows-runtime/']
assert f['source']==q['source']==w['source']==t['source'] and len(f['selectedInputs'])==784 and set(q['profiles'])=={'release','sanitizer'}
for x in f['selectedInputs']:assert sha(x['path'])==x['checkoutSha256']
names=['freeze-inputs.py','qualify.py','qualify-windows.py','retain.py','frozen-inputs.json','qualified-profiles.json','windows-qualification.json','tsan-scope.json','qualification-commands.json','qualification.log','windows-qualification.log','catalog-update.log','catalog-refusals.log','render-review.log']
times={}
for label,p in q['profiles'].items():
 b=r/('qualified-'+label)
 for n,h in p['exeHashes'].items():assert sha(b/n)==h
 for n,x in p['objects'].items():assert sha(b/n)==x['sha256']
 for n,h in p['privateArchives'].items():assert sha(b/n)==h
 for x in list(p['readOnlyArchives'].values())+list(p['readOnlyObjects'].values()):assert sha(x['path'])==x['sha256']
 times[label]=float(re.search(r'Total Test time \(real\) =\s+([0-9.]+)',(r/(label+'-tests.log')).read_text())[1])
for label in ['release','sanitizer','tsan']:
 names += [label+'-'+n+'.log'for n in ['configure','tests','compile-0','compile-1','compile-2','compile-3','compile-4','link-0','link-1','sc-ui-native-recording-archive','sc-ui-native-recording-index','sc-native-monitor-controller-archive','sc-native-monitor-controller-index']]+[label+'-generated-commands.txt']
 for n in ['LastTest.log','CMakeCache.txt']:
  p=r/(label+'-'+n)
  if p.exists():names.append(p.name)
for x in w['objects'].values():assert sha(x['argv'][-1])==x['sha256']
names += ['windows-compile-'+str(n)+'.log'for n in range(4)]
for tag in ['first-panel-observation-failure','first-bypass-peak-assumption-failure','first-gui-tsan-framework-reports']:
 for p in (r/tag).iterdir():
  if p.is_file():names.append(str(p.relative_to(r)))
out.mkdir(exist_ok=False);members={}
for n in sorted(set(names)):
 raw=(r/n).read_bytes();data=gzip.compress(raw,mtime=0);dest=n.replace('/','--')+'.gz';(out/dest).write_bytes(data);members[dest]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'originalBytes':len(raw),'originalSha256':hashlib.sha256(raw).hexdigest(),'lossless':True}
shutil.copyfile(r/'panel-ready.png',out/'panel-ready.png');members['panel-ready.png']={'bytes':(out/'panel-ready.png').stat().st_size,'sha256':sha(out/'panel-ready.png')}
summary={'source':f['source'],'tree':f['tree'],'sourceInputs':784,'linuxTwoSuiteTimesSeconds':times,'visiblePanelFunctional':True,'realControlProcessingDiskWorkers':True,'sdkOperationsSimulated':True,'asyncCloseRetainsResultsAndJoins':True,'panelContextAndFixedControlsAdmitted':True,'sameSharedFixtureExceptJoinedLastOutputDiagnostic':True,'nativeStartupTsanPassed':True,'guiTsanQualified':False,'guiTsanReportsRetained':22,'blanketSuppressionOrUnchangedRetryUsed':False,'fourCurrentCoreWindowsObjectsCompiled':True,'currentGuiWindowsRuntimeExecuted':False,'deviceContextFromCallerWorkerInventory':True,'studioWindowDefaultFactoryEnabled':False,'fullGuiSnapshotResultOwnershipQualified':False,'physicalEndpointsTested':False,'binaryOrAudioPayloadIncluded':False,'screenshotIncluded':True,'fullGoalComplete':False}
raw=(json.dumps(summary,indent=2)+'\n').encode();(out/'summary.json').write_bytes(raw);members['summary.json']={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()};(out/'manifest.json').write_text(json.dumps({'members':members,'scope':'Visible Qt native recording panel; Release/ASanUBSan functional acceptance, native-startup TSan pass and GUI TSan reports retained unqualified; commands/source/logs/hash and own UI screenshot only'},indent=2)+'\n');print('Retained panel',len(members),'bound files',sum(p.stat().st_size for p in out.iterdir()),'bytes')
