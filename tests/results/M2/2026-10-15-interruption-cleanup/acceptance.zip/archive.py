from pathlib import Path
import hashlib,json,subprocess,zipfile
r=Path('.cache/windows-interruption-cleanup-328');dest=Path('tests/results/M2/2026-10-15-interruption-cleanup');dest.mkdir(exist_ok=False)
files={p.name:p.read_bytes() for p in r.iterdir() if p.is_file()}
files['original-desktop-job.log']=Path('.cache/windows-comp-timing-327/ci/job-116532099560.log').read_bytes()
files['original-desktop-artifact.zip']=Path('.cache/windows-comp-timing-327/ci/artifact-11989789178.zip').read_bytes()
files['cleanup.patch']=subprocess.check_output(['git','diff','--','tests/stretch_parent_interruption_windows.py','.github/workflows/ci.yml'])
files['parent_interruption_cleanup_tests.py']=Path('tests/parent_interruption_cleanup_tests.py').read_bytes()
manifest=[dict(path=n,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()) for n,b in files.items()]
files['payload-manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
archive=dest/'acceptance.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
 for n,b in files.items():z.writestr(n,b)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for row in manifest:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
out=dict(archive=archive.name,bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),entries=len(files),baseHead='8c2e4474111c16a66ef16a85abb2211c8cebaca0',faultInjectionTests=8,nativeReplayPerformed=False,originalCiFailureResolved=False)
(dest/'manifest.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
