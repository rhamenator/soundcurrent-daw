from pathlib import Path
import hashlib,json,subprocess,zipfile
r=Path(__file__).resolve().parent;repo=r.parents[1];out=repo/'tests/results/M2/2026-10-15-waveform-coverage-reuse';out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(p.read_text())
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();parent='2ef206571c2d47ea7c62a85b76ac71d1f355a893'
paths=subprocess.check_output(['git','diff','--name-only',parent,head],text=True).splitlines();assert len(paths)==8
assert all(p.startswith(('include/','src/','ui/','tests/')) and not p.startswith('tests/results/') for p in paths)
files={}
for n in ['build.log','ctest.log','LastTest.log','sanitizer-build.log','sanitizer-ctest.log','sanitizer-LastTest.log','final-build.log','final-ctest.log','final-LastTest.log','ci-observation.json','ci-retention.log','window-final.png','archive.py']:
 files[n]=(r/n).read_bytes()
for n in ['final-ctest.log','sanitizer-ctest.log']:assert b'100% tests passed' in files[n]
for p in (r/'ci').iterdir():
 if p.suffix in ['.log','.json']:files['ci/'+p.name]=p.read_bytes()
retained=load(r/'ci/retention.json');assert retained['conclusion']=='success' and len(retained['jobs'])==15 and len(retained['artifacts'])==12 and retained['allAvailableOriginalArchivesRetained'] and retained['allFullLogsRetained']
files['source.patch']=subprocess.check_output(['git','diff','--binary',parent,head])
for n in paths:files['source/'+n]=(repo/n).read_bytes()
builds={}
for folder,label in [('.cache/take-preview-linux/build','release'),('.cache/build-desktop-sanitized','sanitizer')]:
 builds[label]={}
 for n in ['sc-waveform-tests','sc-waveform-worker','sc-waveform-cache-tests','sc-timeline-waveform-tests']+(['sc-studio-waveform-tests','sc-gui-resource-tests'] if label=='release' else []):
  p=repo/folder/n;builds[label][n]=dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(p.open('rb'),'sha256').hexdigest())
files['tested-builds.json']=(json.dumps(builds,indent=2)+'\n').encode()
files['commands.txt']=b'''Builds: nice -n 15 ionice -c 3 cmake --build BUILD --parallel 1 --target TARGETS
Final Release BUILD=.cache/take-preview-linux/build; TARGETS=sc-waveform-tests sc-waveform-worker sc-waveform-cache-tests sc-timeline-waveform-tests sc-studio-waveform-tests sc-gui-resource-tests
Final Release: SC_WINDOW_WAVEFORM_CAPTURE=.../window-final.png nice -n 15 ionice -c 3 ctest --test-dir BUILD --parallel 1 --output-on-failure -R '^(waveform-source-pyramid|desktop-waveform-cache|desktop-timeline-waveforms|desktop-studio-waveforms|desktop-gui-resources)$'
Sanitizer BUILD=.cache/build-desktop-sanitized; TARGETS=first four Release targets.
Sanitizer: ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 nice -n 15 ionice -c 3 ctest --test-dir BUILD --parallel 1 --output-on-failure -R '^(waveform-source-pyramid|desktop-waveform-cache|desktop-timeline-waveforms)$'
Sanitizer Debug flags: -fsanitize=address,undefined -fno-omit-frame-pointer -fPIC
Initial build/ctest/LastTest precede final empty-window guard; final-* and sanitizer-* are final acceptance.
CI original 15 terminal logs and 12 ZIPs retained before PR advancement. ZIP hashes/identities are in ci/retention.json; the large ZIP files remain in local .cache/waveform-reuse-357/ci. This is prior-head hosted evidence, not native Windows qualification of this source.
No VM, physical audio or installed binary change.
'''
index={n:dict(bytes=len(b),sha256=sha(b)) for n,b in files.items()};files['payload-manifest.json']=(json.dumps(index,indent=2)+'\n').encode()
p=out/'acceptance.zip'
with zipfile.ZipFile(p,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,b in files.items():z.writestr(n,b)
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 for n,v in index.items():assert len(z.read(n))==v['bytes'] and sha(z.read(n))==v['sha256']
report=dict(archive=p.name,bytes=p.stat().st_size,sha256=sha(p.read_bytes()),entries=len(files),sourceHead=head,sourceParent=parent,sourceFiles=len(paths),releaseSuites=5,sanitizerSuites=3,asanUbsanLeakDetection=True,coveredMovementRetainsModel=True,coveredMovementRetainsInFlightOperation=True,coarseAndOverBudgetReuseRefused=True,uncoveredMovementPreparesAgain=True,denseSources=72,densePeakReservedBytes=192917472,priorCiRun=38826291512,priorCiHead=retained['head'],priorCiConclusion='success',originalTerminalLogsRetained=15,originalArtifactZipsRetained=12,nativeWindowsQualified=False,installedPreviewsChanged=False,physicalAudio=False,fullSuiteParity=False)
(out/'manifest.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
