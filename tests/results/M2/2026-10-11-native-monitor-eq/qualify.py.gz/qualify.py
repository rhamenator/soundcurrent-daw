from pathlib import Path
import subprocess,json,hashlib,shlex,shutil,re
r=Path('.cache/native-monitor-eq');prior=Path('.cache/native-monitor-recording-owner');q=json.loads((prior/'qualified-profiles.json').read_text());old=json.loads((prior/'frozen-inputs.json').read_text());f=json.loads((r/'frozen-inputs.json').read_text());head=f['source'];prefix=['nice','-n','15','ionice','-c','2','-n','7'];commands=[];profiles={};changed=set(subprocess.check_output(['git','diff','--name-only',old['source'],head],text=True).splitlines())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def checked():
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head and not subprocess.check_output(['git','status','--porcelain'],text=True)
 for x in f['selectedInputs']:assert sha(x['path'])==x['checkoutSha256']
checked()
for x in old['selectedInputs']:
 if x['path'] not in changed:assert sha(x['path'])==x['checkoutSha256']
for label,ctype,flags,linkflags in [('release','Release','',''),('sanitizer','Debug','-fsanitize=address,undefined -fno-omit-frame-pointer','-fsanitize=address,undefined'),('tsan','Debug','-fsanitize=thread -fno-omit-frame-pointer -O1','-fsanitize=thread')]:
 b=(r/('build-'+label)).resolve();previous=(prior/('build-'+label)).resolve();archives={};objects={}
 def run(stage,argv,cwd=None):
  checked();cmd=prefix+argv;commands.append({'profile':label,'stage':stage,'cwd':str(cwd or Path.cwd()),'argv':cmd});(r/'qualification-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
  with (r/(label+'-'+stage+'.log')).open('w') as out:p=subprocess.run(cmd,cwd=cwd,stdout=out,stderr=subprocess.STDOUT)
  if p.returncode:raise SystemExit(label+' '+stage+' failed; original retained')
 print('Starting',label,flush=True);assert sha(previous/'sc-native-monitor-startup-tests')==q['profiles'][label]['exeSha256']
 run('configure',['cmake','-S','.','-B',str(b),'-G','Ninja','-DCMAKE_BUILD_TYPE='+ctype,'-DSC_BUILD_DESKTOP=OFF','-DSC_BUILD_MEDIA=ON','-DCMAKE_CXX_FLAGS='+flags,'-DCMAKE_EXE_LINKER_FLAGS='+linkflags])
 gen=subprocess.check_output(['ninja','-C',str(b),'-t','commands','sc-native-monitor-startup-tests','sc-native-original-recording-tests'],text=True);(r/(label+'-generated-commands.txt')).write_text(gen)
 compiles={}
 for line in gen.splitlines():
  if ' -c ' not in line:continue
  argv=shlex.split(line);obj=argv[argv.index('-o')+1]
  if any(n in obj for n in ['sc-monitor-processing.dir/','sc-native-original-recording.dir/','sc-native-monitor-recording.dir/','sc-native-monitor-startup-tests.dir/','sc-native-original-recording-tests.dir/']):compiles[obj]=argv
 assert len(compiles)==18
 for n,(obj,argv) in enumerate(compiles.items()):
  (b/obj).parent.mkdir(parents=True,exist_ok=True);run('compile-'+str(n),argv,b);assert 'warning:' not in (r/(label+'-compile-'+str(n)+'.log')).read_text();objects[obj]={'bytes':(b/obj).stat().st_size,'sha256':sha(b/obj)}
 for name,target in [('processing','sc-monitor-processing'),('native-state','sc-native-original-recording'),('owner','sc-native-monitor-recording')]:
  members=[obj for obj in compiles if 'CMakeFiles/'+target+'.dir/' in obj];assert members
  run(name+'-archive',['/usr/bin/ar','r','lib'+target+'.a',*members],b);run(name+'-index',['/usr/bin/ranlib','lib'+target+'.a'],b)
 links=[shlex.split(s) for s in gen.splitlines() if ' -o sc-native-monitor-startup-tests ' in s or ' -o sc-native-original-recording-tests ' in s];assert len(links)==2
 for n,argv in enumerate(links):
  assert argv[:2]==[':','&&'] and argv[-2:]==['&&',':'];argv=argv[2:-2];assert '-Wl,--wrap=pthread_mutex_lock' in argv
  for k,a in enumerate(argv):
   if not a.startswith('-') and a.endswith('.a') and not Path(a).is_absolute() and a not in {'libsc-monitor-processing.a','libsc-native-original-recording.a','libsc-native-monitor-recording.a'}:
    p=previous/a
    if not p.is_file():p=Path(q['profiles'][label]['readOnlyArchives'][a]['path'])
    archives[a]={'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)};argv[k]=str(p)
  run('link-'+str(n),argv,b)
 for x in archives.values():assert sha(x['path'])==x['sha256']
 run('tests',['ctest','--test-dir',str(b),'-R','^(native-monitor-startup|original-native-outcomes)$','--output-on-failure','--no-tests=error'])
 assert '100% tests passed, 0 tests failed out of 2' in (r/(label+'-tests.log')).read_text();shutil.copyfile(b/'Testing/Temporary/LastTest.log',r/(label+'-LastTest.log'));shutil.copyfile(b/'CMakeCache.txt',r/(label+'-CMakeCache.txt'))
 log=(r/(label+'-LastTest.log')).read_text();rows=re.findall(r'^owned_native_recording[^\r\n]*',log,re.M);assert len(rows)==6 and 'equalized=1' in rows[-1] and '2 actual EQ publication process boundaries' in log
 assert 'monitor EQ shared-engine/artifact/ingress checks passed; exact PCM=true' in log and 'guarded allocate/free/lock=0' in log
 profiles[label]={'executableHashes':{n:sha(b/n)for n in ['sc-native-monitor-startup-tests','sc-native-original-recording-tests']},'objects':objects,'readOnlyArchives':archives,'ownedRows':rows,'privateArchives':{n:sha(b/n)for n in ['libsc-monitor-processing.a','libsc-native-original-recording.a','libsc-native-monitor-recording.a']}}
 (r/'qualified-profiles.json').write_text(json.dumps({'source':head,'tree':f['tree'],'profiles':profiles,'nativeWindowsRuntimeExecuted':False},indent=2)+'\n');print('Passed',label,flush=True)
print('All three profiles passed',flush=True)
