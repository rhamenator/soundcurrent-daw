from pathlib import Path
import json,subprocess,hashlib,gzip,re
r=Path('.cache/native-monitor-eq');out=Path('tests/results/M2/2026-10-11-native-monitor-eq');f=json.loads((r/'frozen-inputs.json').read_text());q=json.loads((r/'qualified-profiles.json').read_text());w=json.loads((r/'windows-qualification.json').read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert f['source']==q['source']==w['source'] and len(f['selectedInputs'])==647 and set(q['profiles'])=={'release','sanitizer','tsan'}
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==f['source'] and not subprocess.check_output(['git','status','--porcelain'],text=True)
for x in f['selectedInputs']:assert sha(x['path'])==x['checkoutSha256']
names=['freeze-inputs.py','qualify.py','qualify-windows.py','retain.py','frozen-inputs.json','qualified-profiles.json','windows-qualification.json','qualification-commands.json','qualification.log','windows-qualification.log','source-delta.diff','upstream-eq-review.json']
for label,p in q['profiles'].items():
 b=r/('build-'+label)
 for n,h in p['executableHashes'].items():assert sha(b/n)==h
 for x in p['readOnlyArchives'].values():assert sha(x['path'])==x['sha256']
 for n,h in p['privateArchives'].items():assert sha(b/n)==h
 for n,x in p['objects'].items():assert sha(b/n)==x['sha256']
 for n in ['configure','tests','LastTest','owner-archive','owner-index','processing-archive','processing-index','native-state-archive','native-state-index','link-0','link-1']:names.append(label+'-'+n+'.log')
 names += [label+'-generated-commands.txt',label+'-CMakeCache.txt']+[label+'-compile-'+str(n)+'.log' for n in range(18)]
 log=(r/(label+'-LastTest.log')).read_text();assert log.count('owned_native_recording source_rate=')==6
 assert '63863 monitor EQ shared-engine/artifact/ingress checks passed; exact PCM=true' in log
 assert '2 actual EQ publication process boundaries' in log and 'guarded allocate/free/lock=0' in log
for n,x in w['objects'].items():assert sha(x['argv'][-1])==x['sha256']
names += ['windows-compile-'+str(n)+'.log' for n in range(13)]
for tag in ['first-development-link-helper-failure','first-state-test-compile-failure']:
 for p in (r/tag).rglob('*'):
  if p.is_file() and p.suffix in ['.py','.log','.json','.txt','.cpp']:names.append(str(p.relative_to(r)))
out.mkdir(exist_ok=False);members={}
for name in sorted(set(names)):
 raw=(r/name).read_bytes();packed=gzip.compress(raw,mtime=0);dest=name.replace('/','--')+'.gz';assert gzip.decompress(packed)==raw;(out/dest).write_bytes(packed);members[dest]={'bytes':len(packed),'sha256':hashlib.sha256(packed).hexdigest(),'originalBytes':len(raw),'originalSha256':hashlib.sha256(raw).hexdigest(),'lossless':True}
summary={'source':f['source'],'tree':f['tree'],'sourceInputs':647,'currentObjectsPerLinuxProfile':18,'currentWindowsObjects':13,'linuxTestTimesSeconds':{'release':15.38,'sanitizer':40.35,'tsan':29.31},'sameSharedEnginePCM':True,'realProcessingDiskWorkersExecuted':True,'sdkOperationsSimulated':True,'rawPCMBitExact':True,'nativeStateVersion':'1.3','initialEqDeclarationOnly':True,'currentWindowsNativeLinkOrRuntimeExecuted':False,'physicalAudioQualified':False,'desktopFactoryEnabled':False,'fullGoalComplete':False,'binariesOrMediaIncluded':False}
raw=(json.dumps(summary,indent=2)+'\n').encode();(out/'summary.json').write_bytes(raw);members['summary.json']={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
(out/'manifest.json').write_text(json.dumps({'members':members,'scope':'Two expanded existing suites; Linux Release, ASan/UBSan, TSan; Windows current object compilation only; source/log/config/command/hash assets'},indent=2)+'\n')
print('Retained',len(members),'bound files',sum(p.stat().st_size for p in out.iterdir()),'bytes',flush=True)
