from pathlib import Path
import subprocess,json,shlex,hashlib,shutil
r=Path('.cache/native-monitor-eq');b=(r/'build-release').resolve();prior=Path('.cache/native-monitor-recording-owner');previous=(prior/'build-release').resolve();f=json.loads((prior/'frozen-inputs.json').read_text());commands=[];archives={};prefix=['nice','-n','15','ionice','-c','2','-n','7']
def run(stage,argv,cwd=None):
 cmd=prefix+argv;commands.append({'stage':stage,'cwd':str(cwd or Path.cwd()),'argv':cmd});(r/'development-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 with (r/(stage+'.log')).open('w') as out:p=subprocess.run(cmd,cwd=cwd,stdout=out,stderr=subprocess.STDOUT)
 if p.returncode:raise SystemExit(stage+' failed; original log retained')
gen=subprocess.check_output(['ninja','-C',str(b),'-t','commands','sc-native-monitor-startup-tests'],text=True);(r/'release-generated-commands.txt').write_text(gen)
names=['/src/native_monitor_recording.cpp','/src/native_original_recording.cpp','/tests/monitor_eq_tests.cpp','/tests/native_monitor_startup_tests.cpp','/tests/native_monitor_route_tests.cpp','/tests/native_monitor_recording_tests.cpp','/tests/rt_audit.cpp']
compiles=[shlex.split(s) for s in gen.splitlines() if ' -c ' in s and (any(n in s for n in names) or 'CMakeFiles/sc-monitor-processing.dir/' in s)];assert len(compiles)==16
for n,argv in enumerate(compiles):
 obj=Path(argv[argv.index('-o')+1]);(b/obj).parent.mkdir(parents=True,exist_ok=True);run('release-compile-'+str(n),argv,b)
group=[str(Path(a[a.index('-o')+1])) for a in compiles if 'CMakeFiles/sc-monitor-processing.dir/' in a[a.index('-o')+1]]
run('release-processing-archive',['/usr/bin/ar','r','libsc-monitor-processing.a',*group],b);run('release-processing-index',['/usr/bin/ranlib','libsc-monitor-processing.a'],b)
run('release-native-state-archive',['/usr/bin/ar','r','libsc-native-original-recording.a','CMakeFiles/sc-native-original-recording.dir/src/native_original_recording.cpp.o'],b);run('release-native-state-index',['/usr/bin/ranlib','libsc-native-original-recording.a'],b)
run('release-owner-archive',['/usr/bin/ar','r','libsc-native-monitor-recording.a','CMakeFiles/sc-native-monitor-recording.dir/src/native_monitor_recording.cpp.o'],b);run('release-owner-index',['/usr/bin/ranlib','libsc-native-monitor-recording.a'],b)
link=shlex.split(gen.splitlines()[-1]);assert link[:2]==[':','&&'] and link[-2:]==['&&',':'];link=link[2:-2]
for n,a in enumerate(link):
 if not a.startswith('-') and a.endswith('.a') and not Path(a).is_absolute() and a not in {'libsc-native-monitor-recording.a','libsc-monitor-processing.a','libsc-native-original-recording.a'}:
  p=previous/a;assert p.is_file();archives[a]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()};link[n]=str(p)
(r/'development-reused-archives.json').write_text(json.dumps(archives,indent=2)+'\n');run('release-link',link,b)
run('release-tests',['ctest','--test-dir',str(b),'-R','^native-monitor-startup$','--output-on-failure','--no-tests=error']);shutil.copyfile(b/'Testing/Temporary/LastTest.log',r/'release-LastTest.log')
print('Expanded owned recording/startup suite passed',flush=True)
