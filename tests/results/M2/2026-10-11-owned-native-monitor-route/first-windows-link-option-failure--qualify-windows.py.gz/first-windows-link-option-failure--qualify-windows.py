from pathlib import Path
import subprocess,json,hashlib,shlex,shutil
r=Path('.cache/owned-native-monitor-route');old=Path('.cache/native-channel-state');f=json.loads((r/'frozen-inputs.json').read_text());w=json.loads((old/'windows-qualification.json').read_text());head=f['source'];b=(r/'build-windows').resolve();prior=(old/'build-windows').resolve();cmds=[];prefix=['nice','-n','15','ionice','-c','2','-n','7']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(name,argv,cwd=None):
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head and not subprocess.check_output(['git','status','--porcelain'],text=True)
 for x in f['selectedInputs']:assert sha(x['path'])==x['checkoutSha256']
 cmd=prefix+argv;cmds.append({'stage':name,'cwd':str(cwd or Path.cwd()),'argv':cmd})
 with (r/('windows-'+name+'.log')).open('w') as out:p=subprocess.run(cmd,cwd=cwd,stdout=out,stderr=subprocess.STDOUT)
 if p.returncode:raise SystemExit('Windows '+name+' failed; original log retained')
assert w['source']=='9d5da1c5889dc57af20fe70408a43932fcee6f61'
run('configure',['cmake','-S','.','-B',str(b),'-G','Ninja','-DCMAKE_TOOLCHAIN_FILE=cmake/toolchains/windows-mingw.cmake','-DCMAKE_BUILD_TYPE=Release','-DSC_BUILD_MEDIA=OFF','-DSC_BUILD_DESKTOP=OFF'])
gen=subprocess.check_output(['ninja','-C',str(b),'-t','commands','sc-native-monitor-startup-tests'],text=True);(r/'windows-generated-commands.txt').write_text(gen)
srcs=['/src/native_monitor_route.cpp','/tests/native_monitor_startup_tests.cpp','/tests/native_monitor_route_tests.cpp','/tests/rt_audit.cpp'];objects={}
compiles=[shlex.split(s) for s in gen.splitlines() if ' -c ' in s and any(n in s for n in srcs)];assert len(compiles)==4
for n,argv in enumerate(compiles):
 assert argv[0].endswith('x86_64-w64-mingw32-g++') and '-std=c++20' in argv
 obj=Path(argv[argv.index('-o')+1]);(b/obj).parent.mkdir(parents=True,exist_ok=True);run('compile-'+str(n),argv,b)
 assert 'warning:' not in (r/('windows-compile-'+str(n)+'.log')).read_text();objects[str(obj)]={'sha256':sha(b/obj),'bytes':(b/obj).stat().st_size}
link=shlex.split(gen.splitlines()[-1]);assert link[:2]==[':','&&'] and link[-2:]==['&&',':'];link=link[2:-2];archives={}
for n,a in enumerate(link):
 if a.endswith('.a') and not Path(a).is_absolute():
  p=prior/a;assert p.is_file();archives[a]={'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
  if a=='libsc-monitor-processing.a':
   shutil.copyfile(p,b/a);run('extend-private-processing-archive',['x86_64-w64-mingw32-ar','r',a,'CMakeFiles/sc-monitor-processing.dir/src/native_monitor_route.cpp.obj'],b);run('index-private-processing-archive',['x86_64-w64-mingw32-ranlib',a],b);link[n]=str(b/a)
  else:link[n]=str(p)
assert 'libsc-monitor-processing.a' in archives
run('link',link,b)
for x in archives.values():assert sha(x['path'])==x['sha256']
# Independently compile the changed persistence-enabled fixture as used by native CI.
run('persistence-fixture-compile',['x86_64-w64-mingw32-g++','-std=c++20','-O2','-Wall','-Wextra','-Wpedantic','-Wconversion','-DSC_NATIVE_STARTUP_STATE','-Iinclude','-Isrc','-Ithird_party','-Ithird_party/libsndfile','-c','tests/native_monitor_startup_tests.cpp','-o',str(r/'windows-persistence-fixture.obj')])
assert 'warning:' not in (r/'windows-persistence-fixture-compile.log').read_text()
shutil.copyfile(b/'CMakeCache.txt',r/'windows-CMakeCache.txt')
(r/'windows-qualification.json').write_text(json.dumps({'source':head,'tree':f['tree'],'commands':cmds,'objects':objects,'executableSha256':sha(b/'sc-native-monitor-startup-tests.exe'),'persistenceFixtureObjectSha256':sha(r/'windows-persistence-fixture.obj'),'readOnlyArchives':archives,'privateProcessingArchiveSha256':sha(b/'libsc-monitor-processing.a'),'nativeSdkModified':False,'nativeWindowsRuntimeExecuted':False},indent=2)+'\n')
print('Windows core fixture compiled/linked; changed persistence fixture warning-free; no runtime claim',flush=True)
