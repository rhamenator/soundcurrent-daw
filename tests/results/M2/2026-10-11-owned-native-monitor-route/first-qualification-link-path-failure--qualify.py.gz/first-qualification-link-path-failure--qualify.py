from pathlib import Path
import subprocess,json,hashlib,shlex,shutil
r=Path('.cache/owned-native-monitor-route');prior=Path('.cache/native-channel-state');q=json.loads((prior/'qualified-profiles.json').read_text());old=json.loads((prior/'frozen-inputs.json').read_text());frozen=json.loads((r/'frozen-inputs.json').read_text());head=frozen['source'];prefix=['nice','-n','15','ionice','-c','2','-n','7'];commands=[];profiles={}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def checked():
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head and not subprocess.check_output(['git','status','--porcelain'],text=True)
 for x in frozen['selectedInputs']:assert sha(x['path'])==x['checkoutSha256']
checked();assert q['source']==old['source']=='9d5da1c5889dc57af20fe70408a43932fcee6f61'
exceptions={'CMakeLists.txt','tests/native_monitor_startup_tests.cpp','tests/manual_recording_tests.cpp'}
for x in old['selectedInputs']:
 if x['path'] not in exceptions:assert sha(x['path'])==x['checkoutSha256']
for label,ctype,flags,link in [('release','Release','',''),('sanitizer','Debug','-fsanitize=address,undefined -fno-omit-frame-pointer','-fsanitize=address,undefined'),('tsan','Debug','-fsanitize=thread -fno-omit-frame-pointer -O1','-fsanitize=thread')]:
 b=(r/('build-'+label)).resolve();archives={}
 def run(stage,argv,cwd=None):
  checked();cmd=prefix+argv;commands.append({'profile':label,'stage':stage,'cwd':str(cwd or Path.cwd()),'argv':cmd});(r/'qualification-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
  with (r/(label+'-'+stage+'.log')).open('w') as out:p=subprocess.run(cmd,cwd=cwd,stdout=out,stderr=subprocess.STDOUT)
  if p.returncode:raise SystemExit(label+' '+stage+' failed; original log retained')
 print('Starting',label,flush=True)
 run('configure',['cmake','-S','.','-B',str(b),'-G','Ninja','-DCMAKE_BUILD_TYPE='+ctype,'-DSC_BUILD_DESKTOP=OFF','-DSC_BUILD_MEDIA=ON','-DCMAKE_CXX_FLAGS='+flags,'-DCMAKE_EXE_LINKER_FLAGS='+link])
 if label=='release':run('build',['cmake','--build',str(b),'--parallel','1','--target','sc-native-monitor-startup-tests'])
 else:
  previous=(prior/('build-'+label)).resolve()
  for name,h in q['executableHashes'][label].items():assert sha(previous/name)==h
  generated=subprocess.check_output(['ninja','-C',str(b),'-t','commands','sc-native-monitor-startup-tests'],text=True);(r/(label+'-generated-commands.txt')).write_text(generated)
  names=['/src/native_monitor_route.cpp','/tests/native_monitor_startup_tests.cpp','/tests/native_monitor_route_tests.cpp','/tests/rt_audit.cpp']
  compiles=[shlex.split(line) for line in generated.splitlines() if ' -c ' in line and any(n in line for n in names)]
  assert len(compiles)==4
  for n,argv in enumerate(compiles):
   assert argv[0]=='/usr/bin/c++' and '-std=c++20' in argv
   obj=Path(argv[argv.index('-o')+1]);(b/obj).parent.mkdir(parents=True,exist_ok=True);run('compile-'+str(n),argv,b)
  argv=shlex.split(generated.splitlines()[-1]);assert argv[:2]==[':','&&'] and argv[-2:]==['&&',':'];argv=argv[2:-2]
  assert '-Wl,--wrap=pthread_mutex_lock' in argv and argv[argv.index('-o')+1]=='sc-native-monitor-startup-tests'
  for n,a in enumerate(argv):
   if a.startswith('libsc-') and a.endswith('.a'):
    p=previous/a;assert p.is_file();archives[a]={'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
    if a=='libsc-monitor-processing.a':
     shutil.copyfile(p,b/a);run('extend-private-processing-archive',['/usr/bin/ar','r',a,'CMakeFiles/sc-monitor-processing.dir/src/native_monitor_route.cpp.o'],b);run('index-private-processing-archive',['/usr/bin/ranlib',a],b);argv[n]=str(b/a)
    else:argv[n]=str(p)
  assert 'libsc-monitor-processing.a' in archives and len(archives)>19
  run('link-with-readonly-qualified-archives',argv,b)
  for a,v in archives.items():assert sha(v['path'])==v['sha256']
 run('tests',['ctest','--test-dir',str(b),'-R','^native-monitor-startup$','--output-on-failure','--no-tests=error'])
 assert '100% tests passed, 0 tests failed out of 1' in (r/(label+'-tests.log')).read_text()
 shutil.copyfile(b/'Testing/Temporary/LastTest.log',r/(label+'-LastTest.log'));shutil.copyfile(b/'CMakeCache.txt',r/(label+'-CMakeCache.txt'))
 log=(r/(label+'-LastTest.log')).read_text();assert log.count('owned_native_route source_rate=')==7 and '1016991 owned native monitor route checks passed' in log and '4606535 composed native monitor startup checks passed; guarded allocate/free/lock=0' in log
 profiles[label]={'exeSha256':sha(b/'sc-native-monitor-startup-tests'),'productionArchivesReadOnly':archives,'privateProcessingArchiveSha256':sha(b/'libsc-monitor-processing.a'),'originalArchiveSource':old['source'] if archives else head}
 (r/'qualified-profiles.json').write_text(json.dumps({'source':head,'tree':frozen['tree'],'profiles':profiles,'nativeWindowsRuntimeExecuted':False},indent=2)+'\n');print('Passed',label,flush=True)
print('All three profiles passed',flush=True)
