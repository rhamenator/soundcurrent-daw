from pathlib import Path
import json,subprocess,hashlib,gzip,re,shutil
r=Path('.cache/owned-native-monitor-route');out=Path('tests/results/M2/2026-10-11-owned-native-monitor-route');f=json.loads((r/'frozen-inputs.json').read_text());q=json.loads((r/'qualified-profiles.json').read_text());w=json.loads((r/'windows-qualification.json').read_text())
assert f['source']==q['source']==w['source'] and len(f['selectedInputs'])==639 and set(q['profiles'])=={'release','sanitizer','tsan'}
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==f['source'] and not subprocess.check_output(['git','status','--porcelain'],text=True)
for x in f['selectedInputs']:assert hashlib.sha256(Path(x['path']).read_bytes()).hexdigest()==x['checkoutSha256']
observations={};names=['freeze-inputs.py','qualify.py','qualify-windows.py','retain.py','frozen-inputs.json','qualified-profiles.json','windows-qualification.json','qualification-commands.json','qualification.log','source-delta.diff','windows-generated-commands.txt','windows-CMakeCache.txt']
for label,p in q['profiles'].items():
 b=r/('build-'+label);assert hashlib.sha256((b/'sc-native-monitor-startup-tests').read_bytes()).hexdigest()==p['exeSha256']
 for x in p['productionArchivesReadOnly'].values():assert hashlib.sha256(Path(x['path']).read_bytes()).hexdigest()==x['sha256']
 for name in ['configure','build' if label=='release' else 'compile-0','tests','LastTest']:names.append(label+'-'+name+'.log')
 names.append(label+'-CMakeCache.txt')
 if label!='release':
  names += [label+'-generated-commands.txt']+[label+'-'+n+'.log' for n in ['compile-1','compile-2','compile-3','extend-private-processing-archive','index-private-processing-archive','link-with-readonly-qualified-archives']]
 log=(r/(label+'-LastTest.log')).read_text();rows=re.findall(r'^owned_native_route[^\r\n]*',log,re.M);assert len(rows)==7
 assert '1016991 owned native monitor route checks passed' in log and '4606535 composed native monitor startup checks passed; guarded allocate/free/lock=0' in log
 observations[label]={'ownedRuns':rows,'ownedChecks':1016991,'totalComposedChecks':4606535,'guardedAllocationFreeLock':0,'scope':'One expanded native-monitor-startup suite, including all preceding cases'}
for p in r.glob('windows-*.log'):names.append(p.name)
for label in ['first-qualification-link-path-failure','first-windows-link-option-failure']:
 for n in ['qualify.py','qualify-windows.py','qualification.log','windows-qualification.log','qualification-commands.json','sanitizer-link-with-readonly-qualified-archives.log','windows-generated-commands.txt']:
  p=r/label/n
  if p.is_file():
   dest=label+'--'+n;shutil.copyfile(p,r/dest);names.append(dest)
out.mkdir(exist_ok=False);members={}
for n in sorted(set(names)):
 raw=(r/n).read_bytes();packed=gzip.compress(raw,mtime=0);dest=n+'.gz';assert gzip.decompress(packed)==raw;(out/dest).write_bytes(packed)
 members[dest]={'bytes':len(packed),'sha256':hashlib.sha256(packed).hexdigest(),'originalBytes':len(raw),'originalSha256':hashlib.sha256(raw).hexdigest(),'lossless':True}
summary={'source':f['source'],'tree':f['tree'],'sourceInputs':639,'observations':observations,'reusedArchiveSource':'9d5da1c5889dc57af20fe70408a43932fcee6f61','windowsCompileLink':True,'nativeWindowsRuntimeExecuted':False,'sdkActivationOrThreadsOwned':False,'monitoringEqIntegrated':False,'physicalAudioQualified':False,'factoryEnabled':False,'fullGoalComplete':False,'binaryOrMediaIncluded':False}
raw=(json.dumps(summary,indent=2)+'\n').encode();(out/'summary.json').write_bytes(raw);members['summary.json']={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
(out/'manifest.json').write_text(json.dumps({'members':members,'scope':'Owned route plus original startup cases; Release, ASan/UBSan, TSan and Windows cross-compile/link; original helper failures retained; source/log/command/hash assets only'},indent=2)+'\n')
print('Retained',len(members),'bound files;',sum(p.stat().st_size for p in out.iterdir()),'bytes')
