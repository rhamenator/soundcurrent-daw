IfFileExists "$INSTDIR\Qt6Core.dll" 0 check_done_0
System::Call 'kernel32::CreateFileW(w "$INSTDIR\Qt6Core.dll", i 0x40000000, i 7, p 0, i 3, i 0, p 0) p.r0'
${If} $0 == -1
MessageBox MB_OK "Close applications using this preview before continuing."
SetErrorLevel 2
Abort
${EndIf}
System::Call 'kernel32::CloseHandle(p r0)'
check_done_0:
IfFileExists "$INSTDIR\Qt6Gui.dll" 0 check_done_1
System::Call 'kernel32::CreateFileW(w "$INSTDIR\Qt6Gui.dll", i 0x40000000, i 7, p 0, i 3, i 0, p 0) p.r0'
${If} $0 == -1
MessageBox MB_OK "Close applications using this preview before continuing."
SetErrorLevel 2
Abort
${EndIf}
System::Call 'kernel32::CloseHandle(p r0)'
check_done_1:
IfFileExists "$INSTDIR\Qt6Widgets.dll" 0 check_done_2
System::Call 'kernel32::CreateFileW(w "$INSTDIR\Qt6Widgets.dll", i 0x40000000, i 7, p 0, i 3, i 0, p 0) p.r0'
${If} $0 == -1
MessageBox MB_OK "Close applications using this preview before continuing."
SetErrorLevel 2
Abort
${EndIf}
System::Call 'kernel32::CloseHandle(p r0)'
check_done_2:
IfFileExists "$INSTDIR\imageformats\qgif.dll" 0 check_done_6
System::Call 'kernel32::CreateFileW(w "$INSTDIR\imageformats\qgif.dll", i 0x40000000, i 7, p 0, i 3, i 0, p 0) p.r0'
${If} $0 == -1
MessageBox MB_OK "Close applications using this preview before continuing."
SetErrorLevel 2
Abort
${EndIf}
System::Call 'kernel32::CloseHandle(p r0)'
check_done_6:
IfFileExists "$INSTDIR\imageformats\qico.dll" 0 check_done_7
System::Call 'kernel32::CreateFileW(w "$INSTDIR\imageformats\qico.dll", i 0x40000000, i 7, p 0, i 3, i 0, p 0) p.r0'
${If} $0 == -1
MessageBox MB_OK "Close applications using this preview before continuing."
SetErrorLevel 2
Abort
${EndIf}
System::Call 'kernel32::CloseHandle(p r0)'
check_done_7:
IfFileExists "$INSTDIR\imageformats\qjpeg.dll" 0 check_done_8
System::Call 'kernel32::CreateFileW(w "$INSTDIR\imageformats\qjpeg.dll", i 0x40000000, i 7, p 0, i 3, i 0, p 0) p.r0'
${If} $0 == -1
MessageBox MB_OK "Close applications using this preview before continuing."
SetErrorLevel 2
Abort
${EndIf}
System::Call 'kernel32::CloseHandle(p r0)'
check_done_8:
IfFileExists "$INSTDIR\platforms\qwindows.dll" 0 check_done_56
System::Call 'kernel32::CreateFileW(w "$INSTDIR\platforms\qwindows.dll", i 0x40000000, i 7, p 0, i 3, i 0, p 0) p.r0'
${If} $0 == -1
MessageBox MB_OK "Close applications using this preview before continuing."
SetErrorLevel 2
Abort
${EndIf}
System::Call 'kernel32::CloseHandle(p r0)'
check_done_56:
IfFileExists "$INSTDIR\sc-approved-wave-probe.exe" 0 check_done_57
System::Call 'kernel32::CreateFileW(w "$INSTDIR\sc-approved-wave-probe.exe", i 0x40000000, i 7, p 0, i 3, i 0, p 0) p.r0'
${If} $0 == -1
MessageBox MB_OK "Close applications using this preview before continuing."
SetErrorLevel 2
Abort
${EndIf}
System::Call 'kernel32::CloseHandle(p r0)'
check_done_57:
IfFileExists "$INSTDIR\sc-import-inspect-worker.exe" 0 check_done_58
System::Call 'kernel32::CreateFileW(w "$INSTDIR\sc-import-inspect-worker.exe", i 0x40000000, i 7, p 0, i 3, i 0, p 0) p.r0'
${If} $0 == -1
MessageBox MB_OK "Close applications using this preview before continuing."
SetErrorLevel 2
Abort
${EndIf}
System::Call 'kernel32::CloseHandle(p r0)'
check_done_58:
IfFileExists "$INSTDIR\sc-media-import-worker.exe" 0 check_done_59
System::Call 'kernel32::CreateFileW(w "$INSTDIR\sc-media-import-worker.exe", i 0x40000000, i 7, p 0, i 3, i 0, p 0) p.r0'
${If} $0 == -1
MessageBox MB_OK "Close applications using this preview before continuing."
SetErrorLevel 2
Abort
${EndIf}
System::Call 'kernel32::CloseHandle(p r0)'
check_done_59:
IfFileExists "$INSTDIR\sc-stretch-render-worker.exe" 0 check_done_60
System::Call 'kernel32::CreateFileW(w "$INSTDIR\sc-stretch-render-worker.exe", i 0x40000000, i 7, p 0, i 3, i 0, p 0) p.r0'
${If} $0 == -1
MessageBox MB_OK "Close applications using this preview before continuing."
SetErrorLevel 2
Abort
${EndIf}
System::Call 'kernel32::CloseHandle(p r0)'
check_done_60:
IfFileExists "$INSTDIR\sndfile.dll" 0 check_done_61
System::Call 'kernel32::CreateFileW(w "$INSTDIR\sndfile.dll", i 0x40000000, i 7, p 0, i 3, i 0, p 0) p.r0'
${If} $0 == -1
MessageBox MB_OK "Close applications using this preview before continuing."
SetErrorLevel 2
Abort
${EndIf}
System::Call 'kernel32::CloseHandle(p r0)'
check_done_61:
IfFileExists "$INSTDIR\soundcurrent-daw.exe" 0 check_done_62
System::Call 'kernel32::CreateFileW(w "$INSTDIR\soundcurrent-daw.exe", i 0x40000000, i 7, p 0, i 3, i 0, p 0) p.r0'
${If} $0 == -1
MessageBox MB_OK "Close applications using this preview before continuing."
SetErrorLevel 2
Abort
${EndIf}
System::Call 'kernel32::CloseHandle(p r0)'
check_done_62:
IfFileExists "$INSTDIR\styles\qmodernwindowsstyle.dll" 0 check_done_63
System::Call 'kernel32::CreateFileW(w "$INSTDIR\styles\qmodernwindowsstyle.dll", i 0x40000000, i 7, p 0, i 3, i 0, p 0) p.r0'
${If} $0 == -1
MessageBox MB_OK "Close applications using this preview before continuing."
SetErrorLevel 2
Abort
${EndIf}
System::Call 'kernel32::CloseHandle(p r0)'
check_done_63:
