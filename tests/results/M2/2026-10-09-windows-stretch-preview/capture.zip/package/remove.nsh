IfFileExists "$INSTDIR\Qt6Core.dll" 0 remove_done_0
ClearErrors
Delete "$INSTDIR\Qt6Core.dll"
IfErrors removal_failed
remove_done_0:
IfFileExists "$INSTDIR\Qt6Gui.dll" 0 remove_done_1
ClearErrors
Delete "$INSTDIR\Qt6Gui.dll"
IfErrors removal_failed
remove_done_1:
IfFileExists "$INSTDIR\Qt6Widgets.dll" 0 remove_done_2
ClearErrors
Delete "$INSTDIR\Qt6Widgets.dll"
IfErrors removal_failed
remove_done_2:
IfFileExists "$INSTDIR\QtBase-SBOM.json" 0 remove_done_3
ClearErrors
Delete "$INSTDIR\QtBase-SBOM.json"
IfErrors removal_failed
remove_done_3:
IfFileExists "$INSTDIR\SOURCE.txt" 0 remove_done_4
ClearErrors
Delete "$INSTDIR\SOURCE.txt"
IfErrors removal_failed
remove_done_4:
IfFileExists "$INSTDIR\THIRD-PARTY-NOTICES.md" 0 remove_done_5
ClearErrors
Delete "$INSTDIR\THIRD-PARTY-NOTICES.md"
IfErrors removal_failed
remove_done_5:
IfFileExists "$INSTDIR\imageformats\qgif.dll" 0 remove_done_6
ClearErrors
Delete "$INSTDIR\imageformats\qgif.dll"
IfErrors removal_failed
remove_done_6:
IfFileExists "$INSTDIR\imageformats\qico.dll" 0 remove_done_7
ClearErrors
Delete "$INSTDIR\imageformats\qico.dll"
IfErrors removal_failed
remove_done_7:
IfFileExists "$INSTDIR\imageformats\qjpeg.dll" 0 remove_done_8
ClearErrors
Delete "$INSTDIR\imageformats\qjpeg.dll"
IfErrors removal_failed
remove_done_8:
IfFileExists "$INSTDIR\licenses\GPL-3.0.txt" 0 remove_done_9
ClearErrors
Delete "$INSTDIR\licenses\GPL-3.0.txt"
IfErrors removal_failed
remove_done_9:
IfFileExists "$INSTDIR\licenses\NSIS-copyright.txt" 0 remove_done_10
ClearErrors
Delete "$INSTDIR\licenses\NSIS-copyright.txt"
IfErrors removal_failed
remove_done_10:
IfFileExists "$INSTDIR\licenses\Qt-AFL-2.1.txt" 0 remove_done_11
ClearErrors
Delete "$INSTDIR\licenses\Qt-AFL-2.1.txt"
IfErrors removal_failed
remove_done_11:
IfFileExists "$INSTDIR\licenses\Qt-Apache-2.0.txt" 0 remove_done_12
ClearErrors
Delete "$INSTDIR\licenses\Qt-Apache-2.0.txt"
IfErrors removal_failed
remove_done_12:
IfFileExists "$INSTDIR\licenses\Qt-BSD-2-Clause.txt" 0 remove_done_13
ClearErrors
Delete "$INSTDIR\licenses\Qt-BSD-2-Clause.txt"
IfErrors removal_failed
remove_done_13:
IfFileExists "$INSTDIR\licenses\Qt-BSD-3-Clause.txt" 0 remove_done_14
ClearErrors
Delete "$INSTDIR\licenses\Qt-BSD-3-Clause.txt"
IfErrors removal_failed
remove_done_14:
IfFileExists "$INSTDIR\licenses\Qt-BSD-4-Clause.txt" 0 remove_done_15
ClearErrors
Delete "$INSTDIR\licenses\Qt-BSD-4-Clause.txt"
IfErrors removal_failed
remove_done_15:
IfFileExists "$INSTDIR\licenses\Qt-BSL-1.0.txt" 0 remove_done_16
ClearErrors
Delete "$INSTDIR\licenses\Qt-BSL-1.0.txt"
IfErrors removal_failed
remove_done_16:
IfFileExists "$INSTDIR\licenses\Qt-Bitstream-Vera.txt" 0 remove_done_17
ClearErrors
Delete "$INSTDIR\licenses\Qt-Bitstream-Vera.txt"
IfErrors removal_failed
remove_done_17:
IfFileExists "$INSTDIR\licenses\Qt-CC0-1.0.txt" 0 remove_done_18
ClearErrors
Delete "$INSTDIR\licenses\Qt-CC0-1.0.txt"
IfErrors removal_failed
remove_done_18:
IfFileExists "$INSTDIR\licenses\Qt-FTL.txt" 0 remove_done_19
ClearErrors
Delete "$INSTDIR\licenses\Qt-FTL.txt"
IfErrors removal_failed
remove_done_19:
IfFileExists "$INSTDIR\licenses\Qt-GFDL-1.3-no-invariants-only.txt" 0 remove_done_20
ClearErrors
Delete "$INSTDIR\licenses\Qt-GFDL-1.3-no-invariants-only.txt"
IfErrors removal_failed
remove_done_20:
IfFileExists "$INSTDIR\licenses\Qt-GPL-2.0-only.txt" 0 remove_done_21
ClearErrors
Delete "$INSTDIR\licenses\Qt-GPL-2.0-only.txt"
IfErrors removal_failed
remove_done_21:
IfFileExists "$INSTDIR\licenses\Qt-GPL-2.0-or-later.txt" 0 remove_done_22
ClearErrors
Delete "$INSTDIR\licenses\Qt-GPL-2.0-or-later.txt"
IfErrors removal_failed
remove_done_22:
IfFileExists "$INSTDIR\licenses\Qt-GPL-3.0-only.txt" 0 remove_done_23
ClearErrors
Delete "$INSTDIR\licenses\Qt-GPL-3.0-only.txt"
IfErrors removal_failed
remove_done_23:
IfFileExists "$INSTDIR\licenses\Qt-HPND.txt" 0 remove_done_24
ClearErrors
Delete "$INSTDIR\licenses\Qt-HPND.txt"
IfErrors removal_failed
remove_done_24:
IfFileExists "$INSTDIR\licenses\Qt-IJG.txt" 0 remove_done_25
ClearErrors
Delete "$INSTDIR\licenses\Qt-IJG.txt"
IfErrors removal_failed
remove_done_25:
IfFileExists "$INSTDIR\licenses\Qt-IPL-1.0.txt" 0 remove_done_26
ClearErrors
Delete "$INSTDIR\licenses\Qt-IPL-1.0.txt"
IfErrors removal_failed
remove_done_26:
IfFileExists "$INSTDIR\licenses\Qt-Imlib2.txt" 0 remove_done_27
ClearErrors
Delete "$INSTDIR\licenses\Qt-Imlib2.txt"
IfErrors removal_failed
remove_done_27:
IfFileExists "$INSTDIR\licenses\Qt-LGPL-2.1-or-later.txt" 0 remove_done_28
ClearErrors
Delete "$INSTDIR\licenses\Qt-LGPL-2.1-or-later.txt"
IfErrors removal_failed
remove_done_28:
IfFileExists "$INSTDIR\licenses\Qt-LGPL-3.0-only.txt" 0 remove_done_29
ClearErrors
Delete "$INSTDIR\licenses\Qt-LGPL-3.0-only.txt"
IfErrors removal_failed
remove_done_29:
IfFileExists "$INSTDIR\licenses\Qt-Libpng.txt" 0 remove_done_30
ClearErrors
Delete "$INSTDIR\licenses\Qt-Libpng.txt"
IfErrors removal_failed
remove_done_30:
IfFileExists "$INSTDIR\licenses\Qt-LicenseRef-BSD-3-Clause-with-PCRE2-Binary-Like-Packages-Exception.txt" 0 remove_done_31
ClearErrors
Delete "$INSTDIR\licenses\Qt-LicenseRef-BSD-3-Clause-with-PCRE2-Binary-Like-Packages-Exception.txt"
IfErrors removal_failed
remove_done_31:
IfFileExists "$INSTDIR\licenses\Qt-LicenseRef-ICC-License.txt" 0 remove_done_32
ClearErrors
Delete "$INSTDIR\licenses\Qt-LicenseRef-ICC-License.txt"
IfErrors removal_failed
remove_done_32:
IfFileExists "$INSTDIR\licenses\Qt-LicenseRef-Lcs-Telegraphics.txt" 0 remove_done_33
ClearErrors
Delete "$INSTDIR\licenses\Qt-LicenseRef-Lcs-Telegraphics.txt"
IfErrors removal_failed
remove_done_33:
IfFileExists "$INSTDIR\licenses\Qt-LicenseRef-Qt-Commercial.txt" 0 remove_done_34
ClearErrors
Delete "$INSTDIR\licenses\Qt-LicenseRef-Qt-Commercial.txt"
IfErrors removal_failed
remove_done_34:
IfFileExists "$INSTDIR\licenses\Qt-LicenseRef-SHA1-Public-Domain.txt" 0 remove_done_35
ClearErrors
Delete "$INSTDIR\licenses\Qt-LicenseRef-SHA1-Public-Domain.txt"
IfErrors removal_failed
remove_done_35:
IfFileExists "$INSTDIR\licenses\Qt-Linux-syscall-note.txt" 0 remove_done_36
ClearErrors
Delete "$INSTDIR\licenses\Qt-Linux-syscall-note.txt"
IfErrors removal_failed
remove_done_36:
IfFileExists "$INSTDIR\licenses\Qt-MIT-Khronos-old.txt" 0 remove_done_37
ClearErrors
Delete "$INSTDIR\licenses\Qt-MIT-Khronos-old.txt"
IfErrors removal_failed
remove_done_37:
IfFileExists "$INSTDIR\licenses\Qt-MIT-open-group.txt" 0 remove_done_38
ClearErrors
Delete "$INSTDIR\licenses\Qt-MIT-open-group.txt"
IfErrors removal_failed
remove_done_38:
IfFileExists "$INSTDIR\licenses\Qt-MIT.txt" 0 remove_done_39
ClearErrors
Delete "$INSTDIR\licenses\Qt-MIT.txt"
IfErrors removal_failed
remove_done_39:
IfFileExists "$INSTDIR\licenses\Qt-MPL-2.0.txt" 0 remove_done_40
ClearErrors
Delete "$INSTDIR\licenses\Qt-MPL-2.0.txt"
IfErrors removal_failed
remove_done_40:
IfFileExists "$INSTDIR\licenses\Qt-Qt-GPL-exception-1.0.txt" 0 remove_done_41
ClearErrors
Delete "$INSTDIR\licenses\Qt-Qt-GPL-exception-1.0.txt"
IfErrors removal_failed
remove_done_41:
IfFileExists "$INSTDIR\licenses\Qt-SPL-1.0.txt" 0 remove_done_42
ClearErrors
Delete "$INSTDIR\licenses\Qt-SPL-1.0.txt"
IfErrors removal_failed
remove_done_42:
IfFileExists "$INSTDIR\licenses\Qt-Unicode-3.0.txt" 0 remove_done_43
ClearErrors
Delete "$INSTDIR\licenses\Qt-Unicode-3.0.txt"
IfErrors removal_failed
remove_done_43:
IfFileExists "$INSTDIR\licenses\Qt-X11.txt" 0 remove_done_44
ClearErrors
Delete "$INSTDIR\licenses\Qt-X11.txt"
IfErrors removal_failed
remove_done_44:
IfFileExists "$INSTDIR\licenses\Qt-Xerox.txt" 0 remove_done_45
ClearErrors
Delete "$INSTDIR\licenses\Qt-Xerox.txt"
IfErrors removal_failed
remove_done_45:
IfFileExists "$INSTDIR\licenses\Qt-Zlib.txt" 0 remove_done_46
ClearErrors
Delete "$INSTDIR\licenses\Qt-Zlib.txt"
IfErrors removal_failed
remove_done_46:
IfFileExists "$INSTDIR\licenses\Qt-blessing.txt" 0 remove_done_47
ClearErrors
Delete "$INSTDIR\licenses\Qt-blessing.txt"
IfErrors removal_failed
remove_done_47:
IfFileExists "$INSTDIR\licenses\Qt-libpng-2.0.txt" 0 remove_done_48
ClearErrors
Delete "$INSTDIR\licenses\Qt-libpng-2.0.txt"
IfErrors removal_failed
remove_done_48:
IfFileExists "$INSTDIR\licenses\RubberBand-GPL-2.0-or-later.txt" 0 remove_done_49
ClearErrors
Delete "$INSTDIR\licenses\RubberBand-GPL-2.0-or-later.txt"
IfErrors removal_failed
remove_done_49:
IfFileExists "$INSTDIR\licenses\equipment-GPL.txt" 0 remove_done_50
ClearErrors
Delete "$INSTDIR\licenses\equipment-GPL.txt"
IfErrors removal_failed
remove_done_50:
IfFileExists "$INSTDIR\licenses\libsamplerate-BSD-2-Clause.txt" 0 remove_done_51
ClearErrors
Delete "$INSTDIR\licenses\libsamplerate-BSD-2-Clause.txt"
IfErrors removal_failed
remove_done_51:
IfFileExists "$INSTDIR\licenses\libsndfile-ALAC.txt" 0 remove_done_52
ClearErrors
Delete "$INSTDIR\licenses\libsndfile-ALAC.txt"
IfErrors removal_failed
remove_done_52:
IfFileExists "$INSTDIR\licenses\libsndfile-GSM610.txt" 0 remove_done_53
ClearErrors
Delete "$INSTDIR\licenses\libsndfile-GSM610.txt"
IfErrors removal_failed
remove_done_53:
IfFileExists "$INSTDIR\licenses\libsndfile-LGPL.txt" 0 remove_done_54
ClearErrors
Delete "$INSTDIR\licenses\libsndfile-LGPL.txt"
IfErrors removal_failed
remove_done_54:
IfFileExists "$INSTDIR\licenses\nlohmann-MIT.txt" 0 remove_done_55
ClearErrors
Delete "$INSTDIR\licenses\nlohmann-MIT.txt"
IfErrors removal_failed
remove_done_55:
IfFileExists "$INSTDIR\platforms\qwindows.dll" 0 remove_done_56
ClearErrors
Delete "$INSTDIR\platforms\qwindows.dll"
IfErrors removal_failed
remove_done_56:
IfFileExists "$INSTDIR\sc-approved-wave-probe.exe" 0 remove_done_57
ClearErrors
Delete "$INSTDIR\sc-approved-wave-probe.exe"
IfErrors removal_failed
remove_done_57:
IfFileExists "$INSTDIR\sc-import-inspect-worker.exe" 0 remove_done_58
ClearErrors
Delete "$INSTDIR\sc-import-inspect-worker.exe"
IfErrors removal_failed
remove_done_58:
IfFileExists "$INSTDIR\sc-media-import-worker.exe" 0 remove_done_59
ClearErrors
Delete "$INSTDIR\sc-media-import-worker.exe"
IfErrors removal_failed
remove_done_59:
IfFileExists "$INSTDIR\sc-stretch-render-worker.exe" 0 remove_done_60
ClearErrors
Delete "$INSTDIR\sc-stretch-render-worker.exe"
IfErrors removal_failed
remove_done_60:
IfFileExists "$INSTDIR\sndfile.dll" 0 remove_done_61
ClearErrors
Delete "$INSTDIR\sndfile.dll"
IfErrors removal_failed
remove_done_61:
IfFileExists "$INSTDIR\soundcurrent-daw.exe" 0 remove_done_62
ClearErrors
Delete "$INSTDIR\soundcurrent-daw.exe"
IfErrors removal_failed
remove_done_62:
IfFileExists "$INSTDIR\styles\qmodernwindowsstyle.dll" 0 remove_done_63
ClearErrors
Delete "$INSTDIR\styles\qmodernwindowsstyle.dll"
IfErrors removal_failed
remove_done_63:
RMDir "$INSTDIR\imageformats"
RMDir "$INSTDIR\platforms"
RMDir "$INSTDIR\licenses"
RMDir "$INSTDIR\styles"
