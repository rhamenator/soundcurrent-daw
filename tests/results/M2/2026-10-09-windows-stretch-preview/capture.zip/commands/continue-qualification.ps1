$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$root=Join-Path $env:USERPROFILE 'soundcurrent-daw-stretch-f9a6353'
$sdk=Join-Path $env:USERPROFILE 'soundcurrent-daw-msvc-sdk-v1'
$env:PATH=$sdk+'\qt\bin;'+$sdk+'\sndfile-build-v2\Release;'+$env:PATH
& py -3 (Join-Path $env:USERPROFILE 'soundcurrent-stretch-continue-copy.py')
if($LASTEXITCODE -ne 0) {exit $LASTEXITCODE}
Set-Location $root
& py -3 tests/stretch_worker_tests.py build/Release/sc-stretch-render-worker.exe build/Release/sc-stretch-artifact-tests.exe --qualification (Join-Path $env:USERPROFILE 'soundcurrent-stretch-qualification-f9a6353/stretch-worker-qualification.json')
if($LASTEXITCODE -ne 0) {exit $LASTEXITCODE}
$env:QT_QPA_PLATFORM='offscreen'
& 'C:\Program Files\CMake\bin\ctest.exe' --test-dir build --build-config Release --output-on-failure --tests-regex '^desktop-stretch-(ui|controller)$'
exit $LASTEXITCODE
