from pathlib import Path
import subprocess,json,hashlib,sys
source=Path.home()/'soundcurrent-daw-stretch-f9a6353';root=Path.home()/'soundcurrent-stretch-qualification-f9a6353';head='f9a63532685c988b4d7203da537957cab41dff92'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=source,text=True).strip()
previous=json.loads((root/'sc-media-import-worker.exe.stdout').read_bytes());operation=previous['operation'];destination=root/'copied';wave=(root/'audio.wav').read_bytes();digest=hashlib.sha256(wave).hexdigest()
assert (destination/operation/'media.wav').read_bytes()==wave
request={'schema':'sc-media-copy-request-v1','recover':True,'operation':operation,'bundle':'','root':'','destination':str(destination),'expected':'','maximumBytes':1048576,'selectedFilename':False}
exe=source/'build/Release/sc-media-import-worker.exe';exesha=hashlib.sha256(exe.read_bytes()).hexdigest()
p=subprocess.Popen([str(exe),'--desktop','--memory-bytes','67108864'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
stdout,stderr=p.communicate(json.dumps(request).encode(),timeout=25);assert p.returncode==0 and not stderr
(root/'copy-qualified.stdout').write_bytes(stdout);(root/'copy-qualified.stderr').write_bytes(stderr)
report=json.loads(stdout);assert report['protocol']=='sc-media-copy-v1' and report['workerPid']==p.pid and report['committed'] is True and report['phase']==2 and report['sessionAssetPublished'] is False
receipt=json.loads(report['receipt']);assert receipt['sourceSha256']==receipt['stagedSha256']==digest and receipt['frames']==8192 and receipt['channels']==2 and receipt['sourceRootsPersisted'] is False
assert hashlib.sha256(exe.read_bytes()).hexdigest()==exesha and (destination/operation/'media.wav').read_bytes()==wave
record={'sourceCommit':head,'pid':p.pid,'reportedPid':report['workerPid'],'exitCode':p.returncode,'exeSha256':exesha,'protocol':report['protocol'],'phase':report['phase'],'committed':report['committed'],'sessionAssetPublished':report['sessionAssetPublished'],'operation':operation,'nativePlatform':sys.platform,'nativeAudio':False}
(root/'copy-worker-qualification.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print('actual desktop recovery source/staged hashes, independent raw bytes and observed PID verified')
