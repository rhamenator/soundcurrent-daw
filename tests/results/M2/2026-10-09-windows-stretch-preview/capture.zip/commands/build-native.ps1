$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$root=Join-Path $env:USERPROFILE 'soundcurrent-daw-stretch-f9a6353'
Set-Location $root
if((& git rev-parse HEAD).Trim() -ne 'f9a63532685c988b4d7203da537957cab41dff92') {throw 'Unexpected native checkout'}
if((& git status --porcelain --untracked-files=no)) {throw 'Native source dirty before build'}
$watch=[Diagnostics.Stopwatch]::StartNew()
& 'C:\Program Files\CMake\bin\cmake.exe' --build build --config Release --parallel 2 --target soundcurrent-daw sc-stretch-render-worker sc-stretch-artifact-tests sc-stretch-controller-tests sc-stretch-ui-tests sc-import-inspect-worker sc-approved-wave-probe sc-media-import-worker
$code=$LASTEXITCODE
$watch.Stop()
[ordered]@{exitCode=$code;seconds=$watch.Elapsed.TotalSeconds;nativeAudio=$false}|ConvertTo-Json
if($code -ne 0) {exit $code}
if((& git status --porcelain --untracked-files=no)) {throw 'Native source changed during build'}
