$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$out=Join-Path $env:USERPROFILE 'soundcurrent-stretch-qualification-f9a6353'
$files=@(Get-ChildItem $out -File|Where-Object {$_.Extension -in @('.json','.stdout','.stderr','.rpp','.wav','.scinspect','.log')}|ForEach-Object {$_.FullName})
Compress-Archive -LiteralPath $files -DestinationPath (Join-Path $out 'retained.zip')
Get-FileHash (Join-Path $out 'retained.zip'),(Join-Path $out 'deploy.zip') -Algorithm SHA256|Select-Object Path,Hash|ConvertTo-Json
