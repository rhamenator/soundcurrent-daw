from pathlib import Path
import subprocess,json,hashlib,struct,math,uuid,sys,datetime
source=Path.home()/'soundcurrent-daw-stretch-f9a6353';head='f9a63532685c988b4d7203da537957cab41dff92';build=source/'build/Release'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=source,text=True).strip()
root=Path.home()/'soundcurrent-stretch-qualification-f9a6353';root.mkdir(exist_ok=False)
manifest=json.loads((Path.home()/'soundcurrent-stretch-source-inputs.json').read_text(encoding='utf-8'))
for n,h in manifest.items():assert digest(source/n)==h,n
(root/'build-inputs.json').write_text(json.dumps({'sourceCommit':head,'sourceTree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=source,text=True).strip(),'files':[{'name':n,'sha256':h} for n,h in manifest.items()]},indent=2)+'\n',encoding='utf-8')
records=[]
def child(name,args,input=None):
 exe=build/name;before=digest(exe);p=subprocess.Popen([str(exe),*map(str,args)],stdin=subprocess.PIPE if input is not None else None,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 stdout,stderr=p.communicate(input,timeout=25)
 (root/(name+'.stdout')).write_bytes(stdout);(root/(name+'.stderr')).write_bytes(stderr)
 assert p.returncode==0 and not stderr,(name,p.returncode,stderr)
 assert digest(exe)==before
 report=json.loads(stdout);assert report['workerPid']==p.pid,(name,report)
 record={'sourceCommit':head,'pid':p.pid,'reportedPid':report['workerPid'],'exitCode':p.returncode,'exeSha256':before,'protocol':report['protocol'],'nativePlatform':sys.platform,'nativeAudio':False}
 records.append({'name':name,'command':p.args,'record':record,'report':report});return report,record
frames=8192;payload=b''.join(struct.pack('<f',1.8*math.sin(2*math.pi*(440+ch*290)*f/48000)) for f in range(frames) for ch in range(2));fmt=struct.pack('<HHIIHH',3,2,48000,384000,8,32);body=b'WAVEfmt '+struct.pack('<I',16)+fmt+b'data'+struct.pack('<I',len(payload))+payload;wave=b'RIFF'+struct.pack('<I',len(body))+body
(root/'audio.wav').write_bytes(wave)
raw=b'<REAPER_PROJECT 0.1 7.82\n SAMPLERATE 48000 1\n <TRACK\n  <ITEM\n   <SOURCE WAVE\n    FILE "audio.wav"\n   >\n  >\n >\n>\n';(root/'owned.rpp').write_bytes(raw)
report,record=child('sc-import-inspect-worker.exe',['--rpp-properties',root/'owned.rpp','--memory-bytes','4194304']);assert report['complete'] is True and report['source']['sha256']==hashlib.sha256(raw).hexdigest()
(root/'inspection-worker-qualification.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
encoded=json.dumps(report,ensure_ascii=True,separators=(',',':')).encode();bundle=root/'owned.scinspect';bundle.write_bytes(b'SCIBND01'+struct.pack('<QQQ',len(raw),len(encoded),record['pid'])+raw+encoded+hashlib.sha256(encoded).hexdigest().encode())
property=next(i for i,p in enumerate(report['preview']['properties']) if p['id']==20)
report,record=child('sc-approved-wave-probe.exe',['--desktop-check','--root',root,'--relative','audio.wav','--maximum-bytes','1048576']);assert report['complete'] and report['sourceSha256']==hashlib.sha256(wave).hexdigest() and report['frames']==8192 and report['channels']==2 and report['peakLinear']>1
(root/'media-worker-qualification.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
destination=root/'copied';destination.mkdir();operation=str(uuid.uuid4())
report,record=child('sc-media-import-worker.exe',['--commit','--bundle',bundle,'--property',property,'--root',root,'--relative','audio.wav','--destination',destination,'--operation',operation,'--selection','original','--maximum-bytes','1048576']);assert report['committed'] and report['phase']==2 and report['sessionAssetPublished'] is False and (destination/operation/'media.wav').read_bytes()==wave
request={'schema':'sc-media-copy-request-v1','recover':True,'operation':operation,'bundle':'','root':'','destination':str(destination),'expected':'','maximumBytes':1048576,'selectedFilename':False}
report,record=child('sc-media-import-worker.exe',['--desktop','--memory-bytes','67108864'],json.dumps(request).encode());assert report['protocol']=='sc-media-copy-v1' and report['committed'] and report['phase']==2 and report['sessionAssetPublished'] is False
receipt=json.loads(report['receipt']);assert receipt['sha256']==hashlib.sha256(wave).hexdigest()
record.update({k:report[k] for k in ['phase','committed','sessionAssetPublished','operation']});(root/'copy-worker-qualification.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
assert (destination/operation/'media.wav').read_bytes()==wave and (root/'audio.wav').read_bytes()==wave
(root/'helper-records.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
for n,h in manifest.items():assert digest(source/n)==h,n
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=source,text=True).strip()
print('native_helper_receipts: actual inspection/probe/copy/recovery PID/source/executable/protocol/audio hashes verified; no audio endpoint')
