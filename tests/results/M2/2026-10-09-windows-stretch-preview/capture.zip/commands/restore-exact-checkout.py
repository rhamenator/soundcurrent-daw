from pathlib import Path
import json,hashlib,subprocess
root=Path.home()/'soundcurrent-daw-stretch-f9a6353';head='f9a63532685c988b4d7203da537957cab41dff92'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
assert subprocess.check_output(['git','rev-parse','--show-object-format'],cwd=root,text=True).strip()=='sha1'
(root/'.git/info/attributes').write_text('* -text\n',encoding='utf-8')
changed=[]
for record in subprocess.check_output(['git','ls-files','--stage','-z'],cwd=root).split(b'\0'):
 if not record:continue
 meta,name=record.split(b'\t',1);name=name.decode('utf-8');expected=meta.split()[1].decode();p=root/name
 if not p.is_file():continue
 b=p.read_bytes();actual=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
 if actual!=expected:
  b=subprocess.check_output(['git','show',head+':'+name],cwd=root)
  assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==expected
  p.write_bytes(b);changed.append(name)
manifest=json.loads((Path.home()/'soundcurrent-stretch-source-inputs.json').read_text(encoding='utf-8'))
for n,h in manifest.items():assert hashlib.sha256((root/n).read_bytes()).hexdigest()==h,n
subprocess.run(['git','diff','--exit-code','HEAD'],cwd=root,check=True)
status=subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=root,text=True);assert not status.strip(),status
print(json.dumps({'head':head,'sourceInputs':len(manifest),'exactNativeBlobCheckout':True,'additionalRestoredFiles':changed,'trackedClean':True}))
