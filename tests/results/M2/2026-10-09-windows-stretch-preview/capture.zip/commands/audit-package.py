# SPDX-License-Identifier: GPL-3.0-only
"""Check local frozen package bytes and selected complete-source members."""
from pathlib import Path
import hashlib, json, tarfile, subprocess

ROOT = Path(__file__).resolve().parents[2]
p = ROOT / '.cache/windows-stretch-preview-20261009232400'
r = json.loads((p / 'receipt.json').read_text())
head = r['sourceHead']
sha = lambda b: hashlib.sha256(b).hexdigest()
for n, v in r['artifacts'].items():
    f = p / n
    assert f.stat().st_size == v['bytes'] and sha(f.read_bytes()) == v['sha256']
for n, v in r['payload'].items():
    f = p / 'payload' / n
    assert f.stat().st_size == v['bytes'] and sha(f.read_bytes()) == v['sha256']
assert not r['cleanInstallQualified'] and not r['nativeAudioReplayed'] and not r['releaseUploaded']
b = json.loads((ROOT / '.cache/windows-stretch-native-20261009/retained/build-inputs.json').read_text())
expected = {v['name']: v['sha256'] for v in b['files']}
for n in ['third_party/rubberband/COPYING', 'LICENSE', 'packaging/windows/preview.nsi.in', 'THIRD-PARTY-NOTICES.md']:
    expected[n] = sha(subprocess.check_output(['git', 'show', head + ':' + n], cwd=ROOT))
source = p / next(n for n in r['artifacts'] if n.endswith('-source.tar.gz'))
found = set()
with tarfile.open(source, mode='r|gz') as t:
    for m in t:
        n = m.name.removeprefix('soundcurrent-daw/')
        if n in expected:
            assert m.isfile() and sha(t.extractfile(m).read()) == expected[n], n
            assert n not in found
            found.add(n)
assert found == set(expected), (len(found), len(expected))
audit = {'format': 'sc-windows-stretch-package-audit-v1', 'sourceHead': head,
         'sourceTree': b['sourceTree'], 'nativeSourceInputs': 661,
         'sourceArchiveInputsChecked': len(found), 'artifactIdentities': r['artifacts'],
         'payloadFiles': len(r['payload']), 'artifactHashesVerified': True,
         'payloadHashesVerified': True, 'sourceArchiveInputsVerified': True,
         'nativeInstalledAcceptance': False, 'releaseUploaded': False}
(ROOT / '.cache/windows-stretch-native-20261009/package-audit.json').write_text(json.dumps(audit, indent=2) + '\n')
print(json.dumps(audit, indent=2))
