$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$root=Join-Path $env:USERPROFILE 'soundcurrent-daw-stretch-f9a6353'
$out=Join-Path $env:USERPROFILE 'soundcurrent-stretch-qualification-f9a6353'
$sdk=Join-Path $env:USERPROFILE 'soundcurrent-daw-msvc-sdk-v1'
$env:PATH=$sdk+'\qt\bin;'+$sdk+'\sndfile-build-v2\Release;'+$env:PATH
$env:QT_QPA_PLATFORM='windows'
$exe=Join-Path $root 'build/Release/soundcurrent-daw.exe'
if(Test-Path (Join-Path $out 'main-qualification.json')) {throw 'Main receipt already exists'}
$p=Start-Process -FilePath $exe -ArgumentList '--language','en' -WorkingDirectory $root -PassThru -RedirectStandardOutput (Join-Path $out 'main.stdout') -RedirectStandardError (Join-Path $out 'main.stderr')
$handle=$p.Handle
$deadline=[DateTime]::UtcNow.AddSeconds(15)
do {$p.Refresh();if($p.MainWindowHandle -ne 0) {break};Start-Sleep -Milliseconds 100} while([DateTime]::UtcNow -lt $deadline)
if($p.HasExited -or $p.MainWindowHandle -eq 0 -or $p.MainWindowTitle -ne 'SoundCurrent DAW' -or $p.SessionId -eq 0) {throw 'No actual interactive main window'}
$window=[ordered]@{pid=$p.Id;exe=$exe;exeSha256=(Get-FileHash $exe -Algorithm SHA256).Hash.ToLowerInvariant();sessionId=$p.SessionId;windowHandle=$p.MainWindowHandle.ToInt64();title=$p.MainWindowTitle}
$window|ConvertTo-Json|Set-Content (Join-Path $out 'main-window.json') -Encoding UTF8
Start-Sleep -Seconds 3
if(!$p.CloseMainWindow()) {throw 'Normal main close refused'}
if(!$p.WaitForExit(15000)) {throw 'Normal main close timed out'}
$p.Refresh();if($null -eq $p.ExitCode -or $p.ExitCode -ne 0) {throw 'Actual main exit not zero'}
[ordered]@{sourceCommit='f9a63532685c988b4d7203da537957cab41dff92';exeSha256=$window.exeSha256;exeBytes=(Get-Item $exe).Length;pid=$p.Id;sessionId=$window.sessionId;title=$window.title;exitCode=$p.ExitCode;nativeAudioActivated=$false;scope='Actual native main window and normal close using reviewed developer SDK PATH; installation not qualified'}|ConvertTo-Json|Set-Content (Join-Path $out 'main-qualification.json') -Encoding UTF8
