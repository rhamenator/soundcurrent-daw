$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
Set-Location (Join-Path $env:USERPROFILE 'soundcurrent-daw-stretch-f9a6353')
$head=(& git rev-parse HEAD).Trim()
if($head -ne 'f9a63532685c988b4d7203da537957cab41dff92') {throw 'Unexpected native checkout'}
$expected=(& git rev-parse 'HEAD^{tree}').Trim()
& git -c core.fsmonitor=false -c core.fscache=false add --update
if($LASTEXITCODE -ne 0) {exit $LASTEXITCODE}
$indexed=(& git write-tree).Trim()
if($indexed -ne $expected) {throw 'Index refresh changed frozen source tree'}
$status=(& git status --porcelain --untracked-files=no)
[ordered]@{head=$head;expectedTree=$expected;indexedTree=$indexed;status=$status}|ConvertTo-Json -Depth 5
if($status) {exit 1}
exit 0
