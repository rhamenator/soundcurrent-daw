$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$root=Join-Path $env:USERPROFILE 'soundcurrent-daw-stretch-f9a6353'
$out=Join-Path $env:USERPROFILE 'soundcurrent-stretch-qualification-f9a6353'
$sdk=Join-Path $env:USERPROFILE 'soundcurrent-daw-msvc-sdk-v1'
$stage=Join-Path $out 'deploy'
if(Test-Path $stage) {throw 'New owned deployment stage exists'}
New-Item -ItemType Directory -Path $stage|Out-Null
foreach($name in @('soundcurrent-daw.exe','sc-import-inspect-worker.exe','sc-approved-wave-probe.exe','sc-media-import-worker.exe','sc-stretch-render-worker.exe')) {Copy-Item (Join-Path $root ('build/Release/'+$name)) $stage}
Copy-Item (Join-Path $sdk 'sndfile-build-v2/Release/sndfile.dll') $stage
$env:PATH=$sdk+'\qt\bin;'+$env:PATH
& (Join-Path $sdk 'qt/bin/windeployqt.exe') --release --no-compiler-runtime --no-translations --no-opengl-sw --no-system-d3d-compiler --no-system-dxc-compiler --skip-plugin-types generic,networkinformation,tls,sqldrivers,printsupport --dir $stage (Join-Path $stage 'soundcurrent-daw.exe')
if($LASTEXITCODE -ne 0) {exit $LASTEXITCODE}
$files=@(Get-ChildItem $stage -Recurse -File|ForEach-Object {[ordered]@{path=$_.FullName.Substring($stage.Length+1).Replace('\','/');bytes=$_.Length;sha256=(Get-FileHash $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()}})
[ordered]@{files=$files}|ConvertTo-Json -Depth 6|Set-Content (Join-Path $out 'deploy-manifest.json') -Encoding UTF8
Compress-Archive -Path (Join-Path $stage '*') -DestinationPath (Join-Path $out 'deploy.zip')
Copy-Item (Join-Path $root 'build/Testing/Temporary/LastTest.log') (Join-Path $out 'native-desktop-LastTest.log')
[ordered]@{files=$files;sourceCommit=(& git -C $root rev-parse HEAD).Trim();sourceClean=(-not (& git -C $root status --porcelain --untracked-files=no))}|ConvertTo-Json -Depth 6
