$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
& py -3 (Join-Path $env:USERPROFILE 'soundcurrent-stretch-restore-exact-checkout.py')
if($LASTEXITCODE -ne 0) {exit $LASTEXITCODE}
$root=Join-Path $env:USERPROFILE 'soundcurrent-daw-stretch-f9a6353'
Set-Location $root
$head=(& git rev-parse HEAD).Trim()
if($head -ne 'f9a63532685c988b4d7203da537957cab41dff92') {throw 'Native source HEAD mismatch'}
if((& git status --porcelain --untracked-files=no)) {throw 'Native tracked source dirty'}
$manifest=Get-Content -Raw (Join-Path $env:USERPROFILE 'soundcurrent-stretch-source-inputs.json')|ConvertFrom-Json
foreach($entry in $manifest.PSObject.Properties) {
 if((Get-FileHash -Algorithm SHA256 -LiteralPath $entry.Name).Hash.ToLowerInvariant() -ne $entry.Value) {throw ('Native input mismatch: '+$entry.Name)}
}
$sdk=Join-Path $env:USERPROFILE 'soundcurrent-daw-msvc-sdk-v1'
$lib=Join-Path $sdk 'sndfile-build-v2/Release/sndfile.lib'
& 'C:\Program Files\CMake\bin\cmake.exe' -S . -B build -G 'Visual Studio 17 2022' -A x64 '-DSC_BUILD_DESKTOP=ON' '-DSC_BUILD_MEDIA=ON' '-DSC_BUILD_PIPEWIRE=OFF' '-DBUILD_TESTING=ON' ('-DCMAKE_PREFIX_PATH='+$sdk+'\qt') ('-DSNDFILE_LIBRARY='+$lib)
if($LASTEXITCODE -ne 0) {exit $LASTEXITCODE}
[ordered]@{head=$head;tree=(& git rev-parse 'HEAD^{tree}').Trim();inputCount=@($manifest.PSObject.Properties).Count;source=$root;configured=$true;nativeAudio=$false}|ConvertTo-Json -Depth 4
