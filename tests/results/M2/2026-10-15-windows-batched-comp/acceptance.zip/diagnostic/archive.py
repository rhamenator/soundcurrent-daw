from pathlib import Path
import json,subprocess,hashlib,zipfile
r=Path(__file__).resolve().parent;repo=r.parents[1];out=repo/'tests/results/M2/2026-10-15-windows-batched-comp';out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();files={}
for p in r.iterdir():
 if p.is_file() and p.suffix in ['.py','.ps1','.cmd','.json','.log']:files['diagnostic/'+p.name]=p.read_bytes()
for p in (r/'captured').rglob('*'):
 if p.is_file():files['native/'+str(p.relative_to(r/'captured'))]=p.read_bytes()
for p in (r/'ci').iterdir():
 if p.suffix in ['.json','.log']:files['ci/'+p.name]=p.read_bytes()
assert json.loads((r/'verification.json').read_bytes())['passed']
q=json.loads((r/'captured/continued/qualification.json').read_bytes());assert q['passed'] and q['projectFilesUnchanged']==225 and q['assemblySamplesCompared']==16256
head='8bcc163aebd740f453b957cb007dec1224aac71c';assert q['sourceHead']==head
files['source.patch']=subprocess.check_output(['git','diff','82bae0027581a99758245f90625590383a1b923d',head,'--','src','include','tests/comp_pair_assembly_tests.cpp'],cwd=repo)
files['scope.txt']=b'Native Windows fixed-history verification, not installed whole-render timing. Same original 225 project files and all 16256 samples verified. First source-byte admission failure retained. Exact input delivery repairs preparation without changing a product test, deadline or expectation. No installed preview or physical audio changed. All VMs shut off after collection.\n'
index={n:dict(bytes=len(b),sha256=sha(b)) for n,b in files.items()};files['payload-manifest.json']=(json.dumps(index,indent=2)+'\n').encode()
archive=out/'acceptance.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,b in files.items():z.writestr(n,b)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,v in index.items():assert len(z.read(n))==v['bytes'] and sha(z.read(n))==v['sha256']
manifest=dict(archive=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),entries=len(files),sourceHead=head,qualification=q,applicationBinariesIncluded=False)
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest))
