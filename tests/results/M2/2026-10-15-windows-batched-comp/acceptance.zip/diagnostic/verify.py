from pathlib import Path
import json,hashlib,subprocess,datetime,zipfile
r=Path(__file__).resolve().parent;repo=r.parents[1];load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
captureSha=hashlib.sha256((r/'observed.zip').read_bytes()).hexdigest()
assert captureSha=='f3f117a2d430756d5187fa89d10de7e889252e45d2df15ebbb3d71945d0761e3'
with zipfile.ZipFile(r/'observed.zip') as z:assert z.testzip() is None
q=load(r/'captured/continued/qualification.json');assert q['passed']
assert load(r/'captured/continued/terminal.json')['passed']
assert not load(r/'captured/observed/terminal.json')['passed']
assert load(r/'captured/continued/retirement.json')['ownedProcessesRemaining']==0
expected=load(r/'expected-source.json');actual=load(r/'captured/continued/source-inputs.json');assert expected==actual
local=load(repo/'.cache/comp-profile-335/project-inputs.json');native=load(r/'captured/continued/project-inputs.json')
assert local=={n.replace('\\','/'):v for n,v in native.items()}
baseline=load(repo/'.cache/windows-comp-timing-327/captured/continued/qualification.json')
assert q['binaries']['probe-before.exe']==baseline['binaries']['probe-after.exe']
assert q['binaries']['sndfile.dll']==baseline['binaries']['sndfile.dll']
commands=load(r/'captured/continued/commands.json');assert all(x['exitCode']==0 for x in commands)
for i in range(3):
 for version in ['before','after']:
  rows=[json.loads(l) for l in (r/f'captured/continued/{version}-{i}.stdout').read_text().splitlines()]
  assert rows[-1]['event']=='complete' and rows[-1]['comparedSamples']==16256
testOutput=(r/'captured/continued/tests.stdout').read_text()
assert '100% tests passed' in testOutput and testOutput.count('   Passed ')==4
active=subprocess.check_output(['virsh','list','--name'],text=True).strip();assert not active
ci=load(r/'ci/retention.json');assert ci['conclusion']=='success' and len(ci['jobs'])==15 and ci['allAvailableOriginalArchivesRetained'] and ci['allFullLogsRetained']
report=dict(passed=True,sourceFilesVerified=len(actual),projectFilesUnchanged=len(local),nativeRuns=6,eachRunComparedSamples=16256,medianSeconds=q['medianSeconds'],ratio=q['ratio'],nativeTestsPassed=4,originalInputAdmissionFailureRetained=True,allVmsOff=True,wholeRenderMeasured=False,installedPreviewsChanged=False,originalCaptureSha256=captureSha,ciRun=ci['run'],ciHead=ci['head'],ciJobs=len(ci['jobs']),ciArtifacts=len(ci['artifacts']),checkedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(r/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
