$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$r=Join-Path $env:USERPROFILE 'soundcurrent-batched-comp-336'
$old=Join-Path $env:USERPROFILE 'soundcurrent-comp-timing-327'
if(-not(Test-Path (Join-Path $r 'continued/terminal.json'))){throw 'Diagnostic still active'}
$owned=Get-CimInstance Win32_Process|Where-Object {($_.ExecutablePath -like ($r+'*')) -or ($_.ExecutablePath -like ($old+'*')) -or ($_.Name -in @('python.exe','ninja.exe','cmake.exe','cl.exe','link.exe','ctest.exe') -and ($_.CommandLine -like ('*'+$r+'*') -or $_.CommandLine -like ('*'+$old+'*')))}
if($owned){throw 'Owned diagnostic processes still active'}
@{ownedProcessesRemaining=0;nativeAudioActivated=$false;installedPreviewChanged=$false;sourceStatus=(git -C (Join-Path $old 'source') status --porcelain);checkedUtc=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 5|Set-Content (Join-Path $r 'continued/retirement.json') -Encoding UTF8
Compress-Archive -Path (Join-Path $r 'observed'),(Join-Path $r 'continued') -DestinationPath (Join-Path $r 'observed.zip')
Get-FileHash (Join-Path $r 'observed.zip')|Select-Object Hash,Path|ConvertTo-Json
