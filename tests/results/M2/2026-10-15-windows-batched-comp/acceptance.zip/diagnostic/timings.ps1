$r=Join-Path $env:USERPROFILE 'soundcurrent-batched-comp-336/continued'
Get-Content (Join-Path $r 'active.json')
if(Test-Path (Join-Path $r 'terminal.json')){Get-Content (Join-Path $r 'terminal.json')}
if(Test-Path (Join-Path $r 'failure.txt')){Get-Content (Join-Path $r 'failure.txt')}
Get-Content (Join-Path $r 'build.stdout') -Tail 6 -ErrorAction SilentlyContinue
Get-Content (Join-Path $r 'tests.stdout') -Tail 8 -ErrorAction SilentlyContinue

Get-Content (Join-Path $r 'commands.json') -ErrorAction SilentlyContinue
exit 0
