from pathlib import Path
import subprocess,json,hashlib,shutil,time,statistics,zipfile,os,traceback
r=Path(__file__).resolve().parent;out=r/'observed';out.mkdir(exist_ok=False)
old=Path.home()/'soundcurrent-comp-timing-327';source=old/'source';build=old/'build';rows=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(name,args,seconds=120,input=None):
 start=time.monotonic()
 with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
  proc=subprocess.Popen(args,stdin=subprocess.PIPE if input else subprocess.DEVNULL,stdout=stdout,stderr=stderr,cwd=r)
  (out/'active.json').write_text(json.dumps(dict(phase=name,pid=proc.pid,args=args,startedUtc=time.time())))
  try:proc.communicate(input=input,timeout=seconds)
  except subprocess.TimeoutExpired:
   subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'],stdout=stderr,stderr=stderr);proc.wait();raise
 rows.append(dict(name=name,pid=proc.pid,args=args,exitCode=proc.returncode,seconds=time.monotonic()-start))
 (out/'commands.json').write_text(json.dumps(rows,indent=2));assert proc.returncode==0,(name,proc.returncode)
try:
 prior=json.loads((old/'continued/qualification.json').read_text())
 assert prior['passed'] and prior['sourceHead']=='82bae0027581a99758245f90625590383a1b923d'
 for name in ['probe-after.exe','sndfile.dll']:
  assert sha(old/name)==prior['binaries'][name],name
  shutil.copyfile(old/name,r/('probe-before.exe' if name.startswith('probe-') else name))
 project=old/'project-été-Κиїв'
 projectBefore=json.loads((old/'observed/project-inputs.json').read_text())
 assert projectBefore=={str(p.relative_to(project)):sha(p) for p in project.rglob('*') if p.is_file()}
 (out/'project-inputs.json').write_text(json.dumps(projectBefore,indent=2))
 prep=json.loads((r/'prepare.json').read_text());assert sha(r/'update.zip')==prep['updateSha256']
 with zipfile.ZipFile(r/'update.zip') as z:
  assert z.testzip() is None and set(z.namelist())==set(prep['updates'])
  for n in z.namelist():assert not Path(n).is_absolute() and '..' not in Path(n).parts
  z.extractall(source)
 expected=json.loads((r/'expected-source.json').read_text());actual={n:sha(source/n) for n in expected}
 mismatches=[n for n in expected if actual[n]!=expected[n]]
 assert set(mismatches)<=set(['third_party/libsndfile/COPYING','third_party/nlohmann/LICENSE.MIT']),mismatches
 (out/'source-inputs.json').write_text(json.dumps(actual,indent=2))
 run('configure',['cmake','-S',str(old),'-B',str(build),'-DBUILD_TESTING=ON'],60)
 targets=['sc-comp-timing','sc-comp-regeneration-history-tests','sc-comp-protected-worker-fixture']
 run('build',['cmake','--build',str(build),'--target',*targets,'--parallel','1'],420)
 shutil.copyfile(build/'sc-comp-timing.exe',r/'probe-after.exe')
 # Native runtime lookup is inherited by test workers as well as the probe.
 os.environ['PATH']=str(r)+os.pathsep+os.environ['PATH']
 for i in range(3):
  for version in (['before','after'] if i%2==0 else ['after','before']):
   name=f'{version}-{i}';run(name,[str(r/('probe-'+version+'.exe'))],120,json.dumps(dict(root=str(project).replace('\\','/'),assembly='a1a283c7-c9e5-4d5f-bc41-0edadd727ee7')).encode())
   events=[json.loads(l) for l in (out/(name+'.stdout')).read_text().splitlines()];assert events[-1]['event']=='complete' and events[-1]['comparedSamples']==16256
 pattern='^(comp-verified-pair-assembly|comp-owned-assembly-publication|comp-protected-assembly-publication|comp-paired-history-review)$'
 cmd=['ctest','--test-dir',str(build/'source')]
 selected=json.loads(subprocess.check_output(cmd+['--show-only=json-v1','-R',pattern],text=True));assert len(selected['tests'])==4
 (out/'selected-tests.json').write_text(json.dumps(selected,indent=2))
 try:run('tests',cmd+['--output-on-failure','--no-tests=error','-j','1','-R',pattern],1100)
 finally:
  log=build/'source/Testing/Temporary/LastTest.log'
  if log.exists():shutil.copyfile(log,out/'LastTest.log')
 assert projectBefore=={str(p.relative_to(project)):sha(p) for p in project.rglob('*') if p.is_file()}
 median={v:statistics.median(x['seconds'] for x in rows if x['name'].startswith(v+'-')) for v in ['before','after']}
 (out/'qualification.json').write_text(json.dumps(dict(passed=True,sourceHead=prep['head'],sourceFilesVerified=len(actual),gitFilteredLicenseFiles=mismatches,projectFilesUnchanged=len(projectBefore),assemblySamplesCompared=16256,medianSeconds=median,ratio=median['after']/median['before'],binaries={p.name:sha(p) for p in [r/'probe-before.exe',r/'probe-after.exe',r/'sndfile.dll']},physicalAudio=False,installedPreviewChanged=False,wholeRenderMeasured=False),indent=2))
except Exception:
 (out/'failure.txt').write_text(traceback.format_exc());raise
finally:
 # Retain structured evidence and inventory media without bulk-copying PCM.
 inventory=[]
 for folder in ['comp-pair-assembly-evidence','comp-assembly-job-evidence','comp-protected-assembly-evidence','comp-paired-history-evidence']:
  for p in sorted((build/'source'/folder).rglob('*')):
   if p.is_file():
    rel=p.relative_to(build/'source');inventory.append(dict(path=str(rel),bytes=p.stat().st_size,sha256=sha(p)))
    if p.suffix in ['.json','.log','.txt','.ndjson','.stdout','.stderr']:
     dest=out/'test-evidence'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
 (out/'test-file-inventory.json').write_text(json.dumps(inventory,indent=2))
 (out/'terminal.json').write_text(json.dumps(dict(finishedUtc=time.time(),passed=(out/'qualification.json').exists(),pid=os.getpid())))
