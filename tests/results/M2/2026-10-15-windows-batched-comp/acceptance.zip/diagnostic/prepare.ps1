$ErrorActionPreference='Stop'
$r=Join-Path $env:USERPROFILE 'soundcurrent-batched-comp-336'
if(Test-Path $r){throw 'Owned root exists'}
New-Item -ItemType Directory $r|Out-Null
Get-CimInstance Win32_Process|Where-Object {$_.Name -in @('cl.exe','ninja.exe','cmake.exe')}|Select-Object ProcessId,Name,CommandLine|ConvertTo-Json
