$ErrorActionPreference='Stop'
[Diagnostics.Process]::GetCurrentProcess().PriorityClass='BelowNormal'
& cmd.exe /d /c C:\Users\claude\soundcurrent-batched-comp-336\continue.cmd
exit $LASTEXITCODE
