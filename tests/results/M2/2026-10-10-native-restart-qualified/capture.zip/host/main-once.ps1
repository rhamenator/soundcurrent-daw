$ErrorActionPreference='Stop'
$out=Join-Path $env:USERPROFILE 'soundcurrent-render-restart-4fb8'
$root=Join-Path $env:USERPROFILE 'soundcurrent-daw-stretch-f9a6353'
$sdk=Join-Path $env:USERPROFILE 'soundcurrent-daw-msvc-sdk-v1'
$env:PATH=$sdk+'\qt\bin;'+$sdk+'\sndfile-build-v2\Release;'+$env:PATH
$env:QT_QPA_PLATFORM='windows'
Remove-Item Env:\QT_STYLE_OVERRIDE -ErrorAction SilentlyContinue
$exe=Join-Path $root 'build/Release/soundcurrent-daw.exe'
$watch=[Diagnostics.Stopwatch]::StartNew()
$p=Start-Process -FilePath $exe -ArgumentList '--language','en' -WorkingDirectory $root -PassThru -RedirectStandardOutput (Join-Path $out 'main.stdout') -RedirectStandardError (Join-Path $out 'main.stderr')
$handle=$p.Handle
$p.PriorityClass='BelowNormal'
$record=[ordered]@{exeBytes=(Get-Item $exe).Length;nativeAudioActivated=$false;pid=$p.Id;exeSha256=(Get-FileHash $exe -Algorithm SHA256).Hash.ToLowerInvariant();sourceCommit='4fb8c1cdf1b1365e5834256f4b39b51566dbed52';sourceTree='d1b6be0bd9114af21d73a5dd6ba8172b53510c44';styleOverride=$false;nativeAudio=$false;seconds=$null;windowHandle=0;title='';sessionId=$p.SessionId;normalClose=$false;forcedRetirement=$false;exitCode=$null}
try {
 $until=[DateTime]::UtcNow.AddSeconds(20)
 do {$p.Refresh();if($p.HasExited -or $p.MainWindowHandle -ne 0) {break};Start-Sleep -Milliseconds 100} while([DateTime]::UtcNow -lt $until)
 $record.windowHandle=$p.MainWindowHandle.ToInt64();$record.title=$p.MainWindowTitle
 if(!$p.HasExited -and $record.windowHandle -ne 0) {
  $record.normalClose=$p.CloseMainWindow()
  if(!$p.WaitForExit(5000)) {$p.Kill();$record.forcedRetirement=$true;$p.WaitForExit(5000)|Out-Null}
 } elseif(!$p.HasExited) {
  $record.modules=@($p.Modules|ForEach-Object {$_.ModuleName})
  $record.cpuSeconds=$p.TotalProcessorTime.TotalSeconds
  $p.Kill();$record.forcedRetirement=$true;$p.WaitForExit(5000)|Out-Null
 }
 $p.Refresh();$record.exitCode=$p.ExitCode
} finally {
 if(!$p.HasExited) {$p.Kill();$p.WaitForExit(5000)|Out-Null;$record.forcedRetirement=$true}
 $record.seconds=$watch.Elapsed.TotalSeconds
 $record|ConvertTo-Json -Depth 5|Set-Content (Join-Path $out 'main-terminal.json') -Encoding UTF8
 if($record.normalClose -and !$record.forcedRetirement -and $record.exitCode -eq 0) {$record|ConvertTo-Json -Depth 5|Set-Content (Join-Path $out 'main-qualification.json') -Encoding UTF8}
}
