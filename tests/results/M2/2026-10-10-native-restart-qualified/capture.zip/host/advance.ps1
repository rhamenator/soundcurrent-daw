$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';$env:GIT_TERMINAL_PROMPT='0'
(Get-Process -Id $PID).PriorityClass='BelowNormal'
$root=Join-Path $env:USERPROFILE 'soundcurrent-daw-stretch-f9a6353'
$out=Join-Path $env:USERPROFILE 'soundcurrent-render-restart-4fb8'
if(Test-Path $out) {throw 'Fresh output already exists'}
Set-Location $root
& git -c core.fsmonitor=false -c core.fscache=false update-index --really-refresh
if($LASTEXITCODE -ne 0 -or (& git status --porcelain --untracked-files=no)) {throw 'Preserve unexpected source changes'}
& git fetch origin main
if($LASTEXITCODE -ne 0) {throw 'Fetch failed'}
& git checkout --detach 4fb8c1cdf1b1365e5834256f4b39b51566dbed52
if($LASTEXITCODE -ne 0) {throw 'Checkout failed'}
& git -c core.fsmonitor=false -c core.fscache=false update-index --really-refresh
if($LASTEXITCODE -ne 0 -or (& git status --porcelain --untracked-files=no)) {throw 'Source not clean'}
if((& git rev-parse 'HEAD^{tree}').Trim() -ne 'd1b6be0bd9114af21d73a5dd6ba8172b53510c44') {throw 'Wrong source tree'}
New-Item -ItemType Directory -Path $out|Out-Null
[ordered]@{pid=$PID;startedUtc=[DateTime]::UtcNow.ToString('o');sourceCommit=(& git rev-parse HEAD).Trim()}|ConvertTo-Json|Set-Content (Join-Path $out 'build-running.json') -Encoding UTF8
[ordered]@{sourceCommit=(& git rev-parse HEAD).Trim();sourceTree=(& git rev-parse 'HEAD^{tree}').Trim();sourceClean=$true;nativeAudio=$false;parallel=2;priority='BelowNormal'}|ConvertTo-Json|Set-Content (Join-Path $out 'source-before.json') -Encoding UTF8
$sdk=Join-Path $env:USERPROFILE 'soundcurrent-daw-msvc-sdk-v1'
& 'C:\Program Files\CMake\bin\cmake.exe' -S . -B build -G 'Visual Studio 17 2022' -A x64 -DSC_BUILD_DESKTOP=ON -DSC_BUILD_MEDIA=ON -DSC_BUILD_PIPEWIRE=OFF -DBUILD_TESTING=ON -DSC_BUILD_PROTECTED_WARP_PROBE=ON ('-DCMAKE_PREFIX_PATH='+$sdk+'\qt') ('-DSNDFILE_LIBRARY='+$sdk+'\sndfile-build-v2\Release\sndfile.lib')
if($LASTEXITCODE -ne 0) {throw 'Configure failed'}
$watch=[Diagnostics.Stopwatch]::StartNew()
try {
 & 'C:\Program Files\CMake\bin\cmake.exe' --build build --config Release --parallel 2 --target soundcurrent-daw sc-stretch-artifact-tests sc-protected-warp-probe sc-stretch-controller-tests sc-stretch-ui-tests sc-protected-warp-ui-tests sc-import-inspect-worker sc-approved-wave-probe sc-media-import-worker sc-localization-tests
 if($LASTEXITCODE -ne 0) {throw 'Incremental build failed'}
 if((& git status --porcelain --untracked-files=no)) {throw 'Source changed during build'}
 $hashes=@{}
 foreach($name in @('soundcurrent-daw','sc-stretch-render-worker','sc-stretch-artifact-tests','sc-protected-warp-probe','sc-stretch-controller-tests','sc-stretch-ui-tests','sc-protected-warp-ui-tests','sc-import-inspect-worker','sc-approved-wave-probe','sc-media-import-worker')) {$hashes[$name]=(Get-FileHash ('build/Release/'+$name+'.exe') -Algorithm SHA256).Hash.ToLowerInvariant()}
 [ordered]@{exitCode=0;seconds=$watch.Elapsed.TotalSeconds;sourceCommit=(& git rev-parse HEAD).Trim();sourceTree=(& git rev-parse 'HEAD^{tree}').Trim();nativeAudio=$false;exeSha256=$hashes}|ConvertTo-Json -Depth 4|Set-Content (Join-Path $out 'build-terminal.json') -Encoding UTF8
} catch {
 [ordered]@{failed=$true;error=$_.Exception.Message;seconds=$watch.Elapsed.TotalSeconds}|ConvertTo-Json|Set-Content (Join-Path $out 'build-terminal.json') -Encoding UTF8;throw
}
