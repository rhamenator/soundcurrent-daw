from pathlib import Path,PurePosixPath
import subprocess,tarfile,hashlib,json,time
r=Path.cwd();out=r/'.cache/windows-render-restart-4fb8';package=r/'.cache/windows-render-restart-preview-20261010183111';receipt=json.loads((package/'receipt.json').read_text());head=receipt['sourceHead']
items={}
for line in subprocess.check_output(['git','ls-tree','-r','-z',head]).split(b'\0'):
 if not line:continue
 m,n=line.split(b'\t',1);mode,typ,digest=m.decode().split();assert typ=='blob';items[n.decode()]=(mode,digest)
archive=next(package.glob('*source.tar.gz'));seen=set();conversions=[];total=0
with tarfile.open(archive,mode='r|gz') as tf:
 prefix=None
 for member in tf:
  parts=PurePosixPath(member.name).parts
  if prefix is None:prefix=parts[0]
  assert parts[0]==prefix and '..' not in parts
  if member.isdir():continue
  name=str(PurePosixPath(*parts[1:]));assert name in items and name not in seen,(name,'unexpected/duplicate');seen.add(name)
  mode,expected=items[name];total+=member.size
  if member.issym():
   assert mode=='120000';b=member.linkname.encode();h=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b)
  else:
   assert member.isfile() and mode in ('100644','100755');f=tf.extractfile(member);assert f
   if name.endswith('.ps1'):
    b=f.read();normalized=b.replace(b'\r\n',b'\n');h=hashlib.sha1(b'blob '+str(len(normalized)).encode()+b'\0'+normalized)
    if b!=normalized:conversions.append(name)
   else:
    h=hashlib.sha1(b'blob '+str(member.size).encode()+b'\0');left=member.size
    while left:
     b=f.read(min(left,1048576));assert b;left-=len(b);h.update(b)
   assert bool(member.mode&0o111)==(mode=='100755'),(name,'execute mode')
  assert h.hexdigest()==expected,(name,'Git blob mismatch')
assert seen==set(items),(len(seen),len(items))
result={'sourceHead':head,'sourceTree':subprocess.check_output(['git','rev-parse',head+'^{tree}']).decode().strip(),'archive':archive.name,'archiveSha256':receipt['artifacts'][archive.name]['sha256'],'trackedMembersVerified':len(seen),'uncompressedMemberBytes':total,'gitExportCrlfPowerShellFiles':conversions,'everyTrackedBlobAndModeVerified':True,'extractionPerformed':False}
(out/'source-archive-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='gitExportCrlfPowerShellFiles'}))
