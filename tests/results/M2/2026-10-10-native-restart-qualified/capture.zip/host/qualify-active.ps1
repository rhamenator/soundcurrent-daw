$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
(Get-Process -Id $PID).PriorityClass='BelowNormal'
$root=Join-Path $env:USERPROFILE 'soundcurrent-daw-stretch-f9a6353'
$out=Join-Path $env:USERPROFILE 'soundcurrent-render-restart-4fb8'
$sdk=Join-Path $env:USERPROFILE 'soundcurrent-daw-msvc-sdk-v1'
$env:PATH=$sdk+'\qt\bin;'+$sdk+'\sndfile-build-v2\Release;'+$env:PATH
Set-Location $root
if(!(Test-Path (Join-Path $out 'build-terminal.json'))) {throw 'No actual terminal build record'}
$build=Get-Content -Raw (Join-Path $out 'build-terminal.json')|ConvertFrom-Json
if($build.exitCode -ne 0) {throw 'Actual build failed'}
Move-Item (Join-Path $out 'qualification-terminal.json') (Join-Path $out 'qualification-initial-scope-refusal.json')
[ordered]@{pid=$PID;startedUtc=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $out 'qualification-running.json') -Encoding UTF8
try {
 & py -3 (Join-Path $env:USERPROFILE 'soundcurrent-render-restart-4fb8-helpers-export.py')
 if($LASTEXITCODE -ne 0) {throw 'Fresh native helper qualification failed'}
 & py -3 tests/stretch_worker_tests.py build/Release/sc-stretch-render-worker.exe build/Release/sc-stretch-artifact-tests.exe --qualification (Join-Path $out 'stretch-worker-qualification.json')
 if($LASTEXITCODE -ne 0) {throw 'Actual v4 worker bank failed'}
 & py -3 tests/protected_warp_worker_tests.py build/Release/sc-stretch-render-worker.exe build/Release/sc-stretch-artifact-tests.exe build/Release/sc-protected-warp-probe.exe --qualification (Join-Path $out 'protected-warp-qualification.json')
 if($LASTEXITCODE -ne 0) {throw 'Actual v5 worker bank failed'}
 $env:QT_QPA_PLATFORM='offscreen'
 & 'C:\Program Files\CMake\bin\ctest.exe' --test-dir build --build-config Release --output-on-failure --tests-regex '^(desktop-stretch-(ui|controller)|desktop-protected-warp-ui|desktop-localization|protected-warp-package-inputs|worker-observation-failures)$'
 if($LASTEXITCODE -ne 0) {throw 'Actual desktop/observer qualification failed'}
 Copy-Item build/Testing/Temporary/LastTest.log (Join-Path $out 'native-desktop-LastTest.log')
 & py -3 (Join-Path $env:USERPROFILE 'soundcurrent-render-restart-4fb8-input-check-export.py')
 if($LASTEXITCODE -ne 0) {throw 'Post-test native input verification failed'}
 [ordered]@{exitCode=0;sourceCommit=(& git rev-parse HEAD).Trim();sourceTree=(& git rev-parse 'HEAD^{tree}').Trim();nativeAudio=$false}|ConvertTo-Json|Set-Content (Join-Path $out 'qualification-terminal.json') -Encoding UTF8
} catch {
 [ordered]@{failed=$true;error=$_.Exception.Message}|ConvertTo-Json|Set-Content (Join-Path $out 'qualification-terminal.json') -Encoding UTF8;throw
}
