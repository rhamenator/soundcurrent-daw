@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0actions.ps1" select > "%USERPROFILE%\SoundCurrent-Restart-4fb8\records\select-script.log" 2>&1
