@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0final.ps1" > "%USERPROFILE%\SoundCurrent-Restart-4fb8\records\final-script.log" 2>&1
