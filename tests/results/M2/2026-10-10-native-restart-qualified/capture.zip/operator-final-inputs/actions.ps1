﻿param([Parameter(Mandatory=$true)][string]$Stage)
$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$root=Join-Path $env:USERPROFILE 'SoundCurrent-Restart-4fb8'
if((Get-CimInstance Win32_ComputerSystemProduct).UUID.ToLowerInvariant() -ne '670168f5-4e3f-4e7f-b218-3583db31f0f8') {throw 'Wrong owned clone'}
Add-Type -AssemblyName UIAutomationClient,UIAutomationTypes,System.Windows.Forms
$p=Get-Process -Id ([int](Get-Content (Join-Path $root 'main-pid.txt')))
if($p.SessionId -eq 0 -or !$p.MainWindowTitle.StartsWith('SoundCurrent DAW') -or !$p.Path.StartsWith($env:LOCALAPPDATA+'\Programs\SoundCurrent DAW Preview\',[StringComparison]::OrdinalIgnoreCase)) {throw 'Wrong actual installed app'}
Add-Type 'using System;using System.Runtime.InteropServices;public class SCForeground { [DllImport("user32.dll")]public static extern bool SetForegroundWindow(IntPtr h); [DllImport("user32.dll")]public static extern IntPtr GetForegroundWindow(); [DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint pid); }'
function Focus-App {
 $p.Refresh();if(![SCForeground]::SetForegroundWindow($p.MainWindowHandle)) {throw 'Cannot focus actual app'}
 Start-Sleep -Milliseconds 500
 [uint32]$owner=0;[SCForeground]::GetWindowThreadProcessId([SCForeground]::GetForegroundWindow(),[ref]$owner)|Out-Null
 if($owner -ne $p.Id) {throw 'Foreground changed; refuse keys'}
}
function Save-Tree($Name) {
 $condition=New-Object Windows.Automation.PropertyCondition ([Windows.Automation.AutomationElement]::ProcessIdProperty),$p.Id
 $rows=@();foreach($e in [Windows.Automation.AutomationElement]::RootElement.FindAll([Windows.Automation.TreeScope]::Descendants,$condition)) {
  $c=$e.Current;$rows+=@{name=$c.Name;id=$c.AutomationId;class=$c.ClassName;type=$c.ControlType.ProgrammaticName;enabled=$c.IsEnabled;offscreen=$c.IsOffscreen;rect=@($c.BoundingRectangle.X,$c.BoundingRectangle.Y,$c.BoundingRectangle.Width,$c.BoundingRectangle.Height)}
 }
 $rows|ConvertTo-Json -Depth 5|Set-Content (Join-Path $root ('records\uia-'+$Name+'.json')) -Encoding UTF8
}
switch($Stage) {
 'open' {Focus-App;[Windows.Forms.SendKeys]::SendWait('^o');Start-Sleep -Milliseconds 1200;[Windows.Forms.Clipboard]::SetText((Join-Path $root 'project-été-Κиїв'));[Windows.Forms.SendKeys]::SendWait('^l');Start-Sleep -Milliseconds 300;[Windows.Forms.SendKeys]::SendWait('^v');Start-Sleep -Milliseconds 500;[Windows.Forms.SendKeys]::SendWait('{ENTER}');Start-Sleep -Milliseconds 800;[Windows.Forms.SendKeys]::SendWait('{ENTER}');Start-Sleep -Milliseconds 1500;Save-Tree 'project';Copy-Item -LiteralPath (Join-Path $root 'project-été-Κиїв\project.json') (Join-Path $root 'records\project-open.json')}
 'select' {
  $conditions=New-Object Windows.Automation.AndCondition (New-Object Windows.Automation.PropertyCondition ([Windows.Automation.AutomationElement]::ProcessIdProperty),$p.Id),(New-Object Windows.Automation.PropertyCondition ([Windows.Automation.AutomationElement]::NameProperty),'Select Folder')
  $elements=@([Windows.Automation.AutomationElement]::RootElement.FindAll([Windows.Automation.TreeScope]::Descendants,$conditions)|Where-Object {!$_.Current.IsOffscreen})
  if($elements.Count -ne 1) {throw 'No unique actual folder selection button'}
  ([Windows.Automation.InvokePattern]$elements[0].GetCurrentPattern([Windows.Automation.InvokePattern]::Pattern)).Invoke();Start-Sleep -Milliseconds 1200;Save-Tree 'selected';Copy-Item -LiteralPath (Join-Path $root 'project-été-Κиїв\project.json') (Join-Path $root 'records\project-selected.json')
 }
 'dump' {Save-Tree 'current'}
 default {throw 'Unknown owned action'}
}
& (Join-Path $root 'collect.ps1') ('action-4fb8-'+$Stage+'.zip')

if($Stage -eq 'select') { $normal=$p.CloseMainWindow();$exited=$p.WaitForExit(10000);@{pid=$p.Id;normalCloseRequested=$normal;exited=$exited;forced=$false;exitCode=$(if($exited){$p.ExitCode}else{$null});utc=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $root 'records\selected-normal-close.json') -Encoding UTF8;& (Join-Path $root 'collect.ps1') 'selected-close-4fb8.zip' }
