﻿$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$root=Join-Path $env:USERPROFILE 'SoundCurrent-Restart-4fb8'
if((Get-CimInstance Win32_ComputerSystemProduct).UUID.ToLowerInvariant() -ne '670168f5-4e3f-4e7f-b218-3583db31f0f8') {throw 'Wrong owned clone'}
$id=[int](Get-Content (Join-Path $root 'main-pid.txt'))
$p=Get-Process -Id $id -ErrorAction Stop
$handle=$p.Handle
if(!$p.Path.StartsWith($env:LOCALAPPDATA+'\Programs\SoundCurrent DAW Preview\',[StringComparison]::OrdinalIgnoreCase)) {throw 'Wrong installed process'}
$report=[ordered]@{pid=$p.Id;path=$p.Path;hash=(Get-FileHash $p.Path -Algorithm SHA256).Hash;title=$p.MainWindowTitle;startUtc=$p.StartTime.ToUniversalTime().ToString('o');forced=$false}
$report.normalCloseRequested=$p.CloseMainWindow();$report.exited=$p.WaitForExit(10000)
if($report.exited){$report.exitCode=$p.ExitCode}
$report.utc=[DateTime]::UtcNow.ToString('o')
$report|ConvertTo-Json|Set-Content (Join-Path $root 'records\final-normal-close.json') -Encoding UTF8
Set-Content (Join-Path $root 'observer-stop.txt') 'stop'
Start-Sleep -Seconds 3
@(Get-Process|Where-Object {$_.ProcessName.StartsWith('soundcurrent')}|Select-Object Id,ProcessName,Path)|ConvertTo-Json|Set-Content (Join-Path $root 'records\final-owned-processes.json') -Encoding UTF8
& (Join-Path $root 'collect.ps1') 'final-normal-close-4fb8.zip'
if(!$report.exited -or $report.exitCode -ne 0) {throw 'Actual app did not close normally'}
