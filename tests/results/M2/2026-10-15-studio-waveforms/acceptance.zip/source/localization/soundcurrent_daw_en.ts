<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1" language="en" sourcelanguage="en_US">
  <context>
    <name>EquipmentProfiles</name>
    <message>
      <source>Published response and editable correction curves</source>
      <translation>Published response and editable correction curves</translation>
    </message>
    <message>
      <source>Equipment profile editor</source>
      <translation>Equipment profile editor</translation>
    </message>
    <message>
      <source>Brand</source>
      <translation>Brand</translation>
    </message>
    <message>
      <source>Family</source>
      <translation>Family</translation>
    </message>
    <message>
      <source>Equipment subtype</source>
      <translation>Equipment subtype</translation>
    </message>
    <message>
      <source>Active / passive / unknown</source>
      <translation>Active / passive / unknown</translation>
    </message>
    <message>
      <source>Model</source>
      <translation>Model</translation>
    </message>
    <message>
      <source>Source</source>
      <translation>Source</translation>
    </message>
    <message>
      <source>Conditions</source>
      <translation>Conditions</translation>
    </message>
    <message>
      <source>Type</source>
      <translation>Type</translation>
    </message>
    <message>
      <source>Frequency Hz</source>
      <translation>Frequency Hz</translation>
    </message>
    <message>
      <source>Gain dB</source>
      <translation>Gain dB</translation>
    </message>
    <message>
      <source>Q</source>
      <translation>Q</translation>
    </message>
    <message>
      <source>Undo profile edit</source>
      <translation>Undo profile edit</translation>
    </message>
    <message>
      <source>Redo profile edit</source>
      <translation>Redo profile edit</translation>
    </message>
    <message>
      <source>Add filter</source>
      <translation>Add filter</translation>
    </message>
    <message>
      <source>Remove selected filter</source>
      <translation>Remove selected filter</translation>
    </message>
    <message>
      <source>Undo</source>
      <translation>Undo</translation>
      <extracomment>Reverse the previous editable setting change.</extracomment>
    </message>
    <message>
      <source>Redo</source>
      <translation>Redo</translation>
    </message>
    <message>
      <source>Save modified profile?</source>
      <translation>Save modified profile?</translation>
    </message>
    <message>
      <source>This profile has changed. Save a custom copy before leaving?</source>
      <translation>This profile has changed. Save a custom copy before leaving?</translation>
    </message>
    <message>
      <source>Profile exceeds the 1 MiB limit.</source>
      <translation>Profile exceeds the 1 MiB limit.</translation>
    </message>
    <message>
      <source>Profile is not valid UTF-8.</source>
      <translation>Profile is not valid UTF-8.</translation>
    </message>
    <message>
      <source>Profile exceeds nesting limit.</source>
      <translation>Profile exceeds nesting limit.</translation>
    </message>
    <message>
      <source>Duplicate JSON field in equipment profile.</source>
      <translation>Duplicate JSON field in equipment profile.</translation>
    </message>
    <message>
      <source>Expected a JSON equipment profile.</source>
      <translation>Expected a JSON equipment profile.</translation>
    </message>
    <message>
      <source>Invalid equipment JSON.</source>
      <translation>Invalid equipment JSON.</translation>
    </message>
    <message>
      <source>Expected a JSON equipment profile. Import response text using the response import button.</source>
      <translation>Expected a JSON equipment profile. Import response text using the response import button.</translation>
    </message>
    <message>
      <source>Unknown profile field; import would lose data.</source>
      <translation>Unknown profile field; import would lose data.</translation>
    </message>
    <message>
      <source>Profile metadata must be text.</source>
      <translation>Profile metadata must be text.</translation>
    </message>
    <message>
      <source>Custom flag must be boolean.</source>
      <translation>Custom flag must be boolean.</translation>
    </message>
    <message>
      <source>Profile filters and response must be arrays.</source>
      <translation>Profile filters and response must be arrays.</translation>
    </message>
    <message>
      <source>Unsupported equipment profile schema (expected 2 or 3).</source>
      <translation>Unsupported equipment profile schema (expected 2 or 3).</translation>
    </message>
    <message>
      <source>Whole-system profiles require DAW schema 3.</source>
      <translation>Whole-system profiles require DAW schema 3.</translation>
    </message>
    <message>
      <source>Equipment subtype and power type are required (maximum 120 characters each).</source>
      <translation>Equipment subtype and power type are required (maximum 120 characters each).</translation>
    </message>
    <message>
      <source>Equipment kind must be speaker, microphone, amplifier or whole_system.</source>
      <translation>Equipment kind must be speaker, microphone, amplifier or whole_system.</translation>
    </message>
    <message>
      <source>Brand, family and model are required (maximum 120 characters each).</source>
      <translation>Brand, family and model are required (maximum 120 characters each).</translation>
    </message>
    <message>
      <source>Profile metadata is too long.</source>
      <translation>Profile metadata is too long.</translation>
    </message>
    <message>
      <source>Profile metadata contains a NUL character.</source>
      <translation>Profile metadata contains a NUL character.</translation>
    </message>
    <message>
      <source>Measurement conditions are required.</source>
      <translation>Measurement conditions are required.</translation>
    </message>
    <message>
      <source>Published profiles need an HTTPS measurement source.</source>
      <translation>Published profiles need an HTTPS measurement source.</translation>
    </message>
    <message>
      <source>Profiles need 1–16 correction filters.</source>
      <translation>Profiles need 1–16 correction filters.</translation>
    </message>
    <message>
      <source>Invalid filter.</source>
      <translation>Invalid filter.</translation>
    </message>
    <message>
      <source>Unknown filter field; import would lose data.</source>
      <translation>Unknown filter field; import would lose data.</translation>
    </message>
    <message>
      <source>Unsupported filter type.</source>
      <translation>Unsupported filter type.</translation>
    </message>
    <message>
      <source>Filter values must be numbers.</source>
      <translation>Filter values must be numbers.</translation>
    </message>
    <message>
      <source>Filters exceed frequency, gain or Q limits.</source>
      <translation>Filters exceed frequency, gain or Q limits.</translation>
    </message>
    <message>
      <source>Response exceeds 4096 points.</source>
      <translation>Response exceeds 4096 points.</translation>
    </message>
    <message>
      <source>Invalid response point.</source>
      <translation>Invalid response point.</translation>
    </message>
    <message>
      <source>Response frequencies must increase, with finite bounded values.</source>
      <translation>Response frequencies must increase, with finite bounded values.</translation>
    </message>
    <message>
      <source>Response exceeds the 1 MiB limit.</source>
      <translation>Response exceeds the 1 MiB limit.</translation>
    </message>
    <message>
      <source>Response is not valid UTF-8.</source>
      <translation>Response is not valid UTF-8.</translation>
    </message>
    <message>
      <source>Expected frequency Hz and relative measured response dB on every data line.</source>
      <translation>Expected frequency Hz and relative measured response dB on every data line.</translation>
    </message>
    <message>
      <source>Invalid or unordered response data.</source>
      <translation>Invalid or unordered response data.</translation>
    </message>
    <message>
      <source>Response needs at least two measured points.</source>
      <translation>Response needs at least two measured points.</translation>
    </message>
    <message>
      <source>Response needs 2–4096 measured points.</source>
      <translation>Response needs 2–4096 measured points.</translation>
    </message>
    <message>
      <source>Invalid or unordered measured response.</source>
      <translation>Invalid or unordered measured response.</translation>
    </message>
    <message>
      <source>Response has no usable audio range.</source>
      <translation>Response has no usable audio range.</translation>
    </message>
    <message>
      <source>Cannot read profile library.</source>
      <translation>Cannot read profile library.</translation>
    </message>
    <message>
      <source>Profile library exceeds 16 MiB.</source>
      <translation>Profile library exceeds 16 MiB.</translation>
    </message>
    <message>
      <source>Invalid profile library.</source>
      <translation>Invalid profile library.</translation>
    </message>
    <message>
      <source>Duplicate profile identity in library.</source>
      <translation>Duplicate profile identity in library.</translation>
    </message>
    <message>
      <source>The custom library holds up to 256 profiles.</source>
      <translation>The custom library holds up to 256 profiles.</translation>
    </message>
    <message>
      <source>Library exceeds 16 MiB.</source>
      <translation>Library exceeds 16 MiB.</translation>
    </message>
    <message>
      <source>Cannot create profile folder.</source>
      <translation>Cannot create profile folder.</translation>
    </message>
    <message>
      <source>Cannot save profile library.</source>
      <translation>Cannot save profile library.</translation>
    </message>
    <message>
      <source>Cannot finish saving profile library.</source>
      <translation>Cannot finish saving profile library.</translation>
    </message>
    <message>
      <source>Equipment resource missing.</source>
      <translation>Equipment resource missing.</translation>
    </message>
    <message>
      <source>Save profile</source>
      <translation>Save profile</translation>
    </message>
    <message>
      <source>Equipment profiles — brand / family / model</source>
      <translation>Equipment profiles — brand / family / model</translation>
    </message>
    <message>
      <source>Edit and save equipment profiles here. Monitoring correction routing is not yet available.</source>
      <translation>Edit and save equipment profiles here. Monitoring correction routing is not yet available.</translation>
    </message>
    <message>
      <source>Search brand, family, model or measurement conditions</source>
      <translation>Search brand, family, model or measurement conditions</translation>
    </message>
    <message>
      <source>Equipment profiles by brand family and model</source>
      <translation>Equipment profiles by brand family and model</translation>
    </message>
    <message>
      <source>All equipment</source>
      <translation>All equipment</translation>
    </message>
    <message>
      <source>Speakers</source>
      <translation>Speakers</translation>
    </message>
    <message>
      <source>Microphones</source>
      <translation>Microphones</translation>
    </message>
    <message>
      <source>Amplifiers / receivers</source>
      <translation>Amplifiers / receivers</translation>
    </message>
    <message>
      <source>Whole system</source>
      <translation>Whole system</translation>
    </message>
    <message>
      <source>Equipment type</source>
      <translation>Equipment type</translation>
    </message>
    <message>
      <source>Equipment brand</source>
      <translation>Equipment brand</translation>
    </message>
    <message>
      <source>Equipment family</source>
      <translation>Equipment family</translation>
    </message>
    <message>
      <source>Equipment power type</source>
      <translation>Equipment power type</translation>
    </message>
    <message>
      <source>All brands</source>
      <translation>All brands</translation>
    </message>
    <message>
      <source>All families</source>
      <translation>All families</translation>
    </message>
    <message>
      <source>All subtypes</source>
      <translation>All subtypes</translation>
    </message>
    <message>
      <source>All power types</source>
      <translation>All power types</translation>
    </message>
    <message>
      <source>Subtype: %1; power: %2</source>
      <translation>Subtype: %1; power: %2</translation>
    </message>
    <message>
      <source>Profile identity already exists; edit a custom copy instead.</source>
      <translation>Profile identity already exists; edit a custom copy instead.</translation>
    </message>
    <message>
      <source>Profile</source>
      <translation>Profile</translation>
    </message>
    <message>
      <source>Import JSON</source>
      <translation>Import JSON</translation>
    </message>
    <message>
      <source>Import response text</source>
      <translation>Import response text</translation>
    </message>
    <message>
      <source>Create profile</source>
      <translation>Create profile</translation>
    </message>
    <message>
      <source>Edit / save copy</source>
      <translation>Edit / save copy</translation>
    </message>
    <message>
      <source>Export JSON</source>
      <translation>Export JSON</translation>
    </message>
    <message>
      <source>Cannot read profile or file exceeds 1 MiB.</source>
      <translation>Cannot read profile or file exceeds 1 MiB.</translation>
    </message>
    <message>
      <source>Import</source>
      <translation>Import</translation>
    </message>
    <message>
      <source>Cannot read response or file exceeds 1 MiB.</source>
      <translation>Cannot read response or file exceeds 1 MiB.</translation>
    </message>
    <message>
      <source>This imports measured RESPONSE, not already-inverted EQ gains. Confirm equipment type. Absolute SPL needs normalization before import.</source>
      <translation>This imports measured RESPONSE, not already-inverted EQ gains. Confirm equipment type. Absolute SPL needs normalization before import.</translation>
    </message>
    <message>
      <source>Response import</source>
      <translation>Response import</translation>
    </message>
    <message>
      <source>Export</source>
      <translation>Export</translation>
    </message>
  </context>
  <context>
    <name>ExportDialog</name>
    <message>
      <source>Export audio</source>
      <translation>Export audio</translation>
    </message>
    <message>
      <source>Audio track</source>
      <translation>Audio track</translation>
    </message>
    <message>
      <source>Start frame</source>
      <translation>Start frame</translation>
    </message>
    <message>
      <source>End frame (exclusive)</source>
      <translation>End frame (exclusive)</translation>
    </message>
    <message>
      <source>Browse…</source>
      <translation>Browse…</translation>
    </message>
    <message>
      <source>WAV destination</source>
      <translation>WAV destination</translation>
    </message>
    <message>
      <source>Include the EQ tail</source>
      <translation>Include the EQ tail</translation>
    </message>
    <message>
      <source> seconds</source>
      <translation> seconds</translation>
    </message>
    <message>
      <source>Use RF64 for this WAV</source>
      <translation>Use RF64 for this WAV</translation>
    </message>
    <message>
      <source>Maximum tail</source>
      <translation>Maximum tail</translation>
    </message>
    <message>
      <source>Float32 WAV keeps levels above 0 dBFS. Large files use RF64 automatically. The export captures accepted project settings when you start; later edits do not change it. Existing files require a separate replacement confirmation.</source>
      <translation>Float32 WAV keeps levels above 0 dBFS. Large files use RF64 automatically. The export captures accepted project settings when you start; later edits do not change it. Existing files require a separate replacement confirmation.</translation>
    </message>
    <message>
      <source>Export</source>
      <translation>Export</translation>
    </message>
    <message>
      <source>Export WAV</source>
      <translation>Export WAV</translation>
    </message>
    <message>
      <source>WAV audio (*.wav)</source>
      <translation>WAV audio (*.wav)</translation>
    </message>
    <message>
      <source>Choose a destination and a range with end greater than start.</source>
      <translation>Choose a destination and a range with end greater than start.</translation>
    </message>
    <message>
      <source>%1 Hz · %2 seconds selected</source>
      <translation>%1 Hz · %2 seconds selected</translation>
    </message>
  </context>
  <context>
    <name>HistoryResourcesDialog</name>
    <message>
      <source>Project resources</source>
      <translation>Project resources</translation>
    </message>
    <message>
      <source>Limits apply to Undo payload and declared state/edit work. They do not measure total RAM. New edits may retire the oldest Undo commands; reducing limits never clears existing history.</source>
      <translation>Limits apply to Undo payload and declared state/edit work. They do not measure total RAM. New edits may retire the oldest Undo commands; reducing limits never clears existing history.</translation>
    </message>
    <message>
      <source>Current limit: %1 bytes. Edited values use whole MiB.</source>
      <translation>Current limit: %1 bytes. Edited values use whole MiB.</translation>
    </message>
    <message>
      <source>Maximum retained commands</source>
      <translation>Maximum retained commands</translation>
    </message>
    <message>
      <source>Retained payload (MiB)</source>
      <translation>Retained payload (MiB)</translation>
    </message>
    <message>
      <source>Operation workspace (MiB)</source>
      <translation>Operation workspace (MiB)</translation>
    </message>
    <message>
      <source>Enter positive whole numbers within this machine's size range.</source>
      <translation>Enter positive whole numbers within this machine's size range.</translation>
    </message>
    <message>
      <source>Resource request sequence exhausted.</source>
      <translation>Resource request sequence exhausted.</translation>
    </message>
    <message>
      <source>The project worker is busy or closing. Try again.</source>
      <translation>The project worker is busy or closing. Try again.</translation>
    </message>
    <message>
      <source>Applying limits…</source>
      <translation>Applying limits…</translation>
    </message>
    <message>
      <source>The shared project budget covers canonical state, snapshots, Undo, declared edit work, list/timeline indices, projections, prepared DSP, readers, media caches, export buffers, capture pools and writer/hash/journal workspace. New preparation follows this trusted budget. Parser/other IO, copied owner sessions and Qt/allocator overhead remain separate.</source>
      <translation>The shared project budget covers canonical state, snapshots, Undo, declared edit work, list/timeline indices, projections, prepared DSP, readers, media caches, export buffers, capture pools and writer/hash/journal workspace. New preparation follows this trusted budget. Parser/other IO, copied owner sessions and Qt/allocator overhead remain separate.</translation>
    </message>
    <message>
      <source>Shared project budget (MiB)</source>
      <translation>Shared project budget (MiB)</translation>
    </message>
    <message>
      <source>Retained snapshot budget (MiB)</source>
      <translation>Retained snapshot budget (MiB)</translation>
    </message>
    <message>
      <source>Apply memory limits</source>
      <translation>Apply memory limits</translation>
    </message>
    <message>
      <source>Applying memory limits…</source>
      <translation>Applying memory limits…</translation>
    </message>
    <message>
      <source>Project snapshot reservations: %1 owners
%2 / %3 bytes · Peak reservation: %4 bytes</source>
      <translation>Project snapshot reservations: %1 owners
%2 / %3 bytes · Peak reservation: %4 bytes</translation>
    </message>
    <message>
      <source>Shared reservations: %1 / %2 bytes · Peak: %3 bytes
Canonical: %4 bytes · History: %5 bytes</source>
      <translation>Shared reservations: %1 / %2 bytes · Peak: %3 bytes
Canonical: %4 bytes · History: %5 bytes</translation>
    </message>
    <message>
      <source>Memory limits were not changed: %1</source>
      <translation>Memory limits were not changed: %1</translation>
    </message>
    <message>
      <source>Memory limits applied. Retained state is preserved.</source>
      <translation>Memory limits applied. Retained state is preserved.</translation>
    </message>
    <message>
      <source>Limits applied, but preferences could not be saved: %1</source>
      <translation>Limits applied, but preferences could not be saved: %1</translation>
    </message>
    <message>
      <source>Undo: %1 · Redo: %2
Retained: %3 bytes · Active: %4 bytes
Accepted operation peak: %5 bytes · Retired commands: %6</source>
      <translation>Undo: %1 · Redo: %2
Retained: %3 bytes · Active: %4 bytes
Accepted operation peak: %5 bytes · Retired commands: %6</translation>
    </message>
    <message>
      <source>Limits were not changed: %1</source>
      <translation>Limits were not changed: %1</translation>
    </message>
    <message>
      <source>Limits applied. Existing Undo and Redo are preserved.</source>
      <translation>Limits applied. Existing Undo and Redo are preserved.</translation>
    </message>
  </context>
  <context>
    <name>ImportInspectionDialog</name>
    <message>
      <source>Choose a REAPER project</source>
      <translation>Choose a REAPER project</translation>
    </message>
    <message>
      <source>REAPER projects (*.rpp)</source>
      <translation>REAPER projects (*.rpp)</translation>
    </message>
    <message>
      <source>Open saved inspection</source>
      <translation>Open saved inspection</translation>
    </message>
    <message>
      <source>SoundCurrent inspections (*.scinspect)</source>
      <translation>SoundCurrent inspections (*.scinspect)</translation>
    </message>
    <message>
      <source>Save inspection to a new file</source>
      <translation>Save inspection to a new file</translation>
    </message>
    <message>
      <source>Inspect foreign project</source>
      <translation>Inspect foreign project</translation>
    </message>
    <message>
      <source>Choose project…</source>
      <translation>Choose project…</translation>
    </message>
    <message>
      <source>Open inspection…</source>
      <translation>Open inspection…</translation>
    </message>
    <message>
      <source>Save inspection…</source>
      <translation>Save inspection…</translation>
    </message>
    <message>
      <source>Check media…</source>
      <translation>Check media…</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Close</translation>
    </message>
    <message>
      <source>REAPER project inspection preview. Conversion is not available yet. The original file and current project remain unchanged.</source>
      <translation>REAPER project inspection preview. Conversion is not available yet. The original file and current project remain unchanged.</translation>
    </message>
    <message>
      <source>Properties</source>
      <translation>Properties</translation>
    </message>
    <message>
      <source>Original source</source>
      <translation>Original source</translation>
    </message>
    <message>
      <source>Stopping inspection…</source>
      <translation>Stopping inspection…</translation>
    </message>
    <message>
      <source>Saving inspection…</source>
      <translation>Saving inspection…</translation>
    </message>
    <message>
      <source>Opening inspection…</source>
      <translation>Opening inspection…</translation>
    </message>
    <message>
      <source>Inspecting project…</source>
      <translation>Inspecting project…</translation>
    </message>
    <message>
      <source>Inspection saved with the original source bytes. Project properties remain unverified.</source>
      <translation>Inspection saved with the original source bytes. Project properties remain unverified.</translation>
    </message>
    <message numerus="yes">
      <source>%n original property value(s) found. Audio import is not available yet.</source>
      <translation type="unfinished" />
    </message>
    <message numerus="yes">
      <source>%n source line(s) inspected. This saved outline has no property preview.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Inspection canceled.</source>
      <translation>Inspection canceled.</translation>
    </message>
    <message>
      <source>The inspection could not be saved. Choose a new file name in a writable folder; existing files are preserved.</source>
      <translation>The inspection could not be saved. Choose a new file name in a writable folder; existing files are preserved.</translation>
    </message>
    <message>
      <source>The inspection could not be opened. It may be unreadable, damaged, unsupported, or too large for the available import memory.</source>
      <translation>The inspection could not be opened. It may be unreadable, damaged, unsupported, or too large for the available import memory.</translation>
    </message>
    <message>
      <source>Inspection exceeded its time limit.</source>
      <translation>Inspection exceeded its time limit.</translation>
    </message>
    <message>
      <source>There is not enough import memory, or the file exceeds the inspection limits.</source>
      <translation>There is not enough import memory, or the file exceeds the inspection limits.</translation>
    </message>
    <message>
      <source>This project uses invalid or unsupported syntax for this inspector.</source>
      <translation>This project uses invalid or unsupported syntax for this inspector.</translation>
    </message>
    <message>
      <source>The selected project or inspection worker could not be read.</source>
      <translation>The selected project or inspection worker could not be read.</translation>
    </message>
    <message>
      <source>The inspection failed or its result could not be verified.</source>
      <translation>The inspection failed or its result could not be verified.</translation>
    </message>
    <message>
      <source>Choose a project to inspect.</source>
      <translation>Choose a project to inspect.</translation>
    </message>
    <message>
      <source>Media check unavailable</source>
      <translation>Media check unavailable</translation>
    </message>
    <message>
      <source>There is not enough import memory to display the media checklist.</source>
      <translation>There is not enough import memory to display the media checklist.</translation>
    </message>
  </context>
  <context>
    <name>ImportMediaDialog</name>
    <message>
      <source>Choose the folder containing this project's media</source>
      <translation>Choose the folder containing this project's media</translation>
    </message>
    <message>
      <source>Choose a replacement audio file</source>
      <translation>Choose a replacement audio file</translation>
    </message>
    <message>
      <source>WAVE audio (*.wav);;All files (*)</source>
      <translation>WAVE audio (*.wav);;All files (*)</translation>
    </message>
    <message>
      <source>Choose a destination for the verified media copy</source>
      <translation>Choose a destination for the verified media copy</translation>
    </message>
    <message>
      <source>Choose the copied operation's UUID folder</source>
      <translation>Choose the copied operation's UUID folder</translation>
    </message>
    <message>
      <source>Check last copy outcome</source>
      <translation>Check last copy outcome</translation>
    </message>
    <message>
      <source>Recover copied media…</source>
      <translation>Recover copied media…</translation>
    </message>
    <message>
      <source>No media folder selected. Opening an inspection does not grant access to its media.</source>
      <translation>No media folder selected. Opening an inspection does not grant access to its media.</translation>
    </message>
    <message>
      <source>Selected media folder: %1</source>
      <translation>Selected media folder: %1</translation>
    </message>
    <message>
      <source>Copy or recovery in progress. Operation folder: %1</source>
      <translation>Copy or recovery in progress. Operation folder: %1</translation>
    </message>
    <message>
      <source>Media is committed and verified, but directory durability is unconfirmed. Folder: %1</source>
      <translation>Media is committed and verified, but directory durability is unconfirmed. Folder: %1</translation>
    </message>
    <message>
      <source>Media is committed and verified. Folder: %1</source>
      <translation>Media is committed and verified. Folder: %1</translation>
    </message>
    <message>
      <source>The checked media or inspection changed. Check the copy outcome, then check the source again. Operation folder: %1</source>
      <translation>The checked media or inspection changed. Check the copy outcome, then check the source again. Operation folder: %1</translation>
    </message>
    <message>
      <source>The copy outcome is uncertain. Recover this operation folder before using its media: %1</source>
      <translation>The copy outcome is uncertain. Recover this operation folder before using its media: %1</translation>
    </message>
    <message>
      <source>This operation has planned intent but no committed receipt. Partial data is preserved: %1</source>
      <translation>This operation has planned intent but no committed receipt. Partial data is preserved: %1</translation>
    </message>
    <message>
      <source>No intent or receipt was found. No completed copy is established: %1</source>
      <translation>No intent or receipt was found. No completed copy is established: %1</translation>
    </message>
    <message>
      <source>The copy did not start. Check the selected row, destination and available import memory.</source>
      <translation>The copy did not start. Check the selected row, destination and available import memory.</translation>
    </message>
    <message>
      <source>Verified copies preserve the original reference and audio bytes. They are not attached to the current project. Clearing choices leaves copied files intact.</source>
      <translation>Verified copies preserve the original reference and audio bytes. They are not attached to the current project. Clearing choices leaves copied files intact.</translation>
    </message>
    <message>
      <source>Stopping media jobs…</source>
      <translation>Stopping media jobs…</translation>
    </message>
    <message>
      <source>The media job could not be started. Check the selected path and available import memory.</source>
      <translation>The media job could not be started. Check the selected path and available import memory.</translation>
    </message>
    <message>
      <source>Checking selected audio…</source>
      <translation>Checking selected audio…</translation>
    </message>
    <message>
      <source>Choose a media folder and check a reference, or explicitly choose a replacement. Choices stay local to this window.</source>
      <translation>Choose a media folder and check a reference, or explicitly choose a replacement. Choices stay local to this window.</translation>
    </message>
    <message>
      <source>Check and copy project media</source>
      <translation>Check and copy project media</translation>
    </message>
    <message>
      <source>Project conversion is in development. Check media, then copy checked files to a new destination. The checked snapshot is verified again before copying. The current project stays unchanged.</source>
      <translation>Project conversion is in development. Check media, then copy checked files to a new destination. The checked snapshot is verified again before copying. The current project stays unchanged.</translation>
    </message>
    <message>
      <source>Maximum file size for this check (MiB):</source>
      <translation>Maximum file size for this check (MiB):</translation>
    </message>
    <message>
      <source>Choose media folder…</source>
      <translation>Choose media folder…</translation>
    </message>
    <message>
      <source>Check selected reference</source>
      <translation>Check selected reference</translation>
    </message>
    <message>
      <source>Choose replacement…</source>
      <translation>Choose replacement…</translation>
    </message>
    <message>
      <source>Clear local choices</source>
      <translation>Clear local choices</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Close</translation>
    </message>
    <message>
      <source>Copy checked media…</source>
      <translation>Copy checked media…</translation>
    </message>
  </context>
  <context>
    <name>ImportMediaModel</name>
    <message>
      <source>Not copied</source>
      <translation>Not copied</translation>
    </message>
    <message>
      <source>Copying or recovering…</source>
      <translation>Copying or recovering…</translation>
    </message>
    <message>
      <source>Verified copy; directory durability unconfirmed</source>
      <translation>Verified copy; directory durability unconfirmed</translation>
    </message>
    <message>
      <source>Verified copy</source>
      <translation>Verified copy</translation>
    </message>
    <message>
      <source>Outcome uncertain; recover this operation</source>
      <translation>Outcome uncertain; recover this operation</translation>
    </message>
    <message>
      <source>Planned copy; no committed receipt</source>
      <translation>Planned copy; no committed receipt</translation>
    </message>
    <message>
      <source>No intent or receipt found</source>
      <translation>No intent or receipt found</translation>
    </message>
    <message>
      <source>Canceled before copying</source>
      <translation>Canceled before copying</translation>
    </message>
    <message>
      <source>Copy could not start</source>
      <translation>Copy could not start</translation>
    </message>
    <message>
      <source>Reference unavailable</source>
      <translation>Reference unavailable</translation>
    </message>
    <message>
      <source>Selected replacement: %1</source>
      <translation>Selected replacement: %1</translation>
    </message>
    <message>
      <source>Selected folder: %1</source>
      <translation>Selected folder: %1</translation>
    </message>
    <message>
      <source>Ambiguous or unsupported source; no reference selected</source>
      <translation>Ambiguous or unsupported source; no reference selected</translation>
    </message>
    <message>
      <source>Not checked</source>
      <translation>Not checked</translation>
    </message>
    <message>
      <source>Checking…</source>
      <translation>Checking…</translation>
    </message>
    <message>
      <source>Checked snapshot</source>
      <translation>Checked snapshot</translation>
    </message>
    <message>
      <source>Canceled</source>
      <translation>Canceled</translation>
    </message>
    <message>
      <source>Check exceeded its time limit</source>
      <translation>Check exceeded its time limit</translation>
    </message>
    <message>
      <source>File not found in the selected folder</source>
      <translation>File not found in the selected folder</translation>
    </message>
    <message>
      <source>Audio format not supported by this check yet</source>
      <translation>Audio format not supported by this check yet</translation>
    </message>
    <message>
      <source>File or check exceeds resource limits</source>
      <translation>File or check exceeds resource limits</translation>
    </message>
    <message>
      <source>File changed during the check</source>
      <translation>File changed during the check</translation>
    </message>
    <message>
      <source>Invalid audio or a reference requiring an explicit replacement</source>
      <translation>Invalid audio or a reference requiring an explicit replacement</translation>
    </message>
    <message>
      <source>Check unavailable or result could not be verified</source>
      <translation>Check unavailable or result could not be verified</translation>
    </message>
    <message>
      <source>%1 Hz · %2 · %3-bit</source>
      <translation>%1 Hz · %2 · %3-bit</translation>
    </message>
    <message numerus="yes">
      <source>%n channel(s)</source>
      <translation>
        <numerusform>%n channel</numerusform>
        <numerusform>%n channels</numerusform>
      </translation>
    </message>
    <message>
      <source>Silent</source>
      <translation>Silent</translation>
    </message>
    <message>
      <source>%1 dBFS</source>
      <translation>%1 dBFS</translation>
    </message>
    <message>
      <source>Original reference</source>
      <translation>Original reference</translation>
    </message>
    <message>
      <source>Local media choice</source>
      <translation>Local media choice</translation>
    </message>
    <message>
      <source>Status</source>
      <translation>Status</translation>
    </message>
    <message>
      <source>Audio format</source>
      <translation>Audio format</translation>
    </message>
    <message>
      <source>Sample peak</source>
      <translation>Sample peak</translation>
    </message>
    <message>
      <source>Copy state</source>
      <translation>Copy state</translation>
    </message>
  </context>
  <context>
    <name>ImportPreviewModel</name>
    <message>
      <source>Original file bytes: %1 + %2</source>
      <translation>Original file bytes: %1 + %2</translation>
    </message>
    <message>
      <source>Blank line</source>
      <translation>Blank line</translation>
    </message>
    <message>
      <source>Group</source>
      <translation>Group</translation>
    </message>
    <message>
      <source>End of group</source>
      <translation>End of group</translation>
    </message>
    <message>
      <source>Property</source>
      <translation>Property</translation>
    </message>
    <message>
      <source>Unsupported</source>
      <translation>Unsupported</translation>
    </message>
    <message>
      <source>Bytes retained</source>
      <translation>Bytes retained</translation>
    </message>
    <message>
      <source>Unverified</source>
      <translation>Unverified</translation>
    </message>
    <message>
      <source>Item</source>
      <translation>Item</translation>
    </message>
    <message>
      <source>Type</source>
      <translation>Type</translation>
    </message>
    <message>
      <source>Line</source>
      <translation>Line</translation>
    </message>
    <message>
      <source>Status</source>
      <translation>Status</translation>
    </message>
    <message>
      <source>Original line</source>
      <translation>Original line</translation>
    </message>
  </context>
  <context>
    <name>ImportPropertyModel</name>
    <message>
      <source>Project sample rate</source>
      <translation>Project sample rate</translation>
    </message>
    <message>
      <source>Use project sample rate</source>
      <translation>Use project sample rate</translation>
    </message>
    <message>
      <source>Track identity</source>
      <translation>Track identity</translation>
    </message>
    <message>
      <source>Track name</source>
      <translation>Track name</translation>
    </message>
    <message>
      <source>Track gain</source>
      <translation>Track gain</translation>
    </message>
    <message>
      <source>Track pan</source>
      <translation>Track pan</translation>
    </message>
    <message>
      <source>Track channels</source>
      <translation>Track channels</translation>
    </message>
    <message>
      <source>Item identity</source>
      <translation>Item identity</translation>
    </message>
    <message>
      <source>Item position</source>
      <translation>Item position</translation>
    </message>
    <message>
      <source>Item length</source>
      <translation>Item length</translation>
    </message>
    <message>
      <source>Fade-in length</source>
      <translation>Fade-in length</translation>
    </message>
    <message>
      <source>Fade-out length</source>
      <translation>Fade-out length</translation>
    </message>
    <message>
      <source>Take name</source>
      <translation>Take name</translation>
    </message>
    <message>
      <source>Item gain</source>
      <translation>Item gain</translation>
    </message>
    <message>
      <source>Take gain</source>
      <translation>Take gain</translation>
    </message>
    <message>
      <source>Take pan</source>
      <translation>Take pan</translation>
    </message>
    <message>
      <source>Source offset</source>
      <translation>Source offset</translation>
    </message>
    <message>
      <source>Take rate</source>
      <translation>Take rate</translation>
    </message>
    <message>
      <source>Take pitch</source>
      <translation>Take pitch</translation>
    </message>
    <message>
      <source>Source file</source>
      <translation>Source file</translation>
    </message>
    <message>
      <source>Hz</source>
      <translation>Hz</translation>
    </message>
    <message>
      <source>0 / 1</source>
      <translation>0 / 1</translation>
    </message>
    <message>
      <source>channels</source>
      <translation>channels</translation>
    </message>
    <message>
      <source>linear gain</source>
      <translation>linear gain</translation>
    </message>
    <message>
      <source>source pan</source>
      <translation>source pan</translation>
    </message>
    <message>
      <source>seconds</source>
      <translation>seconds</translation>
    </message>
    <message>
      <source>ratio</source>
      <translation>ratio</translation>
    </message>
    <message>
      <source>semitones</source>
      <translation>semitones</translation>
    </message>
    <message>
      <source>original bytes</source>
      <translation>original bytes</translation>
    </message>
    <message>
      <source>Value retained</source>
      <translation>Value retained</translation>
    </message>
    <message>
      <source>Converted</source>
      <translation>Converted</translation>
    </message>
    <message>
      <source>Unsupported</source>
      <translation>Unsupported</translation>
    </message>
    <message>
      <source>Missing</source>
      <translation>Missing</translation>
    </message>
    <message>
      <source>Unverified</source>
      <translation>Unverified</translation>
    </message>
    <message>
      <source>Original value; audio import is not available yet.</source>
      <translation>Original value; audio import is not available yet.</translation>
    </message>
    <message>
      <source>Original state has not been interpreted.</source>
      <translation>Original state has not been interpreted.</translation>
    </message>
    <message>
      <source>Invalid or out-of-range original number.</source>
      <translation>Invalid or out-of-range original number.</translation>
    </message>
    <message>
      <source>Unverified original field layout.</source>
      <translation>Unverified original field layout.</translation>
    </message>
    <message>
      <source>Malformed original token.</source>
      <translation>Malformed original token.</translation>
    </message>
    <message>
      <source>Repeated field; no occurrence selected.</source>
      <translation>Repeated field; no occurrence selected.</translation>
    </message>
    <message>
      <source>The source project does not specify this value.</source>
      <translation>The source project does not specify this value.</translation>
    </message>
    <message>
      <source>Take selection is ambiguous.</source>
      <translation>Take selection is ambiguous.</translation>
    </message>
    <message>
      <source>This processing setting cannot be imported yet.</source>
      <translation>This processing setting cannot be imported yet.</translation>
    </message>
    <message>
      <source>This source type is not implemented.</source>
      <translation>This source type is not implemented.</translation>
    </message>
    <message>
      <source>Original file bytes: %1 + %2</source>
      <translation>Original file bytes: %1 + %2</translation>
    </message>
    <message>
      <source>Project</source>
      <translation>Project</translation>
    </message>
    <message>
      <source>Track</source>
      <translation>Track</translation>
    </message>
    <message>
      <source>Item</source>
      <translation>Item</translation>
    </message>
    <message>
      <source>Source</source>
      <translation>Source</translation>
    </message>
    <message>
      <source>%1 · %2</source>
      <translation>%1 · %2</translation>
    </message>
    <message>
      <source>Unavailable</source>
      <translation>Unavailable</translation>
    </message>
    <message>
      <source>Source object</source>
      <translation>Source object</translation>
    </message>
    <message>
      <source>Property</source>
      <translation>Property</translation>
    </message>
    <message>
      <source>Original value</source>
      <translation>Original value</translation>
    </message>
    <message>
      <source>Units</source>
      <translation>Units</translation>
    </message>
    <message>
      <source>Status</source>
      <translation>Status</translation>
    </message>
    <message>
      <source>Details</source>
      <translation>Details</translation>
    </message>
  </context>
  <context>
    <name>Localization</name>
    <message>
      <source>Language preferences could not be saved.</source>
      <translation>Language preferences could not be saved.</translation>
    </message>
    <message>
      <source>Language and regional settings</source>
      <translation>Language and regional settings</translation>
    </message>
    <message>
      <source>Interface language</source>
      <translation>Interface language</translation>
    </message>
    <message>
      <source>Use system language</source>
      <translation>Use system language</translation>
    </message>
    <message>
      <source>Expanded test language</source>
      <translation>Expanded test language</translation>
    </message>
    <message>
      <source>Right-to-left test language</source>
      <translation>Right-to-left test language</translation>
    </message>
    <message>
      <source>Saved language preference: %1</source>
      <translation>Saved language preference: %1</translation>
    </message>
    <message>
      <source>Number and date format</source>
      <translation>Number and date format</translation>
    </message>
    <message>
      <source>Use system locale</source>
      <translation>Use system locale</translation>
      <extracomment>Use the operating system regional number/date formatting settings; independent of interface language.</extracomment>
    </message>
    <message>
      <source>Saved format preference: %1</source>
      <translation>Saved format preference: %1</translation>
    </message>
    <message>
      <source>Developer test language; no translated language coverage.</source>
      <translation>Developer test language; no translated language coverage.</translation>
    </message>
    <message>
      <source>Requested: %1. Loaded after restart: %2. Translation coverage: %3 of %4 messages. Missing translations use English. Draft translations await native-speaker review.</source>
      <translation>Requested: %1. Loaded after restart: %2. Translation coverage: %3 of %4 messages. Missing translations use English. Draft translations await native-speaker review.</translation>
    </message>
    <message>
      <source>Restart the application to apply language and number format changes. Save projects before quitting.</source>
      <translation>Restart the application to apply language and number format changes. Save projects before quitting.</translation>
    </message>
  </context>
  <context>
    <name>Main</name>
    <message>
      <source>Interface language tag (draft catalogs available)</source>
      <translation>Interface language tag (draft catalogs available)</translation>
    </message>
    <message>
      <source>Project folder to open</source>
      <translation>Project folder to open</translation>
    </message>
  </context>
  <context>
    <name>ManualRecordingPanel</name>
    <message>
      <source>Manual recording and repeated takes</source>
      <translation>Manual recording and repeated takes</translation>
    </message>
    <message>
      <source>Prepare transport</source>
      <translation>Prepare transport</translation>
    </message>
    <message>
      <source>Play / monitor</source>
      <translation>Play / monitor</translation>
    </message>
    <message>
      <source>Prepare next take</source>
      <translation>Prepare next take</translation>
    </message>
    <message>
      <source>Punch In</source>
      <translation>Punch In</translation>
    </message>
    <message>
      <source>Punch Out</source>
      <translation>Punch Out</translation>
    </message>
    <message>
      <source>Stop</source>
      <translation>Stop</translation>
    </message>
    <message>
      <source>Cancel recording</source>
      <translation>Cancel recording</translation>
    </message>
    <message>
      <source> s</source>
      <translation> s</translation>
    </message>
    <message>
      <source>Maximum transport duration</source>
      <translation>Maximum transport duration</translation>
    </message>
    <message>
      <source>Disk stall reserve</source>
      <translation>Disk stall reserve</translation>
    </message>
    <message>
      <source>Tracks armed for manual recording</source>
      <translation>Tracks armed for manual recording</translation>
    </message>
    <message>
      <source>Recorded take previews</source>
      <translation>Recorded take previews</translation>
    </message>
    <message>
      <source>Add complete take</source>
      <translation>Add complete take</translation>
    </message>
    <message>
      <source>Add verified complete lanes</source>
      <translation>Add verified complete lanes</translation>
    </message>
    <message>
      <source>Retain as take lanes</source>
      <translation>Retain as take lanes</translation>
    </message>
    <message>
      <source>Keep a complete group silent. Choose a take region in the timeline to make it audible.</source>
      <translation>Keep a complete group silent. Choose a take region in the timeline to make it audible.</translation>
    </message>
    <message>
      <source>Keep files for recovery</source>
      <translation>Keep files for recovery</translation>
    </message>
    <message>
      <source>Recording command could not be queued. Please retry.</source>
      <translation>Recording command could not be queued. Please retry.</translation>
    </message>
    <message>
      <source>Arm at least one track before preparing.</source>
      <translation>Arm at least one track before preparing.</translation>
    </message>
    <message>
      <source>Select every input and output port before playing.</source>
      <translation>Select every input and output port before playing.</translation>
    </message>
    <message>
      <source>Punch queued; waiting for the audio boundary.</source>
      <translation>Punch queued; waiting for the audio boundary.</translation>
    </message>
    <message>
      <source>Recorded takes</source>
      <translation>Recorded takes</translation>
    </message>
    <message>
      <source>Recorded files have not all been added to the project. Keep them for later recovery, or return to review the previews?</source>
      <translation>Recorded files have not all been added to the project. Keep them for later recovery, or return to review the previews?</translation>
    </message>
    <message>
      <source>Keep for recovery and close</source>
      <translation>Keep for recovery and close</translation>
    </message>
    <message>
      <source>Review takes</source>
      <translation>Review takes</translation>
    </message>
    <message>
      <source>Route change could not be queued. Please retry.</source>
      <translation>Route change could not be queued. Please retry.</translation>
    </message>
    <message>
      <source>%1 input %2</source>
      <translation>%1 input %2</translation>
    </message>
    <message>
      <source>Missing track</source>
      <translation>Missing track</translation>
    </message>
    <message>
      <source>Master output %1</source>
      <translation>Master output %1</translation>
    </message>
    <message>
      <source>Unassigned</source>
      <translation>Unassigned</translation>
    </message>
    <message>
      <source>Saved port missing or ambiguous — select a port</source>
      <translation>Saved port missing or ambiguous — select a port</translation>
    </message>
    <message>
      <source>Take %1 — %2</source>
      <translation>Take %1 — %2</translation>
    </message>
    <message>
      <source>canceled; recovery files retained</source>
      <translation>canceled; recovery files retained</translation>
    </message>
    <message>
      <source>complete</source>
      <translation>complete</translation>
    </message>
    <message>
      <source>partial / failed</source>
      <translation>partial / failed</translation>
    </message>
    <message>
      <source>Take previews will appear here. Adding a take changes the project; Save is separate.</source>
      <translation>Take previews will appear here. Adding a take changes the project; Save is separate.</translation>
    </message>
    <message>
      <source>Take range: %1 to %2 frames</source>
      <translation>Take range: %1 to %2 frames</translation>
    </message>
    <message>
      <source>
%1 — %2 captured frames; %3</source>
      <translation>
%1 — %2 captured frames; %3</translation>
    </message>
    <message>
      <source>verified complete</source>
      <translation>verified complete</translation>
    </message>
    <message>
      <source>retained for review / recovery</source>
      <translation>retained for review / recovery</translation>
    </message>
    <message>
      <source>Take %1</source>
      <translation>Take %1</translation>
    </message>
    <message>
      <source>Files kept in the project for later recovery.</source>
      <translation>Files kept in the project for later recovery.</translation>
    </message>
    <message>
      <source>Could not prepare recording: %1</source>
      <translation>Could not prepare recording: %1</translation>
    </message>
    <message>
      <source>Recording command was not completed: %1</source>
      <translation>Recording command was not completed: %1</translation>
    </message>
    <message>
      <source>%1 applied at frame %2</source>
      <translation>%1 applied at frame %2</translation>
    </message>
    <message>
      <source>transport has changed</source>
      <translation>transport has changed</translation>
    </message>
    <message>
      <source>requested position has passed</source>
      <translation>requested position has passed</translation>
    </message>
    <message>
      <source>position is outside the prepared range</source>
      <translation>position is outside the prepared range</translation>
    </message>
    <message>
      <source>already recording</source>
      <translation>already recording</translation>
    </message>
    <message>
      <source>no active recording</source>
      <translation>no active recording</translation>
    </message>
    <message>
      <source>take is no longer available</source>
      <translation>take is no longer available</translation>
    </message>
    <message>
      <source>transport has stopped</source>
      <translation>transport has stopped</translation>
    </message>
    <message>
      <source>capture failed; files retained for recovery</source>
      <translation>capture failed; files retained for recovery</translation>
    </message>
    <message>
      <source>unknown recording state</source>
      <translation>unknown recording state</translation>
    </message>
    <message>
      <source>Punch refused: %1.</source>
      <translation>Punch refused: %1.</translation>
    </message>
    <message>
      <source>Take lanes retained silently. Choose a comp region in the timeline; Save persists the lanes.</source>
      <translation>Take lanes retained silently. Choose a comp region in the timeline; Save persists the lanes.</translation>
    </message>
    <message>
      <source>Take added. Save to persist the project changes. Reprepare playback to hear new clips.</source>
      <translation>Take added. Save to persist the project changes. Reprepare playback to hear new clips.</translation>
    </message>
    <message>
      <source>Could not add the take: %1. Files and preview are retained.</source>
      <translation>Could not add the take: %1. Files and preview are retained.</translation>
    </message>
    <message>
      <source>Recording failed: %1. Available files are retained.</source>
      <translation>Recording failed: %1. Available files are retained.</translation>
    </message>
    <message>
      <source>Manual recording is unavailable on this platform.</source>
      <translation>Manual recording is unavailable on this platform.</translation>
    </message>
    <message>
      <source>Preparing recording…</source>
      <translation>Preparing recording…</translation>
    </message>
    <message>
      <source>Ready. Select explicit ports, then Play / monitor.</source>
      <translation>Ready. Select explicit ports, then Play / monitor.</translation>
    </message>
    <message>
      <source>Playing / monitoring — frame %1</source>
      <translation>Playing / monitoring — frame %1</translation>
    </message>
    <message>
      <source>Stopping; draining and verifying recordings…</source>
      <translation>Stopping; draining and verifying recordings…</translation>
    </message>
    <message>
      <source>Recording worker closed.</source>
      <translation>Recording worker closed.</translation>
    </message>
    <message>
      <source>Transport stopped.</source>
      <translation>Transport stopped.</translation>
    </message>
    <message>
      <source> · Loop pass %1 · project frame %2</source>
      <translation> · Loop pass %1 · project frame %2</translation>
    </message>
    <message>
      <source> EQ changes pending audio acknowledgement.</source>
      <translation> EQ changes pending audio acknowledgement.</translation>
    </message>
  </context>
  <context>
    <name>MasterDialog</name>
    <message>
      <source>The desktop editor supports at most 4096 entries. The project API supports 65536.</source>
      <translation>The desktop editor supports at most 4096 entries. The project API supports 65536.</translation>
    </message>
    <message>
      <source>Source track</source>
      <translation>Source track</translation>
    </message>
    <message>
      <source>Source channel</source>
      <translation>Source channel</translation>
    </message>
    <message>
      <source>Destination channel</source>
      <translation>Destination channel</translation>
    </message>
    <message>
      <source>Linear gain</source>
      <translation>Linear gain</translation>
    </message>
    <message>
      <source>Master was not applied: %1</source>
      <translation>Master was not applied: %1</translation>
    </message>
    <message>
      <source>Master layout and channel matrix</source>
      <translation>Master layout and channel matrix</translation>
    </message>
    <message>
      <source>Each row maps one source channel to a master channel. Gains are linear, including zero or negative polarity. Unlisted tracks are excluded. Changing the output channel count clears saved output assignments.</source>
      <translation>Each row maps one source channel to a master channel. Gains are linear, including zero or negative polarity. Unlisted tracks are excluded. Changing the output channel count clears saved output assignments.</translation>
    </message>
    <message>
      <source>Mono</source>
      <translation>Mono</translation>
    </message>
    <message>
      <source>Stereo</source>
      <translation>Stereo</translation>
    </message>
    <message>
      <source>Discrete</source>
      <translation>Discrete</translation>
    </message>
    <message>
      <source>Master layout</source>
      <translation>Master layout</translation>
    </message>
    <message>
      <source>Master channels</source>
      <translation>Master channels</translation>
    </message>
    <message>
      <source>Track</source>
      <translation>Track</translation>
    </message>
    <message>
      <source>Master channel</source>
      <translation>Master channel</translation>
    </message>
    <message>
      <source>This matrix exceeds the 4096-entry desktop editor limit; its saved state is preserved. Use the project API.</source>
      <translation>This matrix exceeds the 4096-entry desktop editor limit; its saved state is preserved. Use the project API.</translation>
    </message>
    <message>
      <source>Add route</source>
      <translation>Add route</translation>
    </message>
    <message>
      <source>Remove selected routes</source>
      <translation>Remove selected routes</translation>
    </message>
  </context>
  <context>
    <name>NativeMonitorPanel</name>
    <message>
      <source>Recording</source>
      <translation>Recording</translation>
    </message>
    <message>
      <source>Choose a device</source>
      <translation>Choose a device</translation>
    </message>
    <message>
      <source>Capture source</source>
      <translation>Capture source</translation>
    </message>
    <message>
      <source>Monitoring output</source>
      <translation>Monitoring output</translation>
    </message>
    <message>
      <source>Same native channel order</source>
      <translation>Same native channel order</translation>
    </message>
    <message>
      <source>Duplicate mono to stereo</source>
      <translation>Duplicate mono to stereo</translation>
    </message>
    <message>
      <source>Channel mapping</source>
      <translation>Channel mapping</translation>
    </message>
    <message>
      <source>Refresh devices</source>
      <translation>Refresh devices</translation>
    </message>
    <message>
      <source>Monitoring length (seconds)</source>
      <translation>Monitoring length (seconds)</translation>
    </message>
    <message>
      <source>Monitor EQ</source>
      <translation>Monitor EQ</translation>
    </message>
    <message>
      <source>Prepare</source>
      <translation>Prepare</translation>
    </message>
    <message>
      <source>Record</source>
      <translation>Record</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
    <message>
      <source>Inspect saved take</source>
      <translation>Inspect saved take</translation>
    </message>
    <message>
      <source>Keep take and reset</source>
      <translation>Keep take and reset</translation>
    </message>
    <message>
      <source>Export original WAV…</source>
      <translation>Export original WAV…</translation>
    </message>
    <message>
      <source>Export the verified captured WAV at its native rate. EQ and timeline alignment are not printed.</source>
      <translation>Export the verified captured WAV at its native rate. EQ and timeline alignment are not printed.</translation>
    </message>
    <message>
      <source>Copy verified audio…</source>
      <translation>Copy verified audio…</translation>
    </message>
    <message>
      <source>Copy the verified playable audio to a new WAV. The original take and its outcome stay unchanged.</source>
      <translation>Copy the verified playable audio to a new WAV. The original take and its outcome stay unchanged.</translation>
    </message>
    <message>
      <source>Open saved native take…</source>
      <translation>Open saved native take…</translation>
    </message>
    <message>
      <source>Choose an original take directory in this project's media folder. Inspection does not activate audio devices.</source>
      <translation>Choose an original take directory in this project's media folder. Inspection does not activate audio devices.</translation>
    </message>
    <message>
      <source>Start frame (project rate)</source>
      <translation>Start frame (project rate)</translation>
    </message>
    <message>
      <source>Add to selected track</source>
      <translation>Add to selected track</translation>
    </message>
    <message>
      <source>Use this explicit timeline position. Captured audio and native timing evidence stay unchanged.</source>
      <translation>Use this explicit timeline position. Captured audio and native timing evidence stay unchanged.</translation>
    </message>
    <message>
      <source>Buffer for disk pauses</source>
      <translation>Buffer for disk pauses</translation>
    </message>
    <message>
      <source>Prepare a finite buffer before recording. Repeated pauses or a slow disk can still stop recording.</source>
      <translation>Prepare a finite buffer before recording. Repeated pauses or a slow disk can still stop recording.</translation>
    </message>
    <message>
      <source> ms</source>
      <translation> ms</translation>
    </message>
    <message>
      <source>Choose</source>
      <translation>Choose</translation>
    </message>
    <message>
      <source>Minimum input block (frames)</source>
      <translation>Minimum input block (frames)</translation>
    </message>
    <message>
      <source>Minimum output block (frames)</source>
      <translation>Minimum output block (frames)</translation>
    </message>
    <message>
      <source>Enter the smallest block allowed by your audio setup. Recording stops if an actual block is smaller. This is not the maximum block size.</source>
      <translation>Enter the smallest block allowed by your audio setup. Recording stops if an actual block is smaller. This is not the maximum block size.</translation>
    </message>
    <message>
      <source>Disk pause budget</source>
      <translation>Disk pause budget</translation>
    </message>
    <message>
      <source>Enter a nonnegative project frame.</source>
      <translation>Enter a nonnegative project frame.</translation>
    </message>
    <message>
      <source>Open saved native take</source>
      <translation>Open saved native take</translation>
    </message>
    <message>
      <source>Export original native take</source>
      <translation>Export original native take</translation>
    </message>
    <message>
      <source>WAV audio (*.wav)</source>
      <translation>WAV audio (*.wav)</translation>
    </message>
    <message>
      <source>Copy verified audio</source>
      <translation>Copy verified audio</translation>
    </message>
    <message>
      <source>Recording settings exceed the panel memory limit.</source>
      <translation>Recording settings exceed the panel memory limit.</translation>
    </message>
    <message>
      <source>Monitoring range is too large.</source>
      <translation>Monitoring range is too large.</translation>
    </message>
    <message>
      <source>Recording controls are busy. Try again.</source>
      <translation>Recording controls are busy. Try again.</translation>
    </message>
    <message>
      <source>Recording is closing.</source>
      <translation>Recording is closing.</translation>
    </message>
    <message>
      <source>Recording settings are invalid.</source>
      <translation>Recording settings are invalid.</translation>
    </message>
    <message>
      <source>Recording settings exceed the control memory limit.</source>
      <translation>Recording settings exceed the control memory limit.</translation>
    </message>
    <message>
      <source>Input: %1 · Output: %2</source>
      <translation>Input: %1 · Output: %2</translation>
    </message>
    <message numerus="yes">
      <source>%1 · %n channel(s) · %2 Hz</source>
      <translation type="unfinished" />
    </message>
    <message numerus="yes">
      <source>%1 · %n channel(s)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Device choices exceed the panel memory limit.</source>
      <translation>Device choices exceed the panel memory limit.</translation>
    </message>
    <message>
      <source>The capture device width must match the selected track.</source>
      <translation>The capture device width must match the selected track.</translation>
    </message>
    <message>
      <source>Choose a matching output width or explicit mono-to-stereo mapping.</source>
      <translation>Choose a matching output width or explicit mono-to-stereo mapping.</translation>
    </message>
    <message>
      <source>Selected devices exceed the panel memory limit.</source>
      <translation>Selected devices exceed the panel memory limit.</translation>
    </message>
    <message>
      <source>Prepared: %1 ms · %2 audio slots · %3 bytes of prepared route payload. Output fills are variable.</source>
      <translation>Prepared: %1 ms · %2 audio slots · %3 bytes of prepared route payload. Output fills are variable.</translation>
    </message>
    <message>
      <source>Saved declaration: %1 ms · %2 audio slots. No audio route is allocated.</source>
      <translation>Saved declaration: %1 ms · %2 audio slots. No audio route is allocated.</translation>
    </message>
    <message>
      <source>Saved declaration: %1 ms · %2 audio slots · %3 receipt slots. No audio route is allocated.</source>
      <translation>Saved declaration: %1 ms · %2 audio slots · %3 receipt slots. No audio route is allocated.</translation>
    </message>
    <message>
      <source>Prepared: %1 ms · %2 audio slots · %3 receipt slots · %4 bytes of prepared route payload.</source>
      <translation>Prepared: %1 ms · %2 audio slots · %3 receipt slots · %4 bytes of prepared route payload.</translation>
    </message>
    <message>
      <source>No disk-pause duration was declared for this take.</source>
      <translation>No disk-pause duration was declared for this take.</translation>
    </message>
    <message>
      <source>Disk-pause budgeting is not available for this audio route yet.</source>
      <translation>Disk-pause budgeting is not available for this audio route yet.</translation>
    </message>
    <message>
      <source>Using existing buffers. No disk-pause duration is declared.</source>
      <translation>Using existing buffers. No disk-pause duration is declared.</translation>
    </message>
    <message>
      <source>The input device's actual format and memory cost will be checked during Prepare. Output fills do not set the disk-buffer budget.</source>
      <translation>The input device's actual format and memory cost will be checked during Prepare. Output fills do not set the disk-buffer budget.</translation>
    </message>
    <message>
      <source>Choose the minimum input packet size before preparing.</source>
      <translation>Choose the minimum input packet size before preparing.</translation>
    </message>
    <message>
      <source>Choose minimum input and output block sizes before preparing.</source>
      <translation>Choose minimum input and output block sizes before preparing.</translation>
    </message>
    <message>
      <source>Plan: %1 ms · %2 audio slots · %3 receipt slots · %4 bytes of route payload. Block sizes will be checked while recording.</source>
      <translation>Plan: %1 ms · %2 audio slots · %3 receipt slots · %4 bytes of route payload. Block sizes will be checked while recording.</translation>
    </message>
    <message>
      <source>This disk-pause budget exceeds the buffer or memory limit. Reduce the duration or change the audio setup.</source>
      <translation>This disk-pause budget exceeds the buffer or memory limit. Reduce the duration or change the audio setup.</translation>
    </message>
    <message>
      <source>The minimum block sizes do not match the recording setup.</source>
      <translation>The minimum block sizes do not match the recording setup.</translation>
    </message>
    <message>
      <source>Available to copy: %1 of %2 verified frames · %3 Hz · %4 channels.</source>
      <translation>Available to copy: %1 of %2 verified frames · %3 Hz · %4 channels.</translation>
    </message>
    <message>
      <source> Unverified audio stays in the original take.</source>
      <translation> Unverified audio stays in the original take.</translation>
    </message>
    <message>
      <source> This take was not finalized.</source>
      <translation> This take was not finalized.</translation>
    </message>
    <message>
      <source> Audio from the first invalid sample onward will not be copied.</source>
      <translation> Audio from the first invalid sample onward will not be copied.</translation>
    </message>
    <message>
      <source>Pending</source>
      <translation>Pending</translation>
    </message>
    <message>
      <source>Complete</source>
      <translation>Complete</translation>
    </message>
    <message>
      <source>Cancelled</source>
      <translation>Cancelled</translation>
    </message>
    <message>
      <source>Failed</source>
      <translation>Failed</translation>
    </message>
    <message>
      <source>Interrupted</source>
      <translation>Interrupted</translation>
    </message>
    <message>
      <source>No native outcome</source>
      <translation>No native outcome</translation>
    </message>
    <message>
      <source> Original outcome: %1.</source>
      <translation> Original outcome: %1.</translation>
    </message>
    <message>
      <source>Recording is unavailable.</source>
      <translation>Recording is unavailable.</translation>
    </message>
    <message>
      <source>Choose recording settings, then prepare.</source>
      <translation>Choose recording settings, then prepare.</translation>
    </message>
    <message>
      <source>Preparing recording…</source>
      <translation>Preparing recording…</translation>
    </message>
    <message>
      <source>Opening and verifying saved native take…</source>
      <translation>Opening and verifying saved native take…</translation>
    </message>
    <message>
      <source>Ready to record.</source>
      <translation>Ready to record.</translation>
    </message>
    <message>
      <source>Recording and monitoring…</source>
      <translation>Recording and monitoring…</translation>
    </message>
    <message>
      <source>Finishing and saving the original take…</source>
      <translation>Finishing and saving the original take…</translation>
    </message>
    <message>
      <source>Original take saved.</source>
      <translation>Original take saved.</translation>
    </message>
    <message>
      <source>Recording cancelled. The retained take is available for inspection.</source>
      <translation>Recording cancelled. The retained take is available for inspection.</translation>
    </message>
    <message>
      <source>Recording stopped with an error. Inspect the retained take.</source>
      <translation>Recording stopped with an error. Inspect the retained take.</translation>
    </message>
    <message>
      <source>Recording closed.</source>
      <translation>Recording closed.</translation>
    </message>
    <message>
      <source>Saved native take opened. Original outcome: %1.</source>
      <translation>Saved native take opened. Original outcome: %1.</translation>
    </message>
    <message>
      <source>Verifying original take for the timeline…</source>
      <translation>Verifying original take for the timeline…</translation>
    </message>
    <message>
      <source>Exporting original WAV…</source>
      <translation>Exporting original WAV…</translation>
    </message>
    <message>
      <source>Copying verified audio…</source>
      <translation>Copying verified audio…</translation>
    </message>
    <message>
      <source>Audio copy cancelled. The retained take is unchanged.</source>
      <translation>Audio copy cancelled. The retained take is unchanged.</translation>
    </message>
    <message>
      <source>The saved audio changed or no longer matches the reviewed take. Open and verify it again.</source>
      <translation>The saved audio changed or no longer matches the reviewed take. Open and verify it again.</translation>
    </message>
    <message>
      <source>The recording buffer exceeds the available capacity or memory. Reduce the disk-pause budget.</source>
      <translation>The recording buffer exceeds the available capacity or memory. Reduce the disk-pause budget.</translation>
    </message>
    <message>
      <source>The recording settings do not match the prepared device format. Check the minimum input packet size.</source>
      <translation>The recording settings do not match the prepared device format. Check the minimum input packet size.</translation>
    </message>
    <message>
      <source>Recording error (%1).</source>
      <translation>Recording error (%1).</translation>
    </message>
    <message>
      <source>Original frames: %1 · Monitored frames: %2</source>
      <translation>Original frames: %1 · Monitored frames: %2</translation>
    </message>
    <message>
      <source>EQ accepted: %1 · Applied: %2</source>
      <translation>EQ accepted: %1 · Applied: %2</translation>
    </message>
    <message>
      <source> · Saved frames verified: %1</source>
      <translation> · Saved frames verified: %1</translation>
    </message>
    <message>
      <source> · Original WAV exported: %1 frames</source>
      <translation> · Original WAV exported: %1 frames</translation>
    </message>
    <message>
      <source> · Export published with a durability warning.</source>
      <translation> · Export published with a durability warning.</translation>
    </message>
    <message>
      <source> · Verified audio copied: %1 frames to %2.</source>
      <translation> · Verified audio copied: %1 frames to %2.</translation>
    </message>
    <message>
      <source> · Copy published with a durability warning.</source>
      <translation> · Copy published with a durability warning.</translation>
    </message>
  </context>
  <context>
    <name>SessionListModel</name>
    <message>
      <source>Select a take lane</source>
      <translation>Select a take lane</translation>
    </message>
    <message>
      <source>Select a clip</source>
      <translation>Select a clip</translation>
    </message>
    <message>
      <source>%1 · captured %2–%3 frames</source>
      <translation>%1 · captured %2–%3 frames</translation>
    </message>
    <message>
      <source>Clip %1 · %2 frames</source>
      <translation>Clip %1 · %2 frames</translation>
    </message>
    <message>
      <source>%1 · %2 channel(s) · %3</source>
      <translation>%1 · %2 channel(s) · %3</translation>
    </message>
    <message>
      <source>Monitoring off</source>
      <translation>Monitoring off</translation>
    </message>
    <message>
      <source>Auto during recording</source>
      <translation>Auto during recording</translation>
    </message>
    <message>
      <source>Post-EQ monitoring</source>
      <translation>Post-EQ monitoring</translation>
    </message>
  </context>
  <context>
    <name>StandardActions</name>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Yes</source>
      <translation>Yes</translation>
    </message>
    <message>
      <source>No</source>
      <translation>No</translation>
    </message>
    <message>
      <source>Yes to All</source>
      <translation>Yes to All</translation>
    </message>
    <message>
      <source>No to All</source>
      <translation>No to All</translation>
    </message>
    <message>
      <source>Open</source>
      <translation>Open</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Save</translation>
    </message>
    <message>
      <source>Save All</source>
      <translation>Save All</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Close</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel</translation>
    </message>
    <message>
      <source>Discard</source>
      <translation>Discard</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Apply</translation>
    </message>
    <message>
      <source>Reset</source>
      <translation>Reset</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation>Restore Defaults</translation>
    </message>
    <message>
      <source>Retry</source>
      <translation>Retry</translation>
    </message>
    <message>
      <source>Abort</source>
      <translation>Abort</translation>
    </message>
    <message>
      <source>Ignore</source>
      <translation>Ignore</translation>
    </message>
    <message>
      <source>Help</source>
      <translation>Help</translation>
    </message>
  </context>
  <context>
    <name>StretchDialog</name>
    <message>
      <source>Clip pitch and stretch</source>
      <translation>Clip pitch and stretch</translation>
    </message>
    <message>
      <source>Duration multiplier numerator</source>
      <translation>Duration multiplier numerator</translation>
    </message>
    <message>
      <source>Duration multiplier denominator</source>
      <translation>Duration multiplier denominator</translation>
    </message>
    <message>
      <source>Pitch (semitones)</source>
      <translation>Pitch (semitones)</translation>
    </message>
    <message>
      <source>Preserve formants</source>
      <translation>Preserve formants</translation>
    </message>
    <message>
      <source>Use neighboring source context</source>
      <translation>Use neighboring source context</translation>
    </message>
    <message>
      <source>Context before (source frames)</source>
      <translation>Context before (source frames)</translation>
    </message>
    <message>
      <source>Context after (source frames)</source>
      <translation>Context after (source frames)</translation>
    </message>
    <message>
      <source>Experimental protected stretch markers</source>
      <translation>Experimental protected stretch markers</translation>
      <extracomment>Explicit transient-protected offline editing mode. Broader acoustic and sustained multichannel phase quality remain unqualified; preserve the experimental scope.</extracomment>
    </message>
    <message>
      <source>Stretch markers in retained original source frames</source>
      <translation>Stretch markers in retained original source frames</translation>
    </message>
    <message>
      <source>Marker</source>
      <translation>Marker</translation>
      <extracomment>A stable user stretch anchor. Its displayed UUID prefix is not translated. This is not a project navigation marker.</extracomment>
    </message>
    <message>
      <source>Source position</source>
      <translation>Source position</translation>
      <extracomment>Protected stretch marker offset in physical source-sample frames from the retained nominal raw origin; not an absolute project frame or a filename. Integer acoustic positions use ungrouped digits.</extracomment>
    </message>
    <message>
      <source>Target position</source>
      <translation>Target position</translation>
      <extracomment>Protected stretch marker offset in physical frames in the prepared derivative, independent of project sample rate or linked playback speed.</extracomment>
    </message>
    <message>
      <source>Add marker</source>
      <translation>Add marker</translation>
    </message>
    <message>
      <source>Remove selected marker</source>
      <translation>Remove selected marker</translation>
    </message>
    <message>
      <source>Markers use positions relative to the retained original span, at its physical sample rate. Moving a target protects the attack around that marker. Source and target positions must remain ordered. This first renderer requires integer positions, zero pitch and no neighboring context. Sustained multichannel phase quality is still unqualified.</source>
      <translation>Markers use positions relative to the retained original span, at its physical sample rate. Moving a target protects the attack around that marker. Source and target positions must remain ordered. This first renderer requires integer positions, zero pitch and no neighboring context. Sustained multichannel phase quality is still unqualified.</translation>
    </message>
    <message>
      <source>Protected region: %1 source frames before and %2 after each marker; %3-frame blending boundaries. Fades follow the visible clip length.</source>
      <translation>Protected region: %1 source frames before and %2 after each marker; %3-frame blending boundaries. Fades follow the visible clip length.</translation>
    </message>
    <message>
      <source>Not enough Project resources to add a marker. No marker was added.</source>
      <translation>Not enough Project resources to add a marker. No marker was added.</translation>
    </message>
    <message>
      <source>This dialog stays bound to the clip selected when it opened. Close it before choosing another clip. Duration can be 0.25 to 4 times the source duration. Pitch and duration are independent. Rendering starts from the retained original audio. Linked playback speed remains a separate control. Closing this dialog leaves rendering in the background.</source>
      <translation>This dialog stays bound to the clip selected when it opened. Close it before choosing another clip. Duration can be 0.25 to 4 times the source duration. Pitch and duration are independent. Rendering starts from the retained original audio. Linked playback speed remains a separate control. Closing this dialog leaves rendering in the background.</translation>
    </message>
    <message>
      <source>Context extends the retained original span with real neighboring audio at the source sample rate. The visible duration follows the requested multiplier. Prepare audition, choose playback outputs and play the verified result before Apply. Stop audition to apply it as one undoable edit.</source>
      <translation>Context extends the retained original span with real neighboring audio at the source sample rate. The visible duration follows the requested multiplier. Prepare audition, choose playback outputs and play the verified result before Apply. Stop audition to apply it as one undoable edit.</translation>
    </message>
    <message>
      <source>Render</source>
      <translation>Render</translation>
    </message>
    <message>
      <source>Apply verified result</source>
      <translation>Apply verified result</translation>
    </message>
    <message>
      <source>Cancel render</source>
      <translation>Cancel render</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Close</translation>
    </message>
    <message>
      <source>Prepare audition</source>
      <translation>Prepare audition</translation>
      <extracomment>Prepare an ephemeral playback model for the verified derivative without modifying the project or playing automatically. Output channels are chosen before Play audition.</extracomment>
    </message>
    <message>
      <source>Stop audition</source>
      <translation>Stop audition</translation>
      <extracomment>Retire the temporary playback endpoint; keep the pending verified result available for Apply. This does not cancel a render or undo an edit.</extracomment>
    </message>
    <message>
      <source>Check marker positions: use integer source frames, ordered targets and nonoverlapping protected regions. No project edit was made.</source>
      <translation>Check marker positions: use integer source frames, ordered targets and nonoverlapping protected regions. No project edit was made.</translation>
    </message>
    <message>
      <source>Play audition</source>
      <translation>Play audition</translation>
      <extracomment>Play the verified pending derivative on the explicitly chosen outputs before committing Apply. Audition output choices do not change saved project routes.</extracomment>
    </message>
    <message>
      <source>Apply reviewed completed result</source>
      <translation>Apply reviewed completed result</translation>
    </message>
    <message>
      <source>Applying the verified result as one undoable edit…</source>
      <translation>Applying the verified result as one undoable edit…</translation>
    </message>
    <message>
      <source>Choose settings, render, then apply the verified result.</source>
      <translation>Choose settings, render, then apply the verified result.</translation>
    </message>
    <message>
      <source>Preparing the original audio and reserving render resources…</source>
      <translation>Preparing the original audio and reserving render resources…</translation>
    </message>
    <message>
      <source>Rendering pitch and duration in the background…</source>
      <translation>Rendering pitch and duration in the background…</translation>
    </message>
    <message>
      <source>Checking the completed audio before it can be applied…</source>
      <translation>Checking the completed audio before it can be applied…</translation>
    </message>
    <message>
      <source>This retained result was independently verified after reopening. Review these settings before choosing Apply. No project edit has been made.</source>
      <translation>This retained result was independently verified after reopening. Review these settings before choosing Apply. No project edit has been made.</translation>
    </message>
    <message>
      <source>A complete result was verified after cancellation, a deadline, or an abnormal exit. Review these settings before choosing Apply. No project edit has been made.</source>
      <translation>A complete result was verified after cancellation, a deadline, or an abnormal exit. Review these settings before choosing Apply. No project edit has been made.</translation>
    </message>
    <message>
      <source>Render verified. Choose Apply to replace this clip as one undoable edit.</source>
      <translation>Render verified. Choose Apply to replace this clip as one undoable edit.</translation>
    </message>
    <message>
      <source>Canceled before rendering. No project edit was made.</source>
      <translation>Canceled before rendering. No project edit was made.</translation>
    </message>
    <message>
      <source>Rendering could not start. Check the source, helper installation, settings, and available memory. No project edit was made.</source>
      <translation>Rendering could not start. Check the source, helper installation, settings, and available memory. No project edit was made.</translation>
    </message>
    <message>
      <source>The renderer stopped without a verified completed result. Its owned job files were retained for inspection. No project edit was made.</source>
      <translation>The renderer stopped without a verified completed result. Its owned job files were retained for inspection. No project edit was made.</translation>
    </message>
    <message>
      <source>This protected renderer requires an integer retained raw origin. Constant pitch/stretch remains available for this clip.</source>
      <translation>This protected renderer requires an integer retained raw origin. Constant pitch/stretch remains available for this clip.</translation>
    </message>
    <message>
      <source>The duration multiplier must be between 0.25 and 4.</source>
      <translation>The duration multiplier must be between 0.25 and 4.</translation>
    </message>
    <message>
      <source>Settings have changed. Render again before audition or Apply.</source>
      <translation>Settings have changed. Render again before audition or Apply.</translation>
    </message>
    <message>
      <source>Not enough Project resources to compare settings. Wait or close this dialog.</source>
      <translation>Not enough Project resources to compare settings. Wait or close this dialog.</translation>
    </message>
    <message>
      <source>Verified result: duration %1/%2, pitch %3 semitones, formants %4.</source>
      <translation>Verified result: duration %1/%2, pitch %3 semitones, formants %4.</translation>
    </message>
    <message>
      <source>preserved</source>
      <translation>preserved</translation>
    </message>
    <message>
      <source>shifted</source>
      <translation>shifted</translation>
    </message>
    <message numerus="yes">
      <source>Verified protected marker plan: %n marker(s).</source>
      <translation type="unfinished" />
      <extracomment>Count of original user marker owners in the verified derivative plan. Numerus entry; retain %n and provide the language plural forms when reviewed.</extracomment>
    </message>
    <message>
      <source>Verified source context: %1 frames before, %2 frames after.</source>
      <translation>Verified source context: %1 frames before, %2 frames after.</translation>
    </message>
  </context>
  <context>
    <name>StudioWindow</name>
    <message>
      <source>SoundCurrent DAW</source>
      <translation>SoundCurrent DAW</translation>
    </message>
    <message>
      <source>&amp;File</source>
      <translation>&amp;File</translation>
    </message>
    <message>
      <source>&amp;New project…</source>
      <translation>&amp;New project…</translation>
    </message>
    <message>
      <source>&amp;Open project…</source>
      <translation>&amp;Open project…</translation>
    </message>
    <message>
      <source>Open project folder</source>
      <translation>Open project folder</translation>
    </message>
    <message>
      <source>&amp;Save</source>
      <translation>&amp;Save</translation>
    </message>
    <message>
      <source>Inspect foreign project…</source>
      <translation>Inspect foreign project…</translation>
    </message>
    <message>
      <source>&amp;Export WAV…</source>
      <translation>&amp;Export WAV…</translation>
    </message>
    <message>
      <source>Cancel export</source>
      <translation>Cancel export</translation>
    </message>
    <message>
      <source>&amp;Quit</source>
      <translation>&amp;Quit</translation>
    </message>
    <message>
      <source>Settings</source>
      <translation>Settings</translation>
    </message>
    <message>
      <source>Language and regional settings…</source>
      <translation>Language and regional settings…</translation>
    </message>
    <message>
      <source>&amp;Edit</source>
      <translation>&amp;Edit</translation>
    </message>
    <message>
      <source>&amp;Undo project edit</source>
      <translation>&amp;Undo project edit</translation>
    </message>
    <message>
      <source>&amp;Redo project edit</source>
      <translation>&amp;Redo project edit</translation>
    </message>
    <message>
      <source>Project resources…</source>
      <translation>Project resources…</translation>
    </message>
    <message>
      <source>Review retained pitch/stretch renders…</source>
      <translation>Review retained pitch/stretch renders…</translation>
    </message>
    <message>
      <source>Review rendered transitions…</source>
      <translation>Review rendered transitions…</translation>
    </message>
    <message>
      <source>Retry project display</source>
      <translation>Retry project display</translation>
    </message>
    <message>
      <source>Equipment</source>
      <translation>Equipment</translation>
    </message>
    <message>
      <source>Profile library and editor…</source>
      <translation>Profile library and editor…</translation>
    </message>
    <message>
      <source>Equipment profiles</source>
      <translation>Equipment profiles</translation>
    </message>
    <message>
      <source>&amp;Transport</source>
      <translation>&amp;Transport</translation>
    </message>
    <message>
      <source>Prepare playback</source>
      <translation>Prepare playback</translation>
    </message>
    <message>
      <source>Play / Stop</source>
      <translation>Play / Stop</translation>
    </message>
    <message>
      <source>Stop</source>
      <translation>Stop</translation>
    </message>
    <message>
      <source>Prepare recording</source>
      <translation>Prepare recording</translation>
    </message>
    <message>
      <source>Record</source>
      <translation>Record</translation>
    </message>
    <message>
      <source>Recover recording…</source>
      <translation>Recover recording…</translation>
    </message>
    <message>
      <source>Choose a capture job to inspect</source>
      <translation>Choose a capture job to inspect</translation>
    </message>
    <message>
      <source>Find recoverable recordings…</source>
      <translation>Find recoverable recordings…</translation>
    </message>
    <message>
      <source>Create or open a project to begin.</source>
      <translation>Create or open a project to begin.</translation>
    </message>
    <message>
      <source>Track selection could not be updated: %1. Raise Project resources and retry.</source>
      <translation>Track selection could not be updated: %1. Raise Project resources and retry.</translation>
    </message>
    <message>
      <source>Playback</source>
      <translation>Playback</translation>
    </message>
    <message>
      <source>Play</source>
      <translation>Play</translation>
    </message>
    <message>
      <source>Play project mix (saved master or matching layouts)</source>
      <translation>Play project mix (saved master or matching layouts)</translation>
    </message>
    <message>
      <source>Use the saved master's channel matrix and output routes. Without a saved master, use the selected track's layout and output routes. Different track layouts require an explicit matrix.</source>
      <translation>Use the saved master's channel matrix and output routes. Without a saved master, use the selected track's layout and output routes. Different track layouts require an explicit matrix.</translation>
    </message>
    <message>
      <source>Edit master layout and matrix…</source>
      <translation>Edit master layout and matrix…</translation>
    </message>
    <message>
      <source>Master change was not admitted. Please retry.</source>
      <translation>Master change was not admitted. Please retry.</translation>
    </message>
    <message>
      <source>Loop playback</source>
      <translation>Loop playback</translation>
    </message>
    <message>
      <source>Repeat the saved loop range until Stop. Stop playback before changing the range.</source>
      <translation>Repeat the saved loop range until Stop. Stop playback before changing the range.</translation>
    </message>
    <message>
      <source>Set loop range…</source>
      <translation>Set loop range…</translation>
    </message>
    <message>
      <source>There is no room for a loop range at this position.</source>
      <translation>There is no room for a loop range at this position.</translation>
    </message>
    <message>
      <source>Loop settings could not be changed. Stop transport setup and retry.</source>
      <translation>Loop settings could not be changed. Stop transport setup and retry.</translation>
    </message>
    <message>
      <source>Output peak level</source>
      <translation>Output peak level</translation>
    </message>
    <message>
      <source>Recording</source>
      <translation>Recording</translation>
    </message>
    <message>
      <source>Stop recording</source>
      <translation>Stop recording</translation>
    </message>
    <message>
      <source>Arm selected track</source>
      <translation>Arm selected track</translation>
    </message>
    <message>
      <source>Recording monitoring mode</source>
      <translation>Recording monitoring mode</translation>
    </message>
    <message>
      <source>Monitoring off</source>
      <translation>Monitoring off</translation>
    </message>
    <message>
      <source>Monitor through track EQ</source>
      <translation>Monitor through track EQ</translation>
    </message>
    <message>
      <source>Auto — monitor during recording</source>
      <translation>Auto — monitor during recording</translation>
    </message>
    <message>
      <source>Saved monitoring mode takes effect after Stop and preparation.</source>
      <translation>Saved monitoring mode takes effect after Stop and preparation.</translation>
    </message>
    <message>
      <source>Selected track input latency:</source>
      <translation>Selected track input latency:</translation>
    </message>
    <message>
      <source>Selected track input latency in sample frames</source>
      <translation>Selected track input latency in sample frames</translation>
    </message>
    <message>
      <source> samples</source>
      <translation> samples</translation>
    </message>
    <message>
      <source>Declared input delay, from zero to 60 seconds. New takes are aligned earlier by this amount. Existing clips and monitor audio are unchanged. Stop recording before editing.</source>
      <translation>Declared input delay, from zero to 60 seconds. New takes are aligned earlier by this amount. Existing clips and monitor audio are unchanged. Stop recording before editing.</translation>
    </message>
    <message>
      <source>Input latency could not be changed. Stop recording and retry.</source>
      <translation>Input latency could not be changed. Stop recording and retry.</translation>
    </message>
    <message>
      <source>Record armed tracks with project playback</source>
      <translation>Record armed tracks with project playback</translation>
    </message>
    <message>
      <source>Select tracks below. Every raw input and project output must be chosen explicitly after preparation.</source>
      <translation>Select tracks below. Every raw input and project output must be chosen explicitly after preparation.</translation>
    </message>
    <message>
      <source>Tracks to arm for simultaneous recording</source>
      <translation>Tracks to arm for simultaneous recording</translation>
    </message>
    <message>
      <source>Recording mode</source>
      <translation>Recording mode</translation>
    </message>
    <message>
      <source>Timed recording</source>
      <translation>Timed recording</translation>
    </message>
    <message>
      <source>Loop: chosen number of passes</source>
      <translation>Loop: chosen number of passes</translation>
    </message>
    <message>
      <source>Loop: until Stop</source>
      <translation>Loop: until Stop</translation>
    </message>
    <message>
      <source>Passes</source>
      <translation>Passes</translation>
    </message>
    <message>
      <source>Recording range (seconds)</source>
      <translation>Recording range (seconds)</translation>
    </message>
    <message>
      <source>Maximum shared recording duration in seconds</source>
      <translation>Maximum shared recording duration in seconds</translation>
    </message>
    <message>
      <source>Recording stops at this range; you can stop earlier. Existing audio plays from the current playhead.</source>
      <translation>Recording stops at this range; you can stop earlier. Existing audio plays from the current playhead.</translation>
    </message>
    <message>
      <source>Punch recording</source>
      <translation>Punch recording</translation>
    </message>
    <message>
      <source>Record only within the saved punch range while project playback continues.</source>
      <translation>Record only within the saved punch range while project playback continues.</translation>
    </message>
    <message>
      <source>Set punch range…</source>
      <translation>Set punch range…</translation>
    </message>
    <message>
      <source>There is no room for a punch range at this position.</source>
      <translation>There is no room for a punch range at this position.</translation>
    </message>
    <message>
      <source>Punch settings could not be changed. Stop recording setup and retry.</source>
      <translation>Punch settings could not be changed. Stop recording setup and retry.</translation>
    </message>
    <message>
      <source>Recording disk-stall reserve</source>
      <translation>Recording disk-stall reserve</translation>
    </message>
    <message>
      <source>2 seconds</source>
      <translation>2 seconds</translation>
    </message>
    <message>
      <source>5 seconds</source>
      <translation>5 seconds</translation>
    </message>
    <message>
      <source>10 seconds</source>
      <translation>10 seconds</translation>
    </message>
    <message>
      <source>Uses memory to absorb temporary disk stalls. Applies on Prepare; monitoring latency is unchanged. Preparation refuses a reserve that exceeds the recording memory budget.</source>
      <translation>Uses memory to absorb temporary disk stalls. Applies on Prepare; monitoring latency is unchanged. Preparation refuses a reserve that exceeds the recording memory budget.</translation>
    </message>
    <message>
      <source>Raw input peak level</source>
      <translation>Raw input peak level</translation>
    </message>
    <message>
      <source>Post-EQ monitoring peak level</source>
      <translation>Post-EQ monitoring peak level</translation>
    </message>
    <message>
      <source>Retry adding take</source>
      <translation>Retry adding take</translation>
    </message>
    <message>
      <source>Keep take for recovery</source>
      <translation>Keep take for recovery</translation>
    </message>
    <message>
      <source>Open a project to find stored recordings.</source>
      <translation>Open a project to find stored recordings.</translation>
    </message>
    <message>
      <source>Review recordings…</source>
      <translation>Review recordings…</translation>
    </message>
    <message>
      <source>Refresh</source>
      <translation>Refresh</translation>
    </message>
    <message>
      <source>Take kept for recovery in %1</source>
      <translation>Take kept for recovery in %1</translation>
    </message>
    <message>
      <source>First pass</source>
      <translation>First pass</translation>
    </message>
    <message>
      <source>Passes on this page</source>
      <translation>Passes on this page</translation>
    </message>
    <message>
      <source>Take name prefix</source>
      <translation>Take name prefix</translation>
    </message>
    <message>
      <source>Include the partial final pass</source>
      <translation>Include the partial final pass</translation>
    </message>
    <message>
      <source>Retain this page as takes</source>
      <translation>Retain this page as takes</translation>
    </message>
    <message>
      <source>Retain inactive takes for comping. Existing playback stays as it is; Save remains explicit.</source>
      <translation>Retain inactive takes for comping. Existing playback stays as it is; Save remains explicit.</translation>
    </message>
    <message>
      <source>Recording workflows</source>
      <translation>Recording workflows</translation>
    </message>
    <message>
      <source>Fixed range / locators</source>
      <translation>Fixed range / locators</translation>
    </message>
    <message>
      <source>Manual / repeated takes</source>
      <translation>Manual / repeated takes</translation>
    </message>
    <message>
      <source>Native input monitoring</source>
      <translation>Native input monitoring</translation>
    </message>
    <message>
      <source>Track equalizer</source>
      <translation>Track equalizer</translation>
    </message>
    <message>
      <source>Audio export</source>
      <translation>Audio export</translation>
    </message>
    <message>
      <source>Export WAV…</source>
      <translation>Export WAV…</translation>
    </message>
    <message>
      <source>Audio export progress</source>
      <translation>Audio export progress</translation>
    </message>
    <message>
      <source>Development preview: selected-track recording and shared-clock playback are available on Linux. Captured audio stays raw; track EQ affects monitoring, playback and WAV export.</source>
      <translation>Development preview: selected-track recording and shared-clock playback are available on Linux. Captured audio stays raw; track EQ affects monitoring, playback and WAV export.</translation>
    </message>
    <message>
      <source>Transition preparation could not start. Check Project resources and the installed render helper.</source>
      <translation>Transition preparation could not start. Check Project resources and the installed render helper.</translation>
    </message>
    <message>
      <source>The project was reopened or replaced. Rendering stopped; owned job files were retained.</source>
      <translation>The project was reopened or replaced. Rendering stopped; owned job files were retained.</translation>
    </message>
    <message>
      <source>Rendering canceled. Already accepted project changes and saves may have completed; retained jobs remain available for review.</source>
      <translation>Rendering canceled. Already accepted project changes and saves may have completed; retained jobs remain available for review.</translation>
    </message>
    <message>
      <source>The transition could not be prepared. Check source handles, processing settings, Project resources and the installed helper. No audio was applied.</source>
      <translation>The transition could not be prepared. Check source handles, processing settings, Project resources and the installed helper. No audio was applied.</translation>
    </message>
    <message>
      <source>The edit queue is unavailable. The prepared job files were retained.</source>
      <translation>The edit queue is unavailable. The prepared job files were retained.</translation>
    </message>
    <message>
      <source>The transition sources changed before registration. No render started; prepared files were retained.</source>
      <translation>The transition sources changed before registration. No render started; prepared files were retained.</translation>
    </message>
    <message>
      <source>The project could not be queued for saving. Save it before rendering the retained job.</source>
      <translation>The project could not be queued for saving. Save it before rendering the retained job.</translation>
    </message>
    <message>
      <source>The project could not be saved. Rendering did not start; check the save error and retained job references.</source>
      <translation>The project could not be saved. Rendering did not start; check the save error and retained job references.</translation>
    </message>
    <message>
      <source>The source render queue is unavailable. Saved references were retained.</source>
      <translation>The source render queue is unavailable. Saved references were retained.</translation>
    </message>
    <message>
      <source>Source rendering did not finish successfully. No audio was applied; inspect the retained job before retrying.</source>
      <translation>Source rendering did not finish successfully. No audio was applied; inspect the retained job before retrying.</translation>
    </message>
    <message>
      <source>The assembly queue is unavailable. Rendered source spans were retained.</source>
      <translation>The assembly queue is unavailable. Rendered source spans were retained.</translation>
    </message>
    <message>
      <source>The transition could not be assembled or verified. No audio was applied; retained files remain available for review.</source>
      <translation>The transition could not be assembled or verified. No audio was applied; retained files remain available for review.</translation>
    </message>
    <message>
      <source>Transition rendered and verified. Review it, then choose Apply. The timeline audio has not changed.</source>
      <translation>Transition rendered and verified. Review it, then choose Apply. The timeline audio has not changed.</translation>
    </message>
    <message>
      <source>Render transition</source>
      <translation>Render transition</translation>
    </message>
    <message>
      <source>Cancel rendering</source>
      <translation>Cancel rendering</translation>
    </message>
    <message>
      <source>Review rendered transition</source>
      <translation>Review rendered transition</translation>
    </message>
    <message>
      <source>Canceling rendering and waiting for active work to retire…</source>
      <translation>Canceling rendering and waiting for active work to retire…</translation>
    </message>
    <message>
      <source>Preparing transition sources and owned job files…</source>
      <translation>Preparing transition sources and owned job files…</translation>
    </message>
    <message>
      <source>Registering the transition against the current project…</source>
      <translation>Registering the transition against the current project…</translation>
    </message>
    <message>
      <source>Saving the project and render references…</source>
      <translation>Saving the project and render references…</translation>
    </message>
    <message>
      <source>Checking source audio and previous render history…</source>
      <translation>Checking source audio and previous render history…</translation>
    </message>
    <message>
      <source>Verifying rendered source audio…</source>
      <translation>Verifying rendered source audio…</translation>
    </message>
    <message>
      <source>Rendering the two source spans…</source>
      <translation>Rendering the two source spans…</translation>
    </message>
    <message>
      <source>Loading the saved transition and source history…</source>
      <translation>Loading the saved transition and source history…</translation>
    </message>
    <message>
      <source>Verifying transition audio…</source>
      <translation>Verifying transition audio…</translation>
    </message>
    <message>
      <source>Assembling and verifying transition audio…</source>
      <translation>Assembling and verifying transition audio…</translation>
    </message>
    <message>
      <source>Elapsed: %1 s</source>
      <translation>Elapsed: %1 s</translation>
    </message>
    <message>
      <source>Transition review could not start. Check Project resources and retry.</source>
      <translation>Transition review could not start. Check Project resources and retry.</translation>
    </message>
    <message>
      <source>Transition verification could not start. Check Project resources and retry.</source>
      <translation>Transition verification could not start. Check Project resources and retry.</translation>
    </message>
    <message>
      <source>The transition could not be applied. Review it again; no transition edit was made and retained files were preserved.</source>
      <translation>The transition could not be applied. Review it again; no transition edit was made and retained files were preserved.</translation>
    </message>
    <message>
      <source>The edit queue is unavailable. Review the transition and retry Apply.</source>
      <translation>The edit queue is unavailable. Review the transition and retry Apply.</translation>
    </message>
    <message>
      <source>The transition was not applied because the project or sources changed. Retained files are available for review.</source>
      <translation>The transition was not applied because the project or sources changed. Retained files are available for review.</translation>
    </message>
    <message>
      <source>Transition applied. Undo restores both original clips; save to retain the change.</source>
      <translation>Transition applied. Undo restores both original clips; save to retain the change.</translation>
    </message>
    <message>
      <source>Transition review needs more Project resources. Close unused previews and retry.</source>
      <translation>Transition review needs more Project resources. Close unused previews and retry.</translation>
    </message>
    <message>
      <source>Rendered transitions — preview</source>
      <translation>Rendered transitions — preview</translation>
    </message>
    <message>
      <source>Review a saved transition before applying it. Apply checks the audio again and changes both clips in one Undo step. Save remains explicit. Rendered transitions are experimental. Check for audible artifacts before using them in a final mix.</source>
      <translation>Review a saved transition before applying it. Apply checks the audio again and changes both clips in one Undo step. Save remains explicit. Rendered transitions are experimental. Check for audible artifacts before using them in a final mix.</translation>
    </message>
    <message>
      <source>Previous page</source>
      <translation>Previous page</translation>
    </message>
    <message>
      <source>Next page</source>
      <translation>Next page</translation>
    </message>
    <message>
      <source>Review selected transition</source>
      <translation>Review selected transition</translation>
    </message>
    <message>
      <source>Apply reviewed audio</source>
      <translation>Apply reviewed audio</translation>
    </message>
    <message>
      <source>Cancel operation</source>
      <translation>Cancel operation</translation>
    </message>
    <message>
      <source>This review belongs to a previous project opening. Close it and review the current project.</source>
      <translation>This review belongs to a previous project opening. Close it and review the current project.</translation>
    </message>
    <message>
      <source>Saved transition %1</source>
      <translation>Saved transition %1</translation>
    </message>
    <message>
      <source>%1 · frames %2–%3</source>
      <translation>%1 · frames %2–%3</translation>
    </message>
    <message>
      <source>Checking audio before Apply…</source>
      <translation>Checking audio before Apply…</translation>
    </message>
    <message>
      <source>Reviewing transition audio…</source>
      <translation>Reviewing transition audio…</translation>
    </message>
    <message>
      <source>Applying both clips…</source>
      <translation>Applying both clips…</translation>
    </message>
    <message>
      <source>No saved rendered transitions are awaiting review. Existing timeline crossfades remain available.</source>
      <translation>No saved rendered transitions are awaiting review. Existing timeline crossfades remain available.</translation>
    </message>
    <message>
      <source>Audio verified. Apply will check it again before changing the project.</source>
      <translation>Audio verified. Apply will check it again before changing the project.</translation>
    </message>
    <message>
      <source>This transition is incomplete, canceled, stale or could not be verified. No edit was made; retained files were preserved.</source>
      <translation>This transition is incomplete, canceled, stale or could not be verified. No edit was made; retained files were preserved.</translation>
    </message>
    <message>
      <source>Select a saved transition to review its audio.</source>
      <translation>Select a saved transition to review its audio.</translation>
    </message>
    <message>
      <source>Retained render review needs more Project resources. Close unused previews and retry.</source>
      <translation>Retained render review needs more Project resources. Close unused previews and retry.</translation>
    </message>
    <message>
      <source>Retained pitch/stretch renders</source>
      <translation>Retained pitch/stretch renders</translation>
    </message>
    <message>
      <source>Scan verifies retained jobs in bounded pages. Next page replaces this list; Scan again starts at the beginning. Select a ready job to review its settings, then choose Apply in the clip dialog. Files are preserved; scanning makes no project edit.</source>
      <translation>Scan verifies retained jobs in bounded pages. Next page replaces this list; Scan again starts at the beginning. Select a ready job to review its settings, then choose Apply in the clip dialog. Files are preserved; scanning makes no project edit.</translation>
    </message>
    <message>
      <source>Scan again</source>
      <translation>Scan again</translation>
    </message>
    <message>
      <source>Review selected result</source>
      <translation>Review selected result</translation>
    </message>
    <message>
      <source>Cancel verification</source>
      <translation>Cancel verification</translation>
    </message>
    <message>
      <source>Retained render scan could not start. Check Project resources.</source>
      <translation>Retained render scan could not start. Check Project resources.</translation>
    </message>
    <message>
      <source>The scan expired or the project changed. Scan again.</source>
      <translation>The scan expired or the project changed. Scan again.</translation>
    </message>
    <message>
      <source>Retained render review could not start. Check Project resources.</source>
      <translation>Retained render review could not start. Check Project resources.</translation>
    </message>
    <message>
      <source>This review belongs to a previous project opening. Close it and scan the current project.</source>
      <translation>This review belongs to a previous project opening. Close it and scan the current project.</translation>
    </message>
    <message>
      <source>Verifying retained jobs in the background…</source>
      <translation>Verifying retained jobs in the background…</translation>
    </message>
    <message>
      <source>The selected job could not be reviewed. Its source, target or files may have changed. Scan again.</source>
      <translation>The selected job could not be reviewed. Its source, target or files may have changed. Scan again.</translation>
    </message>
    <message>
      <source>Verification stopped. Check files and Project resources, then scan again. No project edit was made.</source>
      <translation>Verification stopped. Check files and Project resources, then scan again. No project edit was made.</translation>
    </message>
    <message>
      <source>Ready for review</source>
      <translation>Ready for review</translation>
    </message>
    <message>
      <source>Already attached</source>
      <translation>Already attached</translation>
    </message>
    <message>
      <source>Target changed or missing</source>
      <translation>Target changed or missing</translation>
    </message>
    <message>
      <source>Incomplete render</source>
      <translation>Incomplete render</translation>
    </message>
    <message>
      <source>Renderer still owns this job</source>
      <translation>Renderer still owns this job</translation>
    </message>
    <message>
      <source>Invalid or missing files</source>
      <translation>Invalid or missing files</translation>
    </message>
    <message>
      <source>duration %1/%2, pitch %3 semitones</source>
      <translation>duration %1/%2, pitch %3 semitones</translation>
    </message>
    <message numerus="yes">
      <source>%n retained job(s) inspected on this page.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Page %1: %2 No project edit was made.</source>
      <translation>Page %1: %2 No project edit was made.</translation>
    </message>
    <message>
      <source>More entries remain. Choose Next page to continue.</source>
      <translation>More entries remain. Choose Next page to continue.</translation>
    </message>
    <message>
      <source>Scan finished.</source>
      <translation>Scan finished.</translation>
    </message>
    <message>
      <source>The render queue is unavailable. Please retry.</source>
      <translation>The render queue is unavailable. Please retry.</translation>
    </message>
    <message>
      <source>Rendering could not start: %1. Check Project resources and retry.</source>
      <translation>Rendering could not start: %1. Check Project resources and retry.</translation>
    </message>
    <message>
      <source>Audition prepared without a project edit. Choose playback outputs, then Play audition. Stop before Apply.</source>
      <translation>Audition prepared without a project edit. Choose playback outputs, then Play audition. Stop before Apply.</translation>
    </message>
    <message>
      <source>The result could not be applied. The project or clip may have changed; render it again. The owned render files were retained.</source>
      <translation>The result could not be applied. The project or clip may have changed; render it again. The owned render files were retained.</translation>
    </message>
    <message>
      <source>Pitch and stretch applied. Undo restores the previous clip; save to retain these settings.</source>
      <translation>Pitch and stretch applied. Undo restores the previous clip; save to retain these settings.</translation>
    </message>
    <message>
      <source>The marker editor needs more Project resources. Close unused previews and retry.</source>
      <translation>The marker editor needs more Project resources. Close unused previews and retry.</translation>
    </message>
    <message>
      <source>This dialog belongs to a previous project opening. Close it and select a clip in the current project.</source>
      <translation>This dialog belongs to a previous project opening. Close it and select a clip in the current project.</translation>
    </message>
    <message>
      <source>The current render belongs to a different clip. Finish or cancel that render before starting this one.</source>
      <translation>The current render belongs to a different clip. Finish or cancel that render before starting this one.</translation>
    </message>
    <message>
      <source>A different clip has the retained render result. Rendering this clip replaces that pending preview; its owned files are retained.</source>
      <translation>A different clip has the retained render result. Rendering this clip replaces that pending preview; its owned files are retained.</translation>
    </message>
    <message>
      <source>An export is already running or closing. Please retry.</source>
      <translation>An export is already running or closing. Please retry.</translation>
    </message>
    <message>
      <source>The selected export track no longer exists. Please retry.</source>
      <translation>The selected export track no longer exists. Please retry.</translation>
    </message>
    <message>
      <source>Replace existing file?</source>
      <translation>Replace existing file?</translation>
    </message>
    <message>
      <source>Replace this file with the new audio export?
%1
Current size: %2 bytes</source>
      <translation>Replace this file with the new audio export?
%1
Current size: %2 bytes</translation>
    </message>
    <message>
      <source>Export a track through its EQ to float32 WAV.</source>
      <translation>Export a track through its EQ to float32 WAV.</translation>
    </message>
    <message>
      <source>Export queued…</source>
      <translation>Export queued…</translation>
    </message>
    <message>
      <source>Checking the export destination…</source>
      <translation>Checking the export destination…</translation>
    </message>
    <message>
      <source>Waiting for replacement confirmation.</source>
      <translation>Waiting for replacement confirmation.</translation>
    </message>
    <message>
      <source>Rendering snapshot %1 — %2 frames written</source>
      <translation>Rendering snapshot %1 — %2 frames written</translation>
    </message>
    <message>
      <source>Export complete: %1</source>
      <translation>Export complete: %1</translation>
    </message>
    <message>
      <source>
%1 frames · peak %2 dBFS</source>
      <translation>
%1 frames · peak %2 dBFS</translation>
    </message>
    <message>
      <source>−∞</source>
      <translation>−∞</translation>
    </message>
    <message>
      <source>
Float levels exceed 0 dBFS; they were preserved.</source>
      <translation>
Float levels exceed 0 dBFS; they were preserved.</translation>
    </message>
    <message>
      <source>
The tail reached its time limit.</source>
      <translation>
The tail reached its time limit.</translation>
    </message>
    <message>
      <source>
File flushed; directory durability is not confirmed.</source>
      <translation>
File flushed; directory durability is not confirmed.</translation>
    </message>
    <message>
      <source>
The complete file was published with a warning: %1</source>
      <translation>
The complete file was published with a warning: %1</translation>
    </message>
    <message>
      <source>Export canceled; no new file was published.</source>
      <translation>Export canceled; no new file was published.</translation>
    </message>
    <message>
      <source>Export failed: %1</source>
      <translation>Export failed: %1</translation>
    </message>
    <message>
      <source>Closing export…</source>
      <translation>Closing export…</translation>
    </message>
    <message>
      <source>Export worker closed.</source>
      <translation>Export worker closed.</translation>
    </message>
    <message>
      <source>Canceling export; waiting for the current file operation…</source>
      <translation>Canceling export; waiting for the current file operation…</translation>
    </message>
    <message>
      <source>Stop recording and resolve its retained takes before changing the project structure.</source>
      <translation>Stop recording and resolve its retained takes before changing the project structure.</translation>
    </message>
    <message>
      <source>Too many pending changes. Please retry.</source>
      <translation>Too many pending changes. Please retry.</translation>
    </message>
    <message>
      <source>Closing project…</source>
      <translation>Closing project…</translation>
    </message>
    <message>
      <source>Finish recording, pending take attachment and export before opening another project.</source>
      <translation>Finish recording, pending take attachment and export before opening another project.</translation>
    </message>
    <message>
      <source>Choose a folder for the new project</source>
      <translation>Choose a folder for the new project</translation>
    </message>
    <message>
      <source>New project</source>
      <translation>New project</translation>
    </message>
    <message>
      <source>Project name:</source>
      <translation>Project name:</translation>
    </message>
    <message>
      <source>Untitled</source>
      <translation>Untitled</translation>
    </message>
    <message>
      <source>Choose a project name without folder separators.</source>
      <translation>Choose a project name without folder separators.</translation>
    </message>
    <message>
      <source>Sample rate (Hz). For Windows native audio, match the device mix rate:</source>
      <translation>Sample rate (Hz). For Windows native audio, match the device mix rate:</translation>
    </message>
    <message>
      <source>Project display updated. Retained edits are available.</source>
      <translation>Project display updated. Retained edits are available.</translation>
    </message>
    <message>
      <source>Project display could not be updated: %1. The previous view is retained and editing is paused. Raise Project resources, then retry the display.</source>
      <translation>Project display could not be updated: %1. The previous view is retained and editing is paused. Raise Project resources, then retry the display.</translation>
    </message>
    <message>
      <source>Audio view could not be prepared: %1. Raise Project resources and retry.</source>
      <translation>Audio view could not be prepared: %1. Raise Project resources and retry.</translation>
    </message>
    <message>
      <source>Choose an output for every channel.</source>
      <translation>Choose an output for every channel.</translation>
    </message>
    <message>
      <source>Playback queue is full or closing. Please retry.</source>
      <translation>Playback queue is full or closing. Please retry.</translation>
    </message>
    <message>
      <source>Choose an endpoint…</source>
      <translation>Choose an endpoint…</translation>
    </message>
    <message>
      <source> · %1 Hz</source>
      <translation> · %1 Hz</translation>
    </message>
    <message>
      <source>Missing endpoint</source>
      <translation>Missing endpoint</translation>
    </message>
    <message>
      <source>Ambiguous endpoint; choose explicitly</source>
      <translation>Ambiguous endpoint; choose explicitly</translation>
    </message>
    <message>
      <source>Legacy route; choose explicitly</source>
      <translation>Legacy route; choose explicitly</translation>
    </message>
    <message>
      <source>Unavailable backend: %1</source>
      <translation>Unavailable backend: %1</translation>
    </message>
    <message>
      <source>Master output was not admitted. Please retry.</source>
      <translation>Master output was not admitted. Please retry.</translation>
    </message>
    <message>
      <source>The route change was not accepted. Please retry.</source>
      <translation>The route change was not accepted. Please retry.</translation>
    </message>
    <message>
      <source>Saved routing changes take effect after Stop and preparation.</source>
      <translation>Saved routing changes take effect after Stop and preparation.</translation>
    </message>
    <message>
      <source>Output channel %1</source>
      <translation>Output channel %1</translation>
    </message>
    <message>
      <source>Output %1</source>
      <translation>Output %1</translation>
    </message>
    <message>
      <source>The project changed before take audition was prepared.</source>
      <translation>The project changed before take audition was prepared.</translation>
    </message>
    <message>
      <source>Playback could not be prepared. Please retry.</source>
      <translation>Playback could not be prepared. Please retry.</translation>
    </message>
    <message>
      <source>Playback could not be prepared: %1</source>
      <translation>Playback could not be prepared: %1</translation>
    </message>
    <message>
      <source>Native playback is not available in this build.</source>
      <translation>Native playback is not available in this build.</translation>
    </message>
    <message>
      <source>Prepare the selected track or matching-layout mix, choose outputs, then play.</source>
      <translation>Prepare the selected track or matching-layout mix, choose outputs, then play.</translation>
    </message>
    <message>
      <source>Preparing playback…</source>
      <translation>Preparing playback…</translation>
    </message>
    <message>
      <source>Ready to play.</source>
      <translation>Ready to play.</translation>
    </message>
    <message>
      <source>Playing — EQ changes pending</source>
      <translation>Playing — EQ changes pending</translation>
    </message>
    <message>
      <source>Playing — EQ changes acknowledged</source>
      <translation>Playing — EQ changes acknowledged</translation>
    </message>
    <message>
      <source>Stopping playback…</source>
      <translation>Stopping playback…</translation>
    </message>
    <message>
      <source>Playback complete</source>
      <translation>Playback complete</translation>
    </message>
    <message>
      <source>Playback stopped: %1</source>
      <translation>Playback stopped: %1</translation>
    </message>
    <message>
      <source>Closing playback…</source>
      <translation>Closing playback…</translation>
    </message>
    <message>
      <source>Playback closed</source>
      <translation>Playback closed</translation>
    </message>
    <message>
      <source> · %1 s · %2 missing track-frames</source>
      <translation> · %1 s · %2 missing track-frames</translation>
    </message>
    <message numerus="yes">
      <source> · %n mixed track(s)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> · Saved master output</source>
      <translation> · Saved master output</translation>
    </message>
    <message>
      <source> · Shared output routes: %1</source>
      <translation> · Shared output routes: %1</translation>
    </message>
    <message>
      <source> · Another track is prepared. Stop or prepare the selected track.</source>
      <translation> · Another track is prepared. Stop or prepare the selected track.</translation>
    </message>
    <message>
      <source> · Loop pass %1 · project frame %2</source>
      <translation> · Loop pass %1 · project frame %2</translation>
    </message>
    <message>
      <source>Take audition — arrangement unchanged. </source>
      <translation>Take audition — arrangement unchanged. </translation>
    </message>
    <message>
      <source>Audition — project unchanged. </source>
      <translation>Audition — project unchanged. </translation>
    </message>
    <message>
      <source>Output: %1</source>
      <translation>Output: %1</translation>
    </message>
    <message>
      <source>Playback could not be completed: %1</source>
      <translation>Playback could not be completed: %1</translation>
    </message>
    <message>
      <source>Choose a track with the original take's channel layout.</source>
      <translation>Choose a track with the original take's channel layout.</translation>
    </message>
    <message>
      <source>The native take could not be added. Its original files are retained.</source>
      <translation>The native take could not be added. Its original files are retained.</translation>
    </message>
    <message>
      <source>These loop takes belong to an earlier project. Keep the raw takes for recovery.</source>
      <translation>These loop takes belong to an earlier project. Keep the raw takes for recovery.</translation>
    </message>
    <message>
      <source>Choose a positive first pass and a take name prefix.</source>
      <translation>Choose a positive first pass and a take name prefix.</translation>
    </message>
    <message>
      <source>Take retention queue is full. Please retry.</source>
      <translation>Take retention queue is full. Please retry.</translation>
    </message>
    <message>
      <source>Loop takes could not be retained: %1</source>
      <translation>Loop takes could not be retained: %1</translation>
    </message>
    <message>
      <source>Loop take </source>
      <translation>Loop take </translation>
    </message>
    <message>
      <source>%1 complete passes · %2 samples in the partial final pass</source>
      <translation>%1 complete passes · %2 samples in the partial final pass</translation>
    </message>
    <message>
      <source> · Verifying this page…</source>
      <translation> · Verifying this page…</translation>
    </message>
    <message>
      <source> · Retention failed; raw takes are preserved. Retry this page or finish.</source>
      <translation> · Retention failed; raw takes are preserved. Retry this page or finish.</translation>
    </message>
    <message>
      <source>Choose a positive whole number of loop passes.</source>
      <translation>Choose a positive whole number of loop passes.</translation>
    </message>
    <message>
      <source>Loop recording needs an enabled loop, armed project tracks and punch recording off.</source>
      <translation>Loop recording needs an enabled loop, armed project tracks and punch recording off.</translation>
    </message>
    <message>
      <source>Select at least one track to arm.</source>
      <translation>Select at least one track to arm.</translation>
    </message>
    <message>
      <source>Loop %1 to %2 samples. Playback repeats until Stop.</source>
      <translation>Loop %1 to %2 samples. Playback repeats until Stop.</translation>
    </message>
    <message>
      <source>Loop is off. Saved range: %1 to %2 samples.</source>
      <translation>Loop is off. Saved range: %1 to %2 samples.</translation>
    </message>
    <message>
      <source>Punch recording range</source>
      <translation>Punch recording range</translation>
    </message>
    <message>
      <source>Positions are sample frames at %1 Hz. Input latency is accounted for during preparation.</source>
      <translation>Positions are sample frames at %1 Hz. Input latency is accounted for during preparation.</translation>
    </message>
    <message>
      <source>Enable punch recording</source>
      <translation>Enable punch recording</translation>
    </message>
    <message>
      <source>Punch in (samples)</source>
      <translation>Punch in (samples)</translation>
    </message>
    <message>
      <source>Punch out (samples)</source>
      <translation>Punch out (samples)</translation>
    </message>
    <message>
      <source>The project changed. Close this dialog and reopen its punch settings.</source>
      <translation>The project changed. Close this dialog and reopen its punch settings.</translation>
    </message>
    <message>
      <source>Enter nonnegative whole sample positions, with punch out after punch in when enabled.</source>
      <translation>Enter nonnegative whole sample positions, with punch out after punch in when enabled.</translation>
    </message>
    <message>
      <source>Playback loop range</source>
      <translation>Playback loop range</translation>
    </message>
    <message>
      <source>Positions are sample frames at %1 Hz. The loop end is excluded; Stop ends repeated playback.</source>
      <translation>Positions are sample frames at %1 Hz. The loop end is excluded; Stop ends repeated playback.</translation>
    </message>
    <message>
      <source>Enable loop playback</source>
      <translation>Enable loop playback</translation>
    </message>
    <message>
      <source>Loop start (samples)</source>
      <translation>Loop start (samples)</translation>
    </message>
    <message>
      <source>Loop end (samples)</source>
      <translation>Loop end (samples)</translation>
    </message>
    <message>
      <source>The project changed. Close this dialog and reopen its loop settings.</source>
      <translation>The project changed. Close this dialog and reopen its loop settings.</translation>
    </message>
    <message>
      <source>Enter nonnegative whole sample positions, with loop end after loop start when enabled.</source>
      <translation>Enter nonnegative whole sample positions, with loop end after loop start when enabled.</translation>
    </message>
    <message>
      <source> · captured %1 / written %2</source>
      <translation> · captured %1 / written %2</translation>
    </message>
    <message>
      <source> · failed; recovery available</source>
      <translation> · failed; recovery available</translation>
    </message>
    <message>
      <source>Recording indicators could not be updated: %1. Raise Project resources and retry.</source>
      <translation>Recording indicators could not be updated: %1. Raise Project resources and retry.</translation>
    </message>
    <message>
      <source>Punch in %1 · punch out %2 samples. Prepared playback end: %3.</source>
      <translation>Punch in %1 · punch out %2 samples. Prepared playback end: %3.</translation>
    </message>
    <message>
      <source>not prepared</source>
      <translation>not prepared</translation>
    </message>
    <message>
      <source>Punch is off. Saved range: %1 to %2 samples.</source>
      <translation>Punch is off. Saved range: %1 to %2 samples.</translation>
    </message>
    <message>
      <source>Choose an endpoint for every required channel.</source>
      <translation>Choose an endpoint for every required channel.</translation>
    </message>
    <message>
      <source>Device %1 uses %2; this project uses %3. Choose a matching device or change its sample rate in the system audio settings.</source>
      <translation>Device %1 uses %2; this project uses %3. Choose a matching device or change its sample rate in the system audio settings.</translation>
    </message>
    <message>
      <source>Choose all channels from one device for this stream.</source>
      <translation>Choose all channels from one device for this stream.</translation>
    </message>
    <message>
      <source>Choose each device channel only once for this stream.</source>
      <translation>Choose each device channel only once for this stream.</translation>
    </message>
    <message>
      <source>The selected device format is unavailable. Prepare again and choose a current device.</source>
      <translation>The selected device format is unavailable. Prepare again and choose a current device.</translation>
    </message>
    <message>
      <source>Choose an input and every required monitoring output.</source>
      <translation>Choose an input and every required monitoring output.</translation>
    </message>
    <message>
      <source>Recording queue is full or closing. Please retry.</source>
      <translation>Recording queue is full or closing. Please retry.</translation>
    </message>
    <message>
      <source>Recording route was not admitted. Please retry.</source>
      <translation>Recording route was not admitted. Please retry.</translation>
    </message>
    <message>
      <source>Project mix output %1</source>
      <translation>Project mix output %1</translation>
    </message>
    <message>
      <source>Monitor output %1</source>
      <translation>Monitor output %1</translation>
    </message>
    <message>
      <source>Input %1</source>
      <translation>Input %1</translation>
    </message>
    <message>
      <source>%1 — input %2</source>
      <translation>%1 — input %2</translation>
    </message>
    <message>
      <source>Selected recording track no longer exists.</source>
      <translation>Selected recording track no longer exists.</translation>
    </message>
    <message>
      <source>%1 ms</source>
      <translation>%1 ms</translation>
    </message>
    <message>
      <source>Keep raw takes and finish</source>
      <translation>Keep raw takes and finish</translation>
    </message>
    <message>
      <source>Windows recording monitoring is not available in this preview. Use monitoring off.</source>
      <translation>Windows recording monitoring is not available in this preview. Use monitoring off.</translation>
    </message>
    <message>
      <source>Native recording is not available in this build. Stored takes can still be recovered.</source>
      <translation>Native recording is not available in this build. Stored takes can still be recovered.</translation>
    </message>
    <message>
      <source>Choose monitoring, prepare, select inputs, arm, then record.</source>
      <translation>Choose monitoring, prepare, select inputs, arm, then record.</translation>
    </message>
    <message>
      <source>Preparing recording…</source>
      <translation>Preparing recording…</translation>
    </message>
    <message>
      <source>Ready to record.</source>
      <translation>Ready to record.</translation>
    </message>
    <message>
      <source>Arm the track, then record.</source>
      <translation>Arm the track, then record.</translation>
    </message>
    <message>
      <source>Recording — EQ changes pending</source>
      <translation>Recording — EQ changes pending</translation>
    </message>
    <message>
      <source>Recording — EQ changes acknowledged</source>
      <translation>Recording — EQ changes acknowledged</translation>
    </message>
    <message>
      <source>Recording range complete. Stop to add the take.</source>
      <translation>Recording range complete. Stop to add the take.</translation>
    </message>
    <message>
      <source>Finalizing recorded audio…</source>
      <translation>Finalizing recorded audio…</translation>
    </message>
    <message>
      <source>Verifying recovery checkpoint…</source>
      <translation>Verifying recovery checkpoint…</translation>
    </message>
    <message>
      <source>Recovering a copy of the verified take…</source>
      <translation>Recovering a copy of the verified take…</translation>
    </message>
    <message>
      <source>Recording stopped: %1</source>
      <translation>Recording stopped: %1</translation>
    </message>
    <message>
      <source>Closing recording…</source>
      <translation>Closing recording…</translation>
    </message>
    <message>
      <source>Recording closed</source>
      <translation>Recording closed</translation>
    </message>
    <message>
      <source> · Prepared monitoring: %1. Stop and prepare to use the saved mode.</source>
      <translation> · Prepared monitoring: %1. Stop and prepare to use the saved mode.</translation>
    </message>
    <message>
      <source>Off</source>
      <translation>Off</translation>
    </message>
    <message>
      <source>Auto during recording</source>
      <translation>Auto during recording</translation>
    </message>
    <message>
      <source>Through track EQ</source>
      <translation>Through track EQ</translation>
    </message>
    <message>
      <source>Take could not be added. Retry, or keep it for recovery.</source>
      <translation>Take could not be added. Retry, or keep it for recovery.</translation>
    </message>
    <message>
      <source>Adding verified take to the project…</source>
      <translation>Adding verified take to the project…</translation>
    </message>
    <message>
      <source>Loop recording captured. Review the takes below.</source>
      <translation>Loop recording captured. Review the takes below.</translation>
    </message>
    <message>
      <source> · %1 s · %2 rejected frames</source>
      <translation> · %1 s · %2 rejected frames</translation>
    </message>
    <message>
      <source>
Stored recording: %1</source>
      <translation>
Stored recording: %1</translation>
    </message>
    <message numerus="yes">
      <source> · %n armed track(s)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> · %1 missing playback frames</source>
      <translation> · %1 missing playback frames</translation>
    </message>
    <message>
      <source> · pass %1 · loop position %2 samples</source>
      <translation> · pass %1 · loop position %2 samples</translation>
    </message>
    <message>
      <source>%1: %2</source>
      <translation>%1: %2</translation>
    </message>
    <message>
      <source>Input</source>
      <translation>Input</translation>
    </message>
    <message>
      <source>Project output</source>
      <translation>Project output</translation>
    </message>
    <message>
      <source>Monitor</source>
      <translation>Monitor</translation>
    </message>
    <message>
      <source>Recording error details could not be saved: %1</source>
      <translation>Recording error details could not be saved: %1</translation>
    </message>
    <message>
      <source>Recording could not be completed: %1. Any stored checkpoint remains available for recovery.</source>
      <translation>Recording could not be completed: %1. Any stored checkpoint remains available for recovery.</translation>
    </message>
    <message>
      <source>Recover recording</source>
      <translation>Recover recording</translation>
    </message>
    <message>
      <source>Verified %1 frames (%2 seconds). Recover a new copy into this project? The original recording is preserved.</source>
      <translation>Verified %1 frames (%2 seconds). Recover a new copy into this project? The original recording is preserved.</translation>
    </message>
    <message>
      <source>
This older job has no writer lock; writer activity cannot be confirmed. Only the verified checkpoint will be copied.</source>
      <translation>
This older job has no writer lock; writer activity cannot be confirmed. Only the verified checkpoint will be copied.</translation>
    </message>
    <message>
      <source>Recovery queue is full or closing. Please retry.</source>
      <translation>Recovery queue is full or closing. Please retry.</translation>
    </message>
    <message>
      <source>The audio backend stopped recording.</source>
      <translation>The audio backend stopped recording.</translation>
    </message>
    <message>
      <source>The audio block size was outside the prepared recording capacity.</source>
      <translation>The audio block size was outside the prepared recording capacity.</translation>
    </message>
    <message>
      <source>The input sample rate changed.</source>
      <translation>The input sample rate changed.</translation>
    </message>
    <message>
      <source>The recording input or output buffer was unavailable.</source>
      <translation>The recording input or output buffer was unavailable.</translation>
    </message>
    <message>
      <source>The audio backend reported a processing overrun.</source>
      <translation>The audio backend reported a processing overrun.</translation>
    </message>
    <message>
      <source>The audio backend reported a clock discontinuity.</source>
      <translation>The audio backend reported a clock discontinuity.</translation>
    </message>
    <message>
      <source>The audio clock position exceeded the supported range.</source>
      <translation>The audio clock position exceeded the supported range.</translation>
    </message>
    <message>
      <source>The recording clock changed while the take was running.</source>
      <translation>The recording clock changed while the take was running.</translation>
    </message>
    <message>
      <source>The recording clock position did not follow the previous block.</source>
      <translation>The recording clock position did not follow the previous block.</translation>
    </message>
    <message>
      <source>The recording timing origin could not be established.</source>
      <translation>The recording timing origin could not be established.</translation>
    </message>
    <message>
      <source>The raw recording queue or writer stopped.</source>
      <translation>The raw recording queue or writer stopped.</translation>
    </message>
    <message>
      <source>The prepared audio processor stopped.</source>
      <translation>The prepared audio processor stopped.</translation>
    </message>
    <message>
      <source>Clock %1 at position %2, block %3 frames; engine frame %4.</source>
      <translation>Clock %1 at position %2, block %3 frames; engine frame %4.</translation>
    </message>
    <message>
      <source>Previous clock %1 at position %2, block %3 frames.</source>
      <translation>Previous clock %1 at position %2, block %3 frames.</translation>
    </message>
    <message>
      <source>Looking for stored recordings…</source>
      <translation>Looking for stored recordings…</translation>
    </message>
    <message>
      <source>Recording discovery failed: %1</source>
      <translation>Recording discovery failed: %1</translation>
    </message>
    <message numerus="yes">
      <source>%n recording(s) need review.</source>
      <translation type="unfinished" />
    </message>
    <message numerus="yes">
      <source> %n additional job(s) are listed.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> Saved recording error details are available.</source>
      <translation> Saved recording error details are available.</translation>
    </message>
    <message>
      <source> Discovery limit reached; this list is incomplete.</source>
      <translation> Discovery limit reached; this list is incomplete.</translation>
    </message>
    <message>
      <source> Some recovery metadata needs attention.</source>
      <translation> Some recovery metadata needs attention.</translation>
    </message>
    <message>
      <source>Stored recordings</source>
      <translation>Stored recordings</translation>
    </message>
    <message>
      <source>This list shows checkpoint metadata. Review verifies the audio before offering a recovery copy. Active jobs cannot be reviewed.</source>
      <translation>This list shows checkpoint metadata. Review verifies the audio before offering a recovery copy. Active jobs cannot be reviewed.</translation>
    </message>
    <message>
      <source>Needs audio verification</source>
      <translation>Needs audio verification</translation>
    </message>
    <message>
      <source>Needs verification — writer activity unconfirmed</source>
      <translation>Needs verification — writer activity unconfirmed</translation>
    </message>
    <message>
      <source>Active recording</source>
      <translation>Active recording</translation>
    </message>
    <message>
      <source>No committed audio</source>
      <translation>No committed audio</translation>
    </message>
    <message>
      <source>Different project, track, rate or layout</source>
      <translation>Different project, track, rate or layout</translation>
    </message>
    <message>
      <source>Invalid checkpoint: %1</source>
      <translation>Invalid checkpoint: %1</translation>
    </message>
    <message>
      <source>Matching recovered copy is attached</source>
      <translation>Matching recovered copy is attached</translation>
    </message>
    <message>
      <source> · %1 claimed frames</source>
      <translation> · %1 claimed frames</translation>
    </message>
    <message>
      <source>Stored recording error metadata is invalid: %1</source>
      <translation>Stored recording error metadata is invalid: %1</translation>
    </message>
    <message>
      <source>Saved recording error — %1: %2</source>
      <translation>Saved recording error — %1: %2</translation>
    </message>
    <message>
      <source>Metadata warning: %1</source>
      <translation>Metadata warning: %1</translation>
    </message>
    <message>
      <source>Discovery limit reached. The list is incomplete.</source>
      <translation>Discovery limit reached. The list is incomplete.</translation>
    </message>
    <message>
      <source>Review audio…</source>
      <translation>Review audio…</translation>
    </message>
    <message>
      <source>Band</source>
      <translation>Band</translation>
    </message>
    <message>
      <source>Frequency (Hz)</source>
      <translation>Frequency (Hz)</translation>
    </message>
    <message>
      <source>Gain (dB)</source>
      <translation>Gain (dB)</translation>
    </message>
    <message>
      <source>Gain</source>
      <translation>Gain</translation>
      <extracomment>Audio signal level adjustment in dB, positive or negative. Not financial profit.</extracomment>
    </message>
    <message>
      <source>Q</source>
      <translation>Q</translation>
    </message>
    <message>
      <source>Band %1</source>
      <translation>Band %1</translation>
    </message>
    <message>
      <source>%1 frequency</source>
      <translation>%1 frequency</translation>
    </message>
    <message>
      <source>%1 gain</source>
      <translation>%1 gain</translation>
    </message>
    <message>
      <source>%1 Q</source>
      <translation>%1 Q</translation>
    </message>
    <message>
      <source>%1 gain slider</source>
      <translation>%1 gain slider</translation>
    </message>
    <message>
      <source>The operation could not be completed: %1</source>
      <translation>The operation could not be completed: %1</translation>
    </message>
    <message>
      <source> — unsaved changes</source>
      <translation> — unsaved changes</translation>
    </message>
    <message numerus="yes">
      <source>%1 · %2 Hz · %n audio clip(s)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>This project has no audio tracks.</source>
      <translation>This project has no audio tracks.</translation>
    </message>
    <message>
      <source>Exporting an immutable project snapshot…</source>
      <translation>Exporting an immutable project snapshot…</translation>
    </message>
    <message>
      <source>Verifying recorded take…</source>
      <translation>Verifying recorded take…</translation>
    </message>
    <message>
      <source>Saving project…</source>
      <translation>Saving project…</translation>
    </message>
    <message>
      <source>Opening project…</source>
      <translation>Opening project…</translation>
    </message>
    <message>
      <source>Creating project…</source>
      <translation>Creating project…</translation>
    </message>
    <message>
      <source>Unsaved changes</source>
      <translation>Unsaved changes</translation>
    </message>
    <message>
      <source>Ready</source>
      <translation>Ready</translation>
    </message>
    <message>
      <source>Close project</source>
      <translation>Close project</translation>
    </message>
    <message>
      <source>Save your changes before closing?</source>
      <translation>Save your changes before closing?</translation>
    </message>
  </context>
  <context>
    <name>TimelineEditor</name>
    <message>
      <source>Tracks and timeline</source>
      <translation>Tracks and timeline</translation>
    </message>
    <message>
      <source>Audio tracks</source>
      <translation>Audio tracks</translation>
    </message>
    <message>
      <source>Retry waveforms</source>
      <translation>Retry waveforms</translation>
    </message>
    <message>
      <source>Recheck source files and retry waveform preparation without changing audio or project edits.</source>
      <translation>Recheck source files and retry waveform preparation without changing audio or project edits.</translation>
    </message>
    <message>
      <source>Selected track name</source>
      <translation>Selected track name</translation>
    </message>
    <message>
      <source>Mono</source>
      <translation>Mono</translation>
    </message>
    <message>
      <source>Stereo</source>
      <translation>Stereo</translation>
    </message>
    <message>
      <source>Discrete channels</source>
      <translation>Discrete channels</translation>
    </message>
    <message>
      <source>New track channel count</source>
      <translation>New track channel count</translation>
    </message>
    <message>
      <source>Track name</source>
      <translation>Track name</translation>
    </message>
    <message>
      <source>Add track</source>
      <translation>Add track</translation>
    </message>
    <message>
      <source>Audio %1</source>
      <translation>Audio %1</translation>
    </message>
    <message>
      <source>Rename</source>
      <translation>Rename</translation>
    </message>
    <message>
      <source>Remove track</source>
      <translation>Remove track</translation>
    </message>
    <message>
      <source>Up</source>
      <translation>Up</translation>
    </message>
    <message>
      <source>Down</source>
      <translation>Down</translation>
    </message>
    <message>
      <source>Retained take lanes in selected track</source>
      <translation>Retained take lanes in selected track</translation>
    </message>
    <message>
      <source>Retained take</source>
      <translation>Retained take</translation>
    </message>
    <message>
      <source>Take lane name</source>
      <translation>Take lane name</translation>
    </message>
    <message>
      <source>Comp start frame (inclusive)</source>
      <translation>Comp start frame (inclusive)</translation>
    </message>
    <message>
      <source>Comp end frame (exclusive)</source>
      <translation>Comp end frame (exclusive)</translation>
    </message>
    <message>
      <source>Select matching recorded group across tracks</source>
      <translation>Select matching recorded group across tracks</translation>
    </message>
    <message>
      <source>Comp source</source>
      <translation>Comp source</translation>
    </message>
    <message>
      <source>Use take region</source>
      <translation>Use take region</translation>
    </message>
    <message>
      <source>Prepare take audition</source>
      <translation>Prepare take audition</translation>
    </message>
    <message>
      <source>Take audition could not be prepared. Stop other transport and retry.</source>
      <translation>Take audition could not be prepared. Stop other transport and retry.</translation>
    </message>
    <message>
      <source>Rename take</source>
      <translation>Rename take</translation>
    </message>
    <message>
      <source>Take up</source>
      <translation>Take up</translation>
    </message>
    <message>
      <source>Take down</source>
      <translation>Take down</translation>
    </message>
    <message>
      <source>Remove unused take</source>
      <translation>Remove unused take</translation>
    </message>
    <message>
      <source>Clips in selected track</source>
      <translation>Clips in selected track</translation>
    </message>
    <message>
      <source>Selected clip</source>
      <translation>Selected clip</translation>
    </message>
    <message>
      <source>Timeline start frame</source>
      <translation>Timeline start frame</translation>
    </message>
    <message>
      <source>Source start frame</source>
      <translation>Source start frame</translation>
    </message>
    <message>
      <source>Integer source frame; the exact fractional part is preserved. Use project crop for edits between source frames.</source>
      <translation>Integer source frame; the exact fractional part is preserved. Use project crop for edits between source frames.</translation>
    </message>
    <message>
      <source>Length in project frames</source>
      <translation>Length in project frames</translation>
    </message>
    <message>
      <source>Split at timeline frame</source>
      <translation>Split at timeline frame</translation>
    </message>
    <message>
      <source>Crop offset in project frames</source>
      <translation>Crop offset in project frames</translation>
    </message>
    <message>
      <source>Positive values remove the beginning; negative values reveal earlier source audio. Timeline start and length are project frames.</source>
      <translation>Positive values remove the beginning; negative values reveal earlier source audio. Timeline start and length are project frames.</translation>
    </message>
    <message>
      <source>Exact source position</source>
      <translation>Exact source position</translation>
    </message>
    <message>
      <source>Clip playback speed; pitch follows speed</source>
      <translation>Clip playback speed; pitch follows speed</translation>
    </message>
    <message>
      <source>0.250–4.000 times normal speed. Keeps the clip start and source origin; adjusts duration and fades. Export range stays as set. Undo restores the exact previous clip.</source>
      <translation>0.250–4.000 times normal speed. Keeps the clip start and source origin; adjusts duration and fades. Export range stays as set. Undo restores the exact previous clip.</translation>
    </message>
    <message>
      <source>Apply speed</source>
      <translation>Apply speed</translation>
    </message>
    <message>
      <source>Playback speed (pitch follows)</source>
      <translation>Playback speed (pitch follows)</translation>
    </message>
    <message>
      <source>Apply range</source>
      <translation>Apply range</translation>
    </message>
    <message>
      <source>Apply project crop</source>
      <translation>Apply project crop</translation>
    </message>
    <message>
      <source>Split</source>
      <translation>Split</translation>
    </message>
    <message>
      <source>Duplicate</source>
      <translation>Duplicate</translation>
    </message>
    <message>
      <source>Remove clip</source>
      <translation>Remove clip</translation>
    </message>
    <message>
      <source>Clip destination track</source>
      <translation>Clip destination track</translation>
    </message>
    <message>
      <source>Move to track</source>
      <translation>Move to track</translation>
    </message>
    <message>
      <source>Pitch and stretch…</source>
      <translation>Pitch and stretch…</translation>
    </message>
    <message>
      <source>Clip gain and fades</source>
      <translation>Clip gain and fades</translation>
    </message>
    <message>
      <source>Clip gain in decibels</source>
      <translation>Clip gain in decibels</translation>
    </message>
    <message>
      <source>Mute clip</source>
      <translation>Mute clip</translation>
    </message>
    <message>
      <source>Invert clip polarity</source>
      <translation>Invert clip polarity</translation>
    </message>
    <message>
      <source>Clip gain (dB)</source>
      <translation>Clip gain (dB)</translation>
    </message>
    <message>
      <source>Fade out start frame</source>
      <translation>Fade out start frame</translation>
    </message>
    <message>
      <source>Fade in start frame</source>
      <translation>Fade in start frame</translation>
    </message>
    <message>
      <source>Fade out end frame</source>
      <translation>Fade out end frame</translation>
    </message>
    <message>
      <source>Fade in end frame</source>
      <translation>Fade in end frame</translation>
    </message>
    <message>
      <source>Fade out curve</source>
      <translation>Fade out curve</translation>
    </message>
    <message>
      <source>Fade in curve</source>
      <translation>Fade in curve</translation>
    </message>
    <message>
      <source>Linear</source>
      <translation>Linear</translation>
    </message>
    <message>
      <source>Equal power</source>
      <translation>Equal power</translation>
    </message>
    <message>
      <source>Smoothstep</source>
      <translation>Smoothstep</translation>
    </message>
    <message>
      <source>Fade out shape</source>
      <translation>Fade out shape</translation>
    </message>
    <message>
      <source>Fade in shape</source>
      <translation>Fade in shape</translation>
    </message>
    <message>
      <source>Start</source>
      <translation>Start</translation>
    </message>
    <message>
      <source>End</source>
      <translation>End</translation>
    </message>
    <message>
      <source>Fade out</source>
      <translation>Fade out</translation>
    </message>
    <message>
      <source>Fade in</source>
      <translation>Fade in</translation>
    </message>
    <message>
      <source>Fade windows use clip-relative frames: start is included, end is excluded. Set both to 0 to disable. Signed positions preserve fades after trimming or splitting; raw media stays unchanged.</source>
      <translation>Fade windows use clip-relative frames: start is included, end is excluded. Set both to 0 to disable. Signed positions preserve fades after trimming or splitting; raw media stays unchanged.</translation>
    </message>
    <message>
      <source>Apply clip processing</source>
      <translation>Apply clip processing</translation>
    </message>
    <message>
      <source>Crossfade clips…</source>
      <translation>Crossfade clips…</translation>
    </message>
    <message>
      <source>Recorded media asset</source>
      <translation>Recorded media asset</translation>
    </message>
    <message>
      <source>Insert media clip</source>
      <translation>Insert media clip</translation>
    </message>
    <message>
      <source>Timeline zoom</source>
      <translation>Timeline zoom</translation>
    </message>
    <message>
      <source>Zoom</source>
      <translation>Zoom</translation>
    </message>
    <message>
      <source>Edit failed: %1</source>
      <translation>Edit failed: %1</translation>
    </message>
    <message>
      <source>Crossfade</source>
      <translation>Crossfade</translation>
    </message>
    <message>
      <source>Incoming clip</source>
      <translation>Incoming clip</translation>
    </message>
    <message>
      <source>Equal gain · linear</source>
      <translation>Equal gain · linear</translation>
    </message>
    <message>
      <source>Equal gain · smooth</source>
      <translation>Equal gain · smooth</translation>
    </message>
    <message>
      <source>Start (project frames)</source>
      <translation>Start (project frames)</translation>
    </message>
    <message>
      <source>End (project frames, exclusive)</source>
      <translation>End (project frames, exclusive)</translation>
    </message>
    <message>
      <source>Paired curve</source>
      <translation>Paired curve</translation>
    </message>
    <message>
      <source>Use retained-take handles</source>
      <translation>Use retained-take handles</translation>
    </message>
    <message>
      <source>Create overlap from the retained takes without changing source audio.</source>
      <translation>Create overlap from the retained takes without changing source audio.</translation>
    </message>
    <message>
      <source>Render extended processed handles (preview)</source>
      <translation>Render extended processed handles (preview)</translation>
    </message>
    <message>
      <source>Inner blend limit (project frames)</source>
      <translation>Inner blend limit (project frames)</translation>
    </message>
    <message>
      <source>The clips must overlap. Both fades change in one Undo step; source audio stays unchanged.</source>
      <translation>The clips must overlap. Both fades change in one Undo step; source audio stays unchanged.</translation>
    </message>
    <message>
      <source>Save and render</source>
      <translation>Save and render</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Save the current project and new job references, then render the transition in the background. Review the result before applying it. Original takes are preserved. This renderer is experimental.</source>
      <translation>Save the current project and new job references, then render the transition in the background. Review the result before applying it. Original takes are preserved. This renderer is experimental.</translation>
    </message>
    <message>
      <source>This creates a transition from retained source handles. Both fades change in one Undo step; source audio stays unchanged.</source>
      <translation>This creates a transition from retained source handles. Both fades change in one Undo step; source audio stays unchanged.</translation>
    </message>
    <message>
      <source>Crossfade selection changed; reopen the editor.</source>
      <translation>Crossfade selection changed; reopen the editor.</translation>
    </message>
    <message>
      <source>Transition rendering could not start. Stop playback or recording and retry.</source>
      <translation>Transition rendering could not start. Stop playback or recording and retry.</translation>
    </message>
    <message>
      <source>View could not be updated: %1</source>
      <translation>View could not be updated: %1</translation>
    </message>
    <message>
      <source>%1 + %2/%3 source frames · %4 Hz → %5 Hz project · speed %6/%7</source>
      <translation>%1 + %2/%3 source frames · %4 Hz → %5 Hz project · speed %6/%7</translation>
    </message>
    <message>
      <source>Select a clip to edit its exact frame range. Raw media is preserved.</source>
      <translation>Select a clip to edit its exact frame range. Raw media is preserved.</translation>
    </message>
    <message>
      <source>Stop audio preparation or recording to edit tracks and clips.</source>
      <translation>Stop audio preparation or recording to edit tracks and clips.</translation>
    </message>
    <message>
      <source>Selected clip uses %1. Other retained lanes are silent.</source>
      <translation>Selected clip uses %1. Other retained lanes are silent.</translation>
    </message>
    <message>
      <source>Missing take lane</source>
      <translation>Missing take lane</translation>
    </message>
    <message>
      <source>Retained lanes are silent. Use a fully covered project frame range to replace the active arrangement; Undo restores it. Stop and reprepare playback to hear the comp.</source>
      <translation>Retained lanes are silent. Use a fully covered project frame range to replace the active arrangement; Undo restores it. Stop and reprepare playback to hear the comp.</translation>
    </message>
  </context>
  <context>
    <name>TimelineView</name>
    <message>
      <source>Audio clip timeline</source>
      <translation>Audio clip timeline</translation>
    </message>
    <message>
      <source> s</source>
      <translation> s</translation>
    </message>
    <message>
      <source>Start %1 · source %2 + %3/%4 · length %5 project frames</source>
      <translation>Start %1 · source %2 + %3/%4 · length %5 project frames</translation>
    </message>
  </context>
  <context>
    <name>soundcurrent::daw::ui::TimelineWaveforms</name>
    <message>
      <source>Waveforms unavailable: visible source/resource limit</source>
      <translation>Waveforms unavailable: visible source/resource limit</translation>
    </message>
    <message>
      <source>Some source waveforms are unavailable; use Retry waveforms</source>
      <translation>Some source waveforms are unavailable; use Retry waveforms</translation>
    </message>
    <message>
      <source>Preparing source waveforms…</source>
      <translation>Preparing source waveforms…</translation>
    </message>
    <message>
      <source>Source PCM · shaded edges need finer detail · &gt;2 channels combined</source>
      <translation>Source PCM · shaded edges need finer detail · &gt;2 channels combined</translation>
    </message>
  </context>
</TS>