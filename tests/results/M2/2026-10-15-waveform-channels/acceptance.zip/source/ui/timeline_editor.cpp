// SPDX-License-Identifier: GPL-3.0-only
#include "timeline_editor.hpp"
#include "session_list_model.hpp"
#include "timeline_view.hpp"
#include "accelerating_spinbox.hpp"
#include <soundcurrent/clip_timing.hpp>
#include <QCheckBox>
#include <QComboBox>
#include <QFormLayout>
#include <QLabel>
#include <QLineEdit>
#include <QListView>
#include <QItemSelectionModel>
#include <QLocale>
#include <QPushButton>
#include <QSignalBlocker>
#include <QDialog>
#include <QDialogButtonBox>
#include <QScrollArea>
#include <QScreen>
#include <QResizeEvent>
#include <QSlider>
#include <QSpinBox>
#include <QSplitter>
#include <QTimer>
#include <QVBoxLayout>
#include <QScopedValueRollback>
#include <QWheelEvent>
#include <algorithm>
#include <charconv>
#include <cmath>
#include <limits>
namespace soundcurrent::daw::ui {
namespace {
class WrappedHelpLabel : public QLabel {
 public:
    using QLabel::QLabel;
    void reflow() {
        const auto h=heightForWidth(width());
        if(h>=0 && h!=minimumHeight())setMinimumHeight(h);
    }
 protected:
    void resizeEvent(QResizeEvent *event) override {
        QLabel::resizeEvent(event);reflow();
    }
};
class FocusCombo : public QComboBox {
    void wheelEvent(QWheelEvent *e) override {
        if (hasFocus())
            QComboBox::wheelEvent(e);
        else
            e->ignore();
    }
};
class FocusDoubleSpin : public widgets::AcceleratingDoubleSpinBox {
    void wheelEvent(QWheelEvent *e) override {
        if (hasFocus()) widgets::AcceleratingDoubleSpinBox::wheelEvent(e);
        else e->ignore();
    }
};
void numericField(QDoubleSpinBox *w, double value, bool force) {
    if (force || !w->hasFocus()) {
        w->setValue(value);
        w->setProperty("canonicalValue",value);
        w->setProperty("displayValue",w->value());
    }
}
double numericValue(QDoubleSpinBox *w) {
    return w->property("canonicalValue").isValid() &&
           w->value() == w->property("displayValue").toDouble() ?
        w->property("canonicalValue").toDouble() : w->value();
}
QString text(const std::string &s) {
    return QString::fromUtf8(s);
}
void field(QLineEdit *w, Frame f, bool force) {
    if (force || !w->hasFocus())
        w->setText(QString::number(f));
}
} // namespace
TimelineEditor::TimelineEditor(QWidget *parent, ResourceLedger memory)
    : QGroupBox(tr("Tracks and timeline"), parent) {
    setObjectName("timelineEditor");
    auto *body = new QVBoxLayout(this);
    auto *splitter = new QSplitter(this);
    tracks_ = new QListView;
    trackList_ = new SessionListModel(SessionListModel::Kind::Tracks, this, false, memory);
    tracks_->setModel(trackList_);
    tracks_->setUniformItemSizes(true);
    tracks_->setLayoutMode(QListView::Batched);
    tracks_->setBatchSize(128);
    tracks_->setObjectName("timelineTracks");
    tracks_->setAccessibleName(tr("Audio tracks"));
    tracks_->setMinimumWidth(140);
    view_ = new TimelineView(this, memory);
    splitter->addWidget(tracks_);
    splitter->addWidget(view_);
    splitter->setStretchFactor(1, 1);
    splitter->setSizes({170, 700});
    body->addWidget(splitter);
    auto *waveformRow = new QHBoxLayout;
    auto *retryWaveforms = new QPushButton(tr("Retry waveforms"));
    retryWaveforms->setObjectName("retryTimelineWaveforms");
    retryWaveforms->setToolTip(tr("Recheck source files and retry waveform preparation without changing audio or project edits."));
    waveformRow->addWidget(retryWaveforms);
    auto *waveformMode = new FocusCombo;
    waveformMode->setObjectName("waveformChannelMode");
    waveformMode->setAccessibleName(tr("Waveform display"));
    waveformMode->addItem(tr("Overview"));waveformMode->addItem(tr("Single channel"));
    auto *waveformChannel = new QSpinBox;
    waveformChannel->setObjectName("waveformDisplayChannel");waveformChannel->setRange(1,1024);
    waveformChannel->setKeyboardTracking(false);waveformChannel->setEnabled(false);
    waveformChannel->setAccessibleName(tr("Source channel number"));
    waveformChannel->setToolTip(tr("Source channel number; does not change routing or audio."));
    auto *channelLabel = new QLabel(tr("Channel"));channelLabel->setBuddy(waveformChannel);
    waveformRow->addWidget(waveformMode);waveformRow->addWidget(channelLabel);waveformRow->addWidget(waveformChannel);waveformRow->addStretch();
    const auto showChannel=[this,waveformMode,waveformChannel] {
        const bool single=waveformMode->currentIndex()==1;waveformChannel->setEnabled(single);
        view_->setWaveformChannel(single ? std::optional<std::uint32_t>(std::uint32_t(waveformChannel->value()-1)) : std::nullopt);
    };
    connect(waveformMode,&QComboBox::currentIndexChanged,this,showChannel);
    connect(waveformChannel,&QSpinBox::valueChanged,this,showChannel);
    body->addLayout(waveformRow);
    connect(retryWaveforms, &QPushButton::clicked, view_, &TimelineView::retryWaveforms);
    auto *trackRow = new QHBoxLayout;
    name_ = new QLineEdit;
    name_->setObjectName("selectedTrackName");
    name_->setAccessibleName(tr("Selected track name"));
    layout_ = new FocusCombo;
    layout_->setObjectName("newTrackLayout");
    layout_->addItem(tr("Mono"), 0);
    layout_->addItem(tr("Stereo"), 1);
    layout_->addItem(tr("Discrete channels"), 2);
    channels_ = new QSpinBox;
    channels_->setObjectName("newTrackChannels");
    channels_->setRange(1, 256);
    channels_->setValue(2);
    channels_->setAccessibleName(tr("New track channel count"));
    trackRow->addWidget(new QLabel(tr("Track name")));
    trackRow->addWidget(name_, 1);
    trackRow->addWidget(layout_);
    trackRow->addWidget(channels_);
    auto button = [&](QHBoxLayout *row, const char *caption, const char *object,
                      std::function<void()> action) {
        auto *b = new QPushButton(tr(caption));
        b->setObjectName(object);
        mutations_.push_back(b);
        row->addWidget(b);
        connect(b, &QPushButton::clicked, this, [this, action] { operation(action); });
        return b;
    };
    body->addLayout(trackRow);
    trackRow = new QHBoxLayout;
    button(trackRow, QT_TRANSLATE_NOOP("TimelineEditor", "Add track"), "addAudioTrack", [this] {
        if (!model_)
            return;
        ChannelLayout l;
        if (layout_->currentData().toInt() == 1)
            l = {LayoutKind::Stereo, 2};
        else if (layout_->currentData().toInt() == 2)
            l = {LayoutKind::Discrete, std::uint32_t(channels_->value())};
        auto t = makeAudioTrack(tr("Audio %1")
                                    .arg(QLocale().toString(model_->tracks.size() + 1))
                                    .toUtf8()
                                    .toStdString(),
                                l, model_->sampleRate);
        const auto id = t.id;
        mutate({InsertTrack{std::move(t), {}}});
        pendingTrack_ = id;
    });
    button(trackRow, QT_TRANSLATE_NOOP("TimelineEditor", "Rename"), "renameAudioTrack", [this] {
        if (track_)
            mutate({RenameTrack{*track_, name_->text().toUtf8().toStdString()}});
    });
    button(trackRow, QT_TRANSLATE_NOOP("TimelineEditor", "Remove track"), "removeAudioTrack", [this] {
        if (track_)
            mutate({RemoveTrack{*track_}});
    });
    button(trackRow, QT_TRANSLATE_NOOP("TimelineEditor", "Up"), "moveAudioTrackUp", [this] {
        if (!track())
            return;
        const auto it = std::find_if(model_->tracks.begin(), model_->tracks.end(),
                                     [&](const auto &t) { return t.id == *track_; });
        if (it != model_->tracks.begin())
            mutate({MoveTrack{*track_, (it - 1)->id}});
    });
    button(trackRow, QT_TRANSLATE_NOOP("TimelineEditor", "Down"), "moveAudioTrackDown", [this] {
        if (!track())
            return;
        const auto it = std::find_if(model_->tracks.begin(), model_->tracks.end(),
                                     [&](const auto &t) { return t.id == *track_; });
        if (it + 1 != model_->tracks.end())
            mutate({MoveTrack{*track_, it + 2 == model_->tracks.end()
                                           ? std::optional<Id>{}
                                           : std::optional<Id>((it + 2)->id)}});
    });
    body->addLayout(trackRow);
    auto *takeFields = new QFormLayout;
    takes_ = new FocusCombo;
    takes_->setObjectName("timelineTakes");
    takes_->setAccessibleName(tr("Retained take lanes in selected track"));
    takes_->setSizeAdjustPolicy(QComboBox::AdjustToMinimumContentsLengthWithIcon);
    takes_->setMinimumContentsLength(16);
    takeList_ = new SessionListModel(SessionListModel::Kind::TakeLanes, this, false, memory);
    takes_->setModel(takeList_);
    takeFields->addRow(tr("Retained take"), takes_);
    auto takeField = [&](const char *name, const QString &label) {
        auto *f = new QLineEdit;
        f->setObjectName(name); f->setAccessibleName(label); takeFields->addRow(label, f); return f;
    };
    takeName_ = takeField("takeLaneName", tr("Take lane name"));
    compStart_ = takeField("compStartFrame", tr("Comp start frame (inclusive)"));
    compEnd_ = takeField("compEndFrame", tr("Comp end frame (exclusive)"));
    compGroup_ = new QCheckBox(tr("Select matching recorded group across tracks"));
    compGroup_->setObjectName("compGroup"); takeFields->addRow(compGroup_);
    compSource_ = new QLabel;
    compSource_->setObjectName("compSource"); compSource_->setWordWrap(true);
    compSource_->setTextFormat(Qt::PlainText);
    takeFields->addRow(tr("Comp source"), compSource_);
    body->addLayout(takeFields);
    connect(takes_, &QComboBox::currentIndexChanged, this, [this] {
        if (refreshing_) return;
        take_ = takeList_->idAt(takes_->currentIndex());
        refreshTake(true); refresh(false, false);
    });
    auto *takeActions = new QHBoxLayout;
    button(takeActions, QT_TRANSLATE_NOOP("TimelineEditor", "Use take region"), "selectTakeRegion", [this] {
        const auto *lane = takeLane(); if (!lane || !track_) return;
        const auto begin = frame(compStart_), end = frame(compEnd_);
        std::vector<SessionEdit> edits;
        if (compGroup_->isChecked()) {
            for (const auto &t : model_->tracks) for (const auto &candidate : t.takeLanes)
                if (candidate.groupId == lane->groupId) {
                    if (edits.size() == 64) throw ProjectError(ErrorCode::InvalidState, "Comp group exceeds the current desktop transaction capacity");
                    edits.push_back(SelectTakeRegion{t.id, candidate.id, begin, end});
                }
        } else edits.push_back(SelectTakeRegion{*track_, lane->id, begin, end});
        mutate(std::move(edits));
    });
    button(takeActions, QT_TRANSLATE_NOOP("TimelineEditor", "Prepare take audition"), "auditionTakeLane", [this] {
        if (!takeLane() || !takeAuditionRequested || !takeAuditionRequested(*track_,*take_,epoch_))
            throw ProjectError(ErrorCode::InvalidState,tr("Take audition could not be prepared. Stop other transport and retry.").toUtf8().toStdString());
    });
    button(takeActions, QT_TRANSLATE_NOOP("TimelineEditor", "Rename take"), "renameTakeLane", [this] {
        if (takeLane()) mutate({RenameTakeLane{*track_, *take_, takeName_->text().toUtf8().toStdString()}});
    });
    button(takeActions, QT_TRANSLATE_NOOP("TimelineEditor", "Take up"), "moveTakeLaneUp", [this] {
        if (!takeLane()) return;
        const auto &lanes = track()->takeLanes;
        const auto it = std::find_if(lanes.begin(), lanes.end(), [this](const auto &l) { return l.id == *take_; });
        if (it != lanes.begin()) mutate({MoveTakeLane{*track_, *take_, (it - 1)->id}});
    });
    button(takeActions, QT_TRANSLATE_NOOP("TimelineEditor", "Take down"), "moveTakeLaneDown", [this] {
        if (!takeLane()) return;
        const auto &lanes = track()->takeLanes;
        const auto it = std::find_if(lanes.begin(), lanes.end(), [this](const auto &l) { return l.id == *take_; });
        if (it + 1 != lanes.end()) mutate({MoveTakeLane{*track_, *take_, it + 2 == lanes.end() ? std::optional<Id>{} : std::optional<Id>((it + 2)->id)}});
    });
    button(takeActions, QT_TRANSLATE_NOOP("TimelineEditor", "Remove unused take"), "removeTakeLane", [this] {
        if (takeLane()) mutate({RemoveTakeLane{*track_, *take_}});
    });
    body->addLayout(takeActions);
    auto *ranges = new QFormLayout;
    clips_ = new FocusCombo;
    clipList_ = new SessionListModel(SessionListModel::Kind::Clips, this, false, memory);
    clips_->setModel(clipList_);
    clips_->setSizeAdjustPolicy(QComboBox::AdjustToMinimumContentsLengthWithIcon);
    clips_->setMinimumContentsLength(16);
    clips_->setObjectName("timelineClips");
    clips_->setAccessibleName(tr("Clips in selected track"));
    ranges->addRow(tr("Selected clip"), clips_);
    connect(clips_, &QComboBox::currentIndexChanged, this, [this] {
        if (refreshing_)
            return;
        const auto id = clips_->currentData().toString();
        select(track_,
               id.isEmpty() ? std::optional<Id>{} : std::optional<Id>(Id(id.toStdString())));
        if (track_ && clip_)
            view_->ensureClipVisible(*track_, *clip_);
        if (selectionChanged)
            selectionChanged();
    });
    auto frameField = [&](const char *object, const char *caption) {
        auto *w = new QLineEdit;
        w->setObjectName(object);
        w->setAccessibleName(tr(caption));
        ranges->addRow(tr(caption), w);
        return w;
    };
    start_ = frameField("clipStartFrame", QT_TRANSLATE_NOOP("TimelineEditor", "Timeline start frame"));
    source_ = frameField("clipSourceFrame", QT_TRANSLATE_NOOP("TimelineEditor", "Source start frame"));
    source_->setToolTip(tr("Integer source frame; the exact fractional part is preserved. Use project crop for edits between source frames."));
    length_ = frameField("clipLengthFrames", QT_TRANSLATE_NOOP("TimelineEditor", "Length in project frames"));
    split_ = frameField("clipSplitFrame", QT_TRANSLATE_NOOP("TimelineEditor", "Split at timeline frame"));
    consumed_ = frameField("clipConsumedProjectFrames", QT_TRANSLATE_NOOP("TimelineEditor", "Crop offset in project frames"));
    consumed_->setToolTip(tr("Positive values remove the beginning; negative values reveal earlier source audio. Timeline start and length are project frames."));
    sourceTiming_ = new QLabel;
    sourceTiming_->setObjectName("clipSourceTiming");
    sourceTiming_->setWordWrap(true);
    sourceTiming_->setTextInteractionFlags(Qt::TextSelectableByMouse);
    ranges->addRow(tr("Exact source position"), sourceTiming_);
    clipRate_=new FocusDoubleSpin;
    clipRate_->setObjectName("clipPlaybackRate");
    clipRate_->setRange(.25,4);clipRate_->setDecimals(3);clipRate_->setSingleStep(.01);
    clipRate_->setAccessibleName(tr("Clip playback speed; pitch follows speed"));
    clipRate_->setToolTip(tr("0.250–4.000 times normal speed. Keeps the clip start and source origin; adjusts duration and fades. Export range stays as set. Undo restores the exact previous clip."));
    auto *rateRow=new QHBoxLayout;rateRow->addWidget(clipRate_);
    button(rateRow,QT_TRANSLATE_NOOP("TimelineEditor", "Apply speed"),"applyClipPlaybackRate",[this] {
        if(clip_ && track_) {
            // Preserve an unchanged exact ratio even if its three-decimal
            // display rounds. Mark admitted input for coalesced Apply/Undo:
            // the GUI may never receive the intermediate stored rate.
            const auto rate=clipRate_->value()==clipRate_->property("displayValue").toDouble()
                ? displayedRate_ : ClipPlaybackRate{std::uint32_t(std::llround(clipRate_->value()*1000)),1000};
            mutate({SetClipPlaybackRate{*track_,*clip_,rate}});
            displayedRate_=rate;
            numericField(clipRate_,double(rate.numerator)/rate.denominator,true);
        }
    });
    ranges->addRow(tr("Playback speed (pitch follows)"),rateRow);
    body->addLayout(ranges);
    auto *clipRow = new QHBoxLayout;
    button(clipRow, QT_TRANSLATE_NOOP("TimelineEditor", "Apply range"), "applyClipRange", [this] {
        if (clip_ && track_)
            mutate({SetClipRange{*track_, *clip_, frame(start_), frame(source_), frame(length_)}});
    });
    button(clipRow, QT_TRANSLATE_NOOP("TimelineEditor", "Apply project crop"), "cropAudioClip", [this] {
        if (clip_ && track_)
            mutate({CropClip{*track_, *clip_, frame(start_), frame(consumed_,true), frame(length_)}});
    });
    button(clipRow, QT_TRANSLATE_NOOP("TimelineEditor", "Split"), "splitAudioClip", [this] {
        if (clip_ && track_)
            mutate({SplitClip{*track_, *clip_, Id::generate(), frame(split_)}});
    });
    button(clipRow, QT_TRANSLATE_NOOP("TimelineEditor", "Duplicate"), "duplicateAudioClip", [this] {
        if (const auto *c = clip()) {
            if (c->startFrame > std::numeric_limits<Frame>::max() - c->lengthFrames)
                throw ProjectError(ErrorCode::InvalidState, "Clip position overflow");
            auto copy = *c;
            copy.id = Id::generate();
            copy.startFrame += copy.lengthFrames;
            mutate({InsertClip{*track_, std::move(copy), {}}});
        }
    });
    button(clipRow, QT_TRANSLATE_NOOP("TimelineEditor", "Remove clip"), "removeAudioClip", [this] {
        if (clip_ && track_)
            mutate({RemoveClip{*track_, *clip_}});
    });
    destination_ = new FocusCombo;
    destinations_ = new SessionListModel(SessionListModel::Kind::Tracks, this, false, memory);
    destination_->setModel(destinations_);
    destination_->setSizeAdjustPolicy(QComboBox::AdjustToMinimumContentsLengthWithIcon);
    destination_->setMinimumContentsLength(16);
    destination_->setObjectName("clipDestinationTrack");
    destination_->setAccessibleName(tr("Clip destination track"));
    clipRow->addWidget(destination_, 1);
    button(clipRow, QT_TRANSLATE_NOOP("TimelineEditor", "Move to track"), "moveClipToTrack", [this] {
        if (clip_ && track_ && destination_->currentIndex() >= 0)
            mutate({MoveClip{*track_,
                             Id(destination_->currentData().toString().toStdString()),
                             *clip_,
                             frame(start_),
                             {}}});
    });
    body->addLayout(clipRow);
    auto *stretchButton = new QPushButton(tr("Pitch and stretch…"));
    stretchButton->setObjectName("clipStretchButton");
    mutations_.push_back(stretchButton);
    body->addWidget(stretchButton);
    connect(stretchButton,&QPushButton::clicked,this,[this]{
        if(editable_ && track_ && clip_ && pitchStretchRequested)pitchStretchRequested(*track_,*clip_);
    });
    auto *processingToggle = new QPushButton(tr("Clip gain and fades"));
    processingToggle->setObjectName("clipProcessingToggle");
    processingToggle->setCheckable(true);
    body->addWidget(processingToggle);
    auto *processingBody = new QWidget;
    processingBody->setObjectName("clipProcessingFields");
    auto *processingForm = new QFormLayout(processingBody);
    clipGain_ = new FocusDoubleSpin;
    clipGain_->setObjectName("clipGainDb");
    clipGain_->setRange(-120,60);clipGain_->setDecimals(6);clipGain_->setSingleStep(.1);
    clipGain_->setAccessibleName(tr("Clip gain in decibels"));
    auto *gainRow = new QHBoxLayout;
    gainRow->addWidget(clipGain_);
    clipMuted_ = new QCheckBox(tr("Mute clip"));clipMuted_->setObjectName("clipMuted");
    clipInverted_ = new QCheckBox(tr("Invert clip polarity"));clipInverted_->setObjectName("clipPolarityInverted");
    gainRow->addWidget(clipMuted_);gainRow->addWidget(clipInverted_);
    processingForm->addRow(tr("Clip gain (dB)"),gainRow);
    const auto fadeFields = [&](bool out) {
        auto *row = new QHBoxLayout;
        auto *start = new QLineEdit;auto *end = new QLineEdit;
        start->setObjectName(out ? "clipFadeOutStart" : "clipFadeInStart");
        end->setObjectName(out ? "clipFadeOutEnd" : "clipFadeInEnd");
        start->setAccessibleName(out ? tr("Fade out start frame") : tr("Fade in start frame"));
        end->setAccessibleName(out ? tr("Fade out end frame") : tr("Fade in end frame"));
        start->setLayoutDirection(Qt::LeftToRight);end->setLayoutDirection(Qt::LeftToRight);
        auto *curve = new FocusCombo;curve->setObjectName(out ? "clipFadeOutCurve" : "clipFadeInCurve");
        curve->setAccessibleName(out ? tr("Fade out curve") : tr("Fade in curve"));
        curve->addItem(tr("Linear"),int(ClipFadeCurve::Linear));
        curve->addItem(tr("Equal power"),int(ClipFadeCurve::EqualPower));
        curve->addItem(tr("Smoothstep"),int(ClipFadeCurve::Smoothstep));
        auto *shape = new FocusDoubleSpin;shape->setObjectName(out ? "clipFadeOutShape" : "clipFadeInShape");
        shape->setRange(.25,4);shape->setDecimals(6);shape->setSingleStep(.05);
        shape->setAccessibleName(out ? tr("Fade out shape") : tr("Fade in shape"));
        row->addWidget(new QLabel(tr("Start")));row->addWidget(start);
        row->addWidget(new QLabel(tr("End")));row->addWidget(end);
        row->addWidget(curve);row->addWidget(shape);
        processingForm->addRow(out ? tr("Fade out") : tr("Fade in"),row);
        if (out) {fadeOutStart_=start;fadeOutEnd_=end;fadeOutCurve_=curve;fadeOutShape_=shape;}
        else {fadeInStart_=start;fadeInEnd_=end;fadeInCurve_=curve;fadeInShape_=shape;}
    };
    fadeFields(false);fadeFields(true);
    auto *explanation = new QLabel(tr("Fade windows use clip-relative frames: start is included, end is excluded. Set both to 0 to disable. Signed positions preserve fades after trimming or splitting; raw media stays unchanged."));
    explanation->setWordWrap(true);explanation->setTextFormat(Qt::PlainText);
    processingForm->addRow(explanation);
    auto *applyProcessing = new QHBoxLayout;
    button(applyProcessing,QT_TRANSLATE_NOOP("TimelineEditor", "Apply clip processing"),"applyClipProcessing",[this] {
        if (!clip_ || !track_) return;
        ClipProcessing p;
        p.gainDb=numericValue(clipGain_);p.muted=clipMuted_->isChecked();p.polarityInverted=clipInverted_->isChecked();
        p.fadeIn={frame(fadeInStart_,true),frame(fadeInEnd_,true),ClipFadeCurve(fadeInCurve_->currentData().toInt()),numericValue(fadeInShape_)};
        p.fadeOut={frame(fadeOutStart_,true),frame(fadeOutEnd_,true),ClipFadeCurve(fadeOutCurve_->currentData().toInt()),numericValue(fadeOutShape_)};
        mutate({SetClipProcessing{*track_,*clip_,p}});
    });
    processingForm->addRow(applyProcessing);
    auto *crossfadeRow = new QHBoxLayout;
    button(crossfadeRow, QT_TRANSLATE_NOOP("TimelineEditor", "Crossfade clips…"), "crossfadeClips", [this] {
        editCrossfade();
    });
    processingForm->addRow(crossfadeRow);
    body->addWidget(processingBody);processingBody->hide();
    connect(processingToggle,&QPushButton::toggled,processingBody,&QWidget::setVisible);
    auto *assetRow = new QHBoxLayout;
    asset_ = new FocusCombo;
    assets_ = new SessionListModel(SessionListModel::Kind::Assets, this, false, memory);
    asset_->setModel(assets_);
    asset_->setSizeAdjustPolicy(QComboBox::AdjustToMinimumContentsLengthWithIcon);
    asset_->setMinimumContentsLength(16);
    asset_->setObjectName("timelineAsset");
    asset_->setAccessibleName(tr("Recorded media asset"));
    assetRow->addWidget(asset_, 1);
    button(assetRow, QT_TRANSLATE_NOOP("TimelineEditor", "Insert media clip"), "insertMediaClip", [this] {
        if (!track_ || !model_ || asset_->currentIndex() < 0)
            return;
        const auto id = Id(asset_->currentData().toString().toStdString());
        const auto it = std::find_if(model_->assets.begin(), model_->assets.end(),
                                     [&](const auto &a) { return a.id == id; });
        if (it == model_->assets.end())
            return;
        Clip c;
        c.assetId = id;
        c.startFrame = model_->playheadFrame;
        c.lengthFrames = SourceFrameMap(it->sampleRate,model_->sampleRate).projectFramesForSource(it->frames);
        mutate({InsertClip{*track_, std::move(c), {}}});
    });
    zoom_ = new QSlider(Qt::Horizontal);
    zoom_->setObjectName("timelineZoom");
    zoom_->setRange(0, 100);
    zoom_->setValue(50);
    zoom_->setAccessibleName(tr("Timeline zoom"));
    assetRow->addWidget(new QLabel(tr("Zoom")));
    assetRow->addWidget(zoom_);
    body->addLayout(assetRow);
    status_ = new QLabel;
    status_->setObjectName("timelineStatus");
    status_->setWordWrap(true);
    status_->setTextFormat(Qt::PlainText);
    body->addWidget(status_);
    connect(zoom_, &QSlider::valueChanged, this, [this] { draw(); });
    connect(tracks_->selectionModel(), &QItemSelectionModel::currentChanged, this,
            [this](const QModelIndex &index, const QModelIndex &) {
                if (refreshing_)
                    return;
                const auto id = trackList_->idAt(index.row());
                if (id)
                    QTimer::singleShot(0, this, [this, id] { selectTrack(*id); });
            });
    view_->selection = [this](std::optional<Id> track, std::optional<Id> clip) {
        if (refreshing_)
            return;
        select(track ? track : track_, clip);
    };
    refresh(true);
}
TimelineEditor::~TimelineEditor() {
    // Child controls can emit selection changes during QWidget child teardown,
    // after this class's members have been destroyed.
    for (auto *sender : findChildren<QObject *>())
        QObject::disconnect(sender, nullptr, this, nullptr);
}
const Track *TimelineEditor::track() const {
    if (!model_ || !track_)
        return nullptr;
    const auto it = std::find_if(model_->tracks.begin(), model_->tracks.end(),
                                 [&](const auto &t) { return t.id == *track_; });
    return it == model_->tracks.end() ? nullptr : &*it;
}
const Clip *TimelineEditor::clip() const {
    const auto *t = track();
    if (!t || !clip_)
        return nullptr;
    const auto it = std::find_if(t->clips.begin(), t->clips.end(),
                                 [&](const auto &c) { return c.id == *clip_; });
    return it == t->clips.end() ? nullptr : &*it;
}
Frame TimelineEditor::frame(QLineEdit *w, bool allowSigned) const {
    const auto bytes = w->text().toLatin1();
    Frame n = 0;
    const auto [end, error] =
        std::from_chars(bytes.constData(), bytes.constData() + bytes.size(), n);
    if (error != std::errc{} || end != bytes.constData() + bytes.size() || (!allowSigned && n < 0))
        throw ProjectError(ErrorCode::InvalidParameter,
                           allowSigned ? "Frame must be a signed decimal integer" :
                                         "Frame must be a nonnegative decimal integer");
    return n;
}
void TimelineEditor::operation(const std::function<void()> &f) {
    if (!editable_)
        return;
    try {
        f();
    } catch (const std::exception &e) {
        status_->setText(tr("Edit failed: %1").arg(text(e.what())));
    }
}
void TimelineEditor::mutate(std::vector<SessionEdit> edits) {
    if (!submit || !submit(std::move(edits)))
        throw ProjectError(ErrorCode::InvalidState, "Edit was not admitted; please retry");
}
struct TimelineEditor::Prepared {
    std::shared_ptr<const Session> model;
    std::filesystem::path root;
    std::uint64_t epoch = 0;
    bool editable = false, force = false;
    std::optional<Id> track, clip, pending;
    std::shared_ptr<SessionListModel::Prepared> tracks, clips, destinations, assets, takes;
    std::shared_ptr<TimelineView::Prepared> view;
};
std::shared_ptr<TimelineEditor::Prepared>
TimelineEditor::prepare(std::shared_ptr<const Session> s, std::uint64_t epoch, bool editable,
                        std::optional<Id> selected, std::optional<Id> clip, bool specific, std::filesystem::path root) const {
    auto p = std::make_shared<Prepared>();
    p->model = std::move(s);
    p->root = std::move(root);
    p->epoch = epoch;
    p->editable = editable;
    p->force = epoch != epoch_;
    p->track = specific ? selected : p->force ? std::optional<Id>{} : track_;
    p->clip = specific ? clip : p->force ? std::optional<Id>{} : clip_;
    p->pending = p->force || specific ? std::optional<Id>{} : pendingTrack_;
    const Track *t = nullptr;
    if (p->model) {
        if (p->pending)
            for (const auto &candidate : p->model->tracks)
                if (candidate.id == *p->pending) {
                    p->track = candidate.id;
                    p->clip.reset();
                    p->pending.reset();
                    break;
                }
        if (p->track)
            for (const auto &candidate : p->model->tracks)
                if (candidate.id == *p->track)
                    t = &candidate;
        if (!t && !p->model->tracks.empty()) {
            t = &p->model->tracks.front();
            p->track = t->id;
            p->clip.reset();
        }
    }
    if (!t) {
        p->track.reset();
        p->clip.reset();
    }
    if (t && p->clip && std::none_of(t->clips.begin(), t->clips.end(), [&](const auto &c) {
            return c.id == *p->clip;
        }))
        p->clip.reset();
    p->tracks = trackList_->prepare(p->model);
    p->clips = clipList_->prepare(p->model, {}, p->track);
    p->takes = takeList_->prepare(p->model, {}, p->track);
    p->destinations = destinations_->prepare(
        t ? p->model : nullptr, t ? std::optional<ChannelLayout>(t->layout) : std::nullopt);
    p->assets = assets_->prepare(t ? p->model : nullptr,
                                 t ? std::optional<ChannelLayout>(t->layout) : std::nullopt);
    p->view = view_->prepare(p->model, epoch, p->root);
    return p;
}
std::shared_ptr<TimelineEditor::Prepared>
TimelineEditor::prepareModel(std::shared_ptr<const Session> s, std::uint64_t epoch,
                             bool editable, std::filesystem::path root) const {
    return prepare(std::move(s), epoch, editable, {}, {}, false, std::move(root));
}
std::optional<Id> TimelineEditor::preparedTrack(const std::shared_ptr<Prepared> &p) const {
    return p ? p->track : track_;
}
void TimelineEditor::commitModel(std::shared_ptr<Prepared> p) {
    if (!p)
        return;
    const auto previous = track_;
    const bool replacement = epoch_ != p->epoch;
    const auto *previousClip = clip();
    const auto previousProcessing = previousClip ? previousClip->processing : ClipProcessing{};
    const auto previousRate = previousClip ? previousClip->playbackRate : ClipPlaybackRate{};
    const auto previousDestination = destination_->currentData().toString();
    const auto previousAsset = asset_->currentData().toString();
    const bool changed = model_ != p->model || epoch_ != p->epoch || track_ != p->track ||
                         clip_ != p->clip || editable_ != p->editable;
    {
        QScopedValueRollback<bool> guard(refreshing_, true);
        QSignalBlocker a(tracks_), b(clips_), c(destination_), d(asset_), e(takes_);
        trackList_->commit(std::move(p->tracks));
        clipList_->commit(std::move(p->clips));
        takeList_->commit(std::move(p->takes));
        destinations_->commit(std::move(p->destinations));
        assets_->commit(std::move(p->assets));
        view_->commit(std::move(p->view));
        model_ = std::move(p->model);
        root_ = std::move(p->root);
        epoch_ = p->epoch;
        editable_ = p->editable;
        track_ = std::move(p->track);
        clip_ = std::move(p->clip);
        pendingTrack_ = std::move(p->pending);
        if (previous != track_ || replacement) take_.reset();
        if (take_ && (!track() || std::none_of(track()->takeLanes.begin(), track()->takeLanes.end(), [this](const auto &l) { return l.id == *take_; }))) take_.reset();
    }
    if (changed) {
        const auto *currentClip = clip();
        const auto currentProcessing = currentClip ? currentClip->processing : ClipProcessing{};
        const auto currentRate = currentClip ? currentClip->playbackRate : ClipPlaybackRate{};
        // Stored changes (including Undo/Redo) must update these controls even
        // while focused. Unrelated state publication preserves in-progress input.
        refresh(p->force, true, previousDestination, previousAsset,
                previousProcessing != currentProcessing, previousRate != currentRate);
    }
    if (previous != track_ && selectionChanged)
        selectionChanged();
}
void TimelineEditor::updateModel(std::shared_ptr<const Session> s, std::uint64_t epoch,
                                 bool editable, std::filesystem::path root) {
    commitModel(prepareModel(std::move(s), epoch, editable, std::move(root)));
}
void TimelineEditor::editCrossfade() {
    if (!editable_ || !track_ || !clip_) return;
    const auto selectedTrack = *track_, outgoing = *clip_;
    const auto epoch = epoch_;
    QDialog dialog(this);
    dialog.setObjectName("crossfadeDialog");
    dialog.setWindowTitle(tr("Crossfade"));
    auto *outer = new QVBoxLayout(&dialog);
    auto *scroll = new QScrollArea(&dialog);scroll->setWidgetResizable(true);
    scroll->setObjectName("crossfadeScroll");
    auto *body = new QWidget;auto *form = new QFormLayout(body);
    form->setRowWrapPolicy(QFormLayout::WrapLongRows);
    scroll->setWidget(body);outer->addWidget(scroll);
    auto *peer = new FocusCombo;
    peer->setObjectName("crossfadeIncoming");
    peer->setAccessibleName(tr("Incoming clip"));
    peer->setModel(clipList_); // Borrow the already admitted virtual projection.
    peer->setSizeAdjustPolicy(QComboBox::AdjustToMinimumContentsLengthWithIcon);
    peer->setMinimumContentsLength(16);
    auto *start = new QLineEdit, *end = new QLineEdit;
    start->setObjectName("crossfadeStart");end->setObjectName("crossfadeEnd");
    auto *curve = new FocusCombo;
    curve->setObjectName("crossfadeCurve");
    curve->addItem(tr("Equal gain · linear"), int(ClipFadeCurve::Linear));
    curve->addItem(tr("Equal gain · smooth"), int(ClipFadeCurve::Smoothstep));
    curve->addItem(tr("Equal power"), int(ClipFadeCurve::EqualPower));
    form->addRow(tr("Incoming clip"), peer);
    form->addRow(tr("Start (project frames)"), start);
    form->addRow(tr("End (project frames, exclusive)"), end);
    form->addRow(tr("Paired curve"), curve);
    auto *handles = new QCheckBox;
    handles->setAccessibleName(tr("Use retained-take handles"));
    handles->setObjectName("crossfadeUseTakeHandles");
    handles->setToolTip(tr("Create overlap from the retained takes without changing source audio."));
    form->addRow(tr("Use retained-take handles"),handles);
    auto *render=new QCheckBox;
    render->setAccessibleName(tr("Render extended processed handles (preview)"));
    render->setObjectName("crossfadeRenderHandles");
    form->addRow(tr("Render extended processed handles (preview)"),render);
    auto *blend=new QSpinBox;blend->setRange(1,1000000);blend->setValue(8);blend->setObjectName("crossfadeInnerBlend");
    form->addRow(tr("Inner blend limit (project frames)"),blend);
    auto *help = new WrappedHelpLabel(tr("The clips must overlap. Both fades change in one Undo step; source audio stays unchanged."));
    help->setObjectName("crossfadeHelp");help->setWordWrap(true);form->addRow(help);
    // Native fonts and translated captions must not force the scroll body wider
    // than the viewport. Wrap form labels as well as the full-width explanation.
    for(int row=0;row<form->rowCount();++row) {
        const auto *item=form->itemAt(row,QFormLayout::LabelRole);
        if(auto *label=item?qobject_cast<QLabel *>(item->widget()):nullptr) {
            label->setWordWrap(true);
            label->setSizePolicy(QSizePolicy::Preferred,QSizePolicy::Preferred);
        }
    }
    help->setSizePolicy(QSizePolicy::Ignored,QSizePolicy::Preferred);
    auto *buttons = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel);
    outer->addWidget(buttons);
    const auto updateRange = [&] {
        const auto *out = clip();
        const auto id = clipList_->idAt(peer->currentIndex());
        const Clip *in = nullptr;
        if (const auto *t = track(); t && id)
            for (const auto &candidate : t->clips) if (candidate.id == *id) in = &candidate;
        const bool selected = out && out->id == outgoing && in && in->id != outgoing;
        auto first = selected ? std::max(out->startFrame, in->startFrame) : Frame(0);
        auto last = selected ? std::min(out->startFrame + out->lengthFrames,
                                       in->startFrame + in->lengthFrames) : Frame(0);
        const bool retainedPair = selected && out->takeOrigin && in->takeOrigin &&
            out->startFrame <= in->startFrame && out->startFrame+out->lengthFrames <= in->startFrame+in->lengthFrames &&
            in->startFrame <= out->startFrame+out->lengthFrames;
        handles->setEnabled(retainedPair);
        render->setEnabled(retainedPair && handles->isChecked() && bool(compRenderRequested));
        if(!render->isEnabled()){QSignalBlocker blocker(render);render->setChecked(false);}
        blend->setEnabled(render->isChecked());
        buttons->button(QDialogButtonBox::Ok)->setText(render->isChecked()?tr("Save and render"):tr("OK"));
        if (!retainedPair) {QSignalBlocker blocker(handles);handles->setChecked(false);}
        if (retainedPair && handles->isChecked() && last <= first) {
            const auto cut=in->startFrame;
            const auto half=std::max<Frame>(1,Frame(model_->sampleRate)/400);
            first=cut-std::min(half,cut-out->startFrame);
            last=cut+std::min(half,in->startFrame+in->lengthFrames-cut);
        }
        help->setText(render->isChecked()?tr("Save the current project and new job references, then render the transition in the background. Review the result before applying it. Original takes are preserved. This renderer is experimental."):handles->isChecked()
            ? tr("This creates a transition from retained source handles. Both fades change in one Undo step; source audio stays unchanged.")
            : tr("The clips must overlap. Both fades change in one Undo step; source audio stays unchanged."));
        help->reflow();
        buttons->button(QDialogButtonBox::Ok)->setEnabled(selected && last > first);
        if (!selected || last <= first) { start->clear();end->clear();return; }
        Frame begin = first, finish = last;
        const auto &a = out->processing.fadeOut, &b = in->processing.fadeIn;
        // Infer a saved pair only from visible, representable common anchors.
        if (a.startFrame >= 0 && a.endFrame > a.startFrame && a.endFrame <= out->lengthFrames &&
            b.startFrame >= 0 && b.endFrame > b.startFrame && b.endFrame <= in->lengthFrames &&
            a.shape == 1 && b.shape == 1 && a.curve == b.curve &&
            out->startFrame + a.startFrame == in->startFrame + b.startFrame &&
            out->startFrame + a.endFrame == in->startFrame + b.endFrame) {
            begin = out->startFrame + a.startFrame;finish = out->startFrame + a.endFrame;
            curve->setCurrentIndex(curve->findData(int(a.curve)));
        }
        field(start, begin, true);field(end, finish, true);
    };
    connect(peer, &QComboBox::currentIndexChanged, &dialog, updateRange);
    connect(handles, &QCheckBox::toggled, &dialog, updateRange);
    connect(render, &QCheckBox::toggled, &dialog, updateRange);
    connect(buttons, &QDialogButtonBox::accepted, &dialog, &QDialog::accept);
    connect(buttons, &QDialogButtonBox::rejected, &dialog, &QDialog::reject);
    peer->setCurrentIndex(0);updateRange();
    const auto area=dialog.screen()->availableGeometry();
    dialog.resize(std::min(560,std::max(1,area.width()-32)),std::min(420,std::max(1,area.height()-32)));
    if (dialog.exec() != QDialog::Accepted) return;
    if (!editable_ || epoch_ != epoch || track_ != std::optional<Id>(selectedTrack) ||
        clip_ != std::optional<Id>(outgoing))
        throw ProjectError(ErrorCode::InvalidState, tr("Crossfade selection changed; reopen the editor.").toUtf8().toStdString());
    const auto incoming = clipList_->idAt(peer->currentIndex());
    if (!incoming) return;
    if(render->isChecked()){
        if(!compRenderRequested || !compRenderRequested({selectedTrack,outgoing,*incoming,frame(start),frame(end),
            ClipFadeCurve(curve->currentData().toInt())},blend->value(),epoch))
            throw ProjectError(ErrorCode::InvalidState,tr("Transition rendering could not start. Stop playback or recording and retry.").toUtf8().toStdString());
    }else if (handles->isChecked())
        mutate({PrepareCompTransition{selectedTrack,outgoing,*incoming,frame(start),frame(end),
                                      ClipFadeCurve(curve->currentData().toInt())}});
    else
        mutate({SetClipCrossfade{selectedTrack, outgoing, *incoming, frame(start), frame(end),
                                ClipFadeCurve(curve->currentData().toInt())}});
}
void TimelineEditor::editing(bool editable) {
    if (editable_ != editable) {
        editable_ = editable;
        refresh(false, false);
    }
}
std::size_t TimelineEditor::resourceBytes() const {
    return trackList_->resourceBytes() + destinations_->resourceBytes() + assets_->resourceBytes() +
           clipList_->resourceBytes() + takeList_->resourceBytes() + view_->resourceBytes();
}
bool TimelineEditor::select(std::optional<Id> id, std::optional<Id> clip) {
    if (!model_ || !id ||
        std::none_of(model_->tracks.begin(), model_->tracks.end(),
                     [&](const auto &t) { return t.id == *id; }))
        return false;
    if (track_ == id && clip_ == clip)
        return true;
    if (auto *focused = window()->focusWidget())
        focused->clearFocus();
    try {
        auto p = prepare(model_, epoch_, editable_, id, clip, true, root_);
        if (selectionAdmission && !selectionAdmission(model_, p->track)) {
            refresh(false, false);
            return false;
        }
        p->force = true;
        commitModel(std::move(p));
        view_->ensureTrackVisible(*id);
        return true;
    } catch (const std::exception &e) {
        refresh(false, false);
        status_->setText(tr("View could not be updated: %1").arg(text(e.what())));
        return false;
    }
}
bool TimelineEditor::selectTrack(const Id &id) {
    return select(id, track_ == std::optional<Id>(id) ? clip_ : std::optional<Id>{});
}
void TimelineEditor::refresh(bool force, bool redraw, std::optional<QString> destination,
                             std::optional<QString> asset, bool forceProcessing, bool forceRate) {
    QScopedValueRollback<bool> guard(refreshing_, true);
    QSignalBlocker block(tracks_);
    refreshTake(force);
    const auto previousDestination = destination.value_or(destination_->currentData().toString());
    const auto previousAsset = asset.value_or(asset_->currentData().toString());
    const auto *t = track();
    const auto *c = clip();
    trackList_->update(model_);
    if (t)
        tracks_->setCurrentIndex(trackList_->index(trackList_->rowForId(t->id)));
    else
        tracks_->setCurrentIndex({});
    {
        QSignalBlocker blocked(clips_);
        clipList_->update(model_, {}, track_);
        clips_->setCurrentIndex(c ? clipList_->rowForId(c->id) : 0);
    }
    {
        QSignalBlocker blocked(destination_);
        destinations_->update(t ? model_ : nullptr,
                              t ? std::optional<ChannelLayout>(t->layout) : std::nullopt);
        const auto id = previousDestination;
        const auto row = id.isEmpty() ? -1 : destinations_->rowForId(Id(id.toStdString()));
        destination_->setCurrentIndex(row >= 0 ? row : (destinations_->rowCount() ? 0 : -1));
    }
    {
        QSignalBlocker blocked(asset_);
        assets_->update(t ? model_ : nullptr,
                        t ? std::optional<ChannelLayout>(t->layout) : std::nullopt);
        const auto id = previousAsset;
        const auto row = id.isEmpty() ? -1 : assets_->rowForId(Id(id.toStdString()));
        asset_->setCurrentIndex(row >= 0 ? row : (assets_->rowCount() ? 0 : -1));
    }
    if (force || !name_->hasFocus())
        name_->setText(t ? text(t->name) : QString());
    name_->setEnabled(editable_ && t);
    for (auto *w : {fadeInStart_,fadeInEnd_,fadeOutStart_,fadeOutEnd_}) w->setEnabled(editable_ && c);
    for (auto *w : {clipGain_,fadeInShape_,fadeOutShape_,clipRate_}) w->setEnabled(editable_ && c);
    for (auto *w : {clipMuted_,clipInverted_}) w->setEnabled(editable_ && c);
    for (auto *w : {fadeInCurve_,fadeOutCurve_}) w->setEnabled(editable_ && c);
    const auto p = c ? c->processing : ClipProcessing{};
    forceProcessing = forceProcessing || force;
    const auto rate=c ? c->playbackRate : ClipPlaybackRate{};
    const bool rateChanged=rate!=displayedRate_;
    numericField(clipRate_,double(rate.numerator)/rate.denominator,force || forceRate || rateChanged);
    displayedRate_=rate;
    numericField(clipGain_,p.gainDb,forceProcessing);numericField(fadeInShape_,p.fadeIn.shape,forceProcessing);numericField(fadeOutShape_,p.fadeOut.shape,forceProcessing);
    if (forceProcessing || !clipMuted_->hasFocus()) clipMuted_->setChecked(p.muted);
    if (forceProcessing || !clipInverted_->hasFocus()) clipInverted_->setChecked(p.polarityInverted);
    field(fadeInStart_,p.fadeIn.startFrame,forceProcessing);field(fadeInEnd_,p.fadeIn.endFrame,forceProcessing);
    field(fadeOutStart_,p.fadeOut.startFrame,forceProcessing);field(fadeOutEnd_,p.fadeOut.endFrame,forceProcessing);
    if (forceProcessing || !fadeInCurve_->hasFocus()) fadeInCurve_->setCurrentIndex(fadeInCurve_->findData(int(p.fadeIn.curve)));
    if (forceProcessing || !fadeOutCurve_->hasFocus()) fadeOutCurve_->setCurrentIndex(fadeOutCurve_->findData(int(p.fadeOut.curve)));
    for (auto *w : {start_, source_, length_, split_, consumed_})
        w->setEnabled(editable_ && c);
    field(consumed_,0,force);
    if (c) {
        field(start_, c->startFrame, force);
        field(source_, c->sourceFrame, force);
        field(length_, c->lengthFrames, force);
        field(split_, c->startFrame + c->lengthFrames / 2, force);
        const auto asset=std::find_if(model_->assets.begin(),model_->assets.end(),
                                     [&](const auto &a){return a.id==c->assetId;});
        sourceTiming_->setText(tr("%1 + %2/%3 source frames · %4 Hz → %5 Hz project · speed %6/%7")
            .arg(QLocale().toString(c->sourceFrame),
                 QLocale().toString(qulonglong(c->sourceTiming.fraction)),
                 QLocale().toString(qulonglong(c->sourceTiming.denominator)),
                 QLocale().toString(asset->sampleRate),QLocale().toString(model_->sampleRate),
                 QLocale().toString(c->playbackRate.numerator),QLocale().toString(c->playbackRate.denominator)));
    } else
        for (auto *w : {start_, source_, length_, split_, consumed_})
            if (force || !w->hasFocus())
                w->clear();
    if(!c) sourceTiming_->clear();
    for (auto *b : mutations_) {
        const auto n = b->objectName();
        bool usable = bool(t);
        if (n == "addAudioTrack")
            usable = bool(model_);
        else if (n == "insertMediaClip")
            usable = t && asset_->count();
        else if (n == "selectTakeRegion" || n.contains("TakeLane"))
            usable = bool(takeLane());
        else if (n.contains("Clip") || n == "applyClipRange")
            usable = bool(c);
        b->setEnabled(editable_ && usable);
    }
    status_->setText(
        editable_ ? tr("Select a clip to edit its exact frame range. Raw media is preserved.")
                  : tr("Stop audio preparation or recording to edit tracks and clips."));
    if (redraw)
        draw();
}
const TakeLane *TimelineEditor::takeLane() const {
    const auto *t = track();
    if (!t || !take_) return nullptr;
    const auto it = std::find_if(t->takeLanes.begin(), t->takeLanes.end(), [this](const auto &lane) { return lane.id == *take_; });
    return it == t->takeLanes.end() ? nullptr : &*it;
}
void TimelineEditor::refreshTake(bool force) {
    QSignalBlocker blocked(takes_);
    takes_->setCurrentIndex(take_ ? takeList_->rowForId(*take_) : 0);
    const auto *lane = takeLane();
    if (force || !takeName_->hasFocus()) takeName_->setText(lane ? text(lane->name) : QString());
    if (lane && !lane->clips.empty()) {
        field(compStart_, lane->clips.front().startFrame, force);
        const auto &last = lane->clips.back();
        field(compEnd_, last.startFrame + last.lengthFrames, force);
    } else for (auto *w : {compStart_, compEnd_}) if (force || !w->hasFocus()) w->clear();
    for (auto *w : {takeName_, compStart_, compEnd_}) w->setEnabled(editable_ && lane);
    takes_->setEnabled(bool(track())); compGroup_->setEnabled(editable_ && lane);
    const auto *c = clip();
    if (c && c->takeOrigin) {
        const TakeLane *origin = nullptr;
        for (const auto &t : model_->tracks) for (const auto &l : t.takeLanes)
            if (l.id == c->takeOrigin->laneId) origin = &l;
        compSource_->setText(tr("Selected clip uses %1. Other retained lanes are silent.").arg(origin ? text(origin->name) : tr("Missing take lane")));
    } else compSource_->setText(tr("Retained lanes are silent. Use a fully covered project frame range to replace the active arrangement; Undo restores it. Stop and reprepare playback to hear the comp."));
}
void TimelineEditor::draw() {
    view_->setSnapshot(model_, epoch_, root_);
    view_->setZoom(zoom_->value());
    view_->setSelection(track_, clip_);
}
} // namespace soundcurrent::daw::ui
