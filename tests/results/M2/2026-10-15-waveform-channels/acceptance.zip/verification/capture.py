from pathlib import Path
import subprocess,json,os,time
r=Path('.cache/waveform-channels-349');rows=[]
for name,args,env in [('capture-build',['cmake','--build','.cache/take-preview-linux/build','--parallel','1','--target','sc-studio-waveform-tests'],{}),('capture-render',['.cache/take-preview-linux/build/sc-studio-waveform-tests'],{'QT_QPA_PLATFORM':'offscreen','SC_STUDIO_WAVEFORM_CAPTURE':str(r.resolve()/'studio.png')})]:
 start=time.monotonic()
 with (r/(name+'.log')).open('w') as f:p=subprocess.run(['nice','-n','15','ionice','-c','3']+args,env={**os.environ,**env},stdout=f,stderr=subprocess.STDOUT)
 rows.append(dict(phase=name,args=args,environment=env,exitCode=p.returncode,seconds=time.monotonic()-start));(r/'capture-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
