from pathlib import Path
import json,hashlib,subprocess,zipfile
r=Path('.cache/waveform-channels-349');out=Path('tests/results/M2/2026-10-15-waveform-channels');out.mkdir(parents=True,exist_ok=True)
rows=json.loads((r/'commands.json').read_text());assert len(rows)==6 and all(x['exitCode']==0 for x in rows)
captureRows=json.loads((r/'capture-commands.json').read_text());assert len(captureRows)==2 and all(x['exitCode']==0 for x in captureRows)
preceding=json.loads((r/'preceding-ci-status.json').read_text())
files={}
source=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
source=[n for n in source if not n.startswith('docs/') and Path(n).is_file()]
for n in source:files['source/'+n]=Path(n).read_bytes()
for p in r.iterdir():
 if p.is_file() and p.suffix in {'.log','.json','.py','.png'}:files['verification/'+p.name]=p.read_bytes()
binaries={}
for label,b,names in [('release',Path('.cache/take-preview-linux/build'),['sc-studio-waveform-tests','sc-timeline-waveform-tests','sc-waveform-controller-tests','sc-waveform-lifecycle-probe','sc-crossfade-ui-tests','soundcurrent-daw','sc-waveform-worker']),('asan',Path('.cache/waveform-controller-344/asan'),['sc-timeline-waveform-tests','sc-waveform-worker'])]:
 files['build/'+label+'/CMakeCache.txt']=(b/'CMakeCache.txt').read_bytes()
 files['build/'+label+'/commands.txt']=subprocess.check_output(['ninja','-C',str(b),'-t','commands',*names])
 for n in names:
  p=b/n;binaries[label+'/'+n]=dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(p.open('rb'),'sha256').hexdigest())
files['verification/binary-hashes.json']=(json.dumps(binaries,indent=2)+'\n').encode()
index={n:dict(bytes=len(v),sha256=hashlib.sha256(v).hexdigest()) for n,v in files.items()}
files['payload-index.json']=(json.dumps(index,indent=2)+'\n').encode()
p=out/'acceptance.zip'
with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
 for n,v in files.items():z.writestr(n,v)
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 for n,v in index.items():assert hashlib.sha256(z.read(n)).hexdigest()==v['sha256']
m=dict(archive=p.name,bytes=p.stat().st_size,sha256=hashlib.file_digest(p.open('rb'),'sha256').hexdigest(),entries=len(files),baseHead=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),source={n:index['source/'+n] for n in source},commands=rows,captureCommands=captureRows,precedingCIStatus=preceding['status'],precedingCIHead=preceding['headSha'],nativeWindowsChannelSelectionQualified=False,installedPreviewsChanged=False,binariesIncluded=False)
(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps({k:m[k] for k in ['bytes','sha256','entries','baseHead']}))
