from pathlib import Path
import argparse,hashlib,json,os,subprocess,tempfile,time
p=argparse.ArgumentParser();p.add_argument('--menu',action='store_true');p.add_argument('--reopen',action='store_true');p.add_argument('--tag',choices=['edit','reopen','menu']);args=p.parse_args()
r=Path(__file__).resolve().parent.parent;app=r/'app';pkg=Path(json.loads((r/'package-invocation.json').read_text())['output']);receipt=json.loads((pkg/'receipt.json').read_text())
binary=Path(json.loads((r/'user-installation.json').read_text())['installation'])/'usr/bin/soundcurrent-daw'
project=app/'project-été-Κиїв';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(binary)==receipt['packaged_executable_sha256']
tag=args.tag or ('menu' if args.menu else 'reopen' if args.reopen else 'edit')
assert not (app/(tag+'-launch.json')).exists(), 'Launch receipt already exists'
with tempfile.TemporaryDirectory(prefix='sc-p351ui-') as directory, (app/(tag+'-display.txt')).open('w') as display, (app/(tag+'-xvfb.log')).open('w') as xlog, (app/(tag+'-pipewire.log')).open('w') as plog, (app/(tag+'-app.log')).open('w') as alog:
 server=subprocess.Popen(['Xvfb','-displayfd',str(display.fileno()),'-screen','0','1280x1000x24','-nolisten','tcp'],stdout=xlog,stderr=subprocess.STDOUT,pass_fds=(display.fileno(),))
 daemon=None;child=None;pid=None
 try:
  end=time.monotonic()+5
  while not (app/(tag+'-display.txt')).read_text().strip():
   assert server.poll() is None and time.monotonic()<end;time.sleep(.05)
  xdisplay=':'+(app/(tag+'-display.txt')).read_text().strip();env=dict(os.environ,QT_LINUX_ACCESSIBILITY_ALWAYS_ON='1',QT_ACCESSIBILITY='1',DISPLAY=xdisplay,XDG_CONFIG_HOME=str(app/'preferences'),SOUNDCURRENT_DAW_LANGUAGE='en',QT_QPA_PLATFORM='xcb',PIPEWIRE_RUNTIME_DIR=directory,XDG_RUNTIME_DIR=directory,PIPEWIRE_REMOTE='pipewire-0')
  daemon=subprocess.Popen(['pipewire','-c',str(r/'private-recording-pipewire.conf')],env=env,stdout=plog,stderr=subprocess.STDOUT)
  end=time.monotonic()+5
  while not (Path(directory)/'pipewire-0').is_socket():
   assert daemon.poll() is None and time.monotonic()<end;time.sleep(.05)
  objects=json.loads(subprocess.check_output(['pw-dump'],env=env,timeout=5));(app/(tag+'-graph-before.json')).write_text(json.dumps(objects,indent=2)+'\n')
  assert sorted(o['info']['props']['node.name'] for o in objects if o['type']=='PipeWire:Interface:Node')==['Dummy-Driver','Freewheel-Driver']
  if args.menu:
   # Reap the actual menu child after gtk-launch exits.
   import ctypes
   assert ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)==0
   subprocess.run(['gtk-launch','soundcurrent-daw-preview',str(project)],env=env,stdout=alog,stderr=subprocess.STDOUT,check=True,timeout=10)
   end=time.monotonic()+8
   while time.monotonic()<end and pid is None:
    for proc in Path('/proc').iterdir():
     if not proc.name.isdecimal():continue
     try:
      if (proc/'exe').resolve()==binary and str(project).encode() in (proc/'cmdline').read_bytes():pid=int(proc.name);break
     except (OSError,RuntimeError):pass
    time.sleep(.05)
   assert pid
  else:
   child=subprocess.Popen([str(binary),str(project)],env=env,stdout=alog,stderr=subprocess.STDOUT);pid=child.pid
  end=time.monotonic()+8;window=None
  while time.monotonic()<end:
   result=subprocess.run(['xdotool','search','--all','--onlyvisible','--pid',str(pid),'--name','^SoundCurrent DAW'],env=env,capture_output=True,text=True)
   if result.returncode==0:window=result.stdout.splitlines()[0];break
   time.sleep(.05)
  assert window and sha(Path('/proc')/str(pid)/'exe')==receipt['packaged_executable_sha256']
  subprocess.run(['xdotool','windowsize',window,'1100','900'],env=env,check=True)
  time.sleep(.2);subprocess.run(['import','-window',window,str(app/(tag+'-opened.png'))],env=env,check=True,timeout=8)
  d={'pid':pid,'window':window,'display':xdisplay,'binary':str(binary),'project':str(project),'source_head':receipt['source_head'],'running_executable_sha256':sha(binary),'menu_launch':args.menu,'private_display':True,'private_daemon_pid':daemon.pid,'physical_audio':False}
  d['bus']=os.environ.get('DBUS_SESSION_BUS_ADDRESS');d['runtime']=directory
  (app/'active.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
  deadline=time.monotonic()+900
  while not (app/(tag+'-finish')).exists():
   assert time.monotonic()<deadline,'Installed interaction deadline; cleanup cannot qualify'
   time.sleep(.2)
  d['quitRequestedByPublicMenuAction']=True
  end=time.monotonic()+30
  while time.monotonic()<end:
   if child is not None:
    rc=child.poll()
    if rc is None:time.sleep(.1);continue
   else:
    found,status=os.waitpid(pid,os.WNOHANG)
    if not found:time.sleep(.1);continue
    rc=os.waitstatus_to_exitcode(status)
   d['exit_code']=rc;pid=None;(app/(tag+'-launch.json')).write_text(json.dumps(d,indent=2)+'\n');print('Normal app exit',rc,flush=True);assert rc==0;break
  else:raise TimeoutError('Packaged UI deadline reached; forced cleanup cannot qualify')
 finally:
  if pid:
   if child is not None:child.terminate();child.wait(timeout=5)
   else:os.kill(pid,15);os.waitpid(pid,0)
  if daemon is not None:daemon.terminate();daemon.wait(timeout=5)
  server.terminate();server.wait(timeout=5)
