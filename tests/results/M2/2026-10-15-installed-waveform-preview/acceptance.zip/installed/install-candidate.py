from pathlib import Path
import datetime,hashlib,json,shutil
r=Path(__file__).resolve().parent;pkg=Path(json.loads((r/'package-invocation.json').read_text())['output']);receipt=json.loads((pkg/'receipt.json').read_text())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def inventory(root):
 files={}
 for p in root.rglob('*'):
  assert not p.is_symlink(),p
  if p.is_file():files[p.relative_to(root).as_posix()]=sha(p)
 return files
assert receipt['source_head']=='f2f9f7c8916e34582db9f289f62bda2019d1c330' and receipt['all_extracted_payload_bytes_match']
deb=next(pkg.glob('*.deb'));assert sha(deb)==receipt['artifacts'][deb.name]['sha256']
dest=Path.home()/'.local/opt/soundcurrent-daw/previews'/receipt['version'];assert not dest.exists()
launcher=Path.home()/'.local/share/applications/soundcurrent-daw-preview.desktop';old=launcher.read_bytes();oldroot=dest.parent/receipt['previous_version'];assert str(oldroot).encode() in old
oldfiles=inventory(oldroot);(r/'previous-launcher.desktop.txt').write_bytes(old);(r/'preserved-preview-before.json').write_text(json.dumps(oldfiles,indent=2)+'\n')
launchers={p.name:sha(p) for p in launcher.parent.glob('soundcurrent-daw*.desktop')};(r/'preserved-launchers-before.json').write_text(json.dumps(launchers,indent=2)+'\n')
source=pkg/'extracted';files=inventory(source);shutil.copytree(source,dest,copy_function=shutil.copy2);assert inventory(dest)==files and inventory(oldroot)==oldfiles
assert sha(dest/'usr/bin/soundcurrent-daw')==receipt['packaged_executable_sha256'];assert launcher.read_bytes()==old
out=dict(source_head=receipt['source_head'],version=receipt['version'],installation=str(dest),previous_installation=str(oldroot),launcher=str(launcher),launcher_sha256=sha(launcher),payload_sha256=files,all_copied_payload_bytes_match=True,per_user_installation=True,system_package_installation=False,normalLauncherChanged=False)
(r/'user-installation.json').write_text(json.dumps(out,indent=2)+'\n')
provenance=json.loads((r.parents[1]/'installed-comp-323/fixture-provenance.json').read_text());original=Path(provenance['source']);assert inventory(original)==provenance['sourceFiles'];project=r/'app/project-été-Κиїв';assert not project.exists();shutil.copytree(original,project);assert inventory(project)==provenance['sourceFiles'];(r/'fixture-provenance.json').write_text(json.dumps(provenance,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(out))

prepared=r.parents[1]/'installed-comp-323/fixture-before.json'
assert sha(prepared)=='52b7d05a3c0055f88f7eff4935d24399fa39a5f8b48306156a917f3e196b4fd8'
(project/'project.json').write_bytes(prepared.read_bytes())
(r/'fixture-before.json').write_bytes(prepared.read_bytes())
(r/'fixture-preparation.json').write_text(json.dumps(dict(preparedStateSha256=sha(prepared),source=str(prepared),originalMediaUnchanged=True),indent=2)+'\n')
