from access import *
import hashlib
project=Path(d['project']);before=(project/'project.json').read_bytes();session=json.loads(before)
def wait_for(predicate, description):
 end=time.monotonic()+20
 while time.monotonic()<end:
  if predicate():return
  time.sleep(.05)
 snapshot('waveform-failure')
 raise TimeoutError(description)
def status():return find('Audio clip timeline').get_description()
wait_for(lambda:status().startswith('Source PCM'),'Initial installed waveforms')
undo=find('Undo project edit','menu item');undo_before=undo.get_state_set().contains(Atspi.StateType.ENABLED)
mode=find('Overview','combo box');click(mode)
subprocess.run(['xdotool','key','Home','Down','Return'],check=True)
number=find('Source channel number','spin button')
wait_for(lambda:number.get_state_set().contains(Atspi.StateType.ENABLED),'Single channel enabled')
assert Atspi.Value.set_current_value(number,2)
wait_for(lambda:'channel 2' in status() and 'absent' not in status(),'Installed channel 2')
snapshot('waveform-channel-2')
assert Atspi.Value.set_current_value(number,1024)
wait_for(lambda:'absent' in status(),'Absent source channel')
snapshot('waveform-absent-channel')
assert Atspi.Value.set_current_value(number,2)
clip=session['tracks'][0]['clips'][0];asset=next(a for a in session['assets'] if a['id']==clip['assetId'])
source=project/asset['path'];held=source.with_name(source.name+'.owned-waveform-check');assert not held.exists()
original=hashlib.sha256(source.read_bytes()).hexdigest();source.rename(held)
try:
 click(find('Retry waveforms','button'))
 wait_for(lambda:'unavailable' in status(),'Missing source shown')
 snapshot('waveform-missing-source')
finally:held.rename(source)
assert hashlib.sha256(source.read_bytes()).hexdigest()==original
click(find('Retry waveforms','button'))
wait_for(lambda:status().startswith('Source PCM') and 'channel 2' in status() and 'absent' not in status(),'Restored source retry')
snapshot('waveform-recovered')
click(mode);subprocess.run(['xdotool','key','Home','Return'],check=True)
wait_for(lambda:'channels combined' in status(),'Overview restored')
assert not number.get_state_set().contains(Atspi.StateType.ENABLED)
assert find('Undo project edit','menu item').get_state_set().contains(Atspi.StateType.ENABLED)==undo_before
click(find('Save','menu item'));time.sleep(.4)
assert (project/'project.json').read_bytes()==before
report=dict(sourceHead=d['source_head'],installedBinary=d['binary'],sourceChannelSelection=True,absentChannelExplicit=True,missingRestoredMediaRetry=True,projectBytesUnchanged=True,undoAvailabilityUnchanged=True,physicalAudio=False)
(base/'waveform-qualification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
