from pathlib import Path
import subprocess,json,datetime
r=Path('.cache/waveform-preview-351'); b=Path('.cache/take-preview-linux/build')
commands=[['cmake','-S','.', '-B',str(b),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DSC_BUILD_DESKTOP=ON','-DSC_BUILD_PIPEWIRE=ON','-DSC_BUILD_MEDIA=ON','-DSC_BUILD_RESAMPLER=ON','-DSC_BUILD_WARP_MAP_PROBE=ON','-DSC_BUILD_PROTECTED_WARP_PROBE=ON'],['cmake','--build',str(b),'--parallel','1','--target','soundcurrent-daw','sc-native-panel-tests','sc-pipewire-ui-fixture','sc-pipewire-owned-recording-fixture','sc-original-recording-tests','sc-localization-tests','sc-stretch-artifact-tests','sc-protected-warp-probe','sc-export-tests','sc-session-tests','sc-media-staging-tests','sc-wave-validation-tests','sc-project-import-state-tests','sc-media-transaction-tests','sc-playback-controller-tests','sc-take-lane-tests','sc-timeline-ui-tests','sc-crossfade-ui-tests','sc-crossfade-edit-tests','sc-comp-transition-tests','sc-comp-repeat-fixture','sc-comp-transition-ui-tests','sc-comp-uniform-context-worker-fixture','sc-studio-waveform-tests','sc-timeline-waveform-tests','sc-waveform-cache-tests','sc-waveform-controller-tests']]
receipts=[]
for i,argv in enumerate(commands):
 with (r/('configure.log' if i==0 else 'build.log')).open('w') as f:
  child=subprocess.Popen(argv,stdout=f,stderr=subprocess.STDOUT);rc=child.wait()
 receipts.append({'argv':argv,'pid':child.pid,'exit_code':rc,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
 (r/'build-commands.json').write_text(json.dumps(receipts,indent=2)+'\n')
 print('Command',i,'PID',child.pid,'exit',rc,flush=True)
 if rc:raise SystemExit(rc)
