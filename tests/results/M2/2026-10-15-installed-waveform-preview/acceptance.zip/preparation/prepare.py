from pathlib import Path
import subprocess
r=Path('.cache/waveform-preview-351')
for name in ['build.py','qualify-native-linux.py']:
 p=subprocess.run(['python3',str(r/name)]);print(name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
