$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$root=Join-Path $env:USERPROFILE 'SoundCurrent-Installed-354'
$setup=Get-Content -Raw (Join-Path $root 'setup-result.json')|ConvertFrom-Json
if($setup.exitCode -ne 0){throw 'Existing installation did not qualify'}
if(Test-Path (Join-Path $root 'workflow-result.json')){throw 'Workflow already ran; do not restart'}
@{installerAlreadyCompleted=$true;installerNotRepeated=$true;initialCaptureNetworkFailure=$true;existingSetupArchiveUploaded=$true}|ConvertTo-Json|Set-Content (Join-Path $root 'capture-continuation.json') -Encoding UTF8
$config=Get-Content -Raw (Join-Path $root 'private-transport.json')|ConvertFrom-Json
$zip=Join-Path $env:TEMP 'setup-354.zip';$bytes=[IO.File]::ReadAllBytes($zip)
$web=New-Object Net.WebClient;$web.Proxy=$null;$web.Headers.Add('X-SoundCurrent-Capture-Key',$config.key)
$web.UploadData('http://192.168.122.1:18781/setup-354.zip','POST',$bytes)|Out-Null
& (Join-Path $root 'workflow.ps1')
& (Join-Path $root 'end.ps1')
