﻿$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
$receipt=Get-Content -Raw (Join-Path $root 'receipt.json')|ConvertFrom-Json
$uuid=(Get-CimInstance Win32_ComputerSystemProduct).UUID.ToLowerInvariant()
if($uuid -ne '670168f5-4e3f-4e7f-b218-3583db31f0f8') {throw 'Wrong acceptance clone'}
$install=Join-Path $env:LOCALAPPDATA ('Programs\SoundCurrent DAW Preview\'+$receipt.sequence+'-'+$receipt.sourceHead.Substring(0,12))
$exe=Join-Path $install 'soundcurrent-daw.exe'
$project=Join-Path $root 'project-été-Κиїв'
$env:PATH=$install+';'+$env:SystemRoot+'\System32;'+$env:SystemRoot+';'+$env:SystemRoot+'\System32\WindowsPowerShell\v1.0'
$env:QT_QPA_PLATFORM='windows';$env:QT_QPA_PLATFORM_PLUGIN_PATH=Join-Path $install 'platforms'
Add-Type -AssemblyName UIAutomationClient,UIAutomationTypes,System.Windows.Forms,System.Drawing
Add-Type 'using System;using System.Runtime.InteropServices;public class SC321Focus { [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h); [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow(); [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h,out uint pid); }'
function Require($condition,$message) {if(!$condition) {throw $message}}
function Capture($name) {
 $rect=[Windows.Forms.SystemInformation]::VirtualScreen
 $bitmap=New-Object Drawing.Bitmap $rect.Width,$rect.Height
 $graphics=[Drawing.Graphics]::FromImage($bitmap)
 try {$graphics.CopyFromScreen($rect.Left,$rect.Top,0,0,$rect.Size);$bitmap.Save((Join-Path $root ($name+'.png')),[Drawing.Imaging.ImageFormat]::Png)} finally {$graphics.Dispose();$bitmap.Dispose()}
}
function Focus($process) {
 $process.Refresh();Require (!$process.HasExited -and $process.SessionId -gt 0) 'Actual main not running interactively'
 [SC321Focus]::SetForegroundWindow($process.MainWindowHandle)|Out-Null
 Start-Sleep -Milliseconds 400
 [uint32]$owner=0;[SC321Focus]::GetWindowThreadProcessId([SC321Focus]::GetForegroundWindow(),[ref]$owner)|Out-Null
 Require ($owner -eq $process.Id) 'Foreground belongs to another process; refuse keys'
}
function Elements($process) {
 $condition=New-Object Windows.Automation.PropertyCondition ([Windows.Automation.AutomationElement]::ProcessIdProperty),$process.Id
 return [Windows.Automation.AutomationElement]::RootElement.FindAll([Windows.Automation.TreeScope]::Descendants,$condition)
}
$script:staleEnumerationElements=0
function Read-Current($element) {
 try {return $element.Current} catch {
  $errorObject=$_.Exception
  while($errorObject -and !($errorObject -is [Windows.Automation.ElementNotAvailableException])) {$errorObject=$errorObject.InnerException}
  if(!$errorObject){throw}
  $script:staleEnumerationElements++;return $null
 }
}
function Tree($process,$name) {
 $rows=@();foreach($e in (Elements $process)) {$c=Read-Current $e;if($null -eq $c){continue};$rows+=@{name=$c.Name;id=$c.AutomationId;type=$c.ControlType.ProgrammaticName;enabled=$c.IsEnabled;offscreen=$c.IsOffscreen;help=$c.HelpText}}
 $rows|ConvertTo-Json -Depth 5|Set-Content (Join-Path $root ($name+'.json')) -Encoding UTF8
}
function Open-Main($stage) {
 $p=Start-Process -FilePath $exe -ArgumentList ('--language en "'+$project+'"') -WorkingDirectory $install -PassThru -RedirectStandardOutput (Join-Path $root ($stage+'.stdout')) -RedirectStandardError (Join-Path $root ($stage+'.stderr'))
 $handle=$p.Handle;$p.PriorityClass='BelowNormal';$deadline=[DateTime]::UtcNow.AddSeconds(30)
 do {$p.Refresh();if($p.MainWindowHandle -ne 0) {break};Start-Sleep -Milliseconds 100} while([DateTime]::UtcNow -lt $deadline)
 Require (!$p.HasExited -and $p.MainWindowHandle -ne 0 -and $p.MainWindowTitle.StartsWith('SoundCurrent DAW') -and $p.SessionId -gt 0) 'Actual installed main unavailable'
 $modules=@($p.Modules|ForEach-Object {@{name=$_.ModuleName;path=$_.FileName}})
 foreach($name in @('Qt6Core.dll','Qt6Gui.dll','Qt6Widgets.dll','sndfile.dll','qwindows.dll')) {
  $found=@($modules|Where-Object {$_.name -eq $name})
  Require ($found.Count -eq 1 -and $found[0].path.StartsWith($install+'\',[StringComparison]::OrdinalIgnoreCase)) ('Dependency loaded outside install: '+$name)
 }
 $record=@{pid=$p.Id;sessionId=$p.SessionId;window=$p.MainWindowHandle.ToInt64();title=$p.MainWindowTitle;exe=$exe;sha256=(Get-FileHash $exe -Algorithm SHA256).Hash.ToLowerInvariant();modules=$modules}
 $record|ConvertTo-Json -Depth 6|Set-Content (Join-Path $root ($stage+'-launch.json')) -Encoding UTF8
 Set-Content (Join-Path $root 'main-pid.txt') $p.Id
 Start-Sleep -Milliseconds 1200
 Focus $p;Capture ($stage+'-opened');Tree $p ($stage+'-tree')
 return $p
}
function Save-Close($p,$stage) {
 Focus $p;[Windows.Forms.SendKeys]::SendWait('^s');Start-Sleep -Milliseconds 500
 $requested=$p.CloseMainWindow();Require $requested 'Main rejected normal close'
 $exited=$p.WaitForExit(30000);$p.Refresh()
 @{pid=$p.Id;normalCloseRequested=$requested;exited=$exited;forced=$false;exitCode=$(if($exited){$p.ExitCode}else{$null})}|ConvertTo-Json|Set-Content (Join-Path $root ($stage+'-close.json')) -Encoding UTF8
 Require ($exited -and $p.ExitCode -eq 0) 'Normal close incomplete; retain live process identity'
}
function Find-Id($p,[string]$id) {
 $all=@((Elements $p)|Where-Object {$c=Read-Current $_;$null -ne $c -and ([string]$c.AutomationId).EndsWith('.'+$id)})
 Require ($all.Count -eq 1) ('Expected unique control '+$id+', found '+$all.Count)
 return $all[0]
}
function Invoke-Id($p,[string]$id) {
 $e=Find-Id $p $id;Require $e.Current.IsEnabled ('Disabled '+$id)
 ([Windows.Automation.InvokePattern]$e.GetCurrentPattern([Windows.Automation.InvokePattern]::Pattern)).Invoke()
 Start-Sleep -Milliseconds 300
}
function Set-Text($p,[string]$id,[string]$value) {
 $e=Find-Id $p $id;Require $e.Current.IsEnabled ('Disabled '+$id)
 ([Windows.Automation.ValuePattern]$e.GetCurrentPattern([Windows.Automation.ValuePattern]::Pattern)).SetValue($value)
}
Add-Type 'using System;using System.Runtime.InteropServices;public class SC325Mouse { [DllImport("user32.dll")] public static extern void mouse_event(uint f,uint x,uint y,uint data,UIntPtr extra); }'
function Select-Index($p,[string]$id,[int]$index) {
 Focus $p;$e=Find-Id $p $id;Require $e.Current.IsEnabled ('Disabled '+$id)
 $pattern=[Windows.Automation.ExpandCollapsePattern]$e.GetCurrentPattern([Windows.Automation.ExpandCollapsePattern]::Pattern)
 $pattern.Expand();Start-Sleep -Milliseconds 300
 $name=switch($id){'timelineClips' {'Clip 1 · 4032 frames'} 'crossfadeIncoming' {'Clip 2 · 4032 frames'} 'crossfadeCurve' {'Equal power'} 'waveformChannelMode' {if($index -eq 1){'Single channel'}else{'Overview'}} default {throw 'Unknown owned combo'}}
 $items=@((Elements $p)|Where-Object {$c=Read-Current $_;$null -ne $c -and $c.ControlType -eq [Windows.Automation.ControlType]::ListItem -and $c.Name.Replace(',','') -eq $name})
 Require ($items.Count -eq 1) ('Expected unique popup choice '+$name+', found '+$items.Count)
 $point=$items[0].GetClickablePoint();$rect=$items[0].Current.BoundingRectangle
 Require (!$items[0].Current.IsOffscreen -and $rect.Contains($point)) 'Popup item not visibly clickable'
 [uint32]$owner=0;[SC321Focus]::GetWindowThreadProcessId([SC321Focus]::GetForegroundWindow(),[ref]$owner)|Out-Null
 Require ($owner -eq $p.Id) 'Combo foreground belongs to another process'
 [Windows.Forms.Cursor]::Position=New-Object Drawing.Point ([int]$point.X),([int]$point.Y)
 [SC325Mouse]::mouse_event(2,0,0,0,[UIntPtr]::Zero);[SC325Mouse]::mouse_event(4,0,0,0,[UIntPtr]::Zero)
 Start-Sleep -Milliseconds 400
}
function Toggle-On($p,[string]$id) {
 $e=Find-Id $p $id;Require $e.Current.IsEnabled ('Disabled '+$id)
 $pattern=[Windows.Automation.TogglePattern]$e.GetCurrentPattern([Windows.Automation.TogglePattern]::Pattern)
 if($pattern.Current.ToggleState -ne [Windows.Automation.ToggleState]::On){$pattern.Toggle()}
 Start-Sleep -Milliseconds 300
}
function Wait-Enabled($p,[string]$id) {
 $watch=[Diagnostics.Stopwatch]::StartNew()
 do {
  $all=@((Elements $p)|Where-Object {$c=Read-Current $_;$null -ne $c -and ([string]$c.AutomationId).EndsWith('.'+$id)})
  Require ($all.Count -le 1) ('Duplicate control '+$id)
  if($all.Count -eq 1 -and $all[0].Current.IsEnabled -and $watch.ElapsedMilliseconds -le 30000){return}
  Start-Sleep -Milliseconds 150
 } while($watch.ElapsedMilliseconds -lt 30000)
 throw ('Timed out waiting for '+$id)
}
function Read-Project {return Get-Content -Raw (Join-Path $project 'project.json')|ConvertFrom-Json}
function Tracks($s) {return ConvertTo-Json -InputObject @($s.tracks) -Depth 100 -Compress}
function Save-Project($p,[string]$name) {
 Focus $p;[Windows.Forms.SendKeys]::SendWait('^s');Start-Sleep -Milliseconds 800
 $s=Read-Project;$s|ConvertTo-Json -Depth 100|Set-Content (Join-Path $root ($name+'.json')) -Encoding UTF8
 return $s
}
# Qt 6.12 maps QAccessible::Description to UIA_FullDescriptionPropertyId
# (30159), while HelpText maps QAccessible::Help. Use the native UIA client
# to read the property independently of managed UIA's older identifier set.
$script:uia=New-Object -ComObject UIAutomationClient.CUIAutomation
function Waveform-Status($p) {
 $managed=Find-Id $p 'audioTimeline'
 $window=$script:uia.ElementFromHandle($p.MainWindowHandle)
 $condition=$script:uia.CreatePropertyCondition(30011,[string]$managed.Current.AutomationId)
 $element=$window.FindFirst(4,$condition)
 Require ($null -ne $element) 'Native UIA timeline element missing'
 return [string]$element.GetCurrentPropertyValue(30159)
}
function Await-Waveform($p,[string]$stage,[scriptblock]$condition) {
 $watch=[Diagnostics.Stopwatch]::StartNew()
 do {
  $status=Waveform-Status $p
  if((& $condition $status)) {
   @{stage=$stage;status=$status;milliseconds=$watch.ElapsedMilliseconds}|ConvertTo-Json|Set-Content (Join-Path $root ($stage+'-status.json')) -Encoding UTF8
   Capture $stage;return
  }
  Start-Sleep -Milliseconds 100
 } while($watch.ElapsedMilliseconds -lt 20000)
 throw ('Waveform observation timed out: '+$stage+'; last status: '+$status)
}
function Waveform-Number($p,[double]$number) {
 $e=Find-Id $p 'waveformDisplayChannel';Require $e.Current.IsEnabled 'Source channel selector disabled'
 ([Windows.Automation.RangeValuePattern]$e.GetCurrentPattern([Windows.Automation.RangeValuePattern]::Pattern)).SetValue($number)
}
function Check-Waveforms($p,$before) {
 Await-Waveform $p 'waveform-initial' {param($s) $s.StartsWith('Source PCM')}
 Select-Index $p 'waveformChannelMode' 1
 Waveform-Number $p 2
 Await-Waveform $p 'waveform-channel-2' {param($s) $s.Contains('channel 2') -and !$s.Contains('absent')}
 Waveform-Number $p 1024
 Await-Waveform $p 'waveform-absent-channel' {param($s) $s.Contains('absent')}
 Waveform-Number $p 2
 $clip=$before.tracks[0].clips[0];$asset=@($before.assets|Where-Object {$_.id -eq $clip.assetId})
 Require ($asset.Count -eq 1) 'Owned source asset is not unique'
 $source=Join-Path $project $asset[0].path;$held=$source+'.owned-waveform-check'
 Require (!(Test-Path $held)) 'Owned held-source path already exists'
 $digest=(Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
 Move-Item -LiteralPath $source -Destination $held
 try {
  Invoke-Id $p 'retryTimelineWaveforms'
  Await-Waveform $p 'waveform-missing-source' {param($s) $s.Contains('unavailable')}
 } finally {Move-Item -LiteralPath $held -Destination $source}
 Require ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -eq $digest) 'Restored source bytes differ'
 Invoke-Id $p 'retryTimelineWaveforms'
 Await-Waveform $p 'waveform-recovered' {param($s) $s.StartsWith('Source PCM') -and $s.Contains('channel 2') -and !$s.Contains('absent')}
 Select-Index $p 'waveformChannelMode' 0
 Await-Waveform $p 'waveform-overview-restored' {param($s) $s.Contains('channels combined')}
 Require (!(Find-Id $p 'waveformDisplayChannel').Current.IsEnabled) 'Overview left channel editing enabled'
 $saved=Save-Project $p 'waveform-saved-project'
 Require ((ConvertTo-Json $saved -Depth 100 -Compress) -eq (ConvertTo-Json $before -Depth 100 -Compress)) 'Display-only waveform controls changed canonical project'
 @{sourceChannelSelection=$true;absentChannelExplicit=$true;missingRestoredMediaRetry=$true;canonicalProjectUnchanged=$true;physicalAudio=$false}|ConvertTo-Json|Set-Content (Join-Path $root 'waveform-qualification.json') -Encoding UTF8
}

$result=[ordered]@{sourceHead=$receipt.sourceHead;vmUuid=$uuid;phase='started';passed=$false;nativeAudioActivated=$false;cleanOs=$false;reverseHistory=$true}
try {
 $before=Read-Project;$beforeTracks=Tracks $before
 $launch=Get-Content -Raw (Join-Path $root 'first-launch.json')|ConvertFrom-Json
 $p=Get-Process -Id $launch.pid -ErrorAction Stop;$handle=$p.Handle
 Require ($p.Path -eq $exe -and $p.SessionId -eq $launch.sessionId) 'Original app instance differs'
 $result.originalProcessContinued=$p.Id;$result.originalObserverFailureRetained=$true
 $result.phase='waveform-controls'
 Check-Waveforms $p $before
 $result.waveformControlsPassed=$true
 $result.phase='selecting-outgoing'
 Select-Index $p 'timelineClips' 1
 Toggle-On $p 'clipProcessingToggle'
 Invoke-Id $p 'crossfadeClips';Tree $p 'crossfade-open'
 $result.phase='configuring-crossfade'
 Select-Index $p 'crossfadeIncoming' 2
 Toggle-On $p 'crossfadeUseTakeHandles';Toggle-On $p 'crossfadeRenderHandles'
 Set-Text $p 'crossfadeStart' '13936';Set-Text $p 'crossfadeEnd' '14064'
 Select-Index $p 'crossfadeCurve' 2
 Tree $p 'crossfade-settings';Capture 'crossfade-settings'
 $action=@((Elements $p)|Where-Object {$c=Read-Current $_;$null -ne $c -and $c.ControlType -eq [Windows.Automation.ControlType]::Button -and $c.Name -eq 'Save and render'})
 Require ($action.Count -eq 1 -and $action[0].Current.IsEnabled) 'No unique Save and render action'
 $watch=[Diagnostics.Stopwatch]::StartNew();$result.phase='rendering'
 $result.renderInvokedUtc=[DateTime]::UtcNow.ToString('o')
 $result.originalRenderBudgetMilliseconds=30000
 ([Windows.Automation.InvokePattern]$action[0].GetCurrentPattern([Windows.Automation.InvokePattern]::Pattern)).Invoke()
 $samples=@();$readyWithinDeadline=$false;$missingObservations=0
 do {
  # A modal dialog is published asynchronously. Missing targets consume the same
  # stopwatch budget; duplicates and unexpected UIA errors still fail.
  $snapshot=@();foreach($e in (Elements $p)) {$c=Read-Current $e;if($null -ne $c){$snapshot+=@{id=[string]$c.AutomationId;name=$c.Name;enabled=$c.IsEnabled}}}
  $elapsed=@($snapshot|Where-Object {$_.id.EndsWith('.compRenderElapsed')})
  $message=@($snapshot|Where-Object {$_.id.EndsWith('.compRenderStatus')})
  $review=@($snapshot|Where-Object {$_.id.EndsWith('.reviewCreatedComp')})
  Require ($elapsed.Count -le 1 -and $message.Count -le 1 -and $review.Count -le 1) 'Duplicate render controls'
  $complete=($elapsed.Count -eq 1 -and $message.Count -eq 1 -and $review.Count -eq 1)
  $observedMs=$watch.ElapsedMilliseconds
  if(!$complete){$missingObservations++}
  if($samples.Count -lt 128){$samples+=@{milliseconds=$observedMs;allControlsPresent=$complete;elapsed=$(if($elapsed.Count){$elapsed[0].name}else{$null});status=$(if($message.Count){$message[0].name}else{$null});reviewEnabled=($complete -and $review[0].enabled)}}
  $samples|ConvertTo-Json -Depth 5|Set-Content (Join-Path $root 'render-progress.json') -Encoding UTF8
  if($complete -and $review[0].enabled){$readyWithinDeadline=$observedMs -le 30000;break}
  Start-Sleep -Milliseconds 200
 } while($watch.ElapsedMilliseconds -lt 30000)
 $result.originalRenderObservationMilliseconds=$observedMs
 $result.missingDialogObservations=$missingObservations
 $result.originalRenderWaitPassed=$readyWithinDeadline
 Require $readyWithinDeadline 'Original 30-second render observation expired; retain this live operation'
 $result.renderMilliseconds=$watch.ElapsedMilliseconds
 $terminalElapsed=(Find-Id $p 'compRenderElapsed').Current.Name
 Start-Sleep -Milliseconds 400
 $result.elapsedFrozenAtTerminal=$terminalElapsed -eq (Find-Id $p 'compRenderElapsed').Current.Name
 $result.terminalElapsed=$terminalElapsed
 Require $result.elapsedFrozenAtTerminal 'Terminal elapsed label still changes'
 Tree $p 'render-complete';Capture 'render-complete'
 Require ((Tracks (Read-Project)) -eq $beforeTracks) 'Rendering changed clips before Apply'
 Invoke-Id $p 'reviewCreatedComp';Wait-Enabled $p 'reviewCompAssembly';Invoke-Id $p 'reviewCompAssembly';Wait-Enabled $p 'applyCompAssembly'
 Tree $p 'review-verified';Capture 'review-verified';$result.phase='applying'
 Invoke-Id $p 'applyCompAssembly'
 $until=[DateTime]::UtcNow.AddSeconds(30)
 while([DateTime]::UtcNow -lt $until) {
  if((Find-Id $p 'compAssemblyStatus').Current.Name.StartsWith('Transition applied. Undo restores both original clips')){break}
  Start-Sleep -Milliseconds 150
 }
 Require ((Find-Id $p 'compAssemblyStatus').Current.Name.StartsWith('Transition applied. Undo restores both original clips')) 'Apply did not complete'
 Tree $p 'applied';Capture 'applied'
 $close=@((Elements $p)|Where-Object {$c=Read-Current $_;$null -ne $c -and $c.ControlType -eq [Windows.Automation.ControlType]::Button -and $c.Name -eq 'Close' -and $c.AutomationId -ne 'Close' -and $c.IsEnabled})
 Require ($close.Count -eq 1) 'No unique review Close action'
 ([Windows.Automation.InvokePattern]$close[0].GetCurrentPattern([Windows.Automation.InvokePattern]::Pattern)).Invoke();Start-Sleep -Milliseconds 300
 $applied=Save-Project $p 'applied-project';Require ((Tracks $applied) -ne $beforeTracks) 'No applied track change'
 $result.phase='undo-redo'
 Focus $p;[Windows.Forms.SendKeys]::SendWait('^z');Start-Sleep -Milliseconds 400
 $undone=Save-Project $p 'undone-project';Require ((Tracks $undone) -eq $beforeTracks) 'Undo did not restore original clips'
 Focus $p;[Windows.Forms.SendKeys]::SendWait('^y');Start-Sleep -Milliseconds 400
 $redone=Save-Project $p 'redone-project'
 Require ((ConvertTo-Json $redone -Depth 100 -Compress) -eq (ConvertTo-Json $applied -Depth 100 -Compress)) 'Redo did not restore exact applied state'
 Tree $p 'redone';Capture 'redone';Save-Close $p 'first'
 $state=(Get-FileHash (Join-Path $project 'project.json') -Algorithm SHA256).Hash
 $result.phase='reopening';$p=Open-Main 'reopen'
 Require ((Get-FileHash (Join-Path $project 'project.json') -Algorithm SHA256).Hash -eq $state) 'Reopen changed saved project'
 Focus $p;[Windows.Forms.SendKeys]::SendWait('^+e');Start-Sleep -Milliseconds 500
 Wait-Enabled $p 'exportStartFrame';Set-Text $p 'exportStartFrame' '0';Set-Text $p 'exportEndFrame' '18032'
 $output=Join-Path $root 'reverse-history-mix.wav';Set-Text $p 'exportDestination' $output
 Tree $p 'export-settings';Capture 'export-settings';Invoke-Id $p 'startExportJob'
 $until=[DateTime]::UtcNow.AddSeconds(30)
 while(!(Test-Path -LiteralPath $output)){Require ([DateTime]::UtcNow -lt $until) 'Export deadline';Start-Sleep -Milliseconds 100}
 Start-Sleep -Milliseconds 500;Capture 'export-finished';Save-Close $p 'reopen'
 Require ((Get-FileHash (Join-Path $project 'project.json') -Algorithm SHA256).Hash -eq $state) 'Export changed saved project'
 $result.export=@{path=$output;bytes=(Get-Item -LiteralPath $output).Length;sha256=(Get-FileHash -LiteralPath $output -Algorithm SHA256).Hash.ToLowerInvariant()}
 foreach($old in (Get-Content -Raw (Join-Path $root 'previous-files.json')|ConvertFrom-Json)) {Require ((Get-FileHash -LiteralPath $old.path -Algorithm SHA256).Hash -eq $old.sha256) 'Previous preview changed'}
 $result.previousPreviewPreserved=$true;$result.phase='installed-render-review-apply-undo-redo-reopen-export-normal-close';$result.passed=$true
} catch {
 $result.error=$_.Exception.Message;$_|Out-String|Set-Content (Join-Path $root 'workflow-continuation-error.txt') -Encoding UTF8
 try {if($p -and !$p.HasExited){Tree $p 'continuation-failure-tree';Capture 'continuation-failure-window'}}catch{}
}
$result.staleEnumerationElements=$script:staleEnumerationElements
$result|ConvertTo-Json -Depth 8|Set-Content (Join-Path $root 'workflow-continuation-result.json') -Encoding UTF8
& (Join-Path $root 'collect.ps1') 'workflow-continued-354.zip' -MetadataOnly:(!$result.passed)
if(!$result.passed) {throw $result.error}
