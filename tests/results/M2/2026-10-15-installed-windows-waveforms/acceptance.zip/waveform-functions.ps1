function Waveform-Status($p) {return (Find-Id $p 'audioTimeline').Current.HelpText}
function Await-Waveform($p,[string]$stage,[scriptblock]$condition) {
 $watch=[Diagnostics.Stopwatch]::StartNew()
 do {
  $status=Waveform-Status $p
  if((& $condition $status)) {
   @{stage=$stage;status=$status;milliseconds=$watch.ElapsedMilliseconds}|ConvertTo-Json|Set-Content (Join-Path $root ($stage+'-status.json')) -Encoding UTF8
   Capture $stage;return
  }
  Start-Sleep -Milliseconds 100
 } while($watch.ElapsedMilliseconds -lt 20000)
 throw ('Waveform observation timed out: '+$stage+'; last status: '+$status)
}
function Waveform-Number($p,[double]$number) {
 $e=Find-Id $p 'waveformDisplayChannel';Require $e.Current.IsEnabled 'Source channel selector disabled'
 ([Windows.Automation.RangeValuePattern]$e.GetCurrentPattern([Windows.Automation.RangeValuePattern]::Pattern)).SetValue($number)
}
function Check-Waveforms($p,$before) {
 Await-Waveform $p 'waveform-initial' {param($s) $s.StartsWith('Source PCM')}
 Select-Index $p 'waveformChannelMode' 1
 Waveform-Number $p 2
 Await-Waveform $p 'waveform-channel-2' {param($s) $s.Contains('channel 2') -and !$s.Contains('absent')}
 Waveform-Number $p 1024
 Await-Waveform $p 'waveform-absent-channel' {param($s) $s.Contains('absent')}
 Waveform-Number $p 2
 $clip=$before.tracks[0].clips[0];$asset=@($before.assets|Where-Object {$_.id -eq $clip.assetId})
 Require ($asset.Count -eq 1) 'Owned source asset is not unique'
 $source=Join-Path $project $asset[0].path;$held=$source+'.owned-waveform-check'
 Require (!(Test-Path $held)) 'Owned held-source path already exists'
 $digest=(Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
 Move-Item -LiteralPath $source -Destination $held
 try {
  Invoke-Id $p 'retryTimelineWaveforms'
  Await-Waveform $p 'waveform-missing-source' {param($s) $s.Contains('unavailable')}
 } finally {Move-Item -LiteralPath $held -Destination $source}
 Require ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -eq $digest) 'Restored source bytes differ'
 Invoke-Id $p 'retryTimelineWaveforms'
 Await-Waveform $p 'waveform-recovered' {param($s) $s.StartsWith('Source PCM') -and $s.Contains('channel 2') -and !$s.Contains('absent')}
 Select-Index $p 'waveformChannelMode' 0
 Await-Waveform $p 'waveform-overview-restored' {param($s) $s.Contains('channels combined')}
 Require (!(Find-Id $p 'waveformDisplayChannel').Current.IsEnabled) 'Overview left channel editing enabled'
 $saved=Save-Project $p 'waveform-saved-project'
 Require ((ConvertTo-Json $saved -Depth 100 -Compress) -eq (ConvertTo-Json $before -Depth 100 -Compress)) 'Display-only waveform controls changed canonical project'
 @{sourceChannelSelection=$true;absentChannelExplicit=$true;missingRestoredMediaRetry=$true;canonicalProjectUnchanged=$true;physicalAudio=$false}|ConvertTo-Json|Set-Content (Join-Path $root 'waveform-qualification.json') -Encoding UTF8
}
