﻿$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$root=Join-Path $env:USERPROFILE 'SoundCurrent-Installed-354'
if(Test-Path (Join-Path $root 'workflow-render-continued.ps1')) {throw 'Owned continuation already staged'}
Copy-Item -LiteralPath (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'workflow-render-continued.ps1') $root
& (Join-Path $root 'workflow-render-continued.ps1')
& (Join-Path $root 'end.ps1')
