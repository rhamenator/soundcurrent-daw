﻿$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$root=Join-Path $env:USERPROFILE 'SoundCurrent-Installed-354'
if(Test-Path (Join-Path $root 'workflow-continued.ps1')) {throw 'Owned continuation already staged'}
$original=Get-Content -Raw (Join-Path $root 'workflow-result.json')|ConvertFrom-Json
if($original.passed -or $original.phase -ne 'waveform-controls'){throw 'Unexpected original workflow state'}
Copy-Item -LiteralPath (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'workflow-continued.ps1') $root
& (Join-Path $root 'workflow-continued.ps1')
& (Join-Path $root 'end.ps1')
