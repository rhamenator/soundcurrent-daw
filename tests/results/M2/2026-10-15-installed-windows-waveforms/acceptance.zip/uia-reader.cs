using System;
using System.Runtime.InteropServices;
// COM slot order and identifiers from uiautomationclient.h. Uncalled slots
// deliberately have placeholder declarations; only the named methods are invoked.
[ComImport, Guid("30cbe57d-d9d0-452a-ab13-7ac5ac4825ee"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface SCNativeAutomation {
 void S0(); void S1(); void S2();
 void FromHandle(IntPtr hwnd, out SCNativeElement element);
 void S4(); void S5(); void S6(); void S7(); void S8(); void S9();
 void S10(); void S11(); void S12(); void S13(); void S14(); void S15();
 void S16(); void S17(); void S18(); void S19();
 void Condition(int property, [MarshalAs(UnmanagedType.Struct)] object value, out IntPtr condition);
}
[ComImport, Guid("d22108aa-8ac5-49a5-837b-37bbb3d7591e"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface SCNativeElement {
 void S0(); void S1();
 void FindFirst(int scope, IntPtr condition, out SCNativeElement element);
 void S3(); void S4(); void S5(); void S6();
 void Property(int property, [MarshalAs(UnmanagedType.Struct)] out object value);
}
public static class SCDescription {
 public static string Read(IntPtr hwnd, string id) {
  object client=Activator.CreateInstance(Type.GetTypeFromCLSID(new Guid("ff48dba4-60ef-4201-aa87-54103eef594e")));
  SCNativeElement window=null, element=null; IntPtr condition=IntPtr.Zero;
  try {
   SCNativeAutomation uia=(SCNativeAutomation)client;
   uia.FromHandle(hwnd,out window); uia.Condition(30011,id,out condition);
   window.FindFirst(4,condition,out element);
   if(element==null)throw new InvalidOperationException("Native timeline missing");
   object value; element.Property(30159,out value); return value as string ?? "";
  } finally {
   if(element!=null)Marshal.ReleaseComObject(element);
   if(window!=null)Marshal.ReleaseComObject(window);
   if(condition!=IntPtr.Zero)Marshal.Release(condition);
   Marshal.ReleaseComObject(client);
  }
 }
}
