from pathlib import Path
import json,hashlib,math
import numpy as np
from scipy.io import wavfile
r=Path(__file__).resolve().parent;scope=r/'observed/retired-354';project=scope/'project-été-Κиїв';load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
result=load(scope/'render-continuation-result.json');assert result['passed'],result
assert result['sourceHead']=='f2f9f7c8916e34582db9f289f62bda2019d1c330'
assert result['waveformControlsPassed']
waveform=load(scope/'waveform-qualification.json');assert all(waveform[k] for k in ['sourceChannelSelection','absentChannelExplicit','missingRestoredMediaRetry','canonicalProjectUnchanged'])
assert load(scope/'waveform-saved-project.json')==load(r.parent/'installed-comp-323/app/project-été-Κиїв/project.json')
assert not result['originalRenderWaitPassed'] and result['originalRenderObservationFailed']
assert result['originalRenderBudgetMilliseconds']==30000 and result['elapsedFrozenAtTerminal']
initial=load(scope/'workflow-result.json');interrupted=load(scope/'workflow-continuation-result.json')
assert not initial['passed'] and initial['phase']=='waveform-controls'
assert not interrupted['passed'] and interrupted['phase']=='rendering'
assert 'ElementNotAvailableException' in (scope/'workflow-continuation-error.txt').read_text(encoding='utf-8-sig')
assert result['originalProcessContinued']==interrupted['originalProcessContinued']==load(scope/'first-launch.json')['pid']
setup=load(scope/'setup-result.json');retirement=load(scope/'retirement.json')
assert setup['exitCode']==0 and setup['installerInvoked'] and setup['verifiedPayloadFiles']==66 and not setup['compilerOnPath'] and not setup['qtSdkOnPath']
assert retirement['ownedProcessesRemaining']==0 and retirement['installedPayloadFilesVerified']==66
s=load(project/'project.json');applied=load(scope/'applied-project.json');assert s==applied==load(scope/'redone-project.json');original=load(r.parent/'installed-comp-323/app/project-été-Κиїв/project.json');assert load(scope/'undone-project.json')['tracks']==original['tracks'];assert s['tracks']!=original['tracks']
for stage in ['first','reopen']:
 l=load(scope/(stage+'-launch.json'));c=load(scope/(stage+'-close.json'));assert l['sha256']=='1b949aca6339a76faf1440033390528c4c1fafa70756bdcbe38fe2c177c8af1f' and l['sessionId']>0;assert c['pid']==l['pid'] and c['normalCloseRequested'] and c['exited'] and not c['forced'] and c['exitCode']==0
assert len(s['tracks'])==1 and s['master'] is None;t=s['tracks'][0];assert len(t['processors'])==1 and t['processors'][0]['type']=='sc.eq' and t['processors'][0]['bands']==[]
rate,audio=wavfile.read(scope/'reverse-history-mix.wav');assert rate==48000 and audio.dtype==np.float32 and audio.shape==(18032,2) and np.isfinite(audio).all()
ref=np.zeros(audio.shape,dtype=np.float64)
def fade(f,n,out):
 start,end=f['startFrame'],f['endFrame']
 if start==end:return 1.
 phase=0. if n<start else 1. if n>=end else .5 if end-start==1 else (n-start)/(end-start-1)
 if out:phase=1-phase
 if phase<=0:return 0.
 if phase>=1:return 1.
 phase=phase**f['shape']
 if f['curve']=='equal-power':return math.sin(phase*math.pi/2)
 if f['curve']=='smoothstep':return phase*phase*(3-2*phase)
 assert f['curve']=='linear';return phase
for c in t['clips']:
 a=next(a for a in s['assets'] if a['id']==c['assetId']);p=project/a['path'];assert sha(p)==a['sha256'];sr,source=wavfile.read(p);assert sr==rate and source.shape==(4064,2)
 assert c['sourceFrame']==c['sourceTiming']['fraction']==0 and c['playbackRate']['numerator']==c['playbackRate']['denominator']==1
 fx=c['processing'];gain=0 if fx['muted'] else 10**(fx['gainDb']/20)*(-1 if fx['polarityInverted'] else 1)
 for n in range(c['lengthFrames']):ref[c['startFrame']+n]+=source[n].astype(np.float64)*(gain*fade(fx['fadeIn'],n,False)*fade(fx['fadeOut'],n,True))
expected=ref.astype(np.float32);error=float(np.max(np.abs(audio.astype(np.float64)-expected)));assert np.array_equal(audio,expected),error;assert np.all(audio[:10000]==0) and np.all(audio[18000:]==0);peak=float(np.max(np.abs(audio)));assert peak>1
inventory=load(r/'original-project.json');preserved=[n for n in inventory if n not in ['project.json','project.previous.json']]
for n in inventory:assert sha(r.parent/'installed-comp-323/app/project-été-Κиїв'/n)==inventory[n]['sha256']
for n in preserved:assert sha(project/n)==inventory[n]['sha256'],n
assert load(project/'project.previous.json')==s
newComplete=[p for p in project.glob('media/comp-spans/*/complete.json') if str(p.relative_to(project)) not in inventory];assert len(newComplete)==2
reports=[load(p) for p in newComplete];assert all(d['memoryMetric']=='process-commit' for d in reports)
newRequests=[p for p in project.glob('media/comp-requests/*.json') if str(p.relative_to(project)) not in inventory];assert len(newRequests)==2
for p in newRequests:
 d=load(p);assert '077d4102-d5bc-466b-8c51-3144e7343698' in d['recipe'];assert d['executor']['buildSha256']=='7aa8520b52c18b240fc7412b4dd44c0dbeea145fc5f0eec3d4f0e6abd61f91ca'
assert retirement['priorWorkflowFilesVerified']>225
report=dict(overallPreviewQualification=False,independentTimingQualification=False,originalObserverFailuresRetained=True,priorWorkflowFilesVerified=retirement['priorWorkflowFilesVerified'],sourceHead=result['sourceHead'],actualInstalledWindowsWorkflow=True,waveformChannelAndRetryWorkflow=True,originalRenderWaitPassed=result['originalRenderWaitPassed'],elapsedFrozenAtTerminal=result['elapsedFrozenAtTerminal'],terminalElapsed=result['terminalElapsed'],previousPreviewFilesVerified=retirement['earlierPreviewFilesVerified'],reviewApplyUndoRedoSaveReopen=True,normalCloseBothLaunches=True,exportFrames=len(audio),channels=2,sampleRate=rate,floatPeak=peak,independentReferenceMaximumError=error,bitExactToIndependentReference=bool(np.array_equal(audio,expected)),exportSha256=sha(scope/'reverse-history-mix.wav'),linuxProjectUnchangedFiles=len(inventory),preservedOriginalHistoryMediaFiles=len(preserved),nativeNewSpanCompletions=len(reports),linuxHistoryRegenerated=True,previousPreviewPreserved=result['previousPreviewPreserved'],physicalAudio=False,cleanOs=False)
(r/'qualification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
