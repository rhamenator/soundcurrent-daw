from pathlib import Path
import json,hashlib,shutil,secrets,os,subprocess
r=Path(__file__).resolve().parent;iso=r/'iso';old=r.parent/'windows-installed-timing-340';installer=r.parent/'p353-windows-package-20261015223130'
receipt=json.loads((installer/'receipt.json').read_text());head=receipt['sourceHead'];assert head=='f2f9f7c8916e34582db9f289f62bda2019d1c330'
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
setup=next(n for n in receipt['artifacts'] if n.endswith('-setup.exe'));assert sha(installer/setup)==receipt['artifacts'][setup]['sha256']
shutil.copy2(installer/setup,iso/'setup.exe');shutil.copy2(installer/'receipt.json',iso/'receipt.json')
for name in ['project.zip']:
 shutil.copy2(old/'iso'/name,iso/name)
shutil.copy2(old/'original-project.json',r/'original-project.json')
for name in ['receiver.py','extract.py']:
 (r/name).write_text((old/name).read_text().replace('18780','18781'))
key=secrets.token_urlsafe(32)
for p,d in [(r/'receiver-private.json',dict(ip='192.168.122.4',key=key)),(iso/'private-transport.json',dict(key=key))]:
 with p.open('x') as f:os.chmod(p,0o600);json.dump(d,f)
for name,source in [('begin.ps1',r.parent/'windows-installed-batched-339/iso/begin.ps1'),('workflow.ps1',old/'iso/workflow.ps1'),('end.ps1',old/'iso/end.ps1'),('collect.ps1',old/'iso/collect.ps1')]:
 s=source.read_text(encoding='utf-8-sig').replace('Installed-339','Installed-354').replace('Installed-340','Installed-354').replace('-339.zip','-354.zip').replace('-340.zip','-354.zip').replace('18780','18781').replace('20261015172721-b5dc2568dbf0','20261015192606-97e9ecdc32cf')
 if name=='begin.ps1':
  marker=" $previous|ConvertTo-Json -Depth 5|Set-Content (Join-Path $root 'previous-files.json') -Encoding UTF8"
  insert="""
 $priorRoot=Join-Path $env:USERPROFILE 'SoundCurrent-Installed-340'
 Require (Test-Path (Join-Path $priorRoot 'retirement.json')) 'Previous workflow retirement absent'
 $prior=@(Get-ChildItem -LiteralPath $priorRoot -Recurse -File|Where-Object {$_.Name -notin @('private-transport.json','project.zip')}|ForEach-Object {@{path=$_.FullName;sha256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash}})
 $prior|ConvertTo-Json -Depth 5|Set-Content (Join-Path $root 'previous-workflow-files.json') -Encoding UTF8
"""
  assert marker in s;s=s.replace(marker,marker+insert)
  s=s.replace("$report.installerSha256=", "$report.installerInvoked=$true\n $report.installerSha256=")
 if name=='workflow.ps1':
  s=s.replace('offscreen=$c.IsOffscreen','offscreen=$c.IsOffscreen;help=$c.HelpText')
  s=s.replace("'crossfadeCurve' {'Equal power'} default", "'crossfadeCurve' {'Equal power'} 'waveformChannelMode' {if($index -eq 1){'Single channel'}else{'Overview'}} default")
  marker='$result=[ordered]@'
  functions=(r/'waveform-functions.ps1').read_text()
  assert marker in s;s=s.replace(marker,functions+'\n'+marker,1)
  marker=" $p=Open-Main 'first';$result.phase='selecting-outgoing'"
  assert marker in s;s=s.replace(marker," $p=Open-Main 'first';$result.phase='waveform-controls'\n Check-Waveforms $p $before\n $result.waveformControlsPassed=$true\n $result.phase='selecting-outgoing'")
 (iso/name).write_text(s,encoding='utf-8-sig')
(iso/'begin.cmd').write_bytes(b'@echo off\r\npowershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0begin.ps1"\r\npause\r\n')
report=dict(sourceHead=head,sequence=receipt['sequence'],installerSha256=sha(iso/'setup.exe'),projectZipSha256=sha(iso/'project.zip'),preparedBeforeVmBoot=True,actualInstalledWaveformWorkflowPlanned=True)
(r/'prepared-inputs.json').write_text(json.dumps(report,indent=2)+'\n')
subprocess.run(['genisoimage','-quiet','-J','-r','-o',str(r/'private.iso'),str(iso)],check=True);os.chmod(r/'private.iso',0o600)
print(json.dumps(report))
