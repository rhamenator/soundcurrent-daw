from pathlib import Path
import json,subprocess,shlex,hashlib
r=Path('.cache/native-device-selection');b=(r/'corrected-release').resolve();n=json.loads(Path('.cache/native-render-tail-stop/qualified-native.json').read_text())['profiles']['release'];g=json.loads(Path('.cache/native-render-tail-stop/qualified-gui.json').read_text());prefix=['nice','-n','15','ionice','-c','2','-n','7'];commands=[];objects={};private={};sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(stage,argv,cwd=None):
 cmd=prefix+argv;commands.append({'stage':stage,'argv':cmd,'cwd':str(cwd or Path.cwd())});(r/'development-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 with (r/(stage+'.log')).open('w') as out:p=subprocess.run(cmd,cwd=cwd,stdout=out,stderr=subprocess.STDOUT)
 assert p.returncode==0,(stage,p.returncode)
gen=(r/'generated-commands.txt').read_text()
for line in gen.splitlines():
 if ' -c ' not in line:continue
 a=shlex.split(line);obj=a[a.index('-o')+1]
 if any(x in obj for x in ['sc-native-monitor-controller.dir/','sc-ui-native-recording.dir/','sc-native-panel-tests.dir/','tests/native_monitor_recording_tests.cpp.o']):
  (b/obj).parent.mkdir(parents=True,exist_ok=True);run('compile-'+str(len(objects)),a,b);objects[obj]=sha(b/obj)
assert len(objects)==6,len(objects)
for target in ['sc-native-monitor-controller','sc-ui-native-recording']:
 name='lib'+target+'.a';run(target+'-archive',['ar','r',name,*[n for n in objects if target+'.dir/' in n]],b);run(target+'-index',['ranlib',name],b);private[name]=sha(b/name)
for i,line in enumerate(x for x in gen.splitlines() if ' -o sc-native-panel-tests ' in x or ' -o sc-native-monitor-startup-tests ' in x):
 a=shlex.split(line)[2:-2]
 for k,x in enumerate(a):
  if x.endswith('.a') and not Path(x).is_absolute() and x not in private:
   if x in g['privateArchives']:p=Path('.cache/native-render-tail-stop/gui-release')/x;assert sha(p)==g['privateArchives'][x];a[k]=str(p.resolve())
   else:
    rec=g['readOnlyArchives'].get(x,n['readOnlyArchives'].get(x));assert rec and sha(rec['path'])==rec['sha256'];a[k]=rec['path']
  if x.endswith('.o') and x not in objects:
   if x in n['objects']:p=Path('.cache/native-render-tail-stop/qualified-release')/x;assert sha(p)==n['objects'][x]['sha256'];a[k]=str(p.resolve())
   else:rec=n['readOnlyObjects'][x];assert sha(rec['path'])==rec['sha256'];a[k]=rec['path']
 run('link-'+str(i),a,b)
run('tests',['env','QT_QPA_PLATFORM=offscreen','ctest','--test-dir',str(b),'-R','^(desktop-native-recording-panel|native-monitor-startup)$','--output-on-failure','--no-tests=error'])
print('Native explicit selection and original startup suite passed',flush=True)
