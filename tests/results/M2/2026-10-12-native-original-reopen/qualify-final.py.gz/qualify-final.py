from pathlib import Path
import json,subprocess,shlex,hashlib,shutil
r=Path('.cache/native-original-reopen');f=json.loads((r/'frozen-inputs.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();prefix=['nice','-n','15','ionice','-c','2','-n','7'];profiles={};commands=[]
for label,oldlabel,dirname,ctype,flags in [('release','qualified-release','corrected-release','Release',''),('sanitizer','sanitizer','sanitizer','Debug','-fsanitize=address,undefined -fno-omit-frame-pointer')]:
 q=json.loads((r/(oldlabel+'-qualification.json')).read_text());assert subprocess.check_output(['git','diff','--name-only',q['source'],f['source']],text=True).splitlines()==['src/native_original_recording.cpp']
 old=(r/dirname).resolve();b=(r/('final-'+label)).resolve();fresh={};borrowedObjects={};borrowedArchives={}
 def run(stage,args,cwd=None):
  for x in f['selectedInputs']:assert sha(x['path'])==x['checkoutSha256']
  cmd=prefix+args;commands.append({'profile':label,'stage':stage,'argv':cmd,'cwd':str(cwd or Path.cwd())});(r/'final-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
  with (r/('final-'+label+'-'+stage+'.log')).open('w') as out:p=subprocess.run(cmd,cwd=cwd,stdout=out,stderr=subprocess.STDOUT)
  assert p.returncode==0,(label,stage,p.returncode)
  print(label+' '+stage+' passed',flush=True)
 run('configure',['cmake','-S','.','-B',str(b),'-G','Ninja','-DCMAKE_BUILD_TYPE='+ctype,'-DSC_BUILD_DESKTOP=ON','-DSC_BUILD_MEDIA=ON','-DCMAKE_CXX_FLAGS='+flags,'-DCMAKE_EXE_LINKER_FLAGS='+flags])
 targets=['sc-native-panel-tests','sc-native-original-recording-tests','sc-localization-tests','soundcurrent-daw','sc-native-monitor-startup-tests']
 gen=subprocess.check_output(['ninja','-C',str(b),'-t','commands',*targets],text=True);(r/('final-'+label+'-generated-commands.txt')).write_text(gen)
 line=next(x for x in gen.splitlines() if ' -c ' in x and 'sc-native-original-recording.dir/' in x);a=shlex.split(line);obj=a[a.index('-o')+1];(b/obj).parent.mkdir(parents=True,exist_ok=True);run('compile',a,b);fresh[obj]={'bytes':(b/obj).stat().st_size,'sha256':sha(b/obj)}
 archive='libsc-native-original-recording.a';run('archive',['ar','r',archive,obj],b);run('index',['ranlib',archive],b)
 for i,line in enumerate(x for x in gen.splitlines() if any(' -o '+n+' ' in x for n in targets)):
  a=shlex.split(line)[2:-2]
  for j,x in enumerate(a):
   if x.endswith('.a') and not Path(x).is_absolute() and x!=archive:
    if x in q['privateArchives']:p=old/x;expected=q['privateArchives'][x]
    else:rec=q['readOnlyArchives'][x];p=Path(rec['path']);expected=rec['sha256']
    assert sha(p)==expected;a[j]=str(p.resolve());borrowedArchives[x]={'path':a[j],'sha256':expected}
   if x.endswith('.o') and x not in fresh:
    p=old/x;expected=q['objects'][x]['sha256'];assert sha(p)==expected;a[j]=str(p);borrowedObjects[x]={'path':str(p),'sha256':expected}
  run('link-'+str(i),a,b)
 run('tests',['env','QT_QPA_PLATFORM=offscreen','ctest','--test-dir',str(b),'-R','^(desktop-native-recording-panel|original-native-outcomes|desktop-localization|native-monitor-startup)$','--output-on-failure','--no-tests=error'])
 shutil.copyfile(b/'Testing/Temporary/LastTest.log',r/('final-'+label+'-LastTest.log'))
 profiles[label]={'freshObjects':fresh,'privateArchives':{archive:sha(b/archive)},'readOnlyObjects':borrowedObjects,'readOnlyArchives':borrowedArchives,'exeHashes':{n:sha(b/n)for n in targets}}
 (r/'final-qualification.json').write_text(json.dumps({'source':f['source'],'tree':f['tree'],'profiles':profiles,'previousSource':q['source'],'onlySourceChange':'src/native_original_recording.cpp','change':'Separate existing cancellation callback and return statements; no behavior change','guiTsanQualified':False},indent=2)+'\n')
