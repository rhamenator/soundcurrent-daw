from pathlib import Path
import subprocess,json,hashlib,zipfile,io
r=Path('.cache/native-original-reopen/pr156-review');api=lambda tail:subprocess.check_output(['gh','api','repos/rhamenator/soundcurrent-daw/'+tail]);sha=lambda raw:hashlib.sha256(raw).hexdigest()
for name,tail in [('run','actions/runs/38208986550'),('jobs','actions/runs/38208986550/jobs'),('artifacts','actions/runs/38208986550/artifacts')]:
 (r/(name+'.json')).write_bytes(api(tail))
jobs=json.loads((r/'jobs.json').read_bytes())['jobs'];assert all(j['status']=='completed' for j in jobs)
for j in jobs:
 p=r/('job-'+str(j['id'])+'.log')
 if j['id']==114678697746:p.write_bytes((r/'native-original.log').read_bytes())
 else:p.write_bytes(api('actions/jobs/'+str(j['id'])+'/logs'))
for a in json.loads((r/'artifacts.json').read_bytes())['artifacts']:
 if a['name']!='windows-desktop-import-test-log':continue
 raw=api('actions/artifacts/'+str(a['id'])+'/zip');(r/'desktop-original.zip').write_bytes(raw);members={}
 with zipfile.ZipFile(io.BytesIO(raw)) as z:
  for name in z.namelist():
   if not (name.endswith('LastTest.log') or ('parent-observation-timing/' in name and name.endswith('.json')) or name.endswith('verified-runtime.json')):continue
   data=z.read(name);dest='desktop-artifact--'+name.replace('/','_');(r/dest).write_bytes(data);members[name]={'destination':dest,'bytes':len(data),'sha256':sha(data)}
 (r/'desktop-artifact-selected.json').write_text(json.dumps({'artifact':a['id'],'archiveBytes':len(raw),'archiveSha256':sha(raw),'originalMembers':members},indent=2)+'\n')
print('Retained original all-four terminal logs and Windows desktop artifacts; native failed before test executables were built')
