from pathlib import Path
import json,subprocess,shlex,hashlib,shutil
r=Path('.cache/native-original-reopen');b=(r/'release').resolve();prefix=['nice','-n','15','ionice','-c','2','-n','7'];commands=[];objects={};archives={};borrowed={}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
g=json.loads(Path('.cache/native-original-export/sanitizer-qualification.json').read_text());previous=json.loads(Path('.cache/native-device-selection/qualified-gui.json').read_text())
oldroot=Path('.cache/native-original-export/qualified-release').resolve()
def run(stage,args,cwd=None):

 for x in json.loads((r/'frozen-inputs.json').read_text())['selectedInputs']:assert sha(x['path'])==x['checkoutSha256']
 cmd=prefix+args;commands.append({'stage':stage,'argv':cmd,'cwd':str(cwd or Path.cwd())});(r/'corrected-release-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 with (r/('corrected-release-'+stage+'.log')).open('w') as out:proc=subprocess.run(cmd,cwd=cwd,stdout=out,stderr=subprocess.STDOUT)
 assert proc.returncode==0,(stage,proc.returncode)
 print(stage+' passed',flush=True)
targets=['sc-native-panel-tests','sc-native-original-recording-tests','sc-localization-tests','soundcurrent-daw']
gen=(r/'release-generated-commands.txt').read_text()
for line in gen.splitlines():
 if ' -c ' not in line:continue
 a=shlex.split(line);obj=a[a.index('-o')+1]
 if (b/obj).is_file():objects[obj]={'bytes':(b/obj).stat().st_size,'sha256':sha(b/obj)}
for target in sorted({n.split('/')[1][:-4] for n in objects if n.split('/')[1].startswith(('sc-ui-','sc-native-monitor-controller','sc-native-original-export','sc-native-original-recording'))}):
 name='lib'+target+'.a';run(target+'-archive',['ar','r',name,*[n for n in objects if target+'.dir/' in n]],b);run(target+'-index',['ranlib',name],b);archives[name]=sha(b/name)
for i,line in enumerate(x for x in gen.splitlines() if any(' -o '+n+' ' in x for n in targets)):
 a=shlex.split(line)[2:-2]
 for n,x in enumerate(a):
  if x.endswith('.a') and not Path(x).is_absolute() and x not in archives:
   q=json.loads(Path('.cache/native-original-export/qualified-qualification.json').read_text())
   if x in q['privateArchives']:p=oldroot/x;expected=q['privateArchives'][x]
   elif x in q['readOnlyArchives']:rec=q['readOnlyArchives'][x];p=Path(rec['path']);expected=rec['sha256']
   else:raise AssertionError(x)
   assert sha(p)==expected,x;a[n]=str(p.resolve());borrowed[x]={'path':a[n],'sha256':expected}
 run('link-'+str(i),a,b)
run('tests',['env','QT_QPA_PLATFORM=offscreen','ctest','--test-dir',str(b),'-R','^(desktop-native-recording-panel|original-native-outcomes|desktop-localization)$','--output-on-failure','--no-tests=error'])
for x in borrowed.values():assert sha(x['path'])==x['sha256']
shutil.copyfile(b/'Testing/Temporary/LastTest.log',r/'release-LastTest.log');shutil.copyfile(b/'CMakeCache.txt',r/'release-CMakeCache.txt')
(r/'release-qualification.json').write_text(json.dumps({'objects':objects,'privateArchives':archives,'readOnlyArchives':borrowed,'exeHashes':{n:sha(b/n)for n in targets},'windowsRuntimeQualified':False},indent=2)+'\n')
