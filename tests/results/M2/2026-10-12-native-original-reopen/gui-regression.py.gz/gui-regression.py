from pathlib import Path
import json,subprocess,shlex,hashlib,shutil
r=Path('.cache/native-original-reopen');b=(r/'gui-regression').resolve();prefix=['nice','-n','15','ionice','-c','2','-n','7'];q=json.loads((r/'qualified-release-qualification.json').read_text());f=json.loads((r/'frozen-inputs.json').read_text());commands=[];objects={};borrowed={};sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(stage,args,cwd=None):
 for x in f['selectedInputs']:assert sha(x['path'])==x['checkoutSha256']
 cmd=prefix+args;commands.append({'stage':stage,'argv':cmd,'cwd':str(cwd or Path.cwd())});(r/'gui-regression-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 with (r/('gui-regression-'+stage+'.log')).open('w') as out:p=subprocess.run(cmd,cwd=cwd,stdout=out,stderr=subprocess.STDOUT)
 assert p.returncode==0,(stage,p.returncode)
 print(stage+' passed',flush=True)
run('configure',['cmake','-S','.','-B',str(b),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DSC_BUILD_DESKTOP=ON','-DSC_BUILD_MEDIA=ON'])
gen=subprocess.check_output(['ninja','-C',str(b),'-t','commands','sc-ui-tests'],text=True);(r/'gui-regression-generated-commands.txt').write_text(gen)
for line in gen.splitlines():
 if ' -c ' not in line:continue
 a=shlex.split(line);obj=a[a.index('-o')+1]
 if 'sc-ui-tests.dir/' in obj:
  (b/obj).parent.mkdir(parents=True,exist_ok=True);run('compile-'+str(len(objects)),a,b);objects[obj]={'bytes':(b/obj).stat().st_size,'sha256':sha(b/obj)}
line=next(x for x in gen.splitlines() if ' -o sc-ui-tests ' in x);a=shlex.split(line)[2:-2]
for i,x in enumerate(a):
 if x.endswith('.a') and not Path(x).is_absolute():
  if x in q['privateArchives']:p=Path('.cache/native-original-reopen/corrected-release').resolve()/x;expected=q['privateArchives'][x]
  else:rec=q['readOnlyArchives'][x];p=Path(rec['path']);expected=rec['sha256']
  assert sha(p)==expected;a[i]=str(p.resolve());borrowed[x]={'path':str(p),'sha256':expected}
run('link',a,b)
run('tests',['env','QT_QPA_PLATFORM=offscreen','ctest','--test-dir',str(b),'-R','^(desktop-loop-controls|desktop-ui)$','--output-on-failure','--no-tests=error'])
shutil.copyfile(b/'Testing/Temporary/LastTest.log',r/'gui-regression-LastTest.log')
(r/'gui-regression-qualification.json').write_text(json.dumps({'source':f['source'],'tree':f['tree'],'freshObjects':objects,'readOnlyArchives':borrowed,'exeSha256':sha(b/'sc-ui-tests')},indent=2)+'\n')
