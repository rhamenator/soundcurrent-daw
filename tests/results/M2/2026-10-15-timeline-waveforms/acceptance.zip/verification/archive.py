from pathlib import Path
import json,hashlib,subprocess,zipfile
r=Path('.cache/timeline-waveforms-347');out=Path('tests/results/M2/2026-10-15-timeline-waveforms');out.mkdir(parents=True,exist_ok=True)
rows=json.loads((r/'qualified-commands.json').read_text());assert len(rows)==6 and all(x['exitCode']==0 for x in rows)
files={}
source=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+['ui/timeline_waveforms.hpp','ui/timeline_waveforms.cpp','tests/timeline_waveform_tests.cpp']
source=[n for n in source if not n.startswith('docs/') and Path(n).is_file()]
for n in source:files['source/'+n]=Path(n).read_bytes()
for p in r.iterdir():
 if p.suffix in {'.log','.json','.py','.png'}:files['verification/'+p.name]=p.read_bytes()
binaries={}
for label,b in [('release',Path('.cache/take-preview-linux/build')),('asan',Path('.cache/waveform-controller-344/asan'))]:
 files['build/'+label+'/CMakeCache.txt']=(b/'CMakeCache.txt').read_bytes()
 files['build/'+label+'/commands.txt']=subprocess.check_output(['ninja','-C',str(b),'-t','commands','sc-timeline-waveform-tests'])
 for n in ['sc-timeline-waveform-tests','sc-waveform-worker','libsc-ui-timeline.a','libsc-ui-waveform.a']:
  p=b/n;binaries[label+'/'+n]=dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(p.open('rb'),'sha256').hexdigest())
files['verification/binary-hashes.json']=(json.dumps(binaries,indent=2)+'\n').encode()
index={n:dict(bytes=len(v),sha256=hashlib.sha256(v).hexdigest()) for n,v in files.items()}
files['payload-index.json']=(json.dumps(index,indent=2)+'\n').encode()
p=out/'acceptance.zip'
with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
 for n,v in files.items():z.writestr(n,v)
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 for n,v in index.items():assert hashlib.sha256(z.read(n)).hexdigest()==v['sha256']
m=dict(archive=p.name,bytes=p.stat().st_size,sha256=hashlib.file_digest(p.open('rb'),'sha256').hexdigest(),entries=len(files),baseHead=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),source={n:index['source/'+n] for n in source},commands=rows,nativeWindowsQualified=False,installedPreviewsChanged=False,binariesIncluded=False,originalOracleFailureRetained=True)
(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps({k:m[k] for k in ['bytes','sha256','entries','baseHead']}))
