from pathlib import Path
import subprocess,json,os,time
r=Path('.cache/timeline-waveforms-347');rows=[]
commands=[('localization',['python3','tools/localization.py','--update'],{}),('build',['cmake','--build','.cache/take-preview-linux/build','--parallel','1','--target','sc-timeline-waveform-tests','sc-timeline-ui-tests','soundcurrent-daw'],{}),('tests',['ctest','--test-dir','.cache/take-preview-linux/build','-R','^(desktop-timeline-waveforms|desktop-timeline|desktop-virtualized-views|daw-translation-catalogs|daw-translation-catalog-failures|preview-package-provenance|windows-package-inputs)$','--output-on-failure','-V'],{}),('render',['.cache/take-preview-linux/build/sc-timeline-waveform-tests',str(r.resolve()/'timeline-final.png')],{'QT_QPA_PLATFORM':'offscreen'}),('asan-build',['cmake','--build','.cache/waveform-controller-344/asan','--parallel','1','--target','sc-timeline-waveform-tests'],{}),('asan-tests',['ctest','--test-dir','.cache/waveform-controller-344/asan','-R','^desktop-timeline-waveforms$','--output-on-failure','-V'],{'ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'})]
for name,args,env in commands:
 start=time.monotonic()
 with (r/('qualified-'+name+'.log')).open('w') as f:p=subprocess.run(['nice','-n','15','ionice','-c','3']+args,env={**os.environ,**env},stdout=f,stderr=subprocess.STDOUT)
 rows.append(dict(phase=name,args=args,env=env,exitCode=p.returncode,seconds=time.monotonic()-start));(r/'qualified-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
