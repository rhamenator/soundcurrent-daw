from pathlib import Path
import subprocess,json,os,time
r=Path('.cache/timeline-waveforms-347'); rows=[]
commands=[('localization',['python3','tools/localization.py','--update']),('build',['cmake','--build','.cache/take-preview-linux/build','--parallel','1','--target','sc-timeline-waveform-tests','sc-timeline-ui-tests','soundcurrent-daw']),('tests',['ctest','--test-dir','.cache/take-preview-linux/build','-R','^(desktop-timeline-waveforms|desktop-timeline|daw-translation-catalogs|daw-translation-catalog-failures|preview-package-provenance|windows-package-inputs)$','--output-on-failure','-V'])]
for name,args in commands:
 start=time.monotonic()
 with (r/('final-'+name+'.log')).open('w') as f:p=subprocess.run(['nice','-n','15','ionice','-c','3']+args,stdout=f,stderr=subprocess.STDOUT)
 rows.append(dict(phase=name,args=args,exitCode=p.returncode,seconds=time.monotonic()-start));(r/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
