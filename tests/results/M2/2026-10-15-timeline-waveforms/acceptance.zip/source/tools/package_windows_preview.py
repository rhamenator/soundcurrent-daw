#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Prepare a local, unsigned Windows x64 installer and matching source bundle.

Consumes retained native build/deployment inputs; never activates audio, installs
software, changes a VM, or uploads a release. Clean-install acceptance is separate.
"""
import argparse
import datetime
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import tarfile
import zipfile
from stretch_worker_qualification import qualify_stretch_worker as qualify_native_stretch, PROTOCOL as STRETCH_PROTOCOL
from protected_warp_qualification import qualify_protected_warp

ROOT = Path(__file__).resolve().parents[1]
QT_SOURCE = 'a951bd163c7b80fc6b8c88d7668fb56abf91c152373e13c10666763238131307'
SNDFILE_SOURCE = 'ffe12ef8add3eaca876f04087734e6e8e029350082f3251f565fa9da55b52121'
REDIST = '843068991daaa1f73ad9f6239bce4d0f6a07a51f18c37ea2a867e9beca71295c'
RUNTIME_VERSION = '14.51.36247.0'

def require(value, message):
    if not value:
        raise ValueError(message)

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()

def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def relative(value):
    p = PurePosixPath(value)
    require(re.fullmatch(r'[A-Za-z0-9_./-]+',value) and not p.is_absolute() and
            p.parts and '..' not in p.parts and p.as_posix()==value and len(value)<=200,
            'Unsafe payload path')
    require(all(not part.endswith('.') and
                part.split('.')[0].upper() not in {'CON','PRN','AUX','NUL',
                    *('COM'+str(n) for n in range(1,10)),
                    *('LPT'+str(n) for n in range(1,10))} for part in p.parts),
            'Unsafe Windows payload component')
    return p

def deploy_payload(archive, manifest, destination, *, require_worker=False, require_media_worker=False, require_copy_worker=False, require_stretch_worker=False, require_comp_worker=False, require_waveform_worker=False):
    expected = {}
    for row in manifest['files']:
        name = relative(row['path']).as_posix()
        require(name.lower() not in {n.lower() for n in expected}, 'Duplicate manifest path')
        expected[name] = row
    required = {'soundcurrent-daw.exe','sndfile.dll','Qt6Core.dll','Qt6Gui.dll',
                'Qt6Widgets.dll','platforms/qwindows.dll'}
    if require_worker: required.add('sc-import-inspect-worker.exe')
    if require_media_worker: required.add('sc-approved-wave-probe.exe')
    if require_copy_worker: required.add('sc-media-import-worker.exe')
    if require_stretch_worker: required.add('sc-stretch-render-worker.exe')
    if require_waveform_worker: required.add('sc-waveform-worker.exe')
    if require_comp_worker: required.add('sc-comp-span-worker.exe')
    require(required <= set(expected) and len(expected)<=64, 'Missing/excess deployment payload')
    require(all(0<r['bytes']<=64*1024*1024 for r in expected.values()) and
            sum(r['bytes'] for r in expected.values())<=256*1024*1024,
            'Deployment bounds exceeded')
    require(not any(Path(n).name.lower().startswith(('vcruntime','msvcp','ucrtbase'))
                    for n in expected), 'Use official runtime installer, not developer CRT DLLs')
    require(archive.stat().st_size<=300*1024*1024, 'Deployment archive bounds exceeded')
    with zipfile.ZipFile(archive) as z:
        require(len(z.infolist())<=128, 'Deployment entry bounds exceeded')
        # Compress-Archive uses Windows separators. Normalize before comparing
        # membership, retaining duplicate checks and refusing drive/traversal paths.
        files = [(relative(m.filename.replace('\\','/')).as_posix(),m)
                 for m in z.infolist() if not m.is_dir()]
        require(len(files)==len(expected) and {n for n,m in files}==set(expected),
                'Deployment membership mismatch')
        for m in z.infolist():
            relative(m.filename.replace('\\','/').rstrip('/'))
            require((m.external_attr>>16)&0o170000 != 0o120000, 'Deployment symlink refused')
            if not m.is_dir():
                row=expected[relative(m.filename.replace('\\','/')).as_posix()]
                require(m.file_size==row['bytes'], 'Deployment size mismatch')
        require(z.testzip() is None, 'Deployment CRC failure')
        for name,m in files:
            row = expected[name]
            require(m.file_size==row['bytes'] and 0<m.file_size<=64*1024*1024,
                    'Deployment size mismatch')
            data = z.read(m)
            require(hashlib.sha256(data).hexdigest()==row['sha256'], 'Deployment hash mismatch')
            p = destination.joinpath(*relative(name).parts)
            p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
    return expected

def qualified_dependencies(manifest):
    trusted = read_json(ROOT/'research/windows-preview-dependencies.json')
    require(trusted['qtSourceSha256']==QT_SOURCE and
            trusted['sndfileSourceSha256']==SNDFILE_SOURCE, 'Dependency source anchor differs')
    dependencies = {r['path']:r for r in manifest['files'] if r['path'] not in
                    {'soundcurrent-daw.exe','sc-import-inspect-worker.exe','sc-approved-wave-probe.exe','sc-media-import-worker.exe','sc-stretch-render-worker.exe','sc-comp-span-worker.exe','sc-waveform-worker.exe'}}
    require(dependencies==trusted['files'], 'Unqualified dependency binary identity')

def qualify_worker(manifest, qualification, head):
    require(qualification is not None, 'Native inspection worker qualification required')
    row=next((r for r in manifest['files'] if r['path']=='sc-import-inspect-worker.exe'),{})
    require(qualification.get('sourceCommit')==head and qualification.get('exitCode')==0 and
            type(qualification.get('pid')) is int and qualification['pid']>0 and
            row.get('sha256')==qualification.get('exeSha256') and bool(row),
            'Deployed inspection worker differs from qualified native process/source')

def qualify_media_worker(manifest, qualification, head):
    require(qualification is not None, 'Native media worker qualification required')
    row=next((r for r in manifest['files'] if r['path']=='sc-approved-wave-probe.exe'),{})
    require(qualification.get('sourceCommit')==head and qualification.get('exitCode')==0 and
            type(qualification.get('pid')) is int and qualification['pid']>0 and
            type(qualification.get('reportedPid')) is int and
            qualification['reportedPid']==qualification['pid'] and
            qualification.get('protocol')=='sc-approved-wave-validation-v2' and
            row.get('sha256')==qualification.get('exeSha256') and bool(row),
            'Deployed media worker differs from qualified native process/source/protocol')

def nsis_path(path):
    text = str(path.resolve())
    require(not any(c in text for c in '$"\r\n'), 'Unsupported NSIS source path')
    return text

def qualify_copy_worker(manifest, qualification, head):
    require(qualification is not None, 'Native checked-copy worker qualification required')
    row=next((r for r in manifest['files'] if r['path']=='sc-media-import-worker.exe'),{})
    require(qualification.get('sourceCommit')==head and type(qualification.get('exitCode')) is int and qualification['exitCode']==0 and
            type(qualification.get('pid')) is int and qualification['pid']>0 and
            type(qualification.get('reportedPid')) is int and qualification['reportedPid']==qualification['pid'] and
            qualification.get('protocol')=='sc-media-copy-v1' and type(qualification.get('phase')) is int and
            qualification['phase']==2 and qualification.get('committed') is True and qualification.get('sessionAssetPublished') is False and
            type(qualification.get('operation')) is str and
            re.fullmatch(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}',qualification['operation']) and
            row.get('sha256')==qualification.get('exeSha256') and bool(row),
            'Deployed copy worker differs from qualified native process/source/receipt protocol')

def qualify_stretch_worker(manifest, qualification, head, source_tree, *, protocol=STRETCH_PROTOCOL):
    rows=[r for r in manifest['files'] if r['path']=='sc-stretch-render-worker.exe']
    require(len(rows)==1, 'Exactly one qualified stretch helper required')
    qualify_native_stretch(qualification,head,source_tree,rows[0].get('sha256'),'win32',protocol=protocol)

def qualify_protected_worker(manifest, qualification, head, source_tree):
    rows=[r for r in manifest['files'] if r['path']=='sc-stretch-render-worker.exe']
    require(len(rows)==1, 'Exactly one qualified protected stretch helper required')
    return qualify_protected_warp(qualification,head,source_tree,rows[0].get('sha256'),'win32')

def version_tuple(text):
    require(type(text) is str and re.fullmatch(r'[0-9]+(?:\.[0-9]+){2,3}', text),
            'Invalid runtime/toolset version')
    values = tuple(int(v) for v in text.split('.'))
    require(all(v <= 65535 for v in values), 'Version component outside bounds')
    return values + (0,) * (4 - len(values))


def qualify_compiler(compiler, collection, head, tree, compiler_receipt_sha256,
                     runtime_version=RUNTIME_VERSION):
    require(collection.get('format') == 'sc-windows-preview-build-bundle-v1' and
            collection.get('sourceCommit') == head and collection.get('sourceTree') == tree and
            collection.get('nativePlatform') == 'win32' and
            collection.get('sourceInputsUnchanged') is True,
            'Current native build collection required')
    require(collection.get('compiler') == compiler and
            collection.get('artifacts', {}).get('compiler.json', {}).get('sha256') == compiler_receipt_sha256,
            'Compiler receipt differs from native build collection')
    path = compiler.get('path', '').replace('\\', '/')
    match = re.search(r'/Tools/MSVC/(14\.[0-9]+\.[0-9]+)/bin/Hostx64/x64/cl\.exe$',
                      path, re.IGNORECASE)
    require(match is not None and type(compiler.get('bytes')) is int and compiler['bytes'] > 0 and
            re.fullmatch(r'[0-9a-f]{64}', compiler.get('sha256', '')),
            'Native x64 MSVC toolset identity required')
    directory_version = version_tuple(match.group(1))
    product_version = version_tuple(compiler.get('productVersion'))
    file_version = version_tuple(compiler.get('fileVersion'))
    require(product_version[0] == 14 and product_version[:2] == directory_version[:2] and
            product_version >= directory_version and file_version[0] == product_version[0] + 5 and
            file_version[1:] == product_version[1:], 'Compiler version resources are inconsistent')
    # Compiler executable patches and redistributable patches are not interchangeable.
    # Use the actual CRT headers selected by this native toolset, conservatively
    # retaining the toolset's directory version as another lower bound.
    crt_version = version_tuple(compiler.get('crtVersion'))
    require(crt_version[:2] == directory_version[:2] and
            re.fullmatch(r'[0-9a-f]{64}', compiler.get('crtHeaderSha256', '')),
            'Actual native CRT header/version identity required')
    toolset = max(crt_version, directory_version)
    require(version_tuple(runtime_version) >= toolset,
            'Pinned Microsoft runtime is older than the actual MSVC build tools')
    return '.'.join(map(str, toolset))


def scripts(stage, output, sequence, head, runtime, runtime_version=RUNTIME_VERSION):
    runtime_version = '.'.join(map(str, version_tuple(runtime_version)))
    entries = sorted(p for p in stage.rglob('*') if p.is_file())
    put, remove, preflight = [], [], []
    for index,p in enumerate(entries):
        name = str(relative(p.relative_to(stage).as_posix())).replace('/','\\')
        parent = str(relative(p.relative_to(stage).as_posix()).parent).replace('/','\\')
        put += ['SetOutPath "$INSTDIR'+('\\'+parent if parent!='.' else '')+'"',
                'File "'+nsis_path(p)+'"']
        remove += ['IfFileExists "$INSTDIR\\'+name+'" 0 remove_done_'+str(index),
                   'ClearErrors', 'Delete "$INSTDIR\\'+name+'"',
                   'IfErrors removal_failed', 'remove_done_'+str(index)+':']
        if p.suffix.lower() in {'.exe','.dll'}:
            preflight += ['IfFileExists "$INSTDIR\\'+name+'" 0 check_done_'+str(index),
                "System::Call 'kernel32::CreateFileW(w \"$INSTDIR\\"+name+"\", i 0x40000000, i 7, p 0, i 3, i 0, p 0) p.r0'",
                '${If} $0 == -1',
                'MessageBox MB_OK "Close applications using this preview before continuing."',
                'SetErrorLevel 2','Abort','${EndIf}',
                "System::Call 'kernel32::CloseHandle(p r0)'",'check_done_'+str(index)+':'
            ]
    dirs = sorted({p.parent for p in entries if p.parent!=stage},key=lambda p:len(p.parts),reverse=True)
    remove += ['RMDir "$INSTDIR\\'+p.relative_to(stage).as_posix().replace('/','\\')+'"' for p in dirs]
    for name,lines in [('payload.nsh',put),('remove.nsh',remove),('preflight.nsh',preflight)]:
        (output/name).write_text('\n'.join(lines)+'\n')
    installer=output/f'SoundCurrent-DAW-{sequence}-{head[:12]}-x64-setup.exe'
    text=(ROOT/'packaging/windows/preview.nsi.in').read_text()
    values={'BUILD_ID':sequence+'-'+head[:12],'SEQUENCE':sequence,'INSTALLER':nsis_path(installer),
            'LICENSE':nsis_path(ROOT/'LICENSE'),'REDIST':nsis_path(runtime),
            'RUNTIME_VERSION':runtime_version,
            'PAYLOAD_INCLUDE':nsis_path(output/'payload.nsh'),
            'REMOVE_INCLUDE':nsis_path(output/'remove.nsh'),
            'PREFLIGHT_INCLUDE':nsis_path(output/'preflight.nsh')}
    for key,value in values.items():text=text.replace('@'+key+'@',value)
    require(not re.search(r'@[A-Z_]+@',text), 'Unresolved installer template')
    script=output/'preview.nsi';script.write_text(text)
    return script,installer

def package(args):
    require(not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT).strip(),
            'Commit source before producing installer/source artifacts')
    require(re.fullmatch(r'[0-9]{14}',args.sequence), 'Invalid frozen preview sequence')
    datetime.datetime.strptime(args.sequence,'%Y%m%d%H%M%S')
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
    qualification=read_json(args.main_qualification)
    require(qualification['exitCode']==0 and qualification['sessionId']>0,
            'Actual native main launch/close not qualified')
    compiler = read_json(args.compiler_qualification)
    collection = read_json(args.build_collection)
    required_runtime = qualify_compiler(compiler, collection, head,
        subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=ROOT,text=True).strip(),
        digest(args.compiler_qualification))
    build=read_json(args.build_inputs)
    for row in build['files']:
        require(digest(ROOT.joinpath(*relative(row['name']).parts))==row['sha256'],
                'Native input changed: '+row['name'])
    for p,sha in [(args.qt_source,QT_SOURCE),(args.sndfile_source,SNDFILE_SOURCE),(args.runtime,REDIST)]:
        require(digest(p)==sha, 'Pinned external source/runtime mismatch: '+p.name)
    manifest=read_json(args.deploy_manifest)
    qualified_dependencies(manifest)
    needs_worker=(ROOT/'ui/import_inspection_dialog.cpp').is_file()
    if needs_worker:
        qualify_worker(manifest,read_json(args.worker_qualification) if args.worker_qualification else None,head)
    needs_media_worker=(ROOT/'ui/import_media_dialog.cpp').is_file()
    if needs_media_worker:
        qualify_media_worker(manifest,read_json(args.media_worker_qualification) if args.media_worker_qualification else None,head)
    needs_copy_worker=(ROOT/'ui/media_copy_controller.cpp').is_file()
    if needs_copy_worker:
        qualify_copy_worker(manifest,read_json(args.copy_worker_qualification) if args.copy_worker_qualification else None,head)
    needs_stretch_worker=(ROOT/'ui/stretch_controller.cpp').is_file()
    if needs_stretch_worker:
        qualify_stretch_worker(manifest,read_json(args.stretch_worker_qualification) if args.stretch_worker_qualification else None,head,
                              subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=ROOT,text=True).strip())
    needs_protected_warp=needs_stretch_worker and (ROOT/'include/soundcurrent/protected_warp_render.hpp').is_file()
    protected_summary=None
    if needs_protected_warp:
        protected_summary=qualify_protected_worker(manifest,read_json(args.protected_warp_qualification) if args.protected_warp_qualification else None,head,
                              subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=ROOT,text=True).strip())
    needs_comp_worker=(ROOT/'include/soundcurrent/comp_transition_preparation.hpp').is_file()
    if needs_comp_worker:
        comp=next((r for r in manifest['files'] if r['path']=='sc-comp-span-worker.exe'),{})
        require(bool(comp) and qualification.get('executable_sha256',{}).get('sc-comp-span-worker.exe')==comp.get('sha256'),
                'Comp worker differs from the native main-workflow qualification')
    if (ROOT/'ui/timeline_waveforms.cpp').is_file():
        wave=next((r for r in manifest['files'] if r['path']=='sc-waveform-worker.exe'),{})
        require(bool(wave) and qualification.get('executable_sha256',{}).get('sc-waveform-worker.exe')==wave.get('sha256'),
                'Waveform worker differs from the native main-workflow qualification')
    row=next((r for r in manifest['files'] if r['path']=='soundcurrent-daw.exe'),{})
    require(row.get('sha256')==qualification['exeSha256'], 'Deployed main differs from qualified main')
    output=args.output.resolve();output.mkdir(parents=True,exist_ok=False)
    stage=output/'payload';stage.mkdir()
    deploy_payload(args.deploy_zip,manifest,stage,require_worker=needs_worker,
                   require_media_worker=needs_media_worker,require_copy_worker=needs_copy_worker,
                   require_stretch_worker=needs_stretch_worker,
                   require_comp_worker=needs_comp_worker,
                   require_waveform_worker=(ROOT/'ui/timeline_waveforms.cpp').is_file())
    legal=stage/'licenses';legal.mkdir()
    for name,path in {'GPL-3.0.txt':ROOT/'LICENSE','libsndfile-LGPL.txt':ROOT/'third_party/libsndfile/COPYING',
                      'libsamplerate-BSD-2-Clause.txt':ROOT/'third_party/libsamplerate/COPYING',
                      'RubberBand-GPL-2.0-or-later.txt':ROOT/'third_party/rubberband/COPYING',
                      'nlohmann-MIT.txt':ROOT/'third_party/nlohmann/LICENSE.MIT',
                      'equipment-GPL.txt':ROOT/'reuse/equipment/upstream/data/equipment/LICENSE',
                      'NSIS-copyright.txt':Path('/usr/share/doc/nsis/copyright')}.items():
        shutil.copy2(path,legal/name)
    with tarfile.open(args.qt_source) as t:
        for m in t.getmembers():
            if m.isfile() and m.name.startswith('qtbase-everywhere-src-6.12.0/LICENSES/'):
                (legal/('Qt-'+Path(m.name).name)).write_bytes(t.extractfile(m).read())
    with tarfile.open(args.sndfile_source) as t:
        for m in t.getmembers():
            if m.isfile() and m.name.endswith(('/src/ALAC/LICENSE','/src/GSM610/COPYRIGHT')):
                (legal/('libsndfile-'+m.name.split('/')[-2]+'.txt')).write_bytes(t.extractfile(m).read())
    shutil.copy2(ROOT/'THIRD-PARTY-NOTICES.md',stage/'THIRD-PARTY-NOTICES.md')
    shutil.copy2(args.qt_sdk/'sbom/qtbase-6.12.0.spdx.json',stage/'QtBase-SBOM.json')
    (stage/'SOURCE.txt').write_text(f'GPL-3.0-only. Exact SoundCurrent source: {head}\n'
        'Matching application/QtBase/libsndfile source archives are supplied beside setup.\n'
        'Shared Qt 6.12.0 and libsndfile 1.2.2 DLLs can be replaced/relinked.\n'
        'Qt deployment uses windeployqt without compiler runtimes. MSVC runtime is\n'
        f'the independent signed Microsoft {RUNTIME_VERSION} installer; no SDK is required.\n')
    script,installer=scripts(stage,output,args.sequence,head,args.runtime)
    r=subprocess.run(['makensis','-V3',script],capture_output=True,text=True)
    (output/'makensis.log').write_text(r.stdout+r.stderr)
    require(r.returncode==0,'Installer compiler failed; retained log')
    source=output/f'soundcurrent-daw-{args.sequence}-{head[:12]}-source.tar.gz'
    subprocess.run(['git','archive','--format=tar.gz','--prefix=soundcurrent-daw/','-o',str(source),head],cwd=ROOT,check=True)
    dependencies=output/'dependency-source';dependencies.mkdir()
    for p in [args.qt_source,args.sndfile_source]:shutil.copy2(p,dependencies/p.name)
    artifacts=[installer,source,*sorted(dependencies.iterdir())]
    receipt={'sourceHead':head,'sequence':args.sequence,'status':'prepared-local-unsigned-preview',
             'cleanInstallQualified':False,'nativeAudioReplayed':False,'releaseUploaded':False,
             'buildInputsReceiptSha256':digest(args.build_inputs),'mainQualificationSha256':digest(args.main_qualification),
             'workerQualificationSha256':digest(args.worker_qualification) if needs_worker else None,
             'mediaWorkerQualificationSha256':digest(args.media_worker_qualification) if needs_media_worker else None,
             'copyWorkerQualificationSha256':digest(args.copy_worker_qualification) if needs_copy_worker else None,
             'stretchWorkerQualificationSha256':digest(args.stretch_worker_qualification) if needs_stretch_worker else None,
             'protectedWarpQualificationSha256':digest(args.protected_warp_qualification) if needs_protected_warp else None,
             'protectedWarpQualification':protected_summary,
             'deploymentManifestSha256':digest(args.deploy_manifest),'officialRuntimeSha256':REDIST,
             'officialRuntimeVersion':RUNTIME_VERSION,'minimumCompilerRuntimeVersion':required_runtime,
             'compilerQualificationSha256':digest(args.compiler_qualification),
             'buildCollectionSha256':digest(args.build_collection),
             'installerSourceSha256':digest(ROOT/'packaging/windows/preview.nsi.in'),
             'payload':{p.relative_to(stage).as_posix():{'bytes':p.stat().st_size,'sha256':digest(p)} for p in sorted(stage.rglob('*')) if p.is_file()},
             'artifacts':{p.relative_to(output).as_posix():{'bytes':p.stat().st_size,'sha256':digest(p)} for p in artifacts},
             'upgradePolicy':'Separate owned preview directories; prior builds/projects/preferences preserved',
             'uninstallPolicy':'Exact generated owned-file list; no recursive project or preference deletion'}
    (output/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    (output/'SHA256SUMS').write_text(''.join(digest(p)+'  '+p.relative_to(output).as_posix()+'\n' for p in artifacts))
    print(json.dumps({'installer':str(installer),'source':str(source),'cleanInstallQualified':False}))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ['deploy-zip','deploy-manifest','build-inputs','main-qualification','qt-source','sndfile-source','runtime','qt-sdk','output','compiler-qualification','build-collection']:
        parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument('--worker-qualification',type=Path,
                        help='Actual matching-source native worker PID/exit/executable receipt')
    parser.add_argument('--media-worker-qualification',type=Path,
                        help='Matching native media checker PID/report/exit/source/executable receipt')
    parser.add_argument('--copy-worker-qualification',type=Path,
                        help='Matching native checked-copy PID/report/commit/source/executable receipt')
    parser.add_argument('--stretch-worker-qualification',type=Path,
                        help='Matching native render PID/exit/source/hash and verified artifact receipt')
    parser.add_argument('--protected-warp-qualification',type=Path,
                        help='Matching native v5 worker bank, source/hash, full PCM and refusal receipt')
    parser.add_argument('--sequence',required=True)
    package(parser.parse_args())
