from pathlib import Path
import json,subprocess,shlex,hashlib,shutil
r=Path('.cache/native-render-tail-stop');f=json.loads((r/'frozen-inputs.json').read_text());oldroot=Path('.cache/native-command-admission');prior=json.loads((oldroot/'corrected-qualified-profiles.json').read_text());prefix=['nice','-n','15','ionice','-c','2','-n','7'];commands=[];profiles={};executed=json.loads((r/'release-executed-commands.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def checked():
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==f['source']
 for x in f['selectedInputs']:assert sha(x['path'])==x['checkoutSha256']
for label,ctype,flags in [('release','Release',''),('sanitizer','Debug','-fsanitize=address,undefined -fno-omit-frame-pointer'),('tsan','Debug','-fsanitize=thread -fno-omit-frame-pointer -O1')]:
 b=(r/('qualified-'+label)).resolve();objects={};archives={};testobjects={};private={}
 def run(stage,argv,cwd=None):
  checked();cmd=prefix+argv;commands.append({'profile':label,'stage':stage,'argv':cmd,'cwd':str(cwd or Path.cwd())});(r/'qualification-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
  if label=='release':
   original=next(x for x in executed if x['profile']==label and x['stage']==stage);assert original['argv']==cmd and original['cwd']==str(cwd or Path.cwd());return
  with (r/(label+'-'+stage+'.log')).open('w') as out:p=subprocess.run(cmd,cwd=cwd,stdout=out,stderr=subprocess.STDOUT)
  assert p.returncode==0,(label,stage,p.returncode)
 print('Starting native',label,flush=True)
 run('configure',['cmake','-S','.','-B',str(b),'-G','Ninja','-DCMAKE_BUILD_TYPE='+ctype,'-DSC_BUILD_DESKTOP=ON','-DSC_BUILD_MEDIA=ON','-DCMAKE_CXX_FLAGS='+flags,'-DCMAKE_EXE_LINKER_FLAGS='+flags])
 gen=subprocess.check_output(['ninja','-C',str(b),'-t','commands','sc-native-monitor-startup-tests'],text=True);(r/(label+'-generated-commands.txt')).write_text(gen)
 for line in gen.splitlines():
  if ' -c ' not in line:continue
  a=shlex.split(line);obj=a[a.index('-o')+1]
  if obj.endswith(('tests/native_monitor_startup_tests.cpp.o','tests/native_monitor_recording_tests.cpp.o','ui/native_monitor_controller.cpp.o')):
   (b/obj).parent.mkdir(parents=True,exist_ok=True);run('compile-'+str(len(objects)),a,b);assert 'warning:' not in (r/(label+'-compile-'+str(len(objects))+'.log')).read_text();objects[obj]={'bytes':(b/obj).stat().st_size,'sha256':sha(b/obj)}
 assert len(objects)==3
 name='libsc-native-monitor-controller.a';run('controller-archive',['ar','r',name,*[n for n in objects if 'sc-native-monitor-controller.dir/' in n]],b);run('controller-index',['ranlib',name],b);private[name]=sha(b/name)
 line=next(x for x in gen.splitlines() if ' -o sc-native-monitor-startup-tests ' in x);a=shlex.split(line)[2:-2];p=prior['profiles'][label]
 for n,x in enumerate(a):
  if x.endswith('.a') and not Path(x).is_absolute() and x not in private:
   rec=p['readOnlyArchives'][x];assert sha(rec['path'])==rec['sha256'];a[n]=rec['path'];archives[x]=rec
  if x.endswith('.o') and x not in objects:
   rec=p['readOnlyObjects'][x];assert sha(rec['path'])==rec['sha256'];a[n]=rec['path'];testobjects[x]=rec
 run('link',a,b)
 run('tests',['env','SC_NATIVE_OWNER_FAILURE_EVIDENCE='+str(b/'owner-evidence'),'ctest','--test-dir',str(b),'-R','^native-monitor-startup$','--output-on-failure','--no-tests=error'])
 log=(b/'Testing/Temporary/LastTest.log').read_text();assert 'owned_native_recording source_rate=48000' in log and 'native_command_payload aggregate_credit=true' in log and 'guarded allocate/free/lock=0' in log
 evidence=list((b/'owner-evidence').iterdir());assert len(evidence)==1
 d=evidence[0];assert set(x.name for x in d.iterdir())=={'observed.json','native-run.json','journal.json'}
 observed=json.loads((d/'observed.json').read_text());assert not observed['observedBeforeCancellation'] and observed['sdkTailStopPending']==1 and observed['sdkTailStopServiced']==1 and observed['sdkTailAvailable']==32 and all(observed[n] for n in ['processingDone','diskDone','captureEnded','renderEnded'])
 for x in archives.values():assert sha(x['path'])==x['sha256']
 shutil.copyfile(b/'Testing/Temporary/LastTest.log',r/(label+'-LastTest.log'));shutil.copyfile(b/'CMakeCache.txt',r/(label+'-CMakeCache.txt'))
 profiles[label]={'objects':objects,'privateArchives':private,'readOnlyArchives':archives,'readOnlyObjects':testobjects,'exeSha256':sha(b/'sc-native-monitor-startup-tests'),'evidence':{n.name:{'bytes':n.stat().st_size,'sha256':sha(n),'path':str(n)}for n in d.iterdir()}}
 (r/'qualified-native.json').write_text(json.dumps({'source':f['source'],'tree':f['tree'],'sourceInputs':784,'profiles':profiles,'currentWindowsRuntimeQualified':False,'guiTsanQualified':False},indent=2)+'\n');print('Passed native',label,flush=True)
