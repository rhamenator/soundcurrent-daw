from pathlib import Path
import json,subprocess,shlex,hashlib
r=Path('.cache/native-render-tail-stop');b=(r/'reproducer-fair-source-release').resolve();q=json.loads(Path('.cache/native-window-integration/qualified-release.json').read_text());f=json.loads(Path('.cache/native-window-integration/frozen-inputs.json').read_text());old=json.loads(Path('.cache/native-recording-panel/qualified-profiles.json').read_text())['profiles']['release'];prefix=['nice','-n','15','ionice','-c','2','-n','7'];commands=[];objects={};borrowed={};testobjects={};sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
changed={'tests/fake_native_monitor_streams.hpp','tests/native_monitor_recording_tests.cpp','tests/native_monitor_startup_tests.cpp'}
for x in f['selectedInputs']:
 if x['path'] not in changed:assert sha(x['path'])==x['checkoutSha256'],x['path']
(r/'reproducer-source.diff').write_bytes(subprocess.check_output(['git','diff','HEAD']));(r/'reproducer-inputs.json').write_text(json.dumps({'parent':q['source'],'changed':{n:sha(n)for n in changed},'unchanged784InputsExceptChangedTestsVerified':True},indent=2)+'\n')
def run(stage,argv,cwd=None,expected=0):
 cmd=prefix+argv;commands.append({'stage':stage,'argv':cmd,'cwd':str(cwd or Path.cwd())});(r/'reproducer-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 with (r/(stage+'.log')).open('w') as out:p=subprocess.run(cmd,cwd=cwd,stdout=out,stderr=subprocess.STDOUT)
 assert p.returncode==expected,(stage,p.returncode)
if not (b/'build.ninja').exists():run('configure',['cmake','-S','.','-B',str(b),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DSC_BUILD_DESKTOP=ON','-DSC_BUILD_MEDIA=ON'])
gen=subprocess.check_output(['ninja','-C',str(b),'-t','commands','sc-native-monitor-startup-tests'],text=True);(r/'reproducer-generated-commands.txt').write_text(gen)
for line in gen.splitlines():
 if ' -c ' not in line:continue
 a=shlex.split(line);obj=a[a.index('-o')+1]
 if obj.endswith(('tests/native_monitor_startup_tests.cpp.o','tests/native_monitor_recording_tests.cpp.o')):
  (b/obj).parent.mkdir(parents=True,exist_ok=True)
  if not (b/obj).exists():run('compile-'+str(len(objects)),a,b)
  objects[obj]=sha(b/obj)
assert len(objects)==2
line=next(x for x in gen.splitlines() if ' -o sc-native-monitor-startup-tests ' in x);a=shlex.split(line)[2:-2]
for n,x in enumerate(a):
 if x.endswith('.a') and not Path(x).is_absolute():
  if x in q['archives']:
   p=Path('.cache/native-window-integration/build-release')/x;assert sha(p)==q['archives'][x];a[n]=str(p.resolve());borrowed[x]={'path':a[n],'sha256':sha(p)}
  else:
   rec=old['readOnlyArchives'][x];assert sha(rec['path'])==rec['sha256'];a[n]=rec['path'];borrowed[x]=rec
 if x.endswith('.o') and x not in objects:
  rec=old['readOnlyObjects'][x];assert sha(rec['path'])==rec['sha256'];a[n]=rec['path'];testobjects[x]=rec
run('link',a,b)
run('forced-test',[str(b/'sc-native-monitor-startup-tests'),'--render-tail-stop-only'],expected=1)
s=(r/'forced-test.log').read_text();assert 'Owner timeout' in s and 'sdk_tail_stop_pending=1 sdk_tail_frames=32' in s and 'stop_planned=1' in s
for rec in borrowed.values():assert sha(rec['path'])==rec['sha256']
(r/'reproduced.json').write_text(json.dumps({'objects':objects,'archives':borrowed,'testObjects':testobjects,'exeSha256':sha(b/'sc-native-monitor-startup-tests'),'expectedExit':1,'tailStopCycleReproduced':True,'originalFiveSecondLimitUnchanged':True},indent=2)+'\n');print('Original EOF cycle deterministically reproduced with 32-frame tail, planned Stop and no capture end')
