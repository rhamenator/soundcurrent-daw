from pathlib import Path
import json,subprocess,shlex,hashlib,shutil
r=Path('.cache/native-render-tail-stop');f=json.loads((r/'frozen-inputs.json').read_text());q=json.loads(Path('.cache/native-window-integration/qualified-release.json').read_text());b=(r/'gui-release').resolve();prefix=['nice','-n','15','ionice','-c','2','-n','7'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();commands=[];objects={};archives={};borrowed={}
def run(stage,argv,cwd=None):
 for x in f['selectedInputs']:assert sha(x['path'])==x['checkoutSha256']
 cmd=prefix+argv;commands.append({'stage':stage,'argv':cmd,'cwd':str(cwd or Path.cwd())});(r/'gui-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 with (r/('gui-'+stage+'.log')).open('w') as out:p=subprocess.run(cmd,cwd=cwd,stdout=out,stderr=subprocess.STDOUT)
 assert p.returncode==0,(stage,p.returncode)
run('configure',['cmake','-S','.','-B',str(b),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DSC_BUILD_DESKTOP=ON','-DSC_BUILD_MEDIA=ON'])
gen=subprocess.check_output(['ninja','-C',str(b),'-t','commands','sc-native-panel-tests','sc-localization-tests','sc-ui-tests'],text=True);(r/'gui-generated-commands.txt').write_text(gen)
# Generate only actual Qt resource intermediates; engine/dependency archives
# stay read-only. The same GUI policy is compiled on every GUI library.
for line in gen.splitlines():
 if 'rcc' in line and ' -c ' not in line:
  a=shlex.split(line);assert a[0]=='cd' and a[2]=='&&';a=a[3:];run('resource-'+str(len(commands)),a,b)
for line in gen.splitlines():
 if ' -c ' not in line:continue
 a=shlex.split(line);obj=a[a.index('-o')+1]
 if any(x in obj for x in ['sc-ui-','sc-native-panel-tests.dir/','sc-localization-tests.dir/','sc-ui-tests.dir/']):
  if 'sc-ui-' in obj or 'studio_window.cpp.o' in obj or 'localization_tests.cpp.o' in obj:assert '-DQT_NO_KEYWORDS' in a
  (b/obj).parent.mkdir(parents=True,exist_ok=True);run('compile-'+str(len(objects)),a,b);objects[obj]={'bytes':(b/obj).stat().st_size,'sha256':sha(b/obj)}
for target in sorted({n.split('/')[1][:-4] for n in objects if n.split('/')[1].startswith('sc-ui-')}):
 name='lib'+target+'.a';run(target+'-archive',['ar','r',name,*[n for n in objects if target+'.dir/' in n]],b);run(target+'-index',['ranlib',name],b);archives[name]=sha(b/name)
for i,line in enumerate(x for x in gen.splitlines() if any(' -o '+n+' ' in x for n in ['sc-native-panel-tests','sc-localization-tests','sc-ui-tests'])):
 a=shlex.split(line)[2:-2]
 for n,x in enumerate(a):
  if x.endswith('.a') and not Path(x).is_absolute() and x not in archives:
   p=Path('.cache/native-window-integration/build-release')/x
   if x in q['archives']:assert sha(p)==q['archives'][x]
   else:
    old=json.loads(Path('.cache/native-command-admission/corrected-qualified-profiles.json').read_text())['profiles']['release']['readOnlyArchives'][x];assert sha(old['path'])==old['sha256'];p=Path(old['path'])
   a[n]=str(p.resolve());borrowed[x]={'path':a[n],'sha256':sha(p)}
 run('link-'+str(i),a,b)
run('tests',['env','QT_QPA_PLATFORM=offscreen','ctest','--test-dir',str(b),'-R','^(desktop-native-recording-panel|desktop-localization|desktop-loop-controls|desktop-ui)$','--output-on-failure','--no-tests=error'])
for x in borrowed.values():assert sha(x['path'])==x['sha256']
shutil.copyfile(b/'Testing/Temporary/LastTest.log',r/'gui-LastTest.log');shutil.copyfile(b/'CMakeCache.txt',r/'gui-CMakeCache.txt')
(r/'qualified-gui.json').write_text(json.dumps({'source':f['source'],'tree':f['tree'],'objects':objects,'privateArchives':archives,'readOnlyArchives':borrowed,'exeHashes':{n:sha(b/n)for n in ['sc-native-panel-tests','sc-localization-tests','sc-ui-tests']},'qtNoKeywordsPolicyQualifiedLocally':True,'originalFailedLocalizationIncludeOrderCompiled':True,'currentWindowsRuntimeQualified':False,'guiTsanQualified':False},indent=2)+'\n');print('Current GUI macro policy, localization, main-window and original desktop tests passed',flush=True)
