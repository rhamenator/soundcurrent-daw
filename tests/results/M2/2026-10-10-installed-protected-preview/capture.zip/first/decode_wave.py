import struct,math,hashlib
sha=lambda b:hashlib.sha256(b).hexdigest()
def wave(p):
 b=p.read_bytes();assert b[:4] in (b'RIFF',b'RF64') and b[8:12]==b'WAVE';o=12;fmt=None;data=None;d64=None
 while o+8<=len(b):
  tag,n=struct.unpack_from('<4sI',b,o);o+=8
  if tag==b'ds64':d64=struct.unpack_from('<QQQ',b,o)
  if tag==b'data' and n==0xffffffff:assert d64;n=d64[1]
  assert o+n<=len(b)
  chunk=b[o:o+n]
  if tag==b'fmt ':fmt=struct.unpack_from('<HHIIHH',chunk);assert fmt[0]==3 or (fmt[0]==65534 and struct.unpack_from('<I',chunk,24)[0]==3)
  if tag==b'data':assert data is None;data=chunk
  o+=n+(n&1)
 assert o==len(b) and fmt and data is not None
 assert fmt[5]==32 and fmt[4]==fmt[1]*4 and fmt[3]==fmt[2]*fmt[4]
 samples=struct.unpack('<'+'f'*(len(data)//4),data);assert all(math.isfinite(s) for s in samples)
 return {'channels':fmt[1],'rate':fmt[2],'frames':len(data)//fmt[4],'peak':max(abs(s) for s in samples),'fileSha256':sha(b),'sampleSha256':sha(data)},data
