set -eu
cd /home/preview
xdotool mousemove 721 492 click 1
n=0
while test ! -f project-été-Κиїв-mix.wav && test "$n" -lt 200; do n=$((n+1)); sleep .02; done
test -f project-été-Κиїв-mix.wav
sleep .3
import -window root exported.png
cp project-été-Κиїв/project.json before-reopen-project.json
sha256sum project-été-Κиїв/media/raw-été.wav > raw-before-reopen.sha256
window=$(head -n1 window-id.txt)
xdotool windowfocus "$window" key ctrl+q
