set -eu
cd /home/preview
window=$(head -n1 dialog-id.txt)
xdotool windowfocus "$window"
xdotool mousemove 540 32 click 1 key ctrl+a type --clearmodifiers '3'
xdotool mousemove 540 62 click 1 key ctrl+a type --clearmodifiers '2'
xdotool mousemove 138 225 click 1
sleep .2
import -window root marker-mode.png
