set -eu
cd /home/preview
window=$(head -n1 dialog-id.txt)
xdotool windowfocus "$window"
xdotool mousemove 460 274 click 1 key F2 ctrl+a type --clearmodifiers '4096'
xdotool key Return
xdotool mousemove 700 274 click 1 key F2 ctrl+a type --clearmodifiers '6144'
xdotool key Return
import -window root marker-inputs.png
(
  n=0
  while test "$n" -lt 2000; do
    pid=$(pgrep -f '^/usr/bin/sc-stretch-render-worker' | head -n1 || true)
    if test -n "$pid" && test -r "/proc/$pid/status"; then
      echo "$pid" > helper-pid.txt
      cat "/proc/$pid/status" > helper-status.txt
      readlink "/proc/$pid/exe" > helper-executable.txt
      tr '\000' '\n' < "/proc/$pid/cmdline" > helper-command.txt
      exit 0
    fi
    n=$((n+1)); sleep .001
  done
  exit 1
) &
observer=$!
xdotool mousemove 210 630 click 1
wait "$observer"
n=0
while test "$(find project-été-Κиїв/media/derived -name complete.json | wc -l)" -ne 1; do
  test "$n" -lt 200; n=$((n+1)); sleep .05
done
sleep .2
import -window root rendered-markers.png
