#!/bin/sh
set -eu
cd /home/preview
export DISPLAY=:94 XDG_RUNTIME_DIR=/home/preview/run XDG_CONFIG_HOME=/home/preview/config
id > identity.txt
cat /proc/self/status > user-process-status.txt
test ! -e /dev/snd
pipewire -c /home/preview/pipewire.conf > pipewire.log 2>&1 &
pw_pid=$!
Xvfb :94 -screen 0 1280x720x24 -nolisten tcp > xvfb.log 2>&1 &
xvfb_pid=$!
trap 'kill "$pw_pid" "$xvfb_pid" 2>/dev/null || true' EXIT
sleep 1
pw-dump > graph-before.json
/usr/bin/soundcurrent-daw --language en /home/preview/project-été-Κиїв > application.log 2>&1 &
app_pid=$!
echo "$app_pid" > app-pid.txt
trap 'kill "$app_pid" "$pw_pid" "$xvfb_pid" 2>/dev/null || true' EXIT
sleep 2
xdotool search --onlyvisible --name '^SoundCurrent DAW' > window-id.txt
import -window root opened.png
touch ready
wait "$app_pid"
echo "$?" > first-exit.txt
pw-dump > graph-after-first.json

