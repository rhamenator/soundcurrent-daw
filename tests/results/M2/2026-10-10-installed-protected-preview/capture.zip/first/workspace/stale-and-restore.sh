set -eu
cd /home/preview
window=$(head -n1 dialog-id.txt)
xdotool windowfocus "$window"
xdotool mousemove 700 274 click 1 key F2 ctrl+a type --clearmodifiers '8192'
xdotool key Return
sleep .2
import -window root stale-marker.png
xdotool mousemove 755 630 click 1
xdotool mousemove 400 630 click 1
sleep .2
cmp initial-project.json project-été-Κиїв/project.json
pw-dump > graph-stale-inputs.json
xdotool mousemove 700 274 click 1 key F2 ctrl+a type --clearmodifiers '6144'
xdotool key Return
sleep .2
import -window root restored-marker.png
cmp initial-project.json project-été-Κиїв/project.json
