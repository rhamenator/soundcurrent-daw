set -eu
cd /home/preview
window=$(head -n1 dialog-id.txt)
xdotool windowfocus "$window"
xdotool mousemove 400 630 click 1
sleep .5
import -window root audition-prepared.png
pw-dump > graph-audition-prepared.json
cmp initial-project.json project-été-Κиїв/project.json
xdotool mousemove 570 630 click 1
sleep .5
pw-dump > graph-audition-stopped.json
import -window root audition-stopped.png
xdotool mousemove 755 630 click 1
sleep .5
import -window root applied-unsaved.png
xdotool mousemove 820 658 click 1
window=$(head -n1 window-id.txt)
xdotool windowfocus "$window" key ctrl+s
sleep .3
cp project-été-Κиїв/project.json applied-project.json
import -window root applied-saved.png
xdotool key ctrl+z
sleep .3
xdotool key ctrl+s
sleep .3
cp project-été-Κиїв/project.json undone-project.json
import -window root undone.png
xdotool key ctrl+shift+z
sleep .3
xdotool key ctrl+s
sleep .3
cp project-été-Κиїв/project.json redone-project.json
import -window root redone.png
