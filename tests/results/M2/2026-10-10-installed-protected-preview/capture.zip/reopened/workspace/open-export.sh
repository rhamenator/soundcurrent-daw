set -eu
cd /home/preview
window=$(head -n1 dialog-id.txt)
xdotool windowfocus "$window" mousemove 820 658 click 1
window=$(head -n1 window-id.txt)
xdotool windowfocus "$window" key ctrl+shift+e
sleep .2
import -window root export-dialog.png
