from pathlib import Path
import subprocess,sys,json,datetime
root=Path.cwd();out=root/'.cache/protected-preview-gates/reopened-linux';name=sys.argv[1];script=out/'workspace'/(name+'.sh');assert script.exists()
pid=int((out/'namespace-target.txt').read_text());assert Path('/proc/'+str(pid)).exists()
cmd=['sudo','-n','nsenter','--target',str(pid),'--mount','--pid','--root','--wd=/','--setuid=1000','--setgid=1000','--','/usr/bin/env','HOME=/home/preview','XDG_RUNTIME_DIR=/home/preview/run','XDG_CONFIG_HOME=/home/preview/config','DISPLAY=:94','/bin/sh','-c',script.read_text()]
d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'script':str(script.relative_to(root))}
with (out/(name+'.log')).open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
d['exit_code']=r.returncode;(out/(name+'-command.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'name':name,'exit_code':r.returncode}));raise SystemExit(r.returncode)
