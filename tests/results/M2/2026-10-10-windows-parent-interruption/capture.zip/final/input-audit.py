from pathlib import Path
import hashlib,json,subprocess,sys
source=Path.home()/'soundcurrent-daw-stretch-f9a6353'
folder=Path.home()/'soundcurrent-parent-interruption-8fc9db6'
m=json.loads((folder/'compile-inputs.json').read_text(encoding='utf-8'))
for n,r in m.items():
 b=(source/n).read_bytes();assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256'],n
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=source,text=True).strip()
print('Native source inputs byte unchanged:',len(m))
