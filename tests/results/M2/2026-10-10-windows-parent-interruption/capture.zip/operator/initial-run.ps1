$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';$env:GIT_TERMINAL_PROMPT='0';$env:PYTHONUTF8='1'
(Get-Process -Id $PID).PriorityClass='BelowNormal'
$root=Join-Path $env:USERPROFILE 'soundcurrent-daw-stretch-f9a6353'
$out=Join-Path $env:USERPROFILE 'soundcurrent-parent-interruption-46a6d3f'
$sdk=Join-Path $env:USERPROFILE 'soundcurrent-daw-msvc-sdk-v1'
$env:PATH=$sdk+'\qt\bin;'+$sdk+'\sndfile-build-v2\Release;'+$env:PATH
Set-Location $root
if(!(Test-Path $out)) {throw 'Owned input folder missing'}
if(Test-Path (Join-Path $out 'running.json')) {throw 'Never restart an observed test session'}
& git -c core.fsmonitor=false -c core.fscache=false update-index --really-refresh
if($LASTEXITCODE -ne 0 -or (& git status --porcelain --untracked-files=no)) {throw 'Preserve unexpected source changes'}
& git fetch origin codex/stretch-parent-interruption
if($LASTEXITCODE -ne 0) {throw 'Fetch failed'}
& git checkout --detach 46a6d3f8f754e08785f2b841a6d18c1379bc0f5e
if($LASTEXITCODE -ne 0) {throw 'Checkout failed'}
$source=Get-Content -Encoding UTF8 -Raw (Join-Path $out 'source.json')|ConvertFrom-Json
if((& git rev-parse HEAD).Trim() -ne $source.head -or (& git rev-parse 'HEAD^{tree}').Trim() -ne $source.tree) {throw 'Wrong source revision/tree'}
& py -3 (Join-Path $out 'input-audit.py')
if($LASTEXITCODE -ne 0) {throw 'Native inputs differ before configure'}
[ordered]@{pid=$PID;startUtc=[DateTime]::UtcNow.ToString('o');sourceHead=$source.head;sourceTree=$source.tree;parallel=2;priority='BelowNormal';audioEndpointActivated=$false}|ConvertTo-Json|Set-Content (Join-Path $out 'running.json') -Encoding UTF8
$clock=[Diagnostics.Stopwatch]::StartNew()
try {
 & 'C:\Program Files\CMake\bin\cmake.exe' -S . -B build -G 'Visual Studio 17 2022' -A x64 -DSC_BUILD_DESKTOP=ON -DSC_BUILD_MEDIA=ON -DSC_BUILD_PIPEWIRE=OFF -DBUILD_TESTING=ON -DSC_BUILD_PROTECTED_WARP_PROBE=ON ('-DCMAKE_PREFIX_PATH='+$sdk+'\qt') ('-DSNDFILE_LIBRARY='+$sdk+'\sndfile-build-v2\Release\sndfile.lib')
 if($LASTEXITCODE -ne 0) {throw 'Configure failed'}
 & 'C:\Program Files\CMake\bin\cmake.exe' --build build --config Release --parallel 2 --target sc-stretch-parent-probe
 if($LASTEXITCODE -ne 0) {throw 'Native parent probe build failed'}
 [ordered]@{exitCode=0;elapsedSeconds=$clock.Elapsed.TotalSeconds;sourceHead=$source.head;sourceTree=$source.tree;probeSha256=(Get-FileHash build/Release/sc-stretch-parent-probe.exe -Algorithm SHA256).Hash.ToLowerInvariant();helperSha256=(Get-FileHash build/Release/sc-stretch-render-worker.exe -Algorithm SHA256).Hash.ToLowerInvariant();qtCoreSha256=(Get-FileHash (Join-Path $sdk 'qt/bin/Qt6Core.dll') -Algorithm SHA256).Hash.ToLowerInvariant();sndfileSha256=(Get-FileHash (Join-Path $sdk 'sndfile-build-v2/Release/sndfile.dll') -Algorithm SHA256).Hash.ToLowerInvariant()}|ConvertTo-Json|Set-Content (Join-Path $out 'build-terminal.json') -Encoding UTF8
 & py -3 tests/stretch_parent_interruption_windows.py build/Release/sc-stretch-parent-probe.exe build/Release/sc-stretch-render-worker.exe --retain (Join-Path $out 'observed')
 if($LASTEXITCODE -ne 0) {throw 'Actual Windows interruption acceptance failed'}
 & py -3 (Join-Path $out 'input-audit.py')
 if($LASTEXITCODE -ne 0) {throw 'Native inputs changed during acceptance'}
 [ordered]@{exitCode=0;elapsedSeconds=$clock.Elapsed.TotalSeconds;sourceHead=$source.head;sourceTree=$source.tree;audioEndpointActivated=$false;installedGuiQualified=$false;powerLossQualified=$false}|ConvertTo-Json|Set-Content (Join-Path $out 'terminal.json') -Encoding UTF8
} catch {
 [ordered]@{failed=$true;error=$_.Exception.Message;elapsedSeconds=$clock.Elapsed.TotalSeconds;sourceHead=$source.head}|ConvertTo-Json|Set-Content (Join-Path $out 'terminal.json') -Encoding UTF8;throw
}
