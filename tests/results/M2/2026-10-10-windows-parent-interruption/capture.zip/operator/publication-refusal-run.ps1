$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';$env:GIT_TERMINAL_PROMPT='0';$env:PYTHONUTF8='1'
(Get-Process -Id $PID).PriorityClass='BelowNormal'
$root=Join-Path $env:USERPROFILE 'soundcurrent-daw-stretch-f9a6353'
$out=Join-Path $env:USERPROFILE 'soundcurrent-parent-interruption-09d9b2a'
$prior=Join-Path $env:USERPROFILE 'soundcurrent-parent-interruption-46a6d3f'
$sdk=Join-Path $env:USERPROFILE 'soundcurrent-daw-msvc-sdk-v1'
$env:PATH=$sdk+'\qt\bin;'+$sdk+'\sndfile-build-v2\Release;'+$env:PATH
Set-Location $root
if(Test-Path (Join-Path $out 'running.json')) {throw 'Never restart an observed test session'}
$live=@(Get-Process -Name 'sc-stretch-parent-probe','sc-stretch-render-worker' -ErrorAction SilentlyContinue)
if($live.Count -ne 0) {throw 'Inspect prior actual process instances before retry'}
& git -c core.fsmonitor=false -c core.fscache=false update-index --really-refresh
if($LASTEXITCODE -ne 0 -or (& git status --porcelain --untracked-files=no)) {throw 'Preserve unexpected source changes'}
& git fetch origin codex/stretch-parent-interruption
if($LASTEXITCODE -ne 0) {throw 'Fetch failed'}
& git checkout --detach 09d9b2aa7e23268e99d974510902541516011dc7
if($LASTEXITCODE -ne 0) {throw 'Checkout failed'}
$source=Get-Content -Encoding UTF8 -Raw (Join-Path $out 'source.json')|ConvertFrom-Json
if((& git rev-parse HEAD).Trim() -ne $source.head -or (& git rev-parse 'HEAD^{tree}').Trim() -ne $source.tree) {throw 'Wrong source revision/tree'}
& py -3 (Join-Path $out 'input-audit.py')
if($LASTEXITCODE -ne 0) {throw 'Native inputs differ before test'}
$build=Get-Content -Encoding UTF8 -Raw (Join-Path $prior 'build-terminal.json')|ConvertFrom-Json
if($build.exitCode -ne 0 -or $build.sourceHead -ne $source.unchangedCompiledSourceCommit) {throw 'Prior actual build not qualified'}
if((Get-FileHash build/Release/sc-stretch-parent-probe.exe -Algorithm SHA256).Hash.ToLowerInvariant() -ne $build.probeSha256 -or (Get-FileHash build/Release/sc-stretch-render-worker.exe -Algorithm SHA256).Hash.ToLowerInvariant() -ne $build.helperSha256) {throw 'Native executable differs from actual build'}
Copy-Item -LiteralPath (Join-Path $prior 'build-terminal.json') -Destination (Join-Path $out 'inherited-build-terminal.json')
[ordered]@{pid=$PID;startUtc=[DateTime]::UtcNow.ToString('o');driverHead=$source.head;driverTree=$source.tree;compiledSourceHead=$build.sourceHead;compiledSourceTree=$build.sourceTree;priorProcessesAbsent=$true;compiledInputsChanged=$false;audioEndpointActivated=$false}|ConvertTo-Json|Set-Content (Join-Path $out 'running.json') -Encoding UTF8
$clock=[Diagnostics.Stopwatch]::StartNew()
try {
 & py -3 tests/stretch_parent_interruption_windows.py build/Release/sc-stretch-parent-probe.exe build/Release/sc-stretch-render-worker.exe --retain (Join-Path $out 'observed')
 if($LASTEXITCODE -ne 0) {throw 'Corrected actual Windows interruption acceptance failed'}
 & py -3 (Join-Path $out 'input-audit.py')
 if($LASTEXITCODE -ne 0) {throw 'Native inputs changed during acceptance'}
 [ordered]@{exitCode=0;elapsedSeconds=$clock.Elapsed.TotalSeconds;driverHead=$source.head;driverTree=$source.tree;compiledSourceHead=$build.sourceHead;audioEndpointActivated=$false;installedGuiQualified=$false;powerLossQualified=$false}|ConvertTo-Json|Set-Content (Join-Path $out 'terminal.json') -Encoding UTF8
} catch {
 [ordered]@{failed=$true;error=$_.Exception.Message;elapsedSeconds=$clock.Elapsed.TotalSeconds;driverHead=$source.head}|ConvertTo-Json|Set-Content (Join-Path $out 'terminal.json') -Encoding UTF8;throw
}
