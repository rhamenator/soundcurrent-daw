from pathlib import Path
import subprocess,json,hashlib,zipfile,io
r=Path('.cache/pipewire-monitor-controller/pr167-review');r.mkdir(exist_ok=True)
api=lambda tail:subprocess.check_output(['gh','api','repos/rhamenator/soundcurrent-daw/'+tail])
sha=lambda raw:hashlib.sha256(raw).hexdigest()
for name,tail in [('run','actions/runs/38324363198'),('jobs','actions/runs/38324363198/jobs'),('artifacts','actions/runs/38324363198/artifacts')]:
 (r/(name+'.json')).write_bytes(api(tail))
run=json.loads((r/'run.json').read_bytes());assert run['head_sha']=='ad5ae0b998e845c46443cafdf34706575395e242' and run['status']=='completed'
jobs=json.loads((r/'jobs.json').read_bytes())['jobs'];assert len(jobs)==4 and all(j['status']=='completed' for j in jobs)
for j in jobs:(r/('job-'+str(j['id'])+'.log')).write_bytes(api('actions/jobs/'+str(j['id'])+'/logs'))
for a in json.loads((r/'artifacts.json').read_bytes())['artifacts']:
 if a['name'] not in ['windows-native-packet-unit-log','windows-desktop-import-test-log']:continue
 label='native' if a['name']=='windows-native-packet-unit-log' else 'desktop'
 raw=api('actions/artifacts/'+str(a['id'])+'/zip');(r/(label+'-original.zip')).write_bytes(raw);members={}
 with zipfile.ZipFile(io.BytesIO(raw)) as z:
  for name in z.namelist():
   selected=name.endswith('LastTest.log') or name.startswith('manual-owner-') or ('native-owner-failure-evidence/' in name and name.endswith('.json')) or ('parent-observation-timing/' in name and name.endswith('.json')) or name.endswith('verified-runtime.json')
   if not selected:continue
   data=z.read(name);dest=label+'-artifact--'+name.replace('/','_');(r/dest).write_bytes(data);members[name]={'destination':dest,'bytes':len(data),'sha256':sha(data)}
 (r/(label+'-artifact-selected.json')).write_text(json.dumps({'artifact':a['id'],'archiveBytes':len(raw),'archiveSha256':sha(raw),'originalMembers':members},indent=2)+'\n')
print('Retained PR167 four terminal job logs and selected original Windows artifacts')
