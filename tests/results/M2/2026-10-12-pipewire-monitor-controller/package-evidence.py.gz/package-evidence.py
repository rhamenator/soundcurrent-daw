from pathlib import Path
import gzip,hashlib,json,subprocess
r=Path('.cache/pipewire-monitor-controller');d=Path('tests/results/M2/2026-10-12-pipewire-monitor-controller');d.mkdir(parents=True,exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest();f=json.loads((r/'frozen-inputs.json').read_text());members={}
for x in f['selectedInputs']:assert sha(Path(x['path']).read_bytes())==x['checkoutSha256']
def add(n,b):
 z=gzip.compress(b,mtime=0);p=d/(n+'.gz');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z);members[n+'.gz']={'bytes':len(z),'sha256':sha(z),'originalBytes':len(b),'originalSha256':sha(b)}
for n in ['frozen-inputs.json','source-delta.diff','configure.log','build.log','current-build.log','final-build.log','qualified-build.log','final-fixture-build.log','native-controller-build.log','tests.log','panel-tests.log','localization-update.log','localization-check.log','localization-failures.log','localization-final-update.log','private-pipewire.conf','recording-owned-runtime.log','recording-owned-runtime.json','recording-owned-wrapper.log','recording-owned-daemon.log','run-owned-recording.py','windows-qualification.json','windows-qualification.log','qualify-windows.py','freeze-inputs.py','retain167.py','retain167.log','package-evidence.py']:
 add(n,(r/n).read_bytes())
for p in r.glob('windows-compile-*.log'):add(p.name,p.read_bytes())
for folder in ['initial-header-failure','initial-factory-warning','initial-delay-warning','pr167-review']:
 for p in sorted((r/folder).iterdir()):
  if p.is_file() and p.suffix in ['.json','.log','.hpp','.cpp']:add(folder+'/'+p.name,p.read_bytes())
for n in ['CMakeCache.txt','Testing/Temporary/LastTest.log']:add('release/'+n,(r/'release'/n).read_bytes())
add('release/generated-commands.log',subprocess.check_output(['ninja','-C',str(r/'release'),'-t','commands']))
outputs={p.name:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in list((r/'release').glob('*.a'))+list((r/'release').glob('sc-*-tests'))+list((r/'release').glob('sc-*-fixture'))+[r/'release/soundcurrent-daw'] if p.is_file()};add('release/output-hashes.json',json.dumps(outputs,indent=2).encode())
summary={'implementation':f['source'],'inputs':len(f['selectedInputs']),'release':{'tests':5,'passed':5,'seconds':30.61},'qtPanel':{'tests':1,'passed':1,'seconds':13.16,'sdk':'simulated','physical':False},'currentSanitizers':'pending','windows':json.loads((r/'windows-qualification.json').read_text()),'privateControllerPipeWire':{'sdk':'1.6.2','raw':99072,'monitorAndSink':8192,'captureReceipts':387,'renderReceipts':408,'durableReopen':True,'callbackAllocateFreeLock':0,'physical':False},'originalPr167':json.loads((r/'pr167-review/terminal-conclusions.json').read_text()),'catalogs':{'count':34,'keys':985,'nativeReviewed':0,'fullyUiQualified':0},'scope':'typed PW controller/Qt prepare-record-inspect-originalExport-reopen-close; timelineadmission/projectevidence REQUIREDnext; fullparity incomplete','originalRunnerTimingCause':'not proven; old simulated overdue scheduling hazard corrected with600msregression, same gates','payload':'text/log/config/metadata/hash only; failed actual WAV/bin/ZIP local only','members':members}
(d/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for n,row in members.items():
 b=(d/n).read_bytes();assert sha(b)==row['sha256'];raw=gzip.decompress(b);assert len(raw)==row['originalBytes'] and sha(raw)==row['originalSha256']
print('Verified',len(members),'bound evidence members;',len(f['selectedInputs']),'source inputs unchanged')
