#define main stateCorpusMain
#include "/home/rich/dev/soundcurrent-daw/tests/comp_window_state_tests.cpp"
#undef main
#include <filesystem>
#include <fstream>
#include <openssl/sha.h>
void ownedMedia(const std::filesystem::path &root,Session &s) {
    for(auto &a:s.assets) {
        const auto bytes=std::size_t(a.frames)*a.layout.channels*4;
        std::vector<unsigned char> wave(44+bytes,0);
        const auto word=[&](std::size_t at,std::uint32_t v,unsigned count){
            for(unsigned n=0;n<count;++n)wave[at+n]=static_cast<unsigned char>(v>>(n*8));
        };
        std::copy_n("RIFF",4,wave.begin());word(4,std::uint32_t(36+bytes),4);
        std::copy_n("WAVEfmt ",8,wave.begin()+8);word(16,16,4);word(20,3,2);
        word(22,a.layout.channels,2);word(24,a.sampleRate,4);word(28,a.sampleRate*a.layout.channels*4,4);
        word(32,a.layout.channels*4,2);word(34,32,2);std::copy_n("data",4,wave.begin()+36);word(40,std::uint32_t(bytes),4);
        const auto path=root/a.relativePath;std::filesystem::create_directories(path.parent_path());
        std::ofstream f(path,std::ios::binary);f.write(reinterpret_cast<const char *>(wave.data()),std::streamsize(wave.size()));f.close();
        if(!f)throw std::runtime_error("Owned test WAV write failed");
        unsigned char digest[32];SHA256(wave.data(),wave.size(),digest);const char *hex="0123456789abcdef";a.sha256.clear();
        for(auto byte:digest){a.sha256+=hex[byte>>4];a.sha256+=hex[byte&15];}
    }
    auto &c=s.tracks[0].clips[0];c.stretch->sourceSha256=s.assets[0].sha256;c.compHandles->baseSha256=s.assets[1].sha256;
}

int main(){try{
    const auto root=std::filesystem::temp_directory_path()/
        (std::filesystem::path(u8"sc-comp-window-project-é-日本-").native()+std::filesystem::path(Id::generate().str()).native());
    std::filesystem::create_directory(root);
    for(unsigned mode=0;mode<3;++mode){
        ProjectStore store(root/std::to_string(mode));auto initial=makeOneTrackSession("Previous","Track");
        auto expected=fixture(mode);ownedMedia(store.root(),expected);store.save(initial);store.save(expected);
        if(store.load()!=expected || store.loadPrevious()!=initial)throw std::runtime_error("Actual window file generations differ");
        auto next=expected;next.name="Next — Ελληνικά";store.save(next);
        if(store.load()!=next || store.loadPrevious()!=expected)throw std::runtime_error("Previous handle-window generation differs");
    }
    std::filesystem::remove_all(root);
    std::cout<<"actual_project_file_window_cases=3 previous_generation_cases=6 unicode_paths=true owned_silent_wav_fixtures=true actual_dsp_render=false\n";
    return 0;
}catch(const std::exception &e){std::cerr<<e.what()<<'\n';return 1;}}
