#define main stateCorpusMain
#include "/home/rich/dev/soundcurrent-daw/tests/comp_window_state_tests.cpp"
#undef main
#include <filesystem>
int main(){try{
    const auto root=std::filesystem::temp_directory_path()/
        (std::filesystem::path(u8"sc-comp-window-project-é-日本-").native()+std::filesystem::path(Id::generate().str()).native());
    std::filesystem::create_directory(root);
    for(unsigned mode=0;mode<3;++mode){
        ProjectStore store(root/std::to_string(mode));auto initial=makeOneTrackSession("Previous","Track");
        auto expected=fixture(mode);store.save(initial);store.save(expected);
        if(store.load()!=expected || store.loadPrevious()!=initial)throw std::runtime_error("Actual window file generations differ");
        auto next=expected;next.name="Next — Ελληνικά";store.save(next);
        if(store.load()!=next || store.loadPrevious()!=expected)throw std::runtime_error("Previous handle-window generation differs");
    }
    std::filesystem::remove_all(root);
    std::cout<<"actual_project_file_window_cases=3 previous_generation_cases=6 unicode_paths=true actual_audio_render=false\n";
    return 0;
}catch(const std::exception &e){std::cerr<<e.what()<<'\n';return 1;}}
