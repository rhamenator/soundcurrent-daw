from pathlib import Path
import subprocess,time,json,hashlib
r=Path(__file__).resolve().parent;repo=r.parents[1];build=repo/'.cache/take-preview-linux/build'
corpus=build/'comp-transition-ui-evidence';before=set(corpus.iterdir()) if corpus.exists() else set()
command=['ctest','--test-dir',str(build),'--output-on-failure','--no-tests=error','-j','1','-R','^(desktop-comp-transition-create|localization-catalogs|localization-catalog-safety)$']
# Discover exact registered localization checks rather than silently skipping one.
listing=json.loads(subprocess.check_output(['ctest','--test-dir',str(build),'--show-only=json-v1'],text=True))
names=[t['name'] for t in listing['tests'] if t['name']=='desktop-comp-transition-create' or 'catalog' in t['name']]
command[-1]='^('+'|'.join(names)+')$';assert 'desktop-comp-transition-create' in names and len(names)>=3,names
start=time.monotonic()
with (r/'tests.stdout').open('w') as out,(r/'tests.stderr').open('w') as err:result=subprocess.run(command,stdout=out,stderr=err)
(r/'LastTest.log').write_bytes((build/'Testing/Temporary/LastTest.log').read_bytes())
receipt=dict(command=command,exitCode=result.returncode,seconds=time.monotonic()-start,newEvidence=[str(p) for p in set(corpus.iterdir())-before],testNames=names,sourceInputs={str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [repo/'ui/studio_window.cpp',repo/'ui/studio_window.hpp',repo/'tests/comp_transition_ui_tests.cpp']},nativeWindowsExecuted=False)
(r/'tests.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));assert result.returncode==0
