from pathlib import Path
import json,hashlib,subprocess,zipfile
r=Path('.cache/comp-render-progress-329');scope=Path(json.loads((r/'tests.json').read_text())['newEvidence'][0]);dest=Path('tests/results/M2/2026-10-15-comp-render-progress');dest.mkdir(exist_ok=False)
files={p.name:p.read_bytes() for p in r.iterdir() if p.is_file()}
files['source.patch']=subprocess.check_output(['git','diff','--','ui/studio_window.cpp','ui/studio_window.hpp','tests/comp_transition_ui_tests.cpp','localization/source-inventory.json'])
corpus=[]
for p in sorted(scope.rglob('*')):
 if not p.is_file():continue
 b=p.read_bytes();name=p.relative_to(scope).as_posix();published=p.suffix in ('.json','.png','.stdout','.stderr')
 corpus.append(dict(path=name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),published=published))
 if published:files['workflow/'+name]=b
files['generated-file-inventory.json']=(json.dumps(corpus,ensure_ascii=False,indent=2)+'\n').encode()
rows=[dict(path=n,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()) for n,b in files.items()]
files['payload-manifest.json']=(json.dumps(rows,ensure_ascii=False,indent=2)+'\n').encode()
archive=dest/'acceptance.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
 for n,b in files.items():z.writestr(n,b)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for row in rows:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
out=dict(archive=archive.name,bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),entries=len(files),baseHead='edc08502e8582ee062a94f0de1f2211db44528dd',testsPassed=3,desktopCases=8,desktopChecks=228,generatedFiles=len(corpus),allGeneratedMediaPublished=False,nativeWindowsExecuted=False,installedPreviewUpdated=False)
(dest/'manifest.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
