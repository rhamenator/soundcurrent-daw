from pathlib import Path
import json,subprocess,time,statistics,hashlib,zipfile
r=Path(__file__).resolve().parent;repo=r.parents[1];build=repo/'.cache/take-preview-linux/build';old=repo/'.cache/comp-timing-326';root=repo/'.cache/windows-installed-portable-325/observed/retired-325/project-été-Κиїв';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# Bind the original project to the pre-existing checkpoint327 transport archive.
zpath=repo/'.cache/windows-comp-timing-327/inputs/project.zip';assert sha(zpath)==json.loads((zpath.parent/'inputs.json').read_text())['project.zip']
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None
 expected={n.replace('\\','/'):hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if not n.endswith('/')}
actual={str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file()}
# The archive carries files relative to the project root.
assert expected==actual,(len(expected),len(actual),list(expected)[:1])
(r/'project-inputs.json').write_text(json.dumps(actual,indent=2)+'\n')
args=json.loads((old/'build-command.json').read_text());args[args.index('-o')+1]=str(r/'probe-batched')
with (r/'link-batched.log').open('w') as f:subprocess.run(args,cwd=build,stdout=f,stderr=subprocess.STDOUT,check=True)
args=json.loads((r/'hash-build-command.json').read_text());args[args.index('-o')+1]=str(r/'hash-probe-batched')
with (r/'link-hash-batched.log').open('w') as f:subprocess.run(args,cwd=build,stdout=f,stderr=subprocess.STDOUT,check=True)
with (r/'hash-batched.ndjson').open('w') as out,(r/'hash-batched.stderr').open('w') as err:subprocess.run([str(r/'hash-probe-batched'),str(root),'a1a283c7-c9e5-4d5f-bc41-0edadd727ee7'],stdout=out,stderr=err,check=True,timeout=60)
rows=[]
for iteration in range(3):
 for label,binary in ([('before',old/'probe-changed'),('after',r/'probe-batched')] if iteration%2==0 else [('after',r/'probe-batched'),('before',old/'probe-changed')]):
  name=f'{label}-{iteration}';start=time.monotonic()
  with (r/(name+'.ndjson')).open('w') as out,(r/(name+'.stderr')).open('w') as err:proc=subprocess.run([str(binary),str(root),'a1a283c7-c9e5-4d5f-bc41-0edadd727ee7'],stdout=out,stderr=err,timeout=60)
  duration=time.monotonic()-start;events=[json.loads(x) for x in (r/(name+'.ndjson')).read_text().splitlines()]
  assert proc.returncode==0 and events[-1]['event']=='complete' and events[-1]['comparedSamples']==16256
  rows.append(dict(version=label,iteration=iteration,seconds=duration,phases=[x for x in events if x['event']=='end']))
assert actual=={str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file()}
medians={k:statistics.median(x['seconds'] for x in rows if x['version']==k) for k in ['before','after']}
hashes={}
for name,file in [('before','hash-profile.ndjson'),('after','hash-batched.ndjson')]:
 es=[json.loads(l) for l in (r/file).read_text().splitlines()];assert es[-1]['event']=='complete' and es[-1]['comparedSamples']==16256;cs=[x for x in es if x['event']=='hash-counter'];hashes[name]=dict(calls=sum(x['calls'] for x in cs),bytes=sum(x['bytes'] for x in cs),hashSeconds=sum(x['nanoseconds'] for x in cs)/1e9)
report=dict(rows=rows,medianSeconds=medians,ratio=medians['after']/medians['before'],hashCounters=hashes,projectFilesUnchanged=len(actual),comparedSamples=16256,nativeWindowsMeasured=False,binaries={str(p.relative_to(repo)):sha(p) for p in [old/'probe-changed',r/'probe-batched',r/'hash-probe',r/'hash-probe-batched']})
(r/'comparison.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['rows','binaries']},indent=2))
