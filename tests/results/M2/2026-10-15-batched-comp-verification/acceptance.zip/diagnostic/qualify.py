from pathlib import Path
import subprocess,json,time,hashlib
r=Path(__file__).resolve().parent;repo=r.parents[1];build=repo/'.cache/take-preview-linux/build'
targets=['sc-comp-pair-assembly-tests','sc-comp-assembly-job-tests','sc-comp-regeneration-history-tests','sc-comp-span-worker']
with (r/'build-qualified.log').open('w') as f:subprocess.run(['cmake','--build',str(build),'--target',*targets,'--parallel','1'],stdout=f,stderr=subprocess.STDOUT,check=True)
pattern='^(comp-verified-pair-assembly|comp-owned-assembly-publication|comp-protected-assembly-publication|comp-paired-history-review)$'
command=['ctest','--test-dir',str(build),'--output-on-failure','--no-tests=error','-j','1','-R',pattern]
selected=json.loads(subprocess.check_output(command[:3]+['--show-only=json-v1','-R',pattern],text=True));assert len(selected['tests'])==4
(r/'selected-tests.json').write_text(json.dumps(selected,indent=2))
start=time.monotonic()
with (r/'tests.stdout').open('w') as out,(r/'tests.stderr').open('w') as err:code=subprocess.call(command,stdout=out,stderr=err)
(r/'LastTest.log').write_bytes((build/'Testing/Temporary/LastTest.log').read_bytes())
(r/'tests.json').write_text(json.dumps(dict(command=command,exitCode=code,seconds=time.monotonic()-start),indent=2)+'\n');print((r/'tests.stdout').read_text());assert code==0
