from pathlib import Path
import json,subprocess,hashlib,zipfile
r=Path(__file__).resolve().parent;repo=r.parents[1];out=repo/'tests/results/M2/2026-10-15-batched-comp-verification';out.mkdir(parents=True,exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest();files={}
assert json.loads((r/'tests.json').read_text())['exitCode']==0
comparison=json.loads((r/'comparison.json').read_text());assert comparison['projectFilesUnchanged']==225 and comparison['comparedSamples']==16256
for p in r.iterdir():
 if p.is_file() and p.suffix in ['.py','.cpp','.log','.txt','.json','.ndjson','.stdout','.stderr']:files['diagnostic/'+p.name]=p.read_bytes()
paths=['include/soundcurrent/comp_pair_assembly.hpp','src/comp_pair_assembly.cpp','src/comp_assembly_job.cpp','tests/comp_pair_assembly_tests.cpp']
files['source.patch']=subprocess.check_output(['git','diff','--',*paths],cwd=repo)
for n in paths:files['source/'+n]=(repo/n).read_bytes()
baseline=json.loads((repo/'.cache/comp-timing-326/timing.json').read_text())
assert comparison['binaries']['.cache/comp-timing-326/probe-changed']==baseline['binaries']['probe-changed']
for n,expected in baseline['sourceInputs'].items():
 if n in paths:
  b=subprocess.check_output(['git','show','HEAD:'+n],cwd=repo)
 else:b=(repo/n).read_bytes()
 assert sha(b)==expected,n
files['baseline-source-inventory.json']=(json.dumps(baseline['sourceInputs'],indent=2)+'\n').encode()
files['baseline-probe.cpp']=(repo/'.cache/comp-timing-326/probe.cpp').read_bytes()
files['baseline-build-command.json']=(repo/'.cache/comp-timing-326/build-command.json').read_bytes()
roots=[Path(json.loads(l)['scope']) for l in (r/'LastTest.log').read_text().splitlines() if l.startswith('{')]
assert len(roots)==4
inventory={};reports=[]
for root in roots:
 assert root.is_relative_to(repo/'.cache/take-preview-linux/build') and root.name.startswith('run-')
 for p in root.rglob('*'):
  if not p.is_file():continue
  n=str(p.relative_to(repo/'.cache/take-preview-linux/build'));b=p.read_bytes();entry=dict(bytes=len(b),sha256=sha(b));inventory[n]=entry
  if p.suffix in ['.json','.log','.stdout','.stderr'] and len(b)<=4*1024*1024:
   files['tests/'+n]=b;entry['entry']='tests/'+n
files['generated-file-inventory.json']=(json.dumps(inventory,indent=2)+'\n').encode()
files['profile-data-local.json']=(json.dumps({n:subprocess.check_output(['sudo','-n','sha256sum',str(r/n)],text=True).split()[0] for n in ['perf.data','absolute-perf.data']},indent=2)+'\n').encode()
files['scope.txt']=b'Read-only diagnostic verifies existing history, not whole-render performance. Raw perf stacks and binaries remain local. Instrumentation counts all original direct EVP_DigestUpdate calls and delegates to libcrypto. Timing comparison uses uninstrumented binaries. Source patch is relative to dfa5887. An initial relative-root refusal and unknown-target build invocation are retained. No VM or installed package changed. Native Windows qualification pending.\n'
index={n:dict(bytes=len(b),sha256=sha(b)) for n,b in files.items()};files['payload-manifest.json']=(json.dumps(index,indent=2)+'\n').encode();p=out/'acceptance.zip'
with zipfile.ZipFile(p,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,b in files.items():z.writestr(n,b)
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 for n,v in index.items():assert len(z.read(n))==v['bytes'] and sha(z.read(n))==v['sha256']
manifest=dict(archive=p.name,bytes=p.stat().st_size,sha256=sha(p.read_bytes()),entries=len(files),baseHead=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),generatedFiles=len(inventory),testsPassed=4,comparedSamples=16256,projectFilesUnchanged=225,medianSeconds=comparison['medianSeconds'],hashCounters=comparison['hashCounters'],nativeWindowsQualified=False,installedPreviewsChanged=False,physicalAudio=False,applicationBinariesIncluded=False)
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest))
