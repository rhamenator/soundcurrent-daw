from pathlib import Path
import json,subprocess
r=Path(__file__).resolve().parent;repo=r.parents[1];old=repo/'.cache/comp-timing-326';build=repo/'.cache/take-preview-linux/build'
s=(old/'probe.cpp').read_text();marker='template<class F> auto measure';a=s.index(marker)
s=s[:a]+'''#include <openssl/evp.h>
#include <array>
#include <cstdint>
struct Counter {std::uintptr_t caller=0;std::uint64_t calls=0,bytes=0,nanoseconds=0;};
std::array<std::array<Counter,64>,16> counters{};
unsigned currentPhase=0;
extern "C" int __real_EVP_DigestUpdate(EVP_MD_CTX *,const void *,size_t);
extern "C" int __wrap_EVP_DigestUpdate(EVP_MD_CTX *ctx,const void *data,size_t bytes) {
 const auto caller=reinterpret_cast<std::uintptr_t>(__builtin_return_address(0));
 auto &bank=counters.at(currentPhase);auto it=std::find_if(bank.begin(),bank.end(),[&](const auto &x){return x.caller==0 || x.caller==caller;});
 if(it==bank.end())std::abort();it->caller=caller;++it->calls;it->bytes+=bytes;
 const auto start=Clock::now();const auto result=__real_EVP_DigestUpdate(ctx,data,bytes);
 it->nanoseconds+=std::uint64_t(std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now()-start).count());return result;
}
void reportCounters(const char *phase){for(const auto &v:counters.at(currentPhase))if(v.calls)std::cout<<Json{{"event","hash-counter"},{"phase",phase},{"caller",v.caller},{"calls",v.calls},{"bytes",v.bytes},{"nanoseconds",v.nanoseconds}}.dump()<<std::endl;++currentPhase;}
''' +s[a:]
s=s.replace('return value;}catch','reportCounters(name);return value;}catch')
(r/'hash-probe.cpp').write_text(s)
args=json.loads((old/'build-command.json').read_text());args[args.index(str(old/'probe.cpp'))]=str(r/'hash-probe.cpp');args[args.index('-o')+1]=str(r/'hash-probe');args+=['-no-pie','-Wl,--wrap=EVP_DigestUpdate']
(r/'hash-build-command.json').write_text(json.dumps(args))
subprocess.run(args,cwd=build,check=True)
cmd=[str(r/'hash-probe'),str(repo/'.cache/windows-installed-portable-325/observed/retired-325/project-été-Κиїв'),'a1a283c7-c9e5-4d5f-bc41-0edadd727ee7']
with (r/'hash-profile.ndjson').open('w') as out,(r/'hash-profile.stderr').open('w') as err:subprocess.run(cmd,stdout=out,stderr=err,check=True,timeout=60)
rows=[json.loads(s) for s in (r/'hash-profile.ndjson').read_text().splitlines()];assert rows[-1]['event']=='complete' and rows[-1]['comparedSamples']==16256
for row in rows:
 if row['event']=='hash-counter':row['callerSymbol']=subprocess.check_output(['addr2line','-f','-C','-e',str(r/'hash-probe'),hex(row['caller'])],text=True).splitlines()[0]
(r/'hash-profile.json').write_text(json.dumps(rows,indent=2)+'\n')
for row in rows:
 if row['event']=='hash-counter':print(row['phase'],row['calls'],row['bytes'],round(row['nanoseconds']/1e6,3),row['callerSymbol'][:180])
