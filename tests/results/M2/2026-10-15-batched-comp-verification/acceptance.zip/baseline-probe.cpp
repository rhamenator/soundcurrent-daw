// SPDX-License-Identifier: GPL-3.0-only
#include <soundcurrent/comp_assembly_job.hpp>
#include <soundcurrent/comp_span_history.hpp>
#include <soundcurrent/project_store.hpp>
#include <nlohmann/json.hpp>
#include <chrono>
#include <iostream>
#include <algorithm>
using namespace soundcurrent::daw;
using Json=nlohmann::json;
using Clock=std::chrono::steady_clock;
template<class F> auto measure(const char *name,F f){const auto start=Clock::now();std::cout<<Json{{"event","begin"},{"phase",name}}.dump()<<std::endl;try{auto value=f();std::cout<<Json{{"event","end"},{"phase",name},{"milliseconds",std::chrono::duration<double,std::milli>(Clock::now()-start).count()}}.dump()<<std::endl;return value;}catch(const std::exception &e){std::cout<<Json{{"event","error"},{"phase",name},{"error",e.what()},{"milliseconds",std::chrono::duration<double,std::milli>(Clock::now()-start).count()}}.dump()<<std::endl;throw;}}
int main(int argc,char **argv){try{
 if(argc!=3)throw std::runtime_error("Expected project root and trusted assembly ID");
 const auto root=utf8Path(argv[1]);const Id assemblyId(argv[2]);ResourceLedger ledger(512*1024*1024,"Comp timing diagnostic");const CompHandlePlanContext ctx{1,"timing-diagnostic"};
 auto saved=measure("load-project",[&]{return ProjectStore(root).load();});
 const auto found=std::find_if(saved.compPlaybackSources.begin(),saved.compPlaybackSources.end(),[&](const auto &a){return a.assembly.operation==assemblyId;});if(found==saved.compPlaybackSources.end())throw std::runtime_error("Assembly absent from project history");const auto assembly=found->assembly;
 const CompPairSelectionReference ref{assembly.selectionOperation,found->selectionSha256};
 auto pair=measure("load-pair",[&]{return loadCompPairSelectionSnapshot(root,ctx,ref.operation,ref.selectionSha256,ledger);});
 auto selected=pair.recipe().selection();selected.compPairSelections.push_back(ref);selected.compAssemblies.push_back(assembly);validate(selected);
 auto request=measure("load-assembly",[&]{return loadReferencedCompAssemblyRequest(root,selected,ctx,pair,assemblyId,ledger);});
 for(unsigned side=0;side<2;++side)if(pair.children()[side]){
  const auto prefix="side-"+std::to_string(side);const auto &child=*pair.children()[side];
  measure((prefix+"-history").c_str(),[&]{verifyCompSpanHistory(root,child,pair.policy(),ledger,[]{});return true;});
  measure((prefix+"-span").c_str(),[&]{return verifyOwnedCompSpan(root,child,pair.policy(),ledger);});
 }
 auto verified=measure("assembly-with-history",[&]{return verifyCompAssembly(root,selected,ctx,pair,request,ledger);});
 std::cout<<Json{{"event","complete"},{"comparedSamples",verified.comparedSamples()},{"assembly",assemblyId.str()}}.dump()<<std::endl;
 return 0;
}catch(const std::exception &e){std::cerr<<e.what()<<std::endl;return 1;}}
