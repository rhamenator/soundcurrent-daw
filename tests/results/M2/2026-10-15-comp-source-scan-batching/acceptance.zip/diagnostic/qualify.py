from pathlib import Path
import subprocess,json,hashlib,time,statistics
r=Path(__file__).resolve().parent;repo=r.parents[1];build=repo/'.cache/take-preview-linux/build';root=repo/'.cache/windows-installed-portable-325/observed/retired-325/project-été-Κиїв'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
original={str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file()}
rows=[]
for i in range(3):
 for version in (['probe','probe-changed'] if i%2==0 else ['probe-changed','probe']):
  name=f'{version}-{i}';start=time.monotonic()
  with (r/(name+'.ndjson')).open('w') as out,(r/(name+'.stderr')).open('w') as err:proc=subprocess.run([str(r/version),str(root),'a1a283c7-c9e5-4d5f-bc41-0edadd727ee7'],stdout=out,stderr=err,timeout=120)
  events=[json.loads(l) for l in (r/(name+'.ndjson')).read_text().splitlines()];assert proc.returncode==0 and events[-1]['event']=='complete' and events[-1]['comparedSamples']==16256
  rows.append(dict(version=version,iteration=i,seconds=time.monotonic()-start,phases=[e for e in events if e['event']=='end']))
assert original=={str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file()}
median={n:statistics.median(x['seconds'] for x in rows if x['version']==n) for n in ['probe','probe-changed']}
(r/'timing.json').write_text(json.dumps(dict(rows=rows,medianSeconds=median,ratio=median['probe-changed']/median['probe'],projectFilesUnchanged=len(original),comparedSamples=16256,binaries={n:sha(r/n) for n in median},sourceInputs={str(p.relative_to(repo)):sha(p) for d in ['include','src'] for p in (repo/d).rglob('*') if p.is_file()},limitsUnchanged=True,windowsMeasured=False),indent=2)+'\n')
print(json.dumps(dict(medianSeconds=median,ratio=median['probe-changed']/median['probe'],projectFilesUnchanged=len(original))),flush=True)
targets=['sc-wave-validation-tests','sc-comp-media-review-tests','sc-comp-span-worker','sc-comp-span-worker-fixture','sc-comp-regeneration-history-tests']
with (r/'build-tests.log').open('w') as out:subprocess.run(['cmake','--build',str(build),'--target',*targets,'--parallel','1'],stdout=out,stderr=subprocess.STDOUT,check=True)
command=['ctest','--test-dir',str(build),'--output-on-failure','--no-tests=error','-j','1','-R','^(approved-wave-content|comp-actual-media-review|comp-owned-span-worker|comp-paired-history-review)$']
selected=json.loads(subprocess.check_output(command[:3]+['--show-only=json-v1','-R',command[-1]],text=True));assert len(selected['tests'])==4
before={str(p):set(p.iterdir()) for p in [build/'comp-media-review-evidence',build/'comp-span-worker-evidence',build/'comp-paired-history-evidence'] if p.exists()}
start=time.monotonic()
with (r/'tests.stdout').open('w') as out,(r/'tests.stderr').open('w') as err:code=subprocess.call(command,stdout=out,stderr=err)
(r/'LastTest.log').write_bytes((build/'Testing/Temporary/LastTest.log').read_bytes())
new={p:[str(x) for x in set(Path(p).iterdir())-v] for p,v in before.items()}
(r/'tests.json').write_text(json.dumps(dict(command=command,exitCode=code,seconds=time.monotonic()-start,evidence=new),indent=2)+'\n');print((r/'tests.stdout').read_text());assert code==0
