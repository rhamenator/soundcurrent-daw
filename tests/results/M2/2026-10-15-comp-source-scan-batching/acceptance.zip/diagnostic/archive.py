from pathlib import Path
import json,hashlib,zipfile,subprocess
r=Path(__file__).resolve().parent;repo=r.parents[1];build=repo/'.cache/take-preview-linux/build';out=repo/'tests/results/M2/2026-10-15-comp-source-scan-batching';out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();files={}
for p in r.iterdir():
 if p.is_file() and p.suffix in ['.cpp','.py','.json','.ndjson','.stderr','.stdout','.log','.txt']:files['diagnostic/'+p.name]=p.read_bytes()
scopes=['comp-media-review-evidence/run-ts3m_jiz','comp-paired-history-evidence/run-y9t02uzq','comp-span-worker-evidence/run-p_ai2ixz'];inventory={}
for scope in scopes:
 root=build/scope;assert root.is_dir()
 for p in root.rglob('*'):
  if not p.is_file():continue
  n=scope+'/'+str(p.relative_to(root));b=p.read_bytes();entry=dict(bytes=len(b),sha256=sha(b))
  if p.suffix in ['.json','.stdout','.stderr','.log']:
   entry['entry']='tests/'+n;files[entry['entry']]=b
  else:entry['retainedLocalFile']=str(p)
  inventory[n]=entry
files['test-corpus-inventory.json']=(json.dumps(inventory,indent=2)+'\n').encode()
files['source.patch']=subprocess.check_output(['git','diff','--','src/comp_span_protocol.cpp','src/comp_media_review.cpp'],cwd=repo)
for n in ['src/comp_span_protocol.cpp','src/comp_media_review.cpp']:
 files['source/'+n]=(repo/n).read_bytes()
manifestPath=repo/'tests/results/M2/2026-10-15-installed-windows-portable-comp/manifest.json';base=json.loads(manifestPath.read_text());files['project-reference.json']=(json.dumps(dict(archive=str(manifestPath.parent.relative_to(repo)/'acceptance.zip'),sha256=base['sha256'],projectManifest='project-members.json',assembly='a1a283c7-c9e5-4d5f-bc41-0edadd727ee7'),indent=2)+'\n').encode()
index={n:dict(bytes=len(b),sha256=sha(b)) for n,b in files.items()};files['payload-manifest.json']=(json.dumps(index,indent=2)+'\n').encode()
p=out/'acceptance.zip'
with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,b in files.items():z.writestr(n,b)
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 for n,v in index.items():assert sha(z.read(n))==v['sha256']
report=dict(archive=p.name,bytes=p.stat().st_size,sha256=sha(p.read_bytes()),entries=len(files),baseHead='2fdeaf956f97eddba54c3fa61c4d86d16bcade3e',projectFilesUnchanged=225,testCount=4,testsPassed=True,generatedCorpusFiles=len(inventory),allGeneratedMediaPublished=False,nativeWindowsPerformanceQualified=False,sourcePatch='source.patch',applicationBinariesIncluded=False)
(out/'manifest.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
