from pathlib import Path
import json,subprocess,hashlib
r=Path(__file__).resolve().parent;repo=r.parents[1];build=repo/'.cache/take-preview-linux/build'
with (r/'build-final.log').open('w') as out:subprocess.run(['cmake','--build',str(build),'--target','sc-comp-assembly-job','--parallel','1'],stdout=out,stderr=subprocess.STDOUT,check=True)
args=json.loads((r/'build-command.json').read_text());args[args.index('-o')+1]=str(r/'probe-changed')
with (r/'relink.log').open('w') as out:subprocess.run(args,cwd=build,stdout=out,stderr=subprocess.STDOUT,check=True)
root=repo/'.cache/windows-installed-portable-325/observed/retired-325/project-été-Κиїв';command=[str(r/'probe-changed'),str(root),'a1a283c7-c9e5-4d5f-bc41-0edadd727ee7']
for name,prefix in [('changed',[]),('changed-traced',['strace','-f','-c','-o',str(r/'changed-syscalls.txt')])]:
 with (r/(name+'.ndjson')).open('w') as out,(r/(name+'.stderr')).open('w') as err:subprocess.run(prefix+command,stdout=out,stderr=err,timeout=120,check=True)
print((r/'changed.ndjson').read_text())
print((r/'changed-syscalls.txt').read_text())
