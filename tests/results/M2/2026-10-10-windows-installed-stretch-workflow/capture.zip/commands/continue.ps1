﻿$ErrorActionPreference='Stop';$media=Split-Path -Parent $MyInvocation.MyCommand.Path
$root=Join-Path $env:USERPROFILE 'SoundCurrent-Stretch-Installed-f9'
if((Get-CimInstance Win32_ComputerSystemProduct).UUID -ne '670168F5-4E3F-4E7F-B218-3583DB31F0F8') {throw 'Wrong owned clone'}
foreach($name in @('observe.ps1','open-observed.ps1','cycle.ps1')) {Copy-Item -LiteralPath (Join-Path $media $name) $root -Force}
Copy-Item -LiteralPath $MyInvocation.MyCommand.Path (Join-Path $root 'continue.ps1') -Force
& (Join-Path $root 'open-observed.ps1')
