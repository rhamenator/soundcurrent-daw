﻿$ErrorActionPreference='Stop';$root=Split-Path -Parent $MyInvocation.MyCommand.Path
if((Get-CimInstance Win32_ComputerSystemProduct).UUID -ne '670168F5-4E3F-4E7F-B218-3583DB31F0F8') {throw 'Wrong owned clone'}
$rows=@();$seen=@{};$events=@();$deadline=[DateTime]::UtcNow.AddSeconds(900)
$trace=$false;$traceError=$null
try {Register-WmiEvent -Query "SELECT * FROM Win32_ProcessStartTrace WHERE ProcessName='sc-stretch-render-worker.exe'" -SourceIdentifier 'SCStretchStart'|Out-Null;$trace=$true} catch {$traceError=$_.Exception.Message}
try {
 while([DateTime]::UtcNow -lt $deadline -and !(Test-Path (Join-Path $root 'observer-stop.txt'))) {
  if($trace) {
   foreach($event in @(Get-Event -SourceIdentifier 'SCStretchStart' -ErrorAction SilentlyContinue)) {
    $e=$event.SourceEventArgs.NewEvent
    $events+=@{pid=$e.ProcessID;parentPid=$e.ParentProcessID;name=$e.ProcessName;sessionId=$e.SessionID;receivedUtc=[DateTime]::UtcNow.ToString('o');osEventTime=$e.TIME_CREATED.ToString()}
    Remove-Event -EventIdentifier $event.EventIdentifier
   }
  }
  foreach($proc in @(Get-Process -Name 'sc-stretch-render-worker' -ErrorAction SilentlyContinue)) {
   if(!$seen.ContainsKey($proc.Id)) {
    $seen[$proc.Id]=$true
    $row=[ordered]@{pid=$proc.Id;sessionId=$proc.SessionId;observedUtc=[DateTime]::UtcNow.ToString('o')}
    try {$row.path=$proc.Path;$row.sha256=(Get-FileHash -LiteralPath $proc.Path -Algorithm SHA256).Hash.ToLowerInvariant();$row.modules=@($proc.Modules|ForEach-Object {@{name=$_.ModuleName;path=$_.FileName}});$c=Get-CimInstance Win32_Process -Filter ('ProcessId='+$proc.Id);if($c) {$row.parentPid=$c.ParentProcessId;$row.commandLine=$c.CommandLine}} catch {$row.observationError=$_.Exception.Message}
    $rows+=,$row
   }
  }
  @{format='sc-owned-stretch-process-observer-v1';pollMilliseconds=25;traceRegistered=$trace;traceError=$traceError;processes=$rows;startEvents=$events;stopped=$false}|ConvertTo-Json -Depth 10|Set-Content (Join-Path $root 'helper-observer.json') -Encoding UTF8
  Start-Sleep -Milliseconds 25
 }
} finally {
 if($trace) {Unregister-Event -SourceIdentifier 'SCStretchStart'}
 @{format='sc-owned-stretch-process-observer-v1';pollMilliseconds=25;traceRegistered=$trace;traceError=$traceError;processes=$rows;startEvents=$events;stopped=$true}|ConvertTo-Json -Depth 10|Set-Content (Join-Path $root 'helper-observer.json') -Encoding UTF8
}
