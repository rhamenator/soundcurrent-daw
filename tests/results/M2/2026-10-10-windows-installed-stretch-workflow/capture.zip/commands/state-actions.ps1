﻿$ErrorActionPreference='Stop';$root=Join-Path $env:USERPROFILE 'SoundCurrent-Stretch-Installed-f9'
if((Get-CimInstance Win32_ComputerSystemProduct).UUID -ne '670168F5-4E3F-4E7F-B218-3583DB31F0F8') {throw 'Wrong owned clone'}
$file=Join-Path (Join-Path $root 'project-été-Κиїв') 'project.json'
if(Test-Path (Join-Path $root 'applied-project.json')) {throw 'Action checkpoint already exists'}
$applied=Get-Content -LiteralPath $file -Raw|ConvertFrom-Json
if($applied.tracks[0].clips[0].lengthFrames -ne 12288 -or $applied.assets.Count -ne 2) {throw 'No saved applied stretch state'}
Copy-Item -LiteralPath $file (Join-Path $root 'applied-project.json')
Copy-Item -LiteralPath $MyInvocation.MyCommand.Path (Join-Path $root 'state-actions.ps1')
$mainId=[int](Get-Content (Join-Path $root 'main-pid.txt'));$p=Get-Process -Id $mainId
$report=[ordered]@{format='sc-owned-installed-project-actions-v1';pid=$mainId;sessionId=$p.SessionId;undoSaved=$false;redoSaved=$false}
Add-Type -AssemblyName System.Windows.Forms
$shell=New-Object -ComObject WScript.Shell
function SaveAndWait($length) {
 [Windows.Forms.SendKeys]::SendWait('^s');$deadline=[DateTime]::UtcNow.AddSeconds(15)
 do {
  Start-Sleep -Milliseconds 100
  try {$v=Get-Content -LiteralPath $file -Raw|ConvertFrom-Json;if($v.tracks[0].clips[0].lengthFrames -eq $length) {return}} catch {}
 } while([DateTime]::UtcNow -lt $deadline)
 throw 'Actual project action/save did not complete'
}
if(!$shell.AppActivate($mainId)) {throw 'Cannot focus actual owned main'};Start-Sleep -Milliseconds 350
[Windows.Forms.SendKeys]::SendWait('^z');Start-Sleep -Milliseconds 350;SaveAndWait 8192
Copy-Item -LiteralPath $file (Join-Path $root 'undone-project.json');$report.undoSaved=$true
[Windows.Forms.SendKeys]::SendWait('^y');Start-Sleep -Milliseconds 350;SaveAndWait 12288
Copy-Item -LiteralPath $file (Join-Path $root 'redone-project.json');$report.redoSaved=$true
$report|ConvertTo-Json -Depth 6|Set-Content (Join-Path $root 'state-actions.json') -Encoding UTF8
& (Join-Path $root 'collect.ps1') 'state-actions.zip'
