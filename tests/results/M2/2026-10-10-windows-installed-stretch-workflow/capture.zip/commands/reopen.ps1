﻿$ErrorActionPreference='Stop';$root=Join-Path $env:USERPROFILE 'SoundCurrent-Stretch-Installed-f9'
if((Get-CimInstance Win32_ComputerSystemProduct).UUID -ne '670168F5-4E3F-4E7F-B218-3583DB31F0F8') {throw 'Wrong owned clone'}
if(Test-Path (Join-Path $root 'before-reopen-project.json')) {throw 'Reopen already observed'}
Copy-Item -LiteralPath (Join-Path (Join-Path $root 'project-été-Κиїв') 'project.json') (Join-Path $root 'before-reopen-project.json')
Copy-Item -LiteralPath $MyInvocation.MyCommand.Path (Join-Path $root 'reopen.ps1')
& (Join-Path $root 'open-main.ps1')
