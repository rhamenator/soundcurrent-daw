﻿$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
$receipt=Get-Content -Raw (Join-Path $root 'receipt.json')|ConvertFrom-Json
$install=Join-Path $env:LOCALAPPDATA ('Programs\SoundCurrent DAW Preview\'+$receipt.sequence+'-'+$receipt.sourceHead.Substring(0,12))
$env:PATH=$install+';'+$env:SystemRoot+'\System32;'+$env:SystemRoot+';'+$env:SystemRoot+'\System32\WindowsPowerShell\v1.0'
$env:QT_QPA_PLATFORM='windows';$env:QT_QPA_PLATFORM_PLUGIN_PATH=Join-Path $install 'platforms'
$exe=Join-Path $install 'soundcurrent-daw.exe'
$stamp=[DateTime]::UtcNow.ToString('yyyyMMddHHmmssfff')
$p=Start-Process -FilePath $exe -ArgumentList '--language','en' -WorkingDirectory $install -PassThru -RedirectStandardOutput (Join-Path $root ('main-'+$stamp+'.stdout')) -RedirectStandardError (Join-Path $root ('main-'+$stamp+'.stderr'))
$handle=$p.Handle;$deadline=[DateTime]::UtcNow.AddSeconds(20)
do {$p.Refresh();if($p.MainWindowHandle -ne 0) {break};Start-Sleep -Milliseconds 100} while([DateTime]::UtcNow -lt $deadline)
if($p.HasExited -or $p.MainWindowHandle -eq 0 -or $p.MainWindowTitle -ne 'SoundCurrent DAW' -or $p.SessionId -eq 0) {throw 'No actual installed interactive main'}
$modules=@($p.Modules|ForEach-Object {@{name=$_.ModuleName;path=$_.FileName}})
foreach($name in @('Qt6Core.dll','Qt6Gui.dll','Qt6Widgets.dll','sndfile.dll','qwindows.dll')) {
 $found=@($modules|Where-Object {$_.name -eq $name})
 if($found.Count -ne 1 -or !$found[0].path.StartsWith($install+'\',[StringComparison]::OrdinalIgnoreCase)) {throw ('Installed dependency not loaded locally: '+$name)}
}
$report=[ordered]@{format='sc-installed-main-window-v1';sourceHead=$receipt.sourceHead;pid=$p.Id;sessionId=$p.SessionId;windowHandle=$p.MainWindowHandle.ToInt64();title=$p.MainWindowTitle;exe=$exe;exeSha256=(Get-FileHash $exe -Algorithm SHA256).Hash.ToLowerInvariant();modules=$modules;developerSdkUsed=$false;nativeAudioActivated=$false;closed=$false}
$report|ConvertTo-Json -Depth 8|Set-Content (Join-Path $root ('main-'+$stamp+'.json')) -Encoding UTF8
[IO.File]::WriteAllText((Join-Path $root 'main-pid.txt'),$p.Id)
Add-Type -AssemblyName System.Windows.Forms
[Windows.Forms.Clipboard]::SetText((Join-Path $root 'project-été-Κиїв'))
& (Join-Path $root 'collect.ps1') ('main-'+$stamp+'.zip')
if(!$p.WaitForExit(600000)) {throw 'Installed main remains live; preserve identity for diagnosis'}
$p.Refresh();$report.closed=$true;$report.exitCode=$p.ExitCode
$report|ConvertTo-Json -Depth 8|Set-Content (Join-Path $root ('main-'+$stamp+'.json')) -Encoding UTF8
& (Join-Path $root 'collect.ps1') ('closed-'+$stamp+'.zip')
if($p.ExitCode -ne 0) {throw 'Installed main did not quit normally'}
