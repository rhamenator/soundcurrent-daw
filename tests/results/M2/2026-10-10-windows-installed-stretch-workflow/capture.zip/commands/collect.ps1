﻿param([Parameter(Mandatory=$true)][string]$Name)
$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
if($Name -notmatch '^[a-z0-9-]{1,70}\.zip$') {throw 'Invalid owned capture name'}
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
$config=Get-Content -Raw (Join-Path $root 'private-transport.json')|ConvertFrom-Json
$stage=Join-Path $env:TEMP ('sc-capture-'+[Guid]::NewGuid().ToString('D'))
New-Item -ItemType Directory $stage|Out-Null
try {
 foreach($file in (Get-ChildItem $root -File|Where-Object {$_.Name -notin @('private-transport.json','project.zip')})) {Copy-Item -LiteralPath $file.FullName $stage}
 foreach($folder in (Get-ChildItem $root -Directory)) {Copy-Item -LiteralPath $folder.FullName -Destination $stage -Recurse}
 $zip=Join-Path $env:TEMP $Name
 if(Test-Path $zip) {throw 'Existing owned capture archive refused'}
 Compress-Archive -LiteralPath $stage -DestinationPath $zip
 $bytes=[IO.File]::ReadAllBytes($zip)
 if($bytes.Length -gt 30MB) {throw 'Capture bound exceeded'}
 $web=New-Object Net.WebClient;$web.Proxy=$null
 $web.Headers.Add('X-SoundCurrent-Capture-Key',$config.key)
 $web.UploadData(('http://192.168.122.1:18768/'+$Name),'POST',$bytes)|Out-Null
} finally {Remove-Item -LiteralPath $stage -Recurse -Force}
