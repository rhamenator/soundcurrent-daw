from pathlib import Path
import json,hashlib,math
import numpy as np
from scipy.io import wavfile
r=Path(__file__).resolve().parent;project=r/'app/project-été-Κиїв';load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
installation=load(r/'user-installation.json');session=load(project/'project.json');applied=load(r/'applied.json');before=load(r/'before-render.json');assert session==applied==load(r/'redone.json');assert load(r/'undone.json')['tracks']==before['tracks'];assert applied['tracks']!=before['tracks']
launches=[load(r/'app'/f'{tag}-launch.json') for tag in ['edit','reopen']]
for l in launches:
 assert l['exit_code']==0 and not l['menu_launch'] and l['quitRequestedByPublicMenuAction'];assert l['running_executable_sha256']==installation['payload_sha256']['usr/bin/soundcurrent-daw'];assert not Path('/proc',str(l['pid'])).exists() and not Path('/proc',str(l['private_daemon_pid'])).exists()
assert len(session['tracks'])==1 and session['master'] is None;track=session['tracks'][0];assert len(track['processors'])==1 and track['processors'][0]['type']=='sc.eq' and track['processors'][0]['bands']==[]
rate,audio=wavfile.read(r/'app/edited-roundtrip.wav');assert rate==48000 and audio.dtype==np.float32 and audio.shape==(18032,2) and np.isfinite(audio).all()
ref=np.zeros(audio.shape,dtype=np.float64)
def fade(f,n,out):
 start,end=f['startFrame'],f['endFrame']
 if start==end:return 1.
 phase=0. if n<start else 1. if n>=end else .5 if end-start==1 else (n-start)/(end-start-1)
 if out:phase=1-phase
 if phase<=0:return 0.
 if phase>=1:return 1.
 phase=phase**f['shape']
 if f['curve']=='equal-power':return math.sin(phase*math.pi/2)
 if f['curve']=='smoothstep':return phase*phase*(3-2*phase)
 assert f['curve']=='linear';return phase
for clip in track['clips']:
 asset=next(a for a in session['assets'] if a['id']==clip['assetId']);p=project/asset['path'];assert sha(p)==asset['sha256'];sr,source=wavfile.read(p);assert sr==rate and source.shape==(4032,2);assert clip['sourceFrame']==clip['sourceTiming']['fraction']==0 and clip['playbackRate']['numerator']==clip['playbackRate']['denominator']==1
 c=clip['processing'];gain=0 if c['muted'] else 10**(c['gainDb']/20)*(-1 if c['polarityInverted'] else 1)
 for n in range(clip['lengthFrames']):ref[clip['startFrame']+n]+=source[n].astype(np.float64)*(gain*fade(c['fadeIn'],n,False)*fade(c['fadeOut'],n,True))
expected=ref.astype(np.float32);error=float(np.max(np.abs(audio.astype(np.float64)-expected)));assert error<=2e-5,error;assert np.all(audio[:10000]==0) and np.all(audio[18000:]==0);peak=float(np.max(np.abs(audio)));assert peak>1
provenance=load(r/'fixture-provenance.json');source=Path(provenance['source']);assert all(sha(source/n)==h for n,h in provenance['sourceFiles'].items());preserved=[n for n in provenance['sourceFiles'] if n not in ['project.json','project.previous.json']];assert all(sha(project/n)==provenance['sourceFiles'][n] for n in preserved)
assert load(project/'project.previous.json')==applied
for n,h in installation['payload_sha256'].items():assert sha(Path(installation['installation'])/n)==h
old=load(r/'preserved-preview-before.json');assert all(sha(Path(installation['previous_installation'])/n)==h for n,h in old.items());assert sha(Path(installation['launcher']))==installation['launcher_sha256']
render=load(r/'render-observation.json');assert render['passed'] and len(render['workers'])==2 and all(w['retired'] and w['sha256']==installation['payload_sha256']['usr/bin/sc-comp-span-worker'] for w in render['workers'])
report=dict(sourceHead=installation['source_head'],version=installation['version'],installedDirectoryWorkflow=True,renderMilliseconds=render['renderMilliseconds'],reviewApplyUndoRedoSaveReopen=True,normalQuitBothLaunches=True,exportFrames=len(audio),channels=2,sampleRate=rate,floatPeak=peak,independentReferenceMaximumError=error,bitExactToIndependentReference=bool(np.array_equal(audio,expected)),exportSha256=sha(r/'app/edited-roundtrip.wav'),originalFixtureUnchanged=True,preservedProjectFiles=len(preserved),savedProjectBackupMatches=True,previousPreviewPreserved=True,allInstalledPayloadsMatch=True,physicalAudio=False,vmUsed=False,cleanInstallQualified=False)
(r/'qualification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
