from access import *
click(find('Undo project edit','menu item'));time.sleep(.3)
click(find('Save','menu item'));time.sleep(.4)
original=json.loads((base/'fixture-provenance.json').read_text());source=Path(original['source'])
assert json.loads((Path(d['project'])/'project.json').read_text())==json.loads((source/'project.json').read_text())
click(find('File','menu item'));time.sleep(.1);(app/'edit-finish').touch();click(find('Quit','menu item'))
