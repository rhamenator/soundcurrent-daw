from access import *
speed=find('Clip playback speed; pitch follows speed','spin button')
assert Atspi.Value.set_current_value(speed,1.5)
click(find('Apply speed','button'));time.sleep(.3)
assert Atspi.Text.get_text(find('Length in project frames','text'),0,-1)=='4000'
combo=find('Clip 1 · 4000 frames','combo box');click(combo)
subprocess.run(['xdotool','key','Home','Down','Down','Return'],check=True);time.sleep(.2)
assert Atspi.Value.set_current_value(find('Clip playback speed; pitch follows speed','spin button'),1.5)
click(find('Apply speed','button'));time.sleep(.3)
assert Atspi.Text.get_text(find('Length in project frames','text'),0,-1)=='4000'
assert Atspi.EditableText.set_text_contents(find('Timeline start frame','text'),'14000')
click(find('Apply range','button'));time.sleep(.3)
click(find('Save','menu item'));time.sleep(.5)
s=json.loads((Path(d['project'])/'project.json').read_text())
clips=s['tracks'][0]['clips']
assert [c['startFrame'] for c in clips]==[10000,14000]
assert all(c['lengthFrames']==4000 and c['playbackRate']['numerator']==3 and c['playbackRate']['denominator']==2 for c in clips)
(base/'before-render.json').write_text(json.dumps(s,indent=2)+'\n')
click(find('Clip 2 · 4000 frames','combo box'));subprocess.run(['xdotool','key','Home','Down','Return'],check=True);time.sleep(.2)
click(find('Crossfade clips…','button'));time.sleep(.2)
for row in snapshot('crossfade-open'):
 if row['path'] and (row['path'][0]!=0 or row['role']=='dialog'):print(row)
