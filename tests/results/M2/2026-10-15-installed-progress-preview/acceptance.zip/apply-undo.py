from access import *

def waitfor(predicate,description,seconds=30):
 end=time.monotonic()+seconds
 while time.monotonic()<end:
  if predicate():return
  time.sleep(.1)
 snapshot('failed-'+description)
 raise TimeoutError(description)
def notice(phrase):
 return any(phrase in a.get_name() for _,a in walk(root))
def save():
 click(find('Save','menu item'));time.sleep(.7)
 return json.loads((Path(d['project'])/'project.json').read_text())
before=json.loads((base/'before-render.json').read_text())
assert save()['tracks']==before['tracks'],'Rendering changed clips before Apply'
click(find('Review selected transition','button'))
waitfor(lambda:find('Apply reviewed audio','button').get_state_set().contains(Atspi.StateType.ENABLED),'review')
snapshot('review-verified');click(find('Apply reviewed audio','button'))
waitfor(lambda:notice('Transition applied. Undo restores both original clips'),'apply')
snapshot('applied');click(find('Close','button'));time.sleep(.2)
applied=save();assert applied['tracks']!=before['tracks']
(base/'applied.json').write_text(json.dumps(applied,indent=2)+'\n')
click(find('Undo project edit','menu item'));time.sleep(.4)
undone=save();assert undone['tracks']==before['tracks'],'Undo did not restore original clips'
(base/'undone.json').write_text(json.dumps(undone,indent=2)+'\n')
click(find('Redo project edit','menu item'));time.sleep(.4)
redone=save();assert redone==applied,'Redo did not restore exact saved project'
(base/'redone.json').write_text(json.dumps(redone,indent=2)+'\n');snapshot('redone-saved')
click(find('File','menu item'));time.sleep(.1)
(app/'edit-finish').touch();click(find('Quit','menu item'))
print('Reviewed/Applied/Undo/Redo/Save checked; public Quit requested',flush=True)
