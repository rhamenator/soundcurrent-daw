from pathlib import Path
import hashlib,json,zipfile
r=Path(__file__).resolve().parent;dest=Path('tests/results/M2/2026-10-15-installed-progress-preview');dest.mkdir(exist_ok=False)
files={};sha=lambda b:hashlib.sha256(b).hexdigest()
for p in r.iterdir():
 if not p.is_file() or p.name.startswith('pr-') or p.name in ['launch-driver.log','launch-initial-driver.log','reopen-driver.log','menu-driver.log']:continue
 files[p.name]=p.read_bytes()
media=[]
for folder in ['app','initial-fixture']:
 for p in sorted((r/folder).rglob('*')):
  if not p.is_file() or 'preferences' in p.relative_to(r/folder).parts:continue
  n=p.relative_to(r).as_posix()
  if p.name=='active.json':continue
  b=p.read_bytes()
  if p.suffix=='.wav':media.append(dict(path=n,bytes=len(b),sha256=sha(b)));continue
  if p.suffix not in ['.json','.png','.log','.py','.txt']:continue
  if p.name.endswith('-launch.json'):
   d=json.loads(b);d.pop('bus',None);d.pop('runtime',None);b=(json.dumps(d,indent=2)+'\n').encode()
  files[n]=b
files['generated-media-inventory.json']=(json.dumps(media,ensure_ascii=False,indent=2)+'\n').encode()
manifest=[dict(path=n,bytes=len(b),sha256=sha(b)) for n,b in files.items()]
files['payload-manifest.json']=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
a=dest/'acceptance.zip'
with zipfile.ZipFile(a,'x',zipfile.ZIP_DEFLATED) as z:
 for n,b in files.items():z.writestr(n,b)
with zipfile.ZipFile(a) as z:
 assert z.testzip() is None
 for row in manifest:assert sha(z.read(row['path']))==row['sha256']
out=dict(archive=a.name,bytes=a.stat().st_size,sha256=sha(a.read_bytes()),entries=len(files),sourceHead='b5dc2568dbf0e1e623dbaa7d42dcd38fd1eed3ab',installedWorkflowPassed=True,normalApplicationsLauncherQualified=True,initialFixtureDriverFailureRetained=True,generatedAudioFiles=len(media),generatedAudioPublished=False,privatePreferencesIncluded=False,physicalAudio=False,vmUsed=False,cleanInstallQualified=False)
(dest/'manifest.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
