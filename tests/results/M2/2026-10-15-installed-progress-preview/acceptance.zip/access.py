from pathlib import Path
import json,os,sys,time,subprocess
base=Path(__file__).resolve().parent;app=base/'app';d=json.loads((app/'active.json').read_text());os.environ['DBUS_SESSION_BUS_ADDRESS']=d['bus'];os.environ['DISPLAY']=d['display']
assert Path('/proc',str(d['pid']),'exe').resolve()==Path(d['binary'])
import gi;gi.require_version('Atspi','2.0');from gi.repository import Atspi
root=Atspi.get_desktop(0);apps=[root.get_child_at_index(i) for i in range(root.get_child_count())];roots=[a for a in apps if a.get_process_id()==d['pid'] and a.get_child_count()>0];assert len(roots)==1;root=roots[0]
def walk(a,path=()):
 if a is None:return
 yield path,a
 for i in range(a.get_child_count()):yield from walk(a.get_child_at_index(i),path+(i,))
def find(name,role=None):
 values=[a for path,a in walk(root) if a.get_name()==name and (role is None or a.get_role_name()==role)]
 assert len(values)==1,(name,role,len(values));return values[0]
def click(a):
 actions=[a.get_action_name(i) for i in range(a.get_n_actions())]
 assert actions,(a.get_name(),actions)
 assert a.get_state_set().contains(Atspi.StateType.ENABLED),a.get_name()
 assert a.do_action(0)
def snapshot(name):
 rows=[]
 for path,a in walk(root):
  row={'path':list(path),'role':a.get_role_name(),'name':a.get_name(),'enabled':a.get_state_set().contains(Atspi.StateType.ENABLED)}
  if a.is_action():row['actions']=[a.get_action_name(i) for i in range(a.get_n_actions())]
  if a.is_text():row['text']=Atspi.Text.get_text(a,0,-1)
  rows.append(row)
 (app/(name+'.json')).write_text(json.dumps(rows,indent=2,ensure_ascii=False)+'\n')
 subprocess.run(['import','-window','root',str(app/(name+'.png'))],check=True,timeout=8)
 return rows
if __name__=='__main__':
 rows=snapshot(sys.argv[1] if len(sys.argv)>1 else 'tree')
 for r in rows:
  if r['name'] or r.get('actions'):print(r)
