from access import *
assert d['menu_launch']
assert json.loads((Path(d['project'])/'project.json').read_text())==json.loads((base/'applied.json').read_text())
snapshot('menu-qualified')
click(find('File','menu item'));time.sleep(.1)
(app/'menu-finish').touch();click(find('Quit','menu item'))
print('Normal Applications launcher opened exact installed candidate and saved project; public Quit requested')
