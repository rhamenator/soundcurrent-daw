from access import *
click(find('Select a clip','combo box'))
subprocess.run(['xdotool','key','Home','Down','Return'],check=True)
time.sleep(.2)
assert find('Clip 1 · 6000 frames','combo box')
snapshot('clip-selected')
