// SPDX-License-Identifier: GPL-3.0-only
#pragma once
#include "playback.hpp"
#include "project_store.hpp"
#include "media_cache.hpp"
#include <functional>
#include <memory>

namespace soundcurrent::daw {
struct ReadAheadOptions {
    std::uint32_t maximumOpenAssets = 64; // Concurrent shared handles, not asset inventory.
    // Disk/preparation owner only, for cancellation and failure fixtures.
    std::function<void(Frame)> beforeRead;
    // Optional worker-side cancellation during large source admission hashes.
    std::function<void()> beforeAdmissionRead{};
    MediaCacheConfig cache{}; // Effective handle cap is the minimum of both policies.
};
// Worker-side timeline reader. Admits owned WAV/RF64 assets, verifies hashes,
// opens read-only handles, then mixes clip source extents into bounded slabs.
class TrackReader {
  public:
    TrackReader(PlaybackPipe &, std::filesystem::path projectRoot, const Session &, const Id &track,
                ReadAheadOptions = {});
    // Shared-cache callers own aggregate admission and serialize all readers/cache access.
    TrackReader(PlaybackPipe &, const ValidatedSession &, const Id &,
                std::shared_ptr<MediaReadCache>, ReadAheadOptions = {});
    ~TrackReader();
    bool fillOne(); // False: pool full or range completed. Never called by audio.
    std::uint64_t sanitizedSamples() const noexcept; // Atomic point-in-time count.
  private:
    struct State;
    std::unique_ptr<State> state_;
};
// A prepared playback generation, suitable for RtObjectExchange. Construction
// verifies/prefills on the preparation owner, then starts a reader worker.
// process is the only callback method; destruction cancels/joins off RT.
class PlaybackRun {
  public:
    PlaybackRun(std::filesystem::path projectRoot, const Session &, const Id &track, PlaybackConfig,
                ReadAheadOptions = {});
    ~PlaybackRun();
    PlaybackRun(const PlaybackRun &) = delete;
    PlaybackRun &operator=(const PlaybackRun &) = delete;
    PlaybackReport process(std::span<float *const> output, std::uint32_t frames) noexcept;
    PreparedEq &prepared() noexcept; // Immutable control-side event preparation.
    SubmitStatus submit(const EqEvent &) noexcept;
    SubmitStatus submitImmediate(const EqEvent &, std::uint64_t revision) noexcept;
    bool acknowledgement(ImmediateAcknowledgement &) noexcept;
    std::uint64_t droppedAcknowledgements() const noexcept;
    const PlaybackConfig &config() const noexcept;
    Frame position() const noexcept;
    std::uint64_t missingFrames() const noexcept;
    std::uint64_t bufferedFrames() const noexcept;
    bool readerDone() const noexcept;
    std::uint64_t sanitizedSamples() const noexcept;
    void requestStop() noexcept;  // Control request consumed by the audio owner.
    void cancelReader() noexcept; // Control: pair with stop or generation retirement.
    void waitReader();            // Joins/surfaces failures; cancel or consume range first.
  private:
    struct State;
    std::unique_ptr<State> state_;
};
} // namespace soundcurrent::daw
