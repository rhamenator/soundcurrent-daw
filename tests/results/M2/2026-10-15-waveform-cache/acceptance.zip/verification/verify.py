import os,subprocess,json,time
from pathlib import Path
root=Path('.cache/waveform-cache-345');rows=[]
for label,build in [('release','.cache/take-preview-linux/build'),('asan-ubsan','.cache/waveform-controller-344/asan')]:
 extra={} if label=='release' else {'ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'}
 env=os.environ.copy();env.update(extra)
 for phase,cmd in [('build',['cmake','--build',build,'--parallel','1','--target','sc-waveform-cache-tests','sc-waveform-controller-tests']),('tests',['ctest','--test-dir',build,'-R','^(desktop-waveform-cache|desktop-waveform-controller)$','--output-on-failure','-V'])]:
  argv=['nice','-n','15','ionice','-c','3']+cmd;start=time.monotonic()
  with (root/(label+'-'+phase+'.log')).open('wb') as f:r=subprocess.run(argv,stdout=f,stderr=subprocess.STDOUT,env=env)
  rows.append(dict(label=label,phase=phase,argv=argv,environment=extra,exitCode=r.returncode,seconds=time.monotonic()-start))
  (root/'verification-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,phase,r.returncode,flush=True)
  if r.returncode:raise SystemExit(r.returncode)
