from pathlib import Path
import json,hashlib,subprocess,zipfile
root=Path('.cache/waveform-cache-345');out=Path('tests/results/M2/2026-10-15-waveform-cache');out.mkdir(parents=True,exist_ok=True)
source=['include/soundcurrent/waveform_projection.hpp','src/waveform_projection.cpp','ui/waveform_cache.hpp','ui/waveform_cache.cpp','tests/waveform_cache_tests.cpp','CMakeLists.txt','.github/workflows/ci.yml','localization/source-inventory.json']
files={}
for n in source:files['source/'+n]=Path(n).read_bytes()
for p in root.glob('*.log'):files['logs/'+p.name]=p.read_bytes()
for n in ['verification-commands.json','verify.py','archive.py']:files['verification/'+n]=(root/n).read_bytes()
rows=json.loads((root/'verification-commands.json').read_text());assert len(rows)==4 and all(r['exitCode']==0 for r in rows)
for p in (root/'ci').iterdir():
 if p.suffix in {'.json','.log'}: files['preceding-ci/'+p.name]=p.read_bytes()
binaries={}
for label,build in [('release',Path('.cache/take-preview-linux/build')),('asan-ubsan',Path('.cache/waveform-controller-344/asan'))]:
 files['build/'+label+'/CMakeCache.txt']=(build/'CMakeCache.txt').read_bytes()
 files['build/'+label+'/commands.txt']=subprocess.check_output(['ninja','-C',str(build),'-t','commands','sc-waveform-cache-tests','sc-waveform-controller-tests'])
 for name in ['sc-waveform-cache-tests','sc-waveform-controller-tests','sc-waveform-worker','sc-waveform-lifecycle-probe','sc-waveform-protocol-tests','sc-waveform-tests','sc-wave-validation-tests','libsc-ui-waveform.a','libsc-waveform.a']:
  path=build/name
  with path.open('rb') as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
  binaries[label+'/'+name]=dict(bytes=path.stat().st_size,sha256=sha)
files['verification/binary-hashes.json']=(json.dumps(binaries,indent=2)+'\n').encode()
files['verification/tracked.patch']=subprocess.check_output(['git','diff','--','.github/workflows/ci.yml','CMakeLists.txt','include/soundcurrent/waveform_protocol.hpp'])
index={n:dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest()) for n,b in files.items()}
files['payload-index.json']=(json.dumps(index,indent=2)+'\n').encode()
archive=out/'acceptance.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for n,b in files.items():z.writestr(n,b)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,d in index.items():
  b=z.read(n);assert len(b)==d['bytes'] and hashlib.sha256(b).hexdigest()==d['sha256']
m=dict(archive=archive.name,bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),entries=len(files),baseHead=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),testedWorkingTreeSource={n:index['source/'+n] for n in source},controllerChecks=106,cacheProjectionChecks=112881,localizationChecksPassed=True,releasePassed=True,asanUbsanPassed=True,nativeWindowsControllerQualified=False,timelineIntegrated=False,installedPreviewsChanged=False,binariesIncluded=False,precedingCI=json.loads((root/'ci/retention.json').read_text()))
(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps({k:m[k] for k in ['bytes','sha256','entries','baseHead']}))
