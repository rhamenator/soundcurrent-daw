from pathlib import Path
import hashlib,json,gzip,subprocess
r=Path('.cache/pipewire-recording-journal');d=Path('tests/results/M2/2026-10-12-pipewire-recording-journal');d.mkdir(parents=True,exist_ok=True)
f=json.loads((r/'frozen-inputs.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
for x in f['selectedInputs']:assert sha(Path(x['path']).read_bytes())==x['checkoutSha256']
members={}
def put(name,b):
 p=d/(name+'.gz');p.parent.mkdir(parents=True,exist_ok=True);z=gzip.compress(b,mtime=0);p.write_bytes(z)
 members[name+'.gz']={'bytes':len(z),'sha256':sha(z),'originalBytes':len(b),'originalSha256':sha(b)}
for name in ['frozen-inputs.json','source-delta.diff','configure.log','build.log','initial-tests.log','final-build.log','final-tests.log','corrected-build.log','corrected-tests.log','current-release-build.log','current-release-tests.log','current-sanitizer-build.log','current-sanitizer-tests.log','sanitizer-configure.log','sanitizer-build.log','sanitizer-tests.log','windows-qualification.json','windows-qualification.log','freeze-inputs.py','qualify-windows.py','retain161.py','retain161.log','pr161-tested-merge.json']:
 put(name,(r/name).read_bytes())
for p in r.glob('windows-compile-*.log'):put(p.name,p.read_bytes())
for folder in ['initial-failure','empty-finalization-failure','windows-fixture-failure','pr161-review']:
 for p in sorted((r/folder).iterdir()):
  if p.is_file() and p.suffix in ['.json','.log','.cpp']:put(folder+'/'+p.name,p.read_bytes())
hashes={}
for profile in ['release','sanitizer']:
 p=r/profile
 for name in ['CMakeCache.txt','Testing/Temporary/LastTest.log']:put(profile+'/'+name,(p/name).read_bytes())
 put(profile+'/generated-commands.log',subprocess.check_output(['ninja','-C',str(p),'-t','commands']))
 files=list(p.glob('*.a'))+[q for q in p.glob('sc-*-tests') if q.is_file()]
 hashes[profile]={str(q.relative_to(p)):{'bytes':q.stat().st_size,'sha256':sha(q.read_bytes())} for q in files}
put('build-output-hashes.json',json.dumps(hashes,indent=2).encode())
commands={'regex':'^(pipewire-recording-durable-prefix|pipewire-native-receipt-handoffs|pipewire-native-receipt-codec|original-raw-recording)$','ctestArgs':['--output-on-failure','--parallel','1'],'asanEnvironment':{'ASAN_OPTIONS':'detect_leaks=0:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'},'priority':['nice','-n','15','ionice','-c','2','-n','7'],'buildWorkers':1,'windows':'Exact argv/object hashes in windows-qualification.json'}
put('qualification-commands.json',json.dumps(commands,indent=2).encode());put('package-evidence.py',Path(__file__).read_bytes())
summary={'implementation':f['source'],'tree':f['tree'],'sourceInputs':len(f['selectedInputs']),'release':{'passed':4,'tests':4,'seconds':.21,'journalChecksScheduleDependent':70,'actualJournalProcessInterruptions':8},'asanUbsan':{'passed':4,'tests':4,'seconds':1.49,'leakDetection':False},'windows':json.loads((r/'windows-qualification.json').read_text()),'previousCi':{'pr':161,'run':38307710292,'head':'7c478619d042be95a61fc118018a688ddd37a10a','jobs':'All4success original run attempt1','linux':'148/444.00s','desktop':'20/106.68s','native':'75/205.08s','historicalFailuresCausallyResolved':False},'scope':'Disk-owner journal/streaming paired-prefix inspection; no live owner/native controller/Qt route integration','retainedFixtureFailures':3,'newTestsNativeSdkActivated':False,'physicalAudio':False,'vmUsed':False,'windowsRuntimeForCurrentRevision':False,'payloadPolicy':'Text/log/configuration/metadata and local binary hashes only; no binary/audio/ZIP payload','members':members}
(d/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for name,row in members.items():
 b=(d/name).read_bytes();assert sha(b)==row['sha256'];raw=gzip.decompress(b);assert sha(raw)==row['originalSha256'] and len(raw)==row['originalBytes']
print('Verified',len(members),'bound text/log/metadata members;',len(f['selectedInputs']),'qualified inputs unchanged')
