# SPDX-License-Identifier: GPL-3.0-only
import hashlib,json,os,shutil,subprocess,sys,time,uuid
from pathlib import Path
source=Path.home()/'soundcurrent-daw-stretch-f9a6353'
out=Path.home()/'soundcurrent-protected-repro-cceedcc'
sys.path.insert(0,str(source/'tests'))
from worker_observation import observe,diagnostic
sdk=Path.home()/'soundcurrent-daw-msvc-sdk-v1'
os.environ['PATH']=str(sdk/'qt/bin')+';'+str(sdk/'sndfile-build-v2/Release')+';'+os.environ['PATH']
worker=source/'build/Release/sc-stretch-render-worker.exe';prototype=source/'build/Release/sc-protected-warp-probe.exe'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git','-c','core.fsmonitor=false','-c','core.fscache=false',*args],cwd=source,text=True,timeout=20).strip()
commit=git('rev-parse','HEAD');tree=git('rev-parse','HEAD^{tree}')
assert commit=='cceedcc6e6d468a4a22cff617bf26d58515888e8' and tree=='5db68c1e903606eb5965f09175b5a983fc78cc64' and not git('status','--porcelain','--untracked-files=no')
identity={'sourceCommit':commit,'sourceTree':tree,'workerSha256':sha(worker),'prototypeSha256':sha(prototype),'observerSha256':sha(source/'tests/worker_observation.py'),'producerSha256':sha(Path(__file__)),'nativeAudio':False,'installed':False}
for profile in ['identity','uniform','nonuniform']:
    case=out/('one-impulse-'+profile);case.mkdir();root=case/'studio été';(root/'media/derived').mkdir(parents=True)
    prototype_dir=case/'prototype';command=[str(prototype),json.dumps({'family':'impulse','profile':profile}),str(prototype_dir)]
    probe=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    try:probe_out,probe_err=probe.communicate(timeout=15)
    except subprocess.TimeoutExpired:probe.kill();probe_out,probe_err=probe.communicate(timeout=5);raise
    (case/'prototype.stdout').write_bytes(probe_out);(case/'prototype.stderr').write_bytes(probe_err)
    assert probe.returncode==0 and not probe_err
    shutil.copyfile(prototype_dir/'source.wav',root/'media/source.wav')
    events=[4096,12288,20480,28672];target=32768 if profile=='identity' else 49152
    targets=events if profile=='identity' else [v*3//2 for v in events] if profile=='uniform' else [6144,16384,32768,43008]
    markers=[];spans=[];points=[{'source':[0,0,1],'output':[0,0,1]}]
    for i,(x,y) in enumerate(zip(events,targets)):
        owner=f'00000000-0000-0000-0000-{i+1:012x}'
        markers.append({'id':owner,'source':[x,0,1],'output':[y,0,1]});span={'owner':owner}
        for name,value in [('sourceBegin',x-256),('sourceAnchor',x),('sourceEnd',x+2048),('outputBegin',y-256),('outputAnchor',y),('outputEnd',y+2048)]:span[name]=[value,0,1]
        spans.append(span)
        for a,b in [(x-256,y-256),(x,y),(x+2048,y+2048)]:
            point={'source':[a,0,1],'output':[b,0,1]}
            if point!=points[-1]:points.append(point)
    last={'source':[32768,0,1],'output':[target,0,1]}
    if points[-1]!=last:points.append(last)
    q={'protocol':'sc-stretch-render-v5','processor':'soundcurrent.stretch-transient-protected-rubberband4-r3-v1','operation':str(uuid.uuid4()),'assetId':str(uuid.uuid4()),'relative':'media/source.wav','sha256':sha(root/'media/source.wav'),'rate':48000,'channels':2,'sourceFrames':32768,'first':0,'firstFraction':0,'firstDenominator':1,'frames':32768,'timeNumerator':1 if profile=='identity' else 3,'timeDenominator':1 if profile=='identity' else 2,'pitchMilliCents':0,'formantPreserved':True,'contextEnabled':False,'contextBefore':0,'contextAfter':0,'warp':{'mode':'transient-protected-v1','before':256,'after':2048,'halo':64,'minimumNonunityGap':64,'chunkFrames':512,'map':'soundcurrent.warp-piecewise-rational-v1','markers':markers,'spans':spans,'points':points}}
    command=[str(worker),'--project-root',str(root),'--jobs-root',str(root/'media/derived'),'--memory-mib','256','--maximum-input-frames','100000','--maximum-output-bytes','8388608','--deadline-ms','10000']
    (case/'request.json').write_text(json.dumps(dict(identity,request=q,argv=command,prototypePid=probe.pid,prototypeExit=probe.returncode),indent=2),encoding='utf8')
    ready=None
    def acknowledge(line):
        global ready
        packet=json.loads(line)
        if packet.get('event')=='ready':
            assert packet['operation']==q['operation'];ready=packet
            (root/'media/derived'/q['operation']/'start.request').write_text('start')
    result=observe(command,json.dumps(q),acknowledge,timeout=15)
    terminal=dict(identity,profile=profile,ready=ready,**json.loads(diagnostic(result)))
    (case/'terminal.json').write_text(json.dumps(terminal,indent=2),encoding='utf8')
    (case/'worker.stdout').write_text(result.stdout,encoding='utf8');(case/'worker.stderr').write_text(result.stderr,encoding='utf8')
    print(json.dumps({key:terminal[key] for key in ['profile','pid','exitCode','seconds','observationTimedOut','outputLimited','retirementPending','stdout','stderr']}),flush=True)
    if result.returncode!=0 or result.observation_timed_out or result.output_limited or result.retirement_pending:raise RuntimeError('Actual owned protected request failed; terminal retained')
assert not git('status','--porcelain','--untracked-files=no') and git('rev-parse','HEAD')==commit
(out/'one-protected-complete.json').write_text(json.dumps(dict(identity,profiles=['identity','uniform','nonuniform'],completed=True),indent=2),encoding='utf8')
