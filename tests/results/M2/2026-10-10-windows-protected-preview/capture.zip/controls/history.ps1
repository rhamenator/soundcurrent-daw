﻿$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$root=Join-Path $env:USERPROFILE 'SoundCurrent-Protected-Installed-cceed'
if((Get-CimInstance Win32_ComputerSystemProduct).UUID -ne '670168F5-4E3F-4E7F-B218-3583DB31F0F8') {throw 'Wrong owned clone'}
$p=Get-Process -Id ([int](Get-Content (Join-Path $root 'main-pid.txt')))
if($p.SessionId -eq 0 -or !$p.MainWindowTitle.StartsWith('SoundCurrent DAW')) {throw 'Wrong actual app'}
Add-Type -AssemblyName System.Windows.Forms
Add-Type 'using System;using System.Runtime.InteropServices;public class SCForeground { [DllImport("user32.dll")]public static extern bool SetForegroundWindow(IntPtr h); }'
$project=Join-Path $root 'project-été-Κиїв\project.json'
foreach($stage in @('applied','undo','redo')) {
 if($stage -ne 'applied') {
  $p.Refresh();if(![SCForeground]::SetForegroundWindow($p.MainWindowHandle)) {throw 'Cannot focus actual app'}
  Start-Sleep -Milliseconds 750
  $key=if($stage -eq 'undo') {'^z'} else {'^y'}
  [Windows.Forms.SendKeys]::SendWait($key);Start-Sleep -Milliseconds 1000
  [Windows.Forms.SendKeys]::SendWait('^s');Start-Sleep -Milliseconds 1200
 }
 Copy-Item -LiteralPath $project (Join-Path $root ('project-'+$stage+'.json'))
}
& (Join-Path $root 'collect.ps1') 'cceed-history.zip'
