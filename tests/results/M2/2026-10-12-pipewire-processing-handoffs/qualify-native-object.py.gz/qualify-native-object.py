from pathlib import Path
import subprocess,json,hashlib
r=Path('.cache/pipewire-processing-handoffs');f=json.loads((r/'frozen-inputs.json').read_text())
for x in f['selectedInputs']:assert hashlib.sha256(Path(x['path']).read_bytes()).hexdigest()==x['checkoutSha256']
version=subprocess.check_output(['pkg-config','--modversion','libpipewire-0.3'],text=True).strip()
flags=subprocess.check_output(['pkg-config','--cflags','libpipewire-0.3'],text=True).split()
obj=r/'native-render-stream.obj';src='src/pipewire_monitor_render_stream.cpp';cmd=['nice','-n','15','ionice','-c','2','-n','7','g++','-std=c++20','-O2','-Wall','-Wextra','-Wpedantic','-Wconversion','-Iinclude',*flags,'-c',src,'-o',str(obj)]
with (r/'native-adapter-compile.log').open('w') as out:p=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
if p.returncode:raise SystemExit('Native adapter compile failed; original retained')
assert 'warning:' not in (r/'native-adapter-compile.log').read_text()
x={'source':f['source'],'sdkVersion':version,'argv':cmd,'objectBytes':obj.stat().st_size,'objectSha256':hashlib.sha256(obj.read_bytes()).hexdigest(),'sdkAdapterCompiled':True,'linkedOrExecuted':False,'physicalAudio':False}
(r/'native-adapter-qualification.json').write_text(json.dumps(x,indent=2)+'\n');print('Genuine render adapter/current monotonic sampling compiles; SDK',version,'; no runtime claim')
