from pathlib import Path
import hashlib,json,gzip,subprocess
r=Path('.cache/pipewire-processing-handoffs');d=Path('tests/results/M2/2026-10-12-pipewire-processing-handoffs');d.mkdir(parents=True,exist_ok=True)
f=json.loads((r/'frozen-inputs.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
for x in f['selectedInputs']:assert sha(Path(x['path']).read_bytes())==x['checkoutSha256']
members={}
def put(name,b):
 p=d/(name+'.gz');p.parent.mkdir(parents=True,exist_ok=True);z=gzip.compress(b,mtime=0);p.write_bytes(z)
 members[name+'.gz']={'bytes':len(z),'sha256':sha(z),'originalBytes':len(b),'originalSha256':sha(b)}
for name in ['frozen-inputs.json', 'source-delta.diff', 'configure.log', 'build.log', 'initial-tests.log', 'corrected-build.log', 'corrected-tests.log', 'final-build.log', 'current-build.log', 'final-tests.log', 'clock-build.log', 'clock-tests.log', 'sanitizer-configure.log', 'sanitizer-build.log', 'sanitizer-tests.log', 'tsan-configure.log', 'tsan-build.log', 'tsan-tests.log', 'windows-qualification.json', 'windows-qualification.log', 'native-adapter-compile.log', 'native-adapter-qualification.log', 'native-adapter-qualification.json', 'freeze-inputs.py', 'qualify-windows.py', 'qualify-native-object.py', 'retain162.py', 'retain162.log', 'pr162-tested-merge.json']:
 put(name,(r/name).read_bytes())
for p in r.glob('windows-compile-*.log'):put(p.name,p.read_bytes())
for folder in ['initial-fixture-failure','pr162-review']:
 for p in sorted((r/folder).iterdir()):
  if p.is_file() and p.suffix in ['.json','.log','.cpp']:put(folder+'/'+p.name,p.read_bytes())
hashes={}
for profile in ['release','sanitizer','thread-sanitizer']:
 p=r/profile
 for name in ['CMakeCache.txt','Testing/Temporary/LastTest.log']:put(profile+'/'+name,(p/name).read_bytes())
 put(profile+'/generated-commands.log',subprocess.check_output(['ninja','-C',str(p),'-t','commands']))
 files=list(p.glob('*.a'))+[q for q in p.glob('sc-*-tests') if q.is_file()]
 hashes[profile]={str(q.relative_to(p)):{'bytes':q.stat().st_size,'sha256':sha(q.read_bytes())} for q in files}
put('build-output-hashes.json',json.dumps(hashes,indent=2).encode())
commands={'releaseRegex':'^(pipewire-stop-publication|pipewire-shared-processing-handoffs|pipewire-monitor-planar-capture|pipewire-monitor-planar-render|monitor-capture-stop|bounded-monitor-processing|native-monitor-startup)$','asanRegex':'^(pipewire-stop-publication|pipewire-shared-processing-handoffs|pipewire-monitor-planar-capture|pipewire-monitor-planar-render|monitor-capture-stop|bounded-monitor-processing)$','tsanRegex':'^pipewire-stop-publication$','ctestArgs':['--output-on-failure','--parallel','1'],'asanEnvironment':{'ASAN_OPTIONS':'detect_leaks=0:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'},'tsanEnvironment':{'TSAN_OPTIONS':'halt_on_error=1'},'priority':['nice','-n','15','ionice','-c','2','-n','7'],'buildWorkers':1,'windows':'Exact argv/object hashes in windows-qualification.json','native':'Adapter object only, actual monotonic sampling; no runtime claim'}
put('qualification-commands.json',json.dumps(commands,indent=2).encode());put('package-evidence.py',Path(__file__).read_bytes())
summary={'implementation':f['source'],'tree':f['tree'],'sourceInputs':len(f['selectedInputs']),'release':{'passed':7,'tests':7,'seconds':20.18,'pipelineChecks':100993,'processedMonitorFrames':2400,'stopThreadPairs':16},'asanUbsan':{'passed':6,'tests':6,'seconds':3.76,'leakDetection':False},'threadSanitizer':{'passed':1,'tests':1,'seconds':.06,'suppressions':False,'scope':'Backend-neutral/PipeWire immutable stop/end;16 actual thread pairs; media/resampling/SDK disabled'},'windows':json.loads((r/'windows-qualification.json').read_text()),'nativeAdapterObject':json.loads((r/'native-adapter-qualification.json').read_text()),'previousCi':{'pr':162,'run':38310727076,'head':'847d37244413ecad7b6db0cfba5abb18d1114704','jobs':'All4success original run','linux':'149/287.14s','desktop':'20/82.26s','native':'76/206.49s','historicalFailuresCausallyResolved':False},'scope':'Shared processing startup/end composition plus raw/receipt journal; complete native thread factory/controller/UI integration pending','retainedFixtureFailures':1,'newFixtureSdkActivated':False,'physicalAudio':False,'vmUsed':False,'windowsRuntimeForCurrentRevision':False,'payloadPolicy':'Text/log/configuration/metadata and local binary hashes only; no binary/audio/ZIP payload','members':members}
(d/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for name,row in members.items():
 b=(d/name).read_bytes();assert sha(b)==row['sha256'];raw=gzip.decompress(b);assert sha(raw)==row['originalSha256'] and len(raw)==row['originalBytes']
print('Verified',len(members),'bound text/log/metadata members;',len(f['selectedInputs']),'qualified inputs unchanged')
