// SPDX-License-Identifier: GPL-3.0-only
#pragma once
#include "stretch.hpp"
#include "resource_ledger.hpp"
#include <vector>
namespace soundcurrent::daw {
struct CompHandlePoint { SourcePosition raw, output; };
struct CompHandlePlanLimits {
    Frame maximumOutputFrames=1000000000;
    std::uint64_t maximumOutputBytes=8ULL*1024*1024*1024;
    std::size_t maximumMapPoints=16388;
};
struct CompHandleEnvelope {
    ResourceLease lease; // retires after the owned snapshots/map
    Id project=Id::generate(),track=Id::generate();
    std::uint32_t projectRate=0;
    ChannelLayout trackLayout;
    Clip expected,retained;
    Asset raw,base,retainedAsset;
    Frame projectFirst=0,projectEnd=0,prefixFrames=0,suffixFrames=0,outputFrames=0;
    SourcePosition clipOutputOrigin,requestedRawFirst,requestedRawLast,requestedRawEnd;
    std::vector<CompHandlePoint> map;
    bool needsNewSpan=false,needsNominalExposure=false;
};
// Control-side plan only: no I/O, rendering or Session publication. Existing
// anchor/settings/context/markers remain in expected. New data and atomic
// admission still require a separately verified worker result.
void verifyCompHandleEnvelopeCurrent(const Session &,const CompHandleEnvelope &);
struct CompTransitionHandlePlan { PrepareCompTransition transition;CompHandleEnvelope outgoing,incoming; };
CompTransitionHandlePlan prepareCompTransitionHandles(const Session &,const PrepareCompTransition &,ResourceLedger,CompHandlePlanLimits={});
void verifyCompTransitionHandlesCurrent(const Session &,const CompTransitionHandlePlan &);
CompHandleEnvelope prepareCompHandleEnvelope(const Session &,const Id &track,const Id &clip,
    Frame projectFirst,Frame projectEnd,ResourceLedger,CompHandlePlanLimits={});
}
