// SPDX-License-Identifier: GPL-3.0-only
#include <soundcurrent/comp_handle_plan.hpp>
#include <soundcurrent/clip_timing.hpp>
#include <soundcurrent/warp.hpp>
#include <algorithm>
#include <numeric>
#include <limits>
namespace soundcurrent::daw {
namespace {
void require(bool v,const char *s){if(!v)throw ProjectError(ErrorCode::InvalidState,s);}
template<class T> const T &find(const std::vector<T> &v,const Id &id){auto p=std::find_if(v.begin(),v.end(),[&](const auto &x){return x.id==id;});require(p!=v.end(),"Comp handle selection no longer exists");return *p;}
struct Signed {bool negative=false;SourcePosition magnitude;};
Signed coordinate(const SourceFrameMap &m,Frame delta){
    const auto origin=m.at(0);if(delta>=0)return {false,m.at(delta)};
    require(delta!=INT64_MIN,"Comp handle offset overflow");
    const auto amount=scaleSourcePosition({-delta,0,1},m.numerator(),m.denominator());
    return sourcePositionLess(origin,amount)?Signed{true,subtractSourcePosition(amount,origin)}:Signed{false,subtractSourcePosition(origin,amount)};
}
Frame ceil(SourcePosition p){require(p.frame<INT64_MAX || !p.fraction,"Comp handle frame rounding overflow");return p.frame+Frame(p.fraction!=0);}
// Prototype implementation delegates this interval-ratio operation to the
// existing exact warp helper when promoted into the repository.
SourcePosition intervalScale(SourcePosition p,SourcePosition n,SourcePosition d){
    const auto improper=[](SourcePosition q){require(q.denominator && q.fraction<q.denominator && q.frame>=0,"Invalid interval");require(std::uint64_t(q.frame)<=(UINT64_MAX-q.fraction)/q.denominator,"Interval scale overflow");return std::uint64_t(q.frame)*q.denominator+q.fraction;};
    auto nn=improper(n),dn=improper(d),nd=n.denominator,dd=d.denominator;require(nn && dn,"Empty map interval");
    auto a=std::gcd(nn,dn);nn/=a;dn/=a;auto b=std::gcd(dd,nd);dd/=b;nd/=b;
    require(nn<=UINT64_MAX/dd && dn<=UINT64_MAX/nd,"Interval ratio overflow");return scaleSourcePosition(p,nn*dd,dn*nd);
}
SourcePosition rawAt(Signed p,std::span<const CompHandlePoint> map){
    if(p.negative){auto amount=intervalScale(p.magnitude,subtractSourcePosition(map[1].raw,map[0].raw),subtractSourcePosition(map[1].output,map[0].output));return subtractSourcePosition(map.front().raw,amount);}
    if(sourcePositionLess(map.back().output,p.magnitude)) {
        const auto &a=map[map.size()-2],&b=map.back();return addSourcePosition(b.raw,intervalScale(subtractSourcePosition(p.magnitude,b.output),subtractSourcePosition(b.raw,a.raw),subtractSourcePosition(b.output,a.output)));
    }
    if(!sourcePositionLess(p.magnitude,map.back().output))return map.back().raw;
    const auto right=std::upper_bound(map.begin(),map.end(),p.magnitude,[](SourcePosition x,const auto &k){return sourcePositionLess(x,k.output);});
    require(right!=map.begin(),"Comp handle map precedes its origin");const auto &a=*(right-1),&b=*right;
    if(p.magnitude==a.output)return a.raw;
    return addSourcePosition(a.raw,intervalScale(subtractSourcePosition(p.magnitude,a.output),subtractSourcePosition(b.raw,a.raw),subtractSourcePosition(b.output,a.output)));
}
}
CompHandleEnvelope prepareCompHandleEnvelope(const Session &s,const Id &trackId,const Id &clipId,
    Frame first,Frame end,ResourceLedger ledger,CompHandlePlanLimits limits){
    require(limits.maximumOutputFrames>0 && limits.maximumOutputFrames<=1000000000 && limits.maximumMapPoints>=2,"Invalid handle plan limits");
    const auto bytes=sessionPayloadBytes(s);require(bytes<=SIZE_MAX/3,"Handle plan credit overflow");auto credit=ledger.reserve(bytes*3);
    validate(s);const auto &c=find(find(s.tracks,trackId).clips,clipId);
    require(c.takeOrigin && first>=0 && first<=c.startFrame && end>=c.startFrame+c.lengthFrames && end>first,"Handle envelope must extend a retained rendered clip");
    const auto &origin=*c.takeOrigin;const auto &retained=find(find(find(s.tracks,origin.trackId).takeLanes,origin.laneId).clips,origin.clipId);
    const auto &raw=find(s.assets,c.stretch?c.stretch->sourceAssetId:c.assetId),&base=find(s.assets,c.assetId),&retainedAsset=find(s.assets,retained.assetId);
    require(raw.id==retained.assetId || (c.stretch && retained.stretch && raw.id==retained.stretch->sourceAssetId && c.stretch->sourceSha256==retained.stretch->sourceSha256),"Handle render source differs from retained take");
    const auto g=c.stretch?stretchGeometry(*c.stretch,raw.frames):StretchGeometry{{0,0,1},base.frames,base.frames,{0,0,1},{base.frames,0,1},1,1};
    ResourceLease oldMapCredit;std::vector<CompHandlePoint> oldMap;
    if(c.stretch && c.stretch->warp){const auto &p=*c.stretch;ProtectedWarpPlan warp({p.sourceOrigin,raw.sampleRate,raw.frames,p.sourceFrames,g.outputFrames,{0,0,1},{p.sourceFrames,0,1}},p.warp->markers,p.warp->protection,ledger);
        require(warp.map().points().size()<=limits.maximumMapPoints,"Handle map exceeds point limit");oldMapCredit=ledger.reserve(warp.map().points().size()*sizeof(CompHandlePoint));oldMap.reserve(warp.map().points().size());
        for(const auto &k:warp.map().points())oldMap.push_back({addSourcePosition(p.sourceOrigin,k.source),k.output});
    } else {oldMapCredit=ledger.reserve(2*sizeof(CompHandlePoint));oldMap={{g.inputOrigin,{0,0,1}},{addSourcePosition(g.inputOrigin,{g.inputFrames,0,1}),{g.outputFrames,0,1}}};}
    const auto m=clipSourceMap(c,base.sampleRate,s.sampleRate);const auto outputFirst=coordinate(m,first-c.startFrame),outputLast=coordinate(m,end-1-c.startFrame),outputEnd=coordinate(m,end-c.startFrame);
    const auto rawFirst=rawAt(outputFirst,oldMap),rawLast=rawAt(outputLast,oldMap),rawEnd=rawAt(outputEnd,oldMap);
    const auto allowed=clipSourceMap(retained,retainedAsset.sampleRate,s.sampleRate);auto allowedFirst=allowed.at(0),allowedEnd=allowed.at(retained.lengthFrames);
    if(retained.assetId!=raw.id){require(bool(retained.stretch),"Missing retained raw map");auto rg=stretchGeometry(*retained.stretch,raw.frames);if(sourcePositionLess(rg.visibleEnd,allowedEnd))allowedEnd=rg.visibleEnd;allowedFirst=stretchOutputToRaw(*retained.stretch,allowedFirst);allowedEnd=stretchOutputToRaw(*retained.stretch,allowedEnd);}
        if(c.stretch)require(!sourcePositionLess(rawFirst,allowedFirst) && sourcePositionLess(rawLast,allowedEnd),"Requested handles exceed retained take");
    else require(!sourcePositionLess(rawFirst,allowedFirst) && !sourcePositionLess(allowed.at(retained.lengthFrames-1),rawLast),"Requested raw handles exceed retained take");
    const auto prefix=outputFirst.negative?ceil(outputFirst.magnitude):0;
    require(!outputLast.negative && outputLast.magnitude.frame<INT64_MAX,"Comp handle end is negative or overflowing");const auto last=outputLast.magnitude.frame+1;const auto suffix=std::max<Frame>(0,last-base.frames);
    require(base.frames<=limits.maximumOutputFrames && prefix<=limits.maximumOutputFrames-base.frames && suffix<=limits.maximumOutputFrames-base.frames-prefix,"Handle output exceeds frame limit");
    const auto frames=prefix+base.frames+suffix;
    require(std::uint64_t(frames)<=(limits.maximumOutputBytes>8192?limits.maximumOutputBytes-8192:0)/(4ULL*base.layout.channels),"Handle output exceeds byte limit");
    const auto wholeFirst=rawAt({bool(prefix),{prefix,0,1}},oldMap),wholeEnd=rawAt({false,{base.frames+suffix,0,1}},oldMap);
    require(!sourcePositionLess({raw.frames,0,1},wholeEnd),"Full handle input exceeds real source");
    const auto points=oldMap.size()+std::size_t(prefix!=0)+std::size_t(suffix!=0);
    require(points<=limits.maximumMapPoints,"Expanded handle map exceeds point limit");auto mapCredit=ledger.reserve(points*sizeof(CompHandlePoint));
    CompHandleEnvelope result;result.lease=std::move(credit);result.project=s.id;result.projectRate=s.sampleRate;result.track=trackId;result.trackLayout=find(s.tracks,trackId).layout;result.expected=c;result.retained=retained;result.raw=raw;result.base=base;result.retainedAsset=retainedAsset;
    result.projectFirst=first;result.projectEnd=end;result.prefixFrames=prefix;result.suffixFrames=suffix;result.outputFrames=frames;
    result.clipOutputOrigin=outputFirst.negative?subtractSourcePosition({prefix,0,1},outputFirst.magnitude):addSourcePosition({prefix,0,1},outputFirst.magnitude);
    result.requestedRawFirst=rawFirst;result.requestedRawLast=rawLast;result.requestedRawEnd=rawEnd;
    result.map.reserve(points);if(prefix)result.map.push_back({wholeFirst,{0,0,1}});
    for(auto point:oldMap){point.output=addSourcePosition(point.output,{prefix,0,1});result.map.push_back(point);}
    if(suffix)result.map.push_back({wholeEnd,{frames,0,1}});
    result.needsNewSpan=prefix || suffix;result.needsNominalExposure=outputFirst.negative || sourcePositionLess(outputFirst.magnitude,g.visibleBegin) || !sourcePositionLess(outputLast.magnitude,g.visibleEnd);
    // The map's credit must live as long as the vector, not just preparation.
    mapCredit.transferTo(result.lease,mapCredit.bytes());return result;
}
void verifyCompHandleEnvelopeCurrent(const Session &s,const CompHandleEnvelope &p) {
    require(s.id==p.project && s.sampleRate==p.projectRate,"Handle plan belongs to a different project/rate");
    const auto &track=find(s.tracks,p.track);require(track.layout==p.trackLayout && find(track.clips,p.expected.id)==p.expected,"Handle clip/layout changed after planning");
    require(find(s.assets,p.raw.id)==p.raw && find(s.assets,p.base.id)==p.base && find(s.assets,p.retainedAsset.id)==p.retainedAsset,"Handle source declaration changed after planning");
    require(p.expected.takeOrigin.has_value(),"Handle plan has no retained source identity");
    const auto &origin=*p.expected.takeOrigin;
    require(find(find(find(s.tracks,origin.trackId).takeLanes,origin.laneId).clips,origin.clipId)==p.retained,"Retained take changed after planning");
}
CompTransitionHandlePlan prepareCompTransitionHandles(const Session &s,const PrepareCompTransition &e,ResourceLedger ledger,CompHandlePlanLimits limits) {
    require(e.outgoing!=e.incoming,"Handle transition needs distinct fragments");
    const auto &clips=find(s.tracks,e.track).clips;const auto &out=find(clips,e.outgoing),&in=find(clips,e.incoming);
    require(out.startFrame<=in.startFrame && out.startFrame+out.lengthFrames<=in.startFrame+in.lengthFrames && in.startFrame<=out.startFrame+out.lengthFrames,"Handle transition needs ordered adjacent or overlapping fragments");
    require(e.startFrame>=out.startFrame && e.startFrame<out.startFrame+out.lengthFrames && e.endFrame>in.startFrame && e.endFrame<=in.startFrame+in.lengthFrames && e.endFrame>e.startFrame,"Handle transition range exceeds fragment pair");
    validateClipProcessing({0,false,false,{}, {0,1,e.curve,1}});
    auto outgoing=prepareCompHandleEnvelope(s,e.track,e.outgoing,out.startFrame,std::max(out.startFrame+out.lengthFrames,e.endFrame),ledger,limits);
    auto incoming=prepareCompHandleEnvelope(s,e.track,e.incoming,std::min(in.startFrame,e.startFrame),in.startFrame+in.lengthFrames,ledger,limits);
    return {e,std::move(outgoing),std::move(incoming)};
}
void verifyCompTransitionHandlesCurrent(const Session &s,const CompTransitionHandlePlan &p) {
    verifyCompHandleEnvelopeCurrent(s,p.outgoing);verifyCompHandleEnvelopeCurrent(s,p.incoming);
}

}
