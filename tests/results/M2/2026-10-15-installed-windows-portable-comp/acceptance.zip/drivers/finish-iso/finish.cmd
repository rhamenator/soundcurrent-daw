@echo off
copy /y "%~dp0finish.ps1" "%USERPROFILE%\SoundCurrent-Installed-325\finish.ps1" >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%USERPROFILE%\SoundCurrent-Installed-325\finish.ps1"
pause
