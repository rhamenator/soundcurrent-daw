@echo off
copy /y "%~dp0continue.ps1" "%USERPROFILE%\SoundCurrent-Installed-325\continue.ps1" >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%USERPROFILE%\SoundCurrent-Installed-325\continue.ps1"
pause
