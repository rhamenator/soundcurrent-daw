@echo off
copy /y "%~dp0next.ps1" "%USERPROFILE%\SoundCurrent-Installed-325\next.ps1" >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%USERPROFILE%\SoundCurrent-Installed-325\next.ps1"
pause
