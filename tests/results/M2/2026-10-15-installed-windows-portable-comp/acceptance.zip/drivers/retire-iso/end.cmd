@echo off
copy /y "%~dp0end.ps1" "%USERPROFILE%\SoundCurrent-Installed-325\end.ps1" >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%USERPROFILE%\SoundCurrent-Installed-325\end.ps1"
pause
