from pathlib import Path
import datetime, hashlib, json, os, shutil, subprocess

base = Path(__file__).resolve().parent
pkg = base.parent / 'p319-package-20261015124133'
receipt = json.loads((pkg / 'receipt.json').read_text())
sha = lambda p: hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()
def inventory(root):
    return {str(p.relative_to(root)): sha(p) for p in root.rglob('*') if p.is_file()}

assert receipt['source_head'] == '258016450f93ebbecd2d62fa8ee6f9f9e60964e0'
assert receipt['status'] == 'prepared-local-preview'
deb = next(pkg.glob('*.deb'))
assert sha(deb) == receipt['artifacts'][deb.name]['sha256']
source = pkg / 'extracted'
dest = Path.home() / '.local/opt/soundcurrent-daw/previews' / receipt['version']
launcher = Path.home() / '.local/share/applications/soundcurrent-daw-preview.desktop'
previous = launcher.with_name('soundcurrent-daw-preview-before-20261015.desktop')
older = launcher.with_name('soundcurrent-daw-preview-previous.desktop')
oldroot = dest.parent / receipt['previous_version']
assert launcher.is_file() and not launcher.is_symlink()
assert not dest.exists() and not previous.exists()
old = launcher.read_bytes()
assert str(oldroot).encode() in old
oldfiles = inventory(oldroot)
older_hash = sha(older)
(base / 'previous-launcher.desktop.txt').write_bytes(old)
(base / 'preserved-preview-before.json').write_text(json.dumps(oldfiles, indent=2)+'\n')
shutil.copytree(source, dest, copy_function=shutil.copy2)
files = inventory(source)
assert inventory(dest) == files
binary = dest / 'usr/bin/soundcurrent-daw'
assert sha(binary) == receipt['packaged_executable_sha256']
icon = dest / 'usr/share/icons/hicolor/scalable/apps/soundcurrent-daw.svg'
entry = (dest/'usr/share/applications/soundcurrent-daw.desktop').read_text()
entry = entry.replace('Name=SoundCurrent DAW\n','Name=SoundCurrent DAW Preview\n').replace('Exec=soundcurrent-daw %f',f'Exec="{binary}" %f').replace('TryExec=soundcurrent-daw',f'TryExec={binary}').replace('Icon=soundcurrent-daw',f'Icon={icon}')
temporary = launcher.with_name('soundcurrent-daw-preview-candidate.desktop')
assert not temporary.exists()
temporary.write_text(entry)
subprocess.run(['desktop-file-validate',str(temporary)],check=True)
previous.write_bytes(old.replace(b'Name=SoundCurrent DAW Preview\n',b'Name=SoundCurrent DAW Preview (before 2026-10-15)\n'))
subprocess.run(['desktop-file-validate',str(previous)],check=True)
assert launcher.read_bytes() == old
os.replace(temporary,launcher)
subprocess.run(['update-desktop-database',str(launcher.parent)],check=True)
assert inventory(oldroot) == oldfiles and sha(older) == older_hash
out = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_head=receipt['source_head'],version=receipt['version'],installation=str(dest),launcher=str(launcher),launcher_sha256=sha(launcher),previous_launcher=str(previous),previous_exact_launcher_sha256=hashlib.sha256(old).hexdigest(),previous_installation=str(oldroot),previous_version_preserved=True,older_launcher_sha256=older_hash,payload_sha256=files,all_copied_payload_bytes_match=True,per_user_installation=True,system_package_installation=False,menu_launch_qualified=False,physical_audio_qualified=False)
(base/'user-installation.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ['version','installation','launcher','previous_launcher']}))
