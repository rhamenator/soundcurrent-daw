from pathlib import Path
import hashlib, json, math
import numpy as np
from scipy.io import wavfile
from scipy.signal import lfilter

base=Path(__file__).resolve().parent
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
load=lambda p:json.loads(p.read_text())
installation=load(base/'user-installation.json')
for tag in ['menu-first','menu-reopen']:
    record=load(base/'app'/f'{tag}-launch.json')
    assert record['exit_code']==0 and record['menu_launch']
    assert record['running_executable_sha256']==installation['payload_sha256']['usr/bin/soundcurrent-daw']
record=load(base/'export-focused/export-launch.json')
assert record['exit_code']==0 and record['menu_launch']
project=base/'export-focused/project-été-Κиїв'
session=load(project/'project.json')
track=session['tracks'][0]
assert len(session['tracks'])==len(track['clips'])==len(session['assets'])==1
asset=session['assets'][0];clip=track['clips'][0]
assert clip['sourceFrame']==clip['startFrame']==0 and clip['lengthFrames']==480000
assert clip['processing']['gainDb']==0 and not clip['processing']['muted']
assert clip['playbackRate']['numerator']==clip['playbackRate']['denominator']==1
raw=project/asset['path']
assert sha(raw)==asset['sha256']
rate,source=wavfile.read(raw)
out=base/'export-focused/project-été-Κиїв-mix.wav'
output_rate,output=wavfile.read(out)
assert rate==output_rate==48000 and output.shape==source.shape==(480000,)
assert source.dtype==output.dtype==np.float32 and np.isfinite(output).all()
reference=source.astype(np.float64)
assert len(track['processors'])==1
processor=track['processors'][0]
assert processor['type']=='sc.eq' and processor['enabled']
for band in processor['bands']:
    omega=2*math.pi*band['frequencyHz']/rate
    alpha=math.sin(omega)/(2*band['q']);a=10**(band['gainDb']/40)
    b=[1+alpha*a,-2*math.cos(omega),1-alpha*a]
    denominator=[1+alpha/a,-2*math.cos(omega),1-alpha/a]
    reference=lfilter(b,denominator,reference)
reference=reference.astype(np.float32)
error=float(np.max(np.abs(output.astype(np.float64)-reference)))
assert error<=1e-6,error
source_project=base.parent/'comp-preview-delivery/app/project-été-Κиїв'
for folder in [base/'app/project-été-Κиїв',project]:
    assert (folder/'project.json').read_bytes()==(source_project/'project.json').read_bytes()
    assert sha(folder/asset['path'])==asset['sha256']
oldroot=Path(installation['previous_installation'])
oldfiles=load(base/'preserved-preview-before.json')
assert {str(p.relative_to(oldroot)):sha(p) for p in oldroot.rglob('*') if p.is_file()}==oldfiles
launcher=Path(installation['launcher'])
assert sha(launcher)==installation['launcher_sha256']
assert sha(launcher.with_name('soundcurrent-daw-preview-previous.desktop'))==installation['older_launcher_sha256']
assert {str(p.relative_to(Path(installation['installation']))):sha(p) for p in Path(installation['installation']).rglob('*') if p.is_file()}==installation['payload_sha256']
result=dict(sourceHead=installation['source_head'],version=installation['version'],installedMenuOpenSaveQuitReopen=True,installedMenuExportNormalQuit=True,frames=len(output),channels=1,sampleRate=rate,exportSha256=sha(out),independentScipyReferenceMaximumError=error,bitExactToIndependentReference=bool(np.array_equal(output,reference)),peak=float(np.max(np.abs(output))),projectAndRawMediaUnchanged=True,priorPreviewAndLaunchersPreserved=True,physicalAudio=False,cleanInstallQualified=False,earlierDriverFailuresRetained=True)
(base/'qualification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
