from pathlib import Path
import hashlib,json,subprocess,zipfile
r=Path(__file__).resolve().parent;repo=r.parents[1];out=repo/'tests/results/M2/2026-10-15-waveform-source-pyramid';out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
commands=json.loads((r/'verification-commands.json').read_text());assert len(commands)==4 and all(c['exitCode']==0 for c in commands)
for name in ['release-tests.log','asan-ubsan-tests.log']:
 s=(r/name).read_text();assert '100% tests passed, 0 tests failed out of 2' in s and '164507' in s and '20956' in s
 assert 'ERROR: AddressSanitizer' not in s and 'runtime error:' not in s
sources=['include/soundcurrent/waveform.hpp','src/waveform.cpp','tests/waveform_tests.cpp','CMakeLists.txt','.github/workflows/ci.yml']
files={'source/'+n:(repo/n).read_bytes() for n in sources}
for n in ['archive.py','verification-commands.json','build.log','build-final.log','tests.log','tests-final.log','asan-configure.log','asan-build.log','release-build.log','release-tests.log','asan-ubsan-build.log','asan-ubsan-tests.log']:
 files['verification/'+n]=(r/n).read_bytes()
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert base=='2cfec5e5d57afac8727e0bd6d2cb556b057609da'
binaries={}
for label,folder in [('release',repo/'.cache/take-preview-linux/build'),('asan-ubsan',r/'asan')]:
 for name in ['sc-waveform-tests','sc-wave-validation-tests','libsc-waveform.a','libsc-wave-validation.a','libsc-approved-media.a','libsc-session.a']:
  p=folder/name;binaries[label+'/'+name]={'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
 files['verification/'+label+'-compile-link-commands.txt']=subprocess.check_output(['ninja','-C',str(folder),'-t','commands','sc-waveform-tests','sc-wave-validation-tests'])
 files['verification/'+label+'-cmake-cache.txt']=(folder/'CMakeCache.txt').read_bytes()
report=dict(baseHead=base,testedWorkingTreeSource={n:{'bytes':len(files['source/'+n]),'sha256':sha(files['source/'+n])} for n in sources},binaries=binaries,commands=commands,releasePassed=True,addressUndefinedLeakChecksPassed=True,waveformChecks=164507,existingWaveChecks=20956,channelCases=[1,2,8,257,1024],baseWidths=[1,3,7,64],uiIntegrated=False,nativeWindowsQualified=False,installedPreviewsChanged=False,newDependencies=False)
files['qualification.json']=(json.dumps(report,indent=2)+'\n').encode();(r/'qualification.json').write_bytes(files['qualification.json'])
# Every implementation edit is captured above; unchanged inputs are bound to baseHead.
diff=subprocess.check_output(['git','diff','--',*sources],cwd=repo);files['tracked-implementation.patch']=diff
index={n:{'bytes':len(b),'sha256':sha(b)} for n,b in files.items()};files['payload-manifest.json']=(json.dumps(index,indent=2)+'\n').encode()
p=out/'acceptance.zip'
with zipfile.ZipFile(p,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,b in files.items():z.writestr(n,b)
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 for n,v in index.items():assert len(z.read(n))==v['bytes'] and sha(z.read(n))==v['sha256']
m=dict(archive=p.name,bytes=p.stat().st_size,sha256=sha(p.read_bytes()),entries=len(files),baseHead=base,testedWorkingTreeSource=report['testedWorkingTreeSource'],waveformChecks=164507,existingWaveChecks=20956,releasePassed=True,asanUbsanPassed=True,nativeWindowsQualified=False,uiIntegrated=False,binariesIncluded=False)
(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps({k:v for k,v in m.items() if k!='testedWorkingTreeSource'}))
