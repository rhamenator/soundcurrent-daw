from pathlib import Path
import subprocess,json,resource,hashlib,time
root=Path(__file__).resolve().parent
exe=root.parent/'short-span-alignment-build/sc-stretch-alignment-probe'
def limits():
 resource.setrlimit(resource.RLIMIT_AS,(512*1024*1024,512*1024*1024))
 resource.setrlimit(resource.RLIMIT_CORE,(0,0))
start=time.monotonic()
with (root/'results.jsonl').open('wb') as out,(root/'stderr.log').open('wb') as err:
 p=subprocess.Popen([str(exe.resolve())],stdout=out,stderr=err,preexec_fn=limits)
 try:p.wait(timeout=60)
 except subprocess.TimeoutExpired:p.kill();p.wait();raise
used=resource.getrusage(resource.RUSAGE_CHILDREN)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report={'format':'sc-short-span-alignment-run-v1','pid':p.pid,'exitCode':p.returncode,'wallSeconds':time.monotonic()-start,'cpuUserSeconds':used.ru_utime,'cpuSystemSeconds':used.ru_stime,'maximumResidentKiB':used.ru_maxrss,'majorFaults':used.ru_majflt,'swaps':used.ru_nswap,'memoryAddressSpaceCeilingBytes':512*1024*1024,'timeoutSeconds':60,'nativePlatform':'linux','nativeWindowsReplayed':False,'productionChanged':False,'automaticContextQualified':False,'fullProcessingQuality':False,'inputs':{str(n):sha(n) for n in [Path('experiments/stretch-alignment/probe.cpp'),Path('experiments/stretch-alignment/CMakeLists.txt'),exe,root.parent/'build-desktop-release/libsc-positioned-resampling.a',root.parent/'build-desktop-release/libsc-session.a',root.parent/'build-desktop-release/libsc-rubberband.a']}}
(root/'run.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2));assert p.returncode==0,(root/'stderr.log').read_text()
lines=[json.loads(l) for l in (root/'results.jsonl').read_text().splitlines()]
assert len(lines)==41 and lines[-1]['actualRenders']==120 and lines[-1]['cases']==40
