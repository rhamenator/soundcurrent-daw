# SPDX-License-Identifier: GPL-3.0-only
"""Bounded investigation only: compare interior short-clip context with full-source renders."""
from pathlib import Path
import hashlib,json,math,select,struct,subprocess,time,uuid
root=Path(__file__).resolve().parent
worker=(root.parent/'build-desktop-release/sc-stretch-render-worker').resolve()
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(worker.read_bytes())=='faad9539d1fc1bb59f9e732630c2eedfaffbc6c5bcfa3a104b374b68bf6c4f15'
media=root/'owned/media';media.mkdir(parents=True,exist_ok=False)
jobs=media/'derived';jobs.mkdir()
samples=[0.0]*(32768*2)
for pos,left,right in [(16384,1.5,-.75),(17200,.5,.25)]:samples[2*pos]=left;samples[2*pos+1]=right
pcm=struct.pack('<'+'f'*len(samples),*samples)
fmt=struct.pack('<HHIIHH',3,2,48000,384000,8,32)
raw=b'RIFF'+struct.pack('<I',36+len(pcm))+b'WAVEfmt '+struct.pack('<I',16)+fmt+b'data'+struct.pack('<I',len(pcm))+pcm
path=media/'impulses.wav';path.write_bytes(raw)
base={'protocol':'sc-stretch-render-v2','assetId':str(uuid.uuid4()),'relative':'media/impulses.wav','sha256':sha(raw),'rate':48000,'channels':2,'sourceFrames':32768,'firstFraction':0,'firstDenominator':1,'formantPreserved':True}
records=[]
def decode(b):
 assert b[:4]==b'RF64' and b[8:12]==b'WAVE';o=12;ds=None;pcm=None
 while o+8<=len(b):
  tag,n=struct.unpack_from('<4sI',b,o);o+=8
  if tag==b'ds64':ds=struct.unpack_from('<QQQ',b,o);assert ds[0]==len(b)-8
  if tag==b'data' and n==0xffffffff:assert ds;n=ds[1]
  assert o+n<=len(b)
  if tag==b'fmt ':
   f=struct.unpack_from('<HHIIHH',b,o);assert f==(65534,2,48000,384000,8,32)
   assert b[o+24:o+40]==bytes.fromhex('0300000000001000800000aa00389b71')
  if tag==b'data':assert pcm is None;pcm=b[o:o+n]
  o+=n+n%2
 assert o==len(b) and ds and pcm and ds[1]==len(pcm) and ds[2]*8==len(pcm)
 x=struct.unpack('<'+'f'*(len(pcm)//4),pcm);assert all(math.isfinite(v) for v in x)
 return x

def run(kind,first,frames,n,d,pitch,fraction):
 req=dict(base,operation=str(uuid.uuid4()),first=first,frames=frames,timeNumerator=n,timeDenominator=d,pitchMilliCents=pitch,firstFraction=fraction,firstDenominator=2 if fraction else 1)
 command=[str(worker),'--project-root',str(root/'owned'),'--jobs-root',str(jobs),'--memory-mib','256','--maximum-input-frames','65536','--maximum-output-bytes',str(4*1024*1024),'--deadline-ms','10000']
 start=time.monotonic();p=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 try:
  p.stdin.write((json.dumps(req)+'\n').encode());p.stdin.close();p.stdin=None
  assert select.select([p.stdout],[],[],10)[0],'No worker ready/exit within deadline'
  first_line=p.stdout.readline()
  ready=json.loads(first_line) if first_line else None
  if ready:
   assert ready['event']=='ready' and ready['operation']==req['operation']
   (jobs/req['operation']/'start.request').write_text('start\n')
  out,err=p.communicate(timeout=12)
 except BaseException:
  if p.poll() is None:p.kill()
  p.communicate();raise
 record={'kind':kind,'pid':p.pid,'exitCode':p.returncode,'seconds':time.monotonic()-start,'request':req,'stdout':(first_line+out).decode(),'stderr':err.decode()}
 records.append(record)
 if kind=='short':
  assert p.returncode!=0 and not (jobs/req['operation']).exists()
  assert json.loads(err)['complete'] is False
  return None
 assert p.returncode==0,(kind,err)
 report=json.loads(out);assert report['complete'] is True and report['writtenFrames']==(frames*n+d-1)//d
 audio=(jobs/req['operation']/'audio.wav').read_bytes();assert sha(audio)==report['audioSha256']
 return decode(audio)

cases=[];start=time.monotonic()
for fraction in [0,1]:
 for n,d,pitch in [(1,1,0),(3,2,0),(3,2,700007),(1,4,-2400000),(4,1,2400000)]:
  run('short',16320,128,n,d,pitch,fraction)
  context=run('context',12224,8320,n,d,pitch,fraction)
  whole=run('whole',0,32764,n,d,pitch,fraction)
  length=(128*n+d-1)//d
  assert (4096*n)%d==0 and (16320*n)%d==0
  at=4096*n//d;reference_at=16320*n//d
  a=context[2*at:2*(at+length)];b=whole[2*reference_at:2*(reference_at+length)]
  assert len(a)==len(b)==2*length
  differences=[x-y for x,y in zip(a,b)]
  peak_at=lambda x,ch:max(range(len(x)//2),key=lambda i:abs(x[2*i+ch]))
  cases.append({'fraction':fraction,'fractionDenominator':2 if fraction else 1,'timeNumerator':n,'timeDenominator':d,'pitchMilliCents':pitch,'cropFrames':length,'contextCropStart':at,'wholeCropStart':reference_at,'contextVsWholeExact':a==b,'maximumDifference':max(abs(x) for x in differences),'rmsDifference':math.sqrt(sum(x*x for x in differences)/len(differences)),'contextPeakFrames':[peak_at(a,ch) for ch in [0,1]],'wholePeakFrames':[peak_at(b,ch) for ch in [0,1]],'contextPeak':max(abs(x) for x in a),'wholePeak':max(abs(x) for x in b)})
 assert time.monotonic()-start<60,'Experiment wall budget exceeded'
assert sha(path.read_bytes())==base['sha256']
result={'format':'sc-short-span-context-probe-v1','workerSourceCommit':'f9a63532685c988b4d7203da537957cab41dff92','workerSha256':sha(worker.read_bytes()),'actualProcesses':len(records),'shortRefusals':10,'completedContextOrWholeRenders':20,'rawSha256':base['sha256'],'rawUnchanged':True,'seconds':time.monotonic()-start,'cases':cases,'productionChange':False,'automaticContextQualified':False,'nativeWindowsReplayed':False,'fullProcessingQuality':False,'releaseUploaded':False}
(root/'raw-processes.json').write_text(json.dumps(records,indent=2)+'\n')
(root/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
