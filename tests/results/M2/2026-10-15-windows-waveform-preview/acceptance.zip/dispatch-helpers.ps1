$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
[Diagnostics.Process]::GetCurrentProcess().PriorityClass='BelowNormal'
& python.exe (Join-Path $env:USERPROFILE 'soundcurrent-waveform-353/qualify.py')
exit $LASTEXITCODE
