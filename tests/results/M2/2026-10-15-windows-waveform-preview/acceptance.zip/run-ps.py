from pathlib import Path
import subprocess,sys,base64,json,datetime
out=Path(__file__).resolve().parent;name=sys.argv[1];ps=(out/(name+'.ps1')).read_text();assert not (out/(name+'.log')).exists(), 'Refusing to overwrite original command log'
cmd=['ssh','-i','/home/rich/.ssh/copperfin_vfp9_vm','-o','BatchMode=yes','-o','ConnectTimeout=10','claude@192.168.122.149','powershell -NoProfile -EncodedCommand '+base64.b64encode(ps.encode('utf-16le')).decode()]
record={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':cmd}
try:
 with (out/(name+'.log')).open('xb') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=int(sys.argv[2]) if len(sys.argv)>2 else 60)
 record['exitCode']=r.returncode
except subprocess.TimeoutExpired:
 record['observationTimedOut']=True;(out/(name+'-command.json')).write_text(json.dumps(record,indent=2)+'\n');raise
(out/(name+'-command.json')).write_text(json.dumps(record,indent=2)+'\n');print(name,'exit',r.returncode);raise SystemExit(r.returncode)
