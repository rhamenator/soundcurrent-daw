$ErrorActionPreference='Stop'
$r=Join-Path $env:USERPROFILE 'soundcurrent-waveform-353/observed'
$until=[DateTime]::UtcNow.AddSeconds(25)
while(!(Test-Path (Join-Path $r 'main-terminal.json')) -and [DateTime]::UtcNow -lt $until) {Start-Sleep -Milliseconds 250}
Get-Content (Join-Path $r 'main-terminal.json')
