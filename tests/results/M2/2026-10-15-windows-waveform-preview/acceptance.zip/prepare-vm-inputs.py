from pathlib import Path
import zipfile,hashlib,json
r=Path(__file__).resolve().parent;b=r/'windows-bundle'
assert hashlib.sha256((b/'runtime-review/vc_redist.x64.exe').read_bytes()).hexdigest()=='843068991daaa1f73ad9f6239bce4d0f6a07a51f18c37ea2a867e9beca71295c'
files={n:b/n for n in ['build-inputs.json','deploy-manifest.json','runtime-review/vc_redist.x64.exe']}
for folder in ['deploy','verification']:
 for p in (b/folder).rglob('*'):
  if p.is_file():files[p.relative_to(b).as_posix()]=p
files['qualify-helpers.py']=r/'qualify-helpers.py'
assert 'deploy/sc-waveform-worker.exe' in files
zpath=r/'soundcurrent-waveform-353-inputs.zip'
with zipfile.ZipFile(zpath,'x',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(files.items()):z.write(p,name)
with zipfile.ZipFile(zpath) as z:assert z.testzip() is None
report=dict(sourceCommit='f2f9f7c8916e34582db9f289f62bda2019d1c330',zipBytes=zpath.stat().st_size,zipSha256=hashlib.sha256(zpath.read_bytes()).hexdigest(),members=len(files))
(r/'inputs.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
