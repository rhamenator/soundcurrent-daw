from pathlib import Path
import json,hashlib,zipfile
r=Path(__file__).resolve().parent;dest=Path('tests/results/M2/2026-10-15-windows-waveform-preview');dest.mkdir(exist_ok=False)
assert json.loads((r/'verification.json').read_text())['passed'];files={}
for p in r.iterdir():
 if p.is_file() and p.suffix in ['.py','.ps1','.json','.log'] and not p.name.startswith('pr-'):files[p.name]=p.read_bytes()
for p in (r/'observed').rglob('*'):
 if p.is_file():files['native/'+p.relative_to(r/'observed').as_posix()]=p.read_bytes()
for p in (r/'ci').iterdir():
 if p.is_file() and p.suffix in ['.json','.log']:files['ci/'+p.name]=p.read_bytes()
b=r/'windows-bundle'
for n in ['collection.json','build-inputs.json','compiler.json','deploy-manifest.json','terminal.json','LastTest.log','media-build-review/native-review.json','verified-runtime.json']:files['bundle/'+n]=(b/n).read_bytes()
pkg=Path(json.loads((r/'windows-package-invocation.json').read_text())['output']);files['package/receipt.json']=(pkg/'receipt.json').read_bytes()
files['scope.txt']=b'Windows helpers and deployed GUI qualify frozen f2 source; installer is prepared but not exercised. Original overall CI failed Linux GUI resource accounting, with full original logs and artifacts retained. Current fixture fix 1e6c684 waits for waveform admission before the playback baseline and asynchronous view redisplay after routing; 80 local checks pass. Initial diagnostic reproduction and two repair-attempt logs remain. See observer-note.txt for the overwritten lightweight progress poll; no original product or CI logs were overwritten. All VMs off, no physical audio or installed preview mutation.\n'
files['observer-note.txt']=(r/'observer-note.txt').read_bytes()
for n in ['CMakeLists.txt','tests/gui_resource_tests.cpp']:files['corrected-source/'+n]=Path(n).read_bytes()
rows=[dict(path=n,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()) for n,data in files.items()];files['payload-manifest.json']=(json.dumps(rows,indent=2)+'\n').encode();a=dest/'acceptance.zip'
with zipfile.ZipFile(a,'x',zipfile.ZIP_DEFLATED) as z:
 for n,data in files.items():z.writestr(n,data)
with zipfile.ZipFile(a) as z:
 assert z.testzip() is None
 for row in rows:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
record=dict(archive=a.name,bytes=a.stat().st_size,sha256=hashlib.sha256(a.read_bytes()).hexdigest(),entries=len(files),sourceHead='f2f9f7c8916e34582db9f289f62bda2019d1c330',nativeMainNormalExit=True,nativeHelperQualificationPassed=True,linuxResourceFixtureRepaired=True,wholeCiRunPassed=False,installerPrepared=True,installerTested=False,sourceArchiveVerified=True,ciRun=38818238344,ciJobs=15,ciArtifacts=12,ciConclusion='failure',physicalAudio=False,allVmsOff=True)
(dest/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
