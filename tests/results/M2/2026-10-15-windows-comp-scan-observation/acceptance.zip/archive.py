from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path.cwd(); cache=root/'.cache/windows-comp-timing-327'; dest=root/'tests/results/M2/2026-10-15-windows-comp-scan-observation';dest.mkdir(exist_ok=False)
files={}
for p in sorted(cache.iterdir()):
 if p.is_file() and p.name not in ['archive.py','pr-before.json','original-desktop-job.log']:
  files['native/'+p.name]=p.read_bytes()
for folder in ['inputs','ci']:
 for p in sorted((cache/folder).iterdir()):
  if not p.is_file():continue
  if folder=='inputs' and p.suffix=='.zip':continue
  if folder=='ci' and p.suffix=='.zip' and p.name!='artifact-11989789178.zip':continue
  files[folder+'/'+p.name]=p.read_bytes()
files['retention-fix.patch']=subprocess.check_output(['git','diff','--','.github/scripts/retain-controller-failure-projects.py','.github/workflows/ci.yml','tests/controller_retention_tests.py','tests/stretch_parent_interruption_windows.py'])
files['archive.py']=Path(__file__).read_bytes()
files['scope.json']=(json.dumps({'sourceHead':'82bae0027581a99758245f90625590383a1b923d','originalCi':38766825424,'originalCiConclusion':'failure','originalFailedProjectUploaded':False,'completeCiArtifactArchivesLocalOnly':True,'publishedOriginalDesktopArtifact':11989789178,'inputProjectArchiveSha256':hashlib.sha256((cache/'inputs/project.zip').read_bytes()).hexdigest(),'projectSource':'checkpoint 325, 225-file retained Windows project','binariesIncluded':False,'credentialsIncluded':False},indent=2)+'\n').encode()
inventory=[dict(path=n,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()) for n,b in files.items()]
files['payload-manifest.json']=(json.dumps(inventory,indent=2)+'\n').encode()
archive=dest/'acceptance.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,b in files.items():z.writestr(n,b)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for row in inventory:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
manifest=dict(archive=archive.name,bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),entries=len(files),sourceHead='82bae0027581a99758245f90625590383a1b923d',nativeRuns=6,eachRunComparedSamples=16256,originalCiConclusion='failure',originalFailedProjectUploaded=False,retentionTestPassed=True,applicationBinariesIncluded=False)
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest))
