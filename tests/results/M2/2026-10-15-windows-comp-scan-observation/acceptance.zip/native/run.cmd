@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64
if errorlevel 1 exit /b 1
python C:\Users\claude\soundcurrent-comp-timing-327\run.py
exit /b %ERRORLEVEL%
