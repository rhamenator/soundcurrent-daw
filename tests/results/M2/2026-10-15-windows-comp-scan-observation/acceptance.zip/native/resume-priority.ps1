$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$p=Get-CimInstance Win32_Process -Filter 'ProcessId=4384'
if($p.CommandLine -ne 'python  C:\Users\claude\soundcurrent-comp-timing-327\continue.py'){throw 'Owned coordinator identity changed'}
$process=Get-Process -Id 4384
$before=$process.PriorityClass.ToString();$process.PriorityClass='Normal'
@{pid=4384;commandLine=$p.CommandLine;before=$before;after=(Get-Process -Id 4384).PriorityClass.ToString();reason='Bounded owned coordinator scheduling observation; no service/security changes'}|ConvertTo-Json|Set-Content C:/Users/claude/soundcurrent-comp-timing-327/priority-observation.json -Encoding UTF8
