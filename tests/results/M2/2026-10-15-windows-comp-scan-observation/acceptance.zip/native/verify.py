from pathlib import Path
import json,hashlib,subprocess,statistics,datetime
r=Path(__file__).resolve().parent;repo=r.parents[1];load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();portable=lambda n:Path(n.replace('\\','/'))
x=load(r/'captured/continued/qualification.json');assert x['passed'] and x['sourceHead']=='82bae0027581a99758245f90625590383a1b923d'
inputs=load(r/'captured/observed/source-inputs.json');assert len(inputs)==444
filtered=[]
for n,h in inputs.items():
 if sha(repo/portable(n))==h:continue
 path=portable(n).as_posix();assert path in ['third_party/libsndfile/COPYING','third_party/nlohmann/LICENSE.MIT'],path
 data=subprocess.check_output(['git','-c','core.eol=crlf','cat-file','--filters','HEAD:'+path],cwd=repo)
 assert hashlib.sha256(data).hexdigest()==h,path
 filtered.append(path)
project=repo/'.cache/windows-installed-portable-325/observed/retired-325/project-été-Κиїв';original=load(r/'captured/observed/project-inputs.json');assert len(original)==225
for n,h in original.items():assert sha(project/portable(n))==h,n
commands=load(r/'captured/continued/commands.json');assert len(commands)==8 and all(c['exitCode']==0 for c in commands)
for v in ['before','after']:
 times=[]
 for i in range(3):
  name=f'{v}-{i}';rows=[json.loads(l) for l in (r/'captured/continued'/(name+'.stdout')).read_text().splitlines()];assert rows[-1]['comparedSamples']==16256 and rows[-1]['event']=='complete';assert not (r/'captured/continued'/(name+'.stderr')).read_bytes();times.append(next(c['seconds'] for c in commands if c['name']==name))
 assert statistics.median(times)==x['medianSeconds'][v]
assert 'TimeoutExpired' in (r/'captured/observed/failure.txt').read_text()
ret=load(r/'captured/observed/retirement.json');assert ret['ownedProcessesRemaining']==0 and not ret['sourceStatus']
state=subprocess.check_output(['virsh','list','--all'],text=True);assert 'running' not in state
report=dict(passed=True,sourceInputsVerifiedAgainstHost=444,exactBytes=444-len(filtered),gitFilteredLicenseFiles=filtered,projectFilesVerifiedAgainstHost=225,nativeRuns=6,eachRunComparedSamples=16256,medianSeconds=x['medianSeconds'],ratio=x['ratio'],originalBuildTimeoutRetained=True,allVmsOff=True,checkedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),wholeRenderMeasured=False,backgroundActivityObserved=True)
(r/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
