$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
[Diagnostics.Process]::GetCurrentProcess().PriorityClass='BelowNormal'
& cmd.exe /d /c C:\Users\claude\soundcurrent-comp-timing-327\run.cmd
exit $LASTEXITCODE
