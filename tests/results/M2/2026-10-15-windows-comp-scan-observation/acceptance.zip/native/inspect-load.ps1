$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
Get-Process | Sort-Object CPU -Descending | Select-Object -First 7 Name,Id,CPU,WorkingSet64 | ConvertTo-Json
Get-Process -Id 4384 | Select-Object Id,PriorityClass,ProcessorAffinity | ConvertTo-Json
