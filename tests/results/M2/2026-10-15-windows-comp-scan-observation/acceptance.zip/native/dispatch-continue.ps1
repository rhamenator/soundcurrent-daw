$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
[Diagnostics.Process]::GetCurrentProcess().PriorityClass='BelowNormal'
& cmd.exe /d /c C:\Users\claude\soundcurrent-comp-timing-327\continue.cmd
exit $LASTEXITCODE
