from pathlib import Path
import subprocess,json,hashlib,shutil,time,statistics,zipfile,os,traceback
r=Path(__file__).resolve().parent;out=r/'continued';out.mkdir(exist_ok=False);source=r/'source';build=r/'build';rows=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(name,args,seconds=360,input=None):
 started=time.monotonic()
 with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
  proc=subprocess.Popen(args,stdin=subprocess.PIPE if input else subprocess.DEVNULL,stdout=stdout,stderr=stderr,cwd=r)
  (out/'active.json').write_text(json.dumps(dict(phase=name,pid=proc.pid,startedUtc=time.time(),args=args)))
  try:proc.communicate(input=input,timeout=seconds)
  except subprocess.TimeoutExpired:
   # This disposable owned build/probe has an explicit bound; preserve logs.
   subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'],stdout=stderr,stderr=stderr);proc.wait();raise
 rows.append(dict(name=name,pid=proc.pid,args=args,exitCode=proc.returncode,seconds=time.monotonic()-started))
 (out/'commands.json').write_text(json.dumps(rows,indent=2));assert proc.returncode==0,(name,proc.returncode)
 return rows[-1]
try:
 inputs=json.loads((r/'observed/source-inputs.json').read_text())
 project=r/'project-été-Κиїв';projectBefore=json.loads((r/'observed/project-inputs.json').read_text())
 originals={n:subprocess.check_output(['git','-C',str(source),'show','HEAD:src/'+n]) for n in ['comp_span_protocol.cpp','comp_media_review.cpp']}
 snd=Path.home()/'soundcurrent-daw-msvc-sdk-v1/sndfile-build-v2/Release'
 run('build-before',['cmake','--build',str(build),'--target','sc-comp-timing','--parallel','1'],180)
 before=r/'probe-before.exe';shutil.copyfile(build/'sc-comp-timing.exe',before)
 for n,b in originals.items():(source/'src'/n).write_bytes(b)
 run('build-after',['cmake','--build',str(build),'--target','sc-comp-timing','--parallel','1'],120)
 after=r/'probe-after.exe';shutil.copyfile(build/'sc-comp-timing.exe',after)
 dll=snd/'sndfile.dll';shutil.copyfile(dll,r/dll.name)
 assert inputs=={str(p.relative_to(source)):sha(p) for d in ['src','include','third_party'] for p in (source/d).rglob('*') if p.is_file()}
 for i in range(3):
  for version in (['before','after'] if i%2==0 else ['after','before']):
   name=f'{version}-{i}';run(name,[str(r/('probe-'+version+'.exe'))],120,json.dumps(dict(root=str(project).replace('\\','/'),assembly='a1a283c7-c9e5-4d5f-bc41-0edadd727ee7')).encode())
   events=[json.loads(l) for l in (out/(name+'.stdout')).read_text().splitlines()];assert events[-1]['event']=='complete' and events[-1]['comparedSamples']==16256
 assert projectBefore=={str(p.relative_to(project)):sha(p) for p in project.rglob('*') if p.is_file()}
 median={v:statistics.median(x['seconds'] for x in rows if x['name'].startswith(v+'-')) for v in ['before','after']}
 (out/'qualification.json').write_text(json.dumps(dict(passed=True,sourceHead='82bae0027581a99758245f90625590383a1b923d',sourceFilesVerified=len(inputs),projectFilesUnchanged=len(projectBefore),assemblySamplesCompared=16256,medianSeconds=median,ratio=median['after']/median['before'],binaries={p.name:sha(p) for p in [before,after,dll]},physicalAudio=False,installedPreviewChanged=False,wholeRenderMeasured=False),indent=2))
except Exception:
 (out/'failure.txt').write_text(traceback.format_exc());raise
finally:
 (out/'terminal.json').write_text(json.dumps(dict(finishedUtc=time.time(),passed=(out/'qualification.json').exists(),pid=os.getpid())))
