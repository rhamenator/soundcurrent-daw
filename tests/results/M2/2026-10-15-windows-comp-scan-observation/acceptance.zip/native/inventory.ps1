$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
foreach($n in @('soundcurrent-daw-msvc-desktop-v1','soundcurrent-daw-msvc-sdk-v1','soundcurrent-daw-stretch-f9a6353')) {
 $r=Join-Path $env:USERPROFILE $n
 Get-ChildItem $r -Filter CMakeCache.txt -Recurse -ErrorAction SilentlyContinue | ForEach-Object { Write-Output $_.FullName; Select-String -Path $_.FullName -Pattern 'CMAKE_HOME_DIRECTORY:','CMAKE_MAKE_PROGRAM:','SNDFILE_LIBRARY:','SC_BUILD_DESKTOP:','CMAKE_BUILD_TYPE:' | ForEach-Object {$_.Line} }
}
