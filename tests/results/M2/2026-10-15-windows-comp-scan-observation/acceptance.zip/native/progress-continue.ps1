$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$r=Join-Path $env:USERPROFILE 'soundcurrent-comp-timing-327/continued'
if(Test-Path (Join-Path $r 'active.json')) { $a=Get-Content -Raw (Join-Path $r 'active.json')|ConvertFrom-Json; $a|ConvertTo-Json; Get-Process -Id $a.pid -ErrorAction SilentlyContinue|Select-Object Id,ProcessName,CPU|ConvertTo-Json; Select-String -Path (Join-Path $r ($a.phase+'.stdout')) -Pattern '^\[[0-9]+/' | Select-Object -Last 2 | ForEach-Object {$_.Line}; Get-Content (Join-Path $r ($a.phase+'.stdout')) -Tail 2; Get-Content (Join-Path $r ($a.phase+'.stderr')) -Tail 4 }
foreach($n in @('terminal.json','qualification.json','failure.txt')){if(Test-Path (Join-Path $r $n)){Get-Content -Raw (Join-Path $r $n)}}
