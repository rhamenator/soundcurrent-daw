$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$r=Join-Path $env:USERPROFILE 'soundcurrent-comp-timing-327'
if(-not(Test-Path (Join-Path $r 'continued/terminal.json'))){throw 'Original diagnostic is still active'}
$owned=Get-CimInstance Win32_Process|Where-Object {($_.ExecutablePath -like ($r+'*')) -or ($_.Name -in @('python.exe','ninja.exe','cmake.exe','cl.exe','link.exe') -and $_.CommandLine -like ('*'+$r+'*'))}
if($owned){throw 'Owned diagnostic processes remain active'}
@{ownedProcessesRemaining=0;nativeAudioActivated=$false;installedPreviewChanged=$false;sourceStatus=(git -C (Join-Path $r 'source') status --porcelain)}|ConvertTo-Json -Depth 5|Set-Content (Join-Path $r 'observed/retirement.json') -Encoding UTF8
Copy-Item (Join-Path $r 'priority-observation.json') (Join-Path $r 'observed/priority-observation.json')
Copy-Item (Join-Path $r 'setup.json') (Join-Path $r 'observed/setup.json')
Compress-Archive -Path (Join-Path $r 'observed'),(Join-Path $r 'continued') -DestinationPath (Join-Path $r 'observed.zip')
Get-FileHash (Join-Path $r 'observed.zip')|Select-Object Hash,Path|ConvertTo-Json
