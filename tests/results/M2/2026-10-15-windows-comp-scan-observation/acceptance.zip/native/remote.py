from pathlib import Path
import subprocess,base64,sys
script=Path(sys.argv[1]).read_text();cmd=['ssh','-i','/home/rich/.ssh/copperfin_vfp9_vm','-o','StrictHostKeyChecking=yes','-o','BatchMode=yes','-o','ConnectTimeout=5','claude@192.168.122.149','powershell -NoProfile -EncodedCommand '+base64.b64encode(script.encode('utf-16-le')).decode()];raise SystemExit(subprocess.call(cmd))
