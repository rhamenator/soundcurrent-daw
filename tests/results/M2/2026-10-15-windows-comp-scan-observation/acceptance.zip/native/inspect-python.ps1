$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
Get-Process -Id 4384 | Select-Object Id,Path,CPU,StartTime,WorkingSet64,Responding | ConvertTo-Json
(Get-Process -Id 4384).Threads | Select-Object Id,ThreadState,WaitReason | ConvertTo-Json
Get-Item C:/Users/claude/soundcurrent-comp-timing-327/continue.py | Select-Object Length,LastWriteTime | ConvertTo-Json
Get-Content C:/Users/claude/soundcurrent-comp-timing-327/continue.py -TotalCount 4
