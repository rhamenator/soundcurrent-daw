$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
[Diagnostics.Process]::GetCurrentProcess().PriorityClass='BelowNormal'
$root=Join-Path $env:USERPROFILE 'soundcurrent-comp-timing-327'
if(Test-Path $root){throw 'Owned root already exists'}
New-Item -ItemType Directory $root|Out-Null
$source=Join-Path $root 'source'
git clone --config core.autocrlf=false --filter=blob:none --no-checkout --depth 1 --branch backup/comp-source-scan-batching-2026-10-15 https://github.com/rhamenator/soundcurrent-daw.git $source
if($LASTEXITCODE -ne 0){throw 'Source clone failed'}
git -C $source sparse-checkout set --no-cone '/*' '!/tests/results/'
if($LASTEXITCODE -ne 0){throw 'Sparse selection failed'}
git -C $source checkout --detach 82bae0027581a99758245f90625590383a1b923d
if($LASTEXITCODE -ne 0){throw 'Exact checkout failed'}
Get-ChildItem 'C:/Program Files/Microsoft Visual Studio/18/Community/Common7/IDE/CommonExtensions/Microsoft/CMake/Ninja' -Filter ninja.exe | Select-Object FullName | ConvertTo-Json
@{sourceHead=(git -C $source rev-parse HEAD);sourceTree=(git -C $source rev-parse 'HEAD^{tree}');root=$root}|ConvertTo-Json|Set-Content (Join-Path $root 'setup.json') -Encoding UTF8
