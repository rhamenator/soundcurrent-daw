$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$r=Join-Path $env:USERPROFILE 'soundcurrent-comp-timing-327'
Get-ChildItem $r -Directory | Select-Object Name | ConvertTo-Json
Get-CimInstance Win32_Process|Where-Object {$_.Name -in @('python.exe','git.exe','cmd.exe','ninja.exe','cmake.exe','cl.exe','link.exe') -and ($_.CommandLine -like '*comp-timing-327*' -or $_.Name -in @('git.exe','ninja.exe','cl.exe'))}|Select-Object ProcessId,ParentProcessId,Name,CommandLine|ConvertTo-Json -Depth 3
Get-Content (Join-Path $r 'continue.cmd')
