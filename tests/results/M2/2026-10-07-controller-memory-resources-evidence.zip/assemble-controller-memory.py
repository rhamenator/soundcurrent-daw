from pathlib import Path
import datetime,hashlib,json,re,zipfile
root=Path.cwd();cache=root/'.cache';out=root/'tests/results/M2'
h=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(p.read_text())
labels=['combined-state-acceptance','combined-state-acceptance-fixed','combined-state-final-debug','combined-state-final-sanitized'];runs={};items={}
for label in labels:
 p=cache/label;runs[label]=read(p/'launch.json')
 for f in p.rglob('*'):
  if f.is_file() and (f.parts[len(p.parts)] in ['source','generated-projects','export-projects'] or f.suffix in ['.log','.json','.png']):items[label+'/'+str(f.relative_to(p))]=f.read_bytes()
assert [runs[n]['exit_code'] for n in labels]==[8,0,0,0]
final=runs[labels[2]];san=runs[labels[3]]
for n,v in final['source_sha256'].items():assert h((root/n).read_bytes())==v and san['source_sha256'][n]==v,n
base=read(out/'2026-10-07-retained-session-review.json')
assert read(cache/'combined-state-reuse-before.json')==read(cache/'combined-state-reuse-after.json')
keys=base['parity']['projection_keys'];rows=read(root/'research/parity.json')['rows']
assert h(json.dumps([{k:r[k] for k in keys} for r in rows],sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())==base['parity']['explicit_projection_sha256']
for n in ['combined-state-first-build.log','combined-state-ui-build.log','combined-state-acceptance-build.log','combined-state-acceptance-fixed-build.log','combined-state-final-debug-build.log','combined-state-final-sanitized-build.log','combined-state-final-sanitized-session-build.log','combined-state-final-windows-build.log','combined-state-fixture-diagnosis.json','combined-state-reuse-before.json','combined-state-reuse-after.json','combined-state-main-protection.json','run-state-resources.py','assemble-controller-memory.py']:
 items[n]=(cache/n).read_bytes()
items['runs.json']=(json.dumps(runs,indent=2)+'\n').encode()
items['manifest.json']=(json.dumps({'files':{n:{'sha256':h(b),'bytes':len(b)} for n,b in items.items()},'scope':'Original focused fixture failures and corrected scopes; final compiled sources, executable hashes, logs, owned project/media bytes and screenshots. Executable binaries remain private. Only executed cases are qualified.'},indent=2)+'\n').encode()
p=out/'2026-10-07-controller-memory-resources-evidence.zip';assert not p.exists()
with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(items.items()):z.writestr(n,b)
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 for n,b in items.items():assert z.read(n)==b
elapsed=lambda n:float(re.search(r'Total Test time \(real\) =\s+([\d.]+)',(cache/n/'ctest.log').read_text())[1])
assert '0 tests failed out of 55' in (cache/labels[2]/'ctest.log').read_text()
assert '0 tests failed out of 18' in (cache/labels[3]/'ctest.log').read_text()
r={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseline':base['baseline'],'source_parent':final['source_parent'],'compiled_source_sha256':final['source_sha256'],'scope':'Shared controller parent/child declared resource ownership and persistent desktop memory controls',
 'previous_checkpoint':'tests/results/M2/2026-10-07-retained-session-review.json',
 'original_focused_fixture_failures':read(cache/'combined-state-fixture-diagnosis.json'),
 'corrected_focused':{'tests':'6/6','elapsed_seconds':elapsed(labels[1]),'exit_code':0},
 'final_debug':{'tests':'55/55','elapsed_seconds':elapsed(labels[2]),'exit_code':0},
 'final_sanitizers':{'tests':'18/18','elapsed_seconds':elapsed(labels[3]),'exit_code':0,'command':san['command'],'ASAN_OPTIONS':san['environment']['ASAN_OPTIONS'],'UBSAN_OPTIONS':san['environment']['UBSAN_OPTIONS']},
 'workflows':{'512_track_parent_and_child_joint_refusal_and_retry':True,'active_gesture_preserved_on_edit_and_Undo_refusal':True,'Cancel_at_full_parent_budget':True,'canonical_history_snapshot_sum_reconciled':True,'513_track_growth_Undo_Redo_and_stable_IDs':True,'save_reopen_and_external_reader_survival':True,'parent_child_atomic_policy_reduction_failure':True,'concurrent_sibling_domains_and_credit_transfer':True,'actual_desktop_memory_controls':True,'byte_exact_startup_before_initial_publish':True,'locale_numeric_input_scroll_and_display_fit':True,'preference_failure_reporting_and_retry':True,'8192_track_10000_sparse_clip_regression_retained':True},
 'defaults':{'controller_parent_bytes':1073741824,'snapshot_child_bytes':268435456},
 'accounting':{'canonical_history_unique_snapshots_declared_edit_work_share_parent':True,'off_audio_only':True,'GUI_graph_cache_IO_allocators_RSS_admitted':False,'expanding_trials_and_command_payloads_preallocated_under_parent':False,'external_owner_is_fixture_not_GUI_cache':True},
 'Windows':{'core_media_cross_build':True,'GUI_built':False,'runtime_qualified':False},
 'evidence_archive':{'path':str(p.relative_to(root)),'sha256':h(p.read_bytes()),'bytes':p.stat().st_size,'entries':len(items),'CRC_and_all_entry_bytes_verified':True},
 'equalizer_reuse':base['equalizer_reuse'],'parity':base['parity'],'native_audio_runs':0,'native_observations_total_unchanged':71,'native_observation71_gap_and_source_CPU_cause_unresolved':True,'schema_minor':7,'new_third_party_dependencies':[],
 'sustained_qualified':False,'remaining_full_X006_and_frozen_scope_unchanged':True,'next_implementation_task':'Admit actual selected-track GUI projections and list/timeline indices from the shared parent, stage replacements and expose retryable resource failure; then coordinate graph/cache/IO and qualify RSS/sustained platforms'}
(out/'2026-10-07-controller-memory-resources.json').write_text(json.dumps(r,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'archive':r['evidence_archive'],'debug':r['final_debug'],'sanitizers':r['final_sanitizers']}))
