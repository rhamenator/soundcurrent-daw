from pathlib import Path
import hashlib,json,subprocess,zipfile
r=Path('.cache/preview-candidate-330');dest=Path('tests/results/M2/2026-10-15-linux-preview-candidate');dest.mkdir(exist_ok=False)
(r/'LastTest.log').write_bytes(Path('.cache/take-preview-linux/build/Testing/Temporary/LastTest.log').read_bytes())
files={p.name:p.read_bytes() for p in r.iterdir() if p.is_file() and not p.name.startswith('pr-')}
for p in (r/'ci').iterdir():
 if p.is_file() and p.suffix in ('.json','.log'):files['ci/'+p.name]=p.read_bytes()
package=Path(json.loads((r/'package-invocation.json').read_text())['output'])
for n in ['receipt.json','commands.json']:files['package/'+n]=(package/n).read_bytes()
q=json.loads((r/'native-linux-test-qualification.json').read_text());inventory=[]
for d in q['new_evidence_runs']:
 root=Path(d)
 for p in sorted(root.rglob('*')):
  if not p.is_file():continue
  n=root.parent.name+'/'+root.name+'/'+p.relative_to(root).as_posix();b=p.read_bytes();published=p.suffix in ('.json','.png','.stdout','.stderr')
  inventory.append(dict(path=n,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),published=published))
  if published:files['workflow/'+n]=b
files['generated-workflow-inventory.json']=(json.dumps(inventory,ensure_ascii=False,indent=2)+'\n').encode()
rows=[dict(path=n,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()) for n,b in files.items()]
files['payload-manifest.json']=(json.dumps(rows,ensure_ascii=False,indent=2)+'\n').encode()
archive=dest/'acceptance.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
 for n,b in files.items():z.writestr(n,b)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for row in rows:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
out=dict(archive=archive.name,bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),entries=len(files),sourceHead=q['source_head'],linuxTests=27,linuxTestsPassed=True,sourceArchiveFiles=8079,sourceArchiveVerified=True,originalCi=38773460845,originalCiHead='8c2e4474111c16a66ef16a85abb2211c8cebaca0',originalCiJobs=14,originalCiArtifacts=12,originalCiConclusion='success',originalCiArchivesLocalOnly=True,generatedWorkflowFiles=len(inventory),allGeneratedMediaPublished=False,binariesIncluded=False,installedPreviewUpdated=False)
(dest/'manifest.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
