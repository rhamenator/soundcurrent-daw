from pathlib import Path
import subprocess,json,hashlib,gzip,tarfile
base=Path('.cache/preview-candidate-330');head='b5dc2568dbf0e1e623dbaa7d42dcd38fd1eed3ab'
entries=subprocess.check_output(['git','ls-tree','-rz',head]).split(b'\0');tracked={}
for entry in entries:
 if not entry:continue
 meta,name=entry.split(b'\t',1);mode,kind,oid=meta.decode().split();assert kind=='blob';tracked[name.decode()]=(mode,oid)
native={}
class Reader:
 def __init__(self,f):self.f=f;self.digest=hashlib.sha256();self.bytes=0
 def read(self,n=-1):
  b=self.f.read(n);self.digest.update(b);self.bytes+=len(b);return b
 def tell(self):return self.f.tell()
results=[]
for platform,directory in [('Linux',Path(json.loads((base/'package-invocation.json').read_text())['output']))]:
 receipt=json.loads((directory/'receipt.json').read_text());name=next(n for n in receipt['artifacts'] if n.endswith('-source.tar.gz'));path=directory/name;expected=receipt['artifacts'][name];seen=set();nativeCount=rawGitCount=filteredGitCount=0
 with path.open('rb') as f:
  reader=Reader(f)
  with gzip.GzipFile(fileobj=reader,mode='rb') as gz:
   with tarfile.open(fileobj=gz,mode='r|') as tar:
    for member in tar:
     if member.isdir():continue
     assert member.name.startswith('soundcurrent-daw/')
     n=member.name[len('soundcurrent-daw/'):];assert n in tracked and n not in seen;seen.add(n)
     assert member.isfile(),member.name
     sha=hashlib.sha256();oid=hashlib.sha1(('blob '+str(member.size)+'\0').encode());source=tar.extractfile(member)
     while data:=source.read(1024*1024):sha.update(data);oid.update(data)
     if platform=='Windows' and n in native:assert sha.hexdigest()==native[n],n;nativeCount+=1
     elif oid.hexdigest()==tracked[n][1]:rawGitCount+=1
     else:
      cwd=base/'windows-producer-checkout' if platform=='Windows' else Path.cwd()
      result=subprocess.run(['git','cat-file','--filters',head+':'+n],cwd=cwd,capture_output=True,check=True)
      assert hashlib.sha256(result.stdout).hexdigest()==sha.hexdigest(),n
      filteredGitCount+=1
   while gz.read(1024*1024):pass
  assert reader.bytes==expected['bytes'] and reader.digest.hexdigest()==expected['sha256']
 assert seen==set(tracked)
 if platform=='Windows':assert nativeCount==len(native)
 r=dict(platform=platform,path=str(path.resolve()),sourceHead=head,files=len(seen),exactNativeSourceFiles=nativeCount,exactRawGitBlobs=rawGitCount,exactGitFilteredBlobs=filteredGitCount,sha256=reader.digest.hexdigest(),bytes=reader.bytes,gzipCrcVerified=True,completeTrackedMembership=True)
 results.append(r);print(json.dumps(r),flush=True)
(base/'source-archive-verification.json').write_text(json.dumps(results,indent=2)+'\n')
