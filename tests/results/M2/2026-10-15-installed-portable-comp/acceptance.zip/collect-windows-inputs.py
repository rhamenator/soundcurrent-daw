from pathlib import Path
import subprocess,json,hashlib,zipfile
r=Path(__file__).resolve().parent;ci=r/'ci';ci.mkdir(exist_ok=True);aid=11984295136
api=subprocess.check_output(['gh','api',f'repos/rhamenator/soundcurrent-daw/actions/artifacts/{aid}']);m=json.loads(api);assert m['workflow_run']['head_sha']=='61bcaa3439ac0ec9a9856d893e5c0b10fee23e72' and m['name']=='windows-preview-build-inputs';(ci/f'artifact-{aid}-api.json').write_bytes(api)
p=ci/f'artifact-{aid}.zip';assert not p.exists()
with p.with_suffix('.partial').open('wb') as f:subprocess.run(['gh','api',f'repos/rhamenator/soundcurrent-daw/actions/artifacts/{aid}/zip'],stdout=f,check=True)
p.with_suffix('.partial').rename(p);assert p.stat().st_size==m['size_in_bytes'] and 'sha256:'+hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==m['digest']
out=r/'windows-bundle';out.mkdir(exist_ok=False)
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 for item in z.infolist():
  n=Path(item.filename);assert not n.is_absolute() and '..' not in n.parts and not (item.external_attr>>16 & 0o170000)==0o120000
 z.extractall(out)
print(json.dumps(dict(artifact=aid,bytes=p.stat().st_size,files=len(list(out.rglob('*'))),output=str(out))))
