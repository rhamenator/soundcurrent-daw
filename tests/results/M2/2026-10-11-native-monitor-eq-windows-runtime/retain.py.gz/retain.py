from pathlib import Path
import json,hashlib,gzip,subprocess,re
p=Path('.cache/native-monitor-eq/runtime-ci-review');out=Path('tests/results/M2/2026-10-11-native-monitor-eq-windows-runtime');b=json.loads(Path('.cache/native-monitor-eq/pr148-tested-merge.json').read_text());run=json.loads((p/'run.json').read_text());jobs=json.loads((p/'jobs.json').read_text());assert run['id']==38186095168 and run['head_sha']==b['head']
paths=[p/'retain.py',p/'first-retain-member-path-failure.py',p/'run.json',p/'jobs.json',p/'artifacts.json',Path('.cache/native-monitor-eq/pr148-tested-merge.json')];bindings={}
for j in jobs['jobs']:
 assert j['head_sha']==b['head'] and j['run_id']==run['id']
 if j['status']!='completed':continue
 f=p/('job-'+str(j['id'])+'.log');raw=f.read_bytes();text=raw.decode('utf-8-sig');assert b['mergeRef'] in text and b['head'] in text and b['base'] in text;paths.append(f);bindings[str(j['id'])]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'conclusion':j['conclusion']}
for n,x in b['files'].items():assert hashlib.sha256(subprocess.check_output(['git','show',b['mergeRef']+':'+n])).hexdigest()==x['sha256']
for tag in ['native-artifact','desktop-artifact']:
 m=json.loads((p/(tag+'-selected.json')).read_text());assert hashlib.sha256((p/(tag+'.zip')).read_bytes()).hexdigest()==m['zipSha256'];paths.append(p/(tag+'-selected.json'))
 for x in m['selected']:
  f=p/x['file'];assert hashlib.sha256(f.read_bytes()).hexdigest()==x['sha256'];paths.append(f)
log=(p/'native-artifact--Testing_Temporary_LastTest.log').read_text();assert log.count('owned_native_recording source_rate=')==6 and '63863 monitor EQ' in log and '2 actual EQ publication process boundaries' in log
for n in range(1,4):assert 'original_concurrent_owner_diagnostic completed20takes; original5sdeadline; native_audio=false' in (p/('native-artifact--manual-owner-'+str(n)+'-stdout.log')).read_text() and not (p/('native-artifact--manual-owner-'+str(n)+'-stderr.log')).read_bytes()
original=(p/'job-114608611360.log').read_text();assert '100% tests passed out of 71' in original
failed=(p/'desktop-artifact--build-desktop-native_Testing_Temporary_LastTest.log').read_text();assert 'parent_interruption_failure' in failed and '"exitCode": 2' in failed and "'status': 'Incomplete'" in failed
out.mkdir(exist_ok=False);members={}
for f in paths:
 raw=f.read_bytes();data=gzip.compress(raw,mtime=0);n=f.name+'.gz';assert n not in members;(out/n).write_bytes(data);members[n]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'originalBytes':len(raw),'originalSha256':hashlib.sha256(raw).hexdigest(),'lossless':True}
summary={'pr':148,'run':run['id'],'head':b['head'],'base':b['base'],'testedMerge':b['mergeRef'],'tree':b['tree'],'changedBlobBindings':len(b['files']),'qualifiedInputCount':647,'terminalJobBindings':bindings,'linuxJobStatusAtCollection':'completed_success','allFourJobsPassed':False,'native71CTestPassed':True,'nativeSixOwnedRecordingsAndSharedEq':True,'nativeTwoActualEqPublicationBoundaries':True,'nativeThreeOriginalStandaloneCompletions':True,'desktop18PassedOneFailed':True,'desktopFailedSuite':'desktop-stretch-parent-interruption','desktopFailureStage':'during-processing','helperExitCode':2,'recoveryActual':'Incomplete','recoveryExpected':'Ready','previousManualFlushStallCauseResolved':False,'currentControllerQualifiedByThisRun':False,'physicalAudioQualified':False,'binariesOrMediaIncluded':False}
raw=(json.dumps(summary,indent=2)+'\n').encode();(out/'summary.json').write_bytes(raw);members['summary.json']={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()};(out/'manifest.json').write_text(json.dumps({'members':members,'scope':'PR148 actual native Windows EQ execution plus original desktop failure; all four original terminal job logs; native/Linux/cross pass and desktop fails; original artifact logs and exact tested source bindings; no ZIP/binary/audio'},indent=2)+'\n');print('Retained148 original native success/desktop failure',len(members),'bound files',sum(f.stat().st_size for f in out.iterdir()),'bytes')
