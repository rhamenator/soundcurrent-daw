﻿# SPDX-License-Identifier: GPL-3.0-only
$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
if((Get-CimInstance Win32_ComputerSystemProduct).UUID.ToLowerInvariant() -ne '670168f5-4e3f-4e7f-b218-3583db31f0f8') {throw 'Wrong independent clone'}
if(Get-Process -Name soundcurrent-daw,sc-stretch-render-worker -ErrorAction SilentlyContinue) {throw 'An actual product process is already live'}
$root=Join-Path $env:USERPROFILE 'SoundCurrent-Installed-Interruption-4fb8-2'
if(Test-Path $root) {throw 'Existing fixture root refused'}
New-Item -ItemType Directory $root|Out-Null;$records=Join-Path $root 'records';New-Item -ItemType Directory $records|Out-Null
foreach($name in @('collect.ps1','private-transport.json')) {Copy-Item -LiteralPath (Join-Path $PSScriptRoot $name) -Destination (Join-Path $root $name)}
$project=Join-Path $root 'project-été-Κиїв';Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'fixture') -Destination $project -Recurse
$prior=Join-Path $env:USERPROFILE 'SoundCurrent-Restart-4fb8-2';$original=Join-Path $prior 'project-été-Κиїв'
$receipt=Get-Content -LiteralPath (Join-Path $prior 'receipt.json') -Raw -Encoding UTF8|ConvertFrom-Json
if($receipt.sourceHead -ne '4fb8c1cdf1b1365e5834256f4b39b51566dbed52' -or $receipt.sequence -ne '20261010183111') {throw 'Unqualified installed preview identity'}
Copy-Item -LiteralPath (Join-Path $prior 'receipt.json') -Destination (Join-Path $records 'installed-receipt.json')
$install=Join-Path $env:LOCALAPPDATA ('Programs\SoundCurrent DAW Preview\'+$receipt.sequence+'-'+$receipt.sourceHead.Substring(0,12))
foreach($f in $receipt.payload.PSObject.Properties) {if((Get-FileHash -LiteralPath (Join-Path $install $f.Name) -Algorithm SHA256).Hash.ToLowerInvariant() -ne $f.Value.sha256) {throw ('Installed payload changed: '+$f.Name)}}
function Files($Path) {return @(Get-ChildItem -LiteralPath $Path -Recurse -File|ForEach-Object {@{path=$_.FullName.Substring($Path.Length+1);bytes=$_.Length;sha256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()}}|Sort-Object path)}
$before=Files $project;$before|ConvertTo-Json -Depth 6|Set-Content (Join-Path $records 'fixture-before.json') -Encoding UTF8
$originalBefore=Files $original;$originalBefore|ConvertTo-Json -Depth 6|Set-Content (Join-Path $records 'original-before.json') -Encoding UTF8
$env:PATH=$install+';'+$env:SystemRoot+'\System32;'+$env:SystemRoot+';'+$env:SystemRoot+'\System32\WindowsPowerShell\v1.0'
foreach($name in @('cl.exe','clang++.exe','cmake.exe','qmake6.exe')) {if(Get-Command $name -ErrorAction SilentlyContinue) {throw 'Developer SDK on runtime PATH'}}
$env:QT_QPA_PLATFORM='windows';$env:QT_QPA_PLATFORM_PLUGIN_PATH=Join-Path $install 'platforms'
Add-Type -AssemblyName UIAutomationClient,UIAutomationTypes,System.Windows.Forms
Add-Type 'using System;using System.Runtime.InteropServices;public class SCForeground { [DllImport("user32.dll")]public static extern bool SetForegroundWindow(IntPtr h); [DllImport("user32.dll")]public static extern IntPtr GetForegroundWindow(); [DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint pid); }'
Add-Type -TypeDefinition ([IO.File]::ReadAllText((Join-Path $PSScriptRoot 'native.cs')))
$stamp=[DateTime]::UtcNow.ToString('yyyyMMddHHmmssfff');$events=@();$p=$null;$source=$null;$watch=$null;$fresh=$null
function Event($Name,$Data) {$script:events+=,@{utc=[DateTime]::UtcNow.ToString('o');name=$Name;data=$Data};$script:events|ConvertTo-Json -Depth 12|Set-Content (Join-Path $records ('interruption-'+$stamp+'.json')) -Encoding UTF8}
function Identity($Process) {return @{pid=$Process.Pid;creationFileTime=$Process.CreationFileTime;exe=$Process.Image;sha256=(Get-FileHash -LiteralPath $Process.Image -Algorithm SHA256).Hash.ToLowerInvariant()}}

function Elements {
 $condition=New-Object Windows.Automation.PropertyCondition ([Windows.Automation.AutomationElement]::ProcessIdProperty),$p.Id
 return [Windows.Automation.AutomationElement]::RootElement.FindAll([Windows.Automation.TreeScope]::Descendants,$condition)
}
function Find-Id($Id) {
 $all=@(Elements|Where-Object {($_.Current.AutomationId -eq $Id -or $_.Current.AutomationId.EndsWith('.'+$Id)) -and $_.Current.ClassName -ne ''})
 if($all.Count -ne 1) {throw ('No unique actual control: '+$Id)};return $all[0]
}
function Await($Check,$Name) {$end=[DateTime]::UtcNow.AddSeconds(15);do {if(& $Check) {return};Start-Sleep -Milliseconds 100} while([DateTime]::UtcNow -lt $end);throw ('Observation deadline: '+$Name)}
function Assert-Foreground {[uint32]$owner=0;[SCForeground]::GetWindowThreadProcessId([SCForeground]::GetForegroundWindow(),[ref]$owner)|Out-Null;if($owner -ne $p.Id) {throw 'Foreground changed; keys refused'}}
function Keys($Keys) {Assert-Foreground;[Windows.Forms.SendKeys]::SendWait($Keys);Start-Sleep -Milliseconds 200}
function Focus-App {$p.Refresh();if(![SCForeground]::SetForegroundWindow($p.MainWindowHandle)) {throw 'Cannot focus owned app'};Start-Sleep -Milliseconds 300;Assert-Foreground}
function Button($Id) {$e=Find-Id $Id;if(!$e.Current.IsEnabled) {throw ('Disabled button: '+$Id)};([Windows.Automation.InvokePattern]$e.GetCurrentPattern([Windows.Automation.InvokePattern]::Pattern)).Invoke();Start-Sleep -Milliseconds 250}
function Menu($Name) {
 Focus-App;Keys '%e'
 $all=@(Elements|Where-Object {$_.Current.ControlType -eq [Windows.Automation.ControlType]::MenuItem -and $_.Current.Name.Contains($Name)})
 if($all.Count -ne 1 -or !$all[0].Current.IsEnabled) {throw ('No enabled menu item: '+$Name)}
 ([Windows.Automation.InvokePattern]$all[0].GetCurrentPattern([Windows.Automation.InvokePattern]::Pattern)).Invoke();Start-Sleep -Milliseconds 250;if(!$Name.StartsWith('Review retained')) {Keys '{ESC}'}
}
function Tree($Name) {
 $rows=@();foreach($e in (Elements)) {$c=$e.Current;$v=$null;$vp=$null;if($e.TryGetCurrentPattern([Windows.Automation.ValuePattern]::Pattern,[ref]$vp)) {$v=([Windows.Automation.ValuePattern]$vp).Current.Value};$rows+=@{name=$c.Name;id=$c.AutomationId;class=$c.ClassName;type=$c.ControlType.ProgrammaticName;enabled=$c.IsEnabled;value=$v;patterns=@($e.GetSupportedPatterns()|ForEach-Object {$_.ProgrammaticName})}}
 $rows|ConvertTo-Json -Depth 6|Set-Content (Join-Path $records ('uia-restart-'+$stamp+'-'+$Name+'.json')) -Encoding UTF8
}
function Snapshot($Name) {Copy-Item -LiteralPath (Join-Path $project 'project.json') -Destination (Join-Path $records ('project-restart-'+$stamp+'-'+$Name+'.json'));Tree $Name;Event $Name @{projectSha256=(Get-FileHash (Join-Path $project 'project.json') -Algorithm SHA256).Hash.ToLowerInvariant()}}
function Launch($Phase) {
 $script:p=Start-Process -FilePath (Join-Path $install 'soundcurrent-daw.exe') -ArgumentList '--language','en' -WorkingDirectory $install -PassThru -RedirectStandardOutput (Join-Path $records ('restart-'+$stamp+'-'+$Phase+'.stdout')) -RedirectStandardError (Join-Path $records ('restart-'+$stamp+'-'+$Phase+'.stderr'))
 $script:actualHandle=$p.Handle;$p.PriorityClass='BelowNormal'
 Await {$p.Refresh();return $p.MainWindowHandle -ne 0 -and !$p.HasExited} 'actual installed window'
 if($p.SessionId -eq 0 -or !$p.MainWindowTitle.StartsWith('SoundCurrent DAW')) {throw 'No interactive installed app'}
 $modules=@($p.Modules|ForEach-Object {@{name=$_.ModuleName;path=$_.FileName}})
 foreach($name in @('Qt6Core.dll','Qt6Gui.dll','Qt6Widgets.dll','sndfile.dll','qwindows.dll')) {$found=@($modules|Where-Object {$_.name -eq $name});if($found.Count -ne 1 -or !$found[0].path.StartsWith($install+'\',[StringComparison]::OrdinalIgnoreCase)) {throw ('Wrong installed module: '+$name)}}
 [IO.File]::WriteAllText((Join-Path $root 'main-pid.txt'),$p.Id)
 Event ('launch-'+$Phase) @{pid=$p.Id;startUtc=$p.StartTime.ToUniversalTime().ToString('o');sessionId=$p.SessionId;exe=$p.Path;sha256=(Get-FileHash $p.Path -Algorithm SHA256).Hash.ToLowerInvariant();modules=$modules;developerSdkUsed=$false;nativeAudioActivated=$false}

 Focus-App;Keys '^o';Start-Sleep -Milliseconds 500
 [Windows.Forms.Clipboard]::SetText($project);Keys '^l';Keys '^v';Keys '{ENTER}';Start-Sleep -Milliseconds 400
 $button=@(Elements|Where-Object {$_.Current.Name -eq 'Select Folder' -and $_.Current.ControlType -eq [Windows.Automation.ControlType]::Button -and !$_.Current.IsOffscreen})
 if($button.Count -ne 1) {throw 'No unique actual folder button'};$button[0].SetFocus();Keys '{ENTER}'
 Await {return (Find-Id 'clipStretchButton').Current.IsEnabled -or (Find-Id 'timelineClips').Current.IsEnabled} 'opened owned project'
 Start-Sleep -Milliseconds 500;Snapshot ('opened-'+$Phase)
}
function Scan($Phase) {
 Menu 'Review retained pitch/stretch renders'
 Await {return @(Elements|Where-Object {$_.Current.ControlType -eq [Windows.Automation.ControlType]::ListItem -and $_.Current.AutomationId.EndsWith('.stretchRecoveryList')}).Count -eq 1} 'specific retained job inventory'
 $list=Find-Id 'stretchRecoveryList';$list.SetFocus();Keys '{HOME}';Start-Sleep -Milliseconds 250;Tree ('scan-'+$Phase)
 $item=@(Elements|Where-Object {$_.Current.ControlType -eq [Windows.Automation.ControlType]::ListItem -and $_.Current.AutomationId.EndsWith('.stretchRecoveryList')})[0]
 Event ('inventory-'+$Phase) @{name=$item.Current.Name;reviewEnabled=(Find-Id 'reviewRetainedStretch').Current.IsEnabled}
 return $item.Current.Name
}
function Normal-Quit($Phase) {$start=$p.StartTime.ToUniversalTime().ToString('o');$normal=$p.CloseMainWindow();$exited=$p.WaitForExit(10000);Event ('quit-'+$Phase) @{pid=$p.Id;startUtc=$start;normalCloseRequested=$normal;actualExited=$exited;exitCode=$(if($exited){$p.ExitCode}else{$null});forced=$false};if(!$exited -or $p.ExitCode -ne 0) {throw 'Actual main did not quit normally'}}

# SPDX-License-Identifier: GPL-3.0-only
try {
 Launch 'source';$source=New-Object SCProcess ([uint32]$p.Id),(Join-Path $install 'soundcurrent-daw.exe')
 Event 'source-identity' (Identity $source)
 $combo=Find-Id 'timelineClips';([Windows.Automation.ExpandCollapsePattern]$combo.GetCurrentPattern([Windows.Automation.ExpandCollapsePattern]::Pattern)).Expand();Start-Sleep -Milliseconds 250;Keys '{END}{ENTER}';Tree 'selected-source';Button 'clipStretchButton'
 Await {return @(Elements|Where-Object {$_.Current.AutomationId.EndsWith('.stretchNumerator') -and $_.Current.ClassName -ne ''}).Count -eq 1} 'actual stretch controls'
 foreach($pair in @(@('stretchNumerator',3),@('stretchDenominator',2))) {
  ([Windows.Automation.RangeValuePattern](Find-Id $pair[0]).GetCurrentPattern([Windows.Automation.RangeValuePattern]::Pattern)).SetValue($pair[1])
 }
 Tree 'configured-source'
 $watch=New-Object SCWatch ([uint32]$p.Id),(Join-Path $install 'sc-stretch-render-worker.exe'),(Join-Path $project 'media\derived')
 Button 'renderStretch';Await {return $watch.Done} 'actual helper partial pause'
 if($watch.Error) {throw $watch.Error}
 if(!$watch.Child.Running() -or $watch.Threads.Count -lt 1) {throw 'No live paused owned helper'}
 $partialHash=(Get-FileHash -LiteralPath $watch.Partial -Algorithm SHA256).Hash.ToLowerInvariant()
 $cim=Get-CimInstance Win32_Process -Filter ('ProcessId='+$watch.Child.Pid)
 if($cim.ParentProcessId -ne $source.Pid -or !$cim.CommandLine.Contains($project)) {throw 'Observed helper is not bound to source GUI/fixture'}
 $operation=Split-Path -Leaf (Split-Path -Parent $watch.Partial)
 Event 'helper-observed' @{identity=(Identity $watch.Child);parentPid=$cim.ParentProcessId;commandLine=$cim.CommandLine;operation=$operation;partialBytes=$watch.PartialBytes;partialSha256=$partialHash;threads=@($watch.Threads|ForEach-Object {@{tid=$_.Tid;previousSuspendCount=$_.Previous}})}
 Tree 'partial-source'
 $parentCode=$source.Kill(0x53430001);Event 'source-terminal' @{identity=(Identity $source);actualExited=$true;exitCode=$parentCode}
 if(!$watch.Child.Running()) {throw 'Helper did not survive the parent interruption'}
 Launch 'recovery';$fresh=New-Object SCProcess ([uint32]$p.Id),(Join-Path $install 'soundcurrent-daw.exe');Event 'fresh-identity' (Identity $fresh)
 $inventory=Scan 'active'
 if(!$inventory.Contains('Renderer still owns this job') -or (Find-Id 'reviewRetainedStretch').Current.IsEnabled -or !$watch.Child.Running()) {throw 'Live writer admitted or not observed'}
 if((Get-FileHash -LiteralPath $watch.Partial -Algorithm SHA256).Hash.ToLowerInvariant() -ne $partialHash) {throw 'Paused partial changed'}
 Event 'active-refused' @{identity=(Identity $watch.Child);running=$true;inventory=$inventory;selectedReviewEnabled=$false;partialSha256=$partialHash}
 $helperCode=$watch.Child.Kill(0x53430002);Event 'helper-terminal' @{identity=(Identity $watch.Child);actualExited=$true;exitCode=$helperCode}
 $watch.RetireThreads();Event 'threads-retired' @{threads=@($watch.Threads|ForEach-Object {@{tid=$_.Tid;previousSuspendCount=$_.Previous;closed=$_.Closed}});helperRunning=$watch.Child.Running()}
 $scanButtons=@(Elements|Where-Object {$_.Current.ControlType -eq [Windows.Automation.ControlType]::Button -and $_.Current.Name -eq 'Scan again' -and $_.Current.IsEnabled})
 if($scanButtons.Count -ne 1) {throw 'No unique actual Scan again'}
 ([Windows.Automation.InvokePattern]$scanButtons[0].GetCurrentPattern([Windows.Automation.InvokePattern]::Pattern)).Invoke()
 Await {return @(Elements|Where-Object {$_.Current.ControlType -eq [Windows.Automation.ControlType]::ListItem -and $_.Current.AutomationId.EndsWith('.stretchRecoveryList') -and $_.Current.Name.Contains('Incomplete render')}).Count -eq 1} 'actual incomplete scan'
 (Find-Id 'stretchRecoveryList').SetFocus();Keys '{HOME}';Tree 'scan-incomplete'
 if((Find-Id 'reviewRetainedStretch').Current.IsEnabled) {throw 'Incomplete render admitted'}
 if((Get-FileHash -LiteralPath $watch.Partial -Algorithm SHA256).Hash.ToLowerInvariant() -ne $partialHash -or (Get-Item -LiteralPath $watch.Partial).Length -ne $watch.PartialBytes) {throw 'Partial bytes not preserved'}
 $job=Split-Path -Parent $watch.Partial
 if((Test-Path (Join-Path $job 'audio.wav')) -or (Test-Path (Join-Path $job 'complete.json'))) {throw 'Unexpected completed output'}
 Event 'incomplete-refused' @{operation=$operation;selectedReviewEnabled=$false;partialSha256=$partialHash;partialBytes=$watch.PartialBytes;noFinalOrCompletion=$true}
 (Find-Id 'stretchRecoveryDialog').SetFocus();Keys '{ESC}';Snapshot 'final-recovery';Normal-Quit 'recovery'
 if($fresh.Running() -or $fresh.Exit() -ne 0) {throw 'Fresh process not actually terminal0'}
 $after=Files $project;$after|ConvertTo-Json -Depth 6|Set-Content (Join-Path $records 'fixture-after.json') -Encoding UTF8
 foreach($f in $before) {$actual=@($after|Where-Object {$_.path -eq $f.path});if($actual.Count -ne 1 -or $actual[0].bytes -ne $f.bytes -or $actual[0].sha256 -ne $f.sha256) {throw 'Saved fixture or raw changed'}}
 $originalAfter=Files $original;$originalAfter|ConvertTo-Json -Depth 6|Set-Content (Join-Path $records 'original-after.json') -Encoding UTF8
 if(($originalBefore|ConvertTo-Json -Depth 6 -Compress) -ne ($originalAfter|ConvertTo-Json -Depth 6 -Compress)) {throw 'Proven original changed'}
 Event 'completed' @{sourceHead=$receipt.sourceHead;sequence=$receipt.sequence;projectAndRawUnchanged=$true;originalUnchanged=$true;parentExit=$parentCode;helperExit=$helperCode;freshExit=0;powerLossQualified=$false;playRequested=$false;fullGoalComplete=$false}
} catch {
 Event 'operator-failure' @{message=$_.Exception.Message;stack=$_.ScriptStackTrace}
 try {Tree 'failure'} catch {}
 throw
} finally {
 $cleanup=@()
 if($watch) {if(!$watch.Join()) {throw 'Native watcher remains live; cleanup unresolved'};if($watch.Child) {if($watch.Child.Running()) {$code=$watch.Child.Kill(0x53430002)}else{$code=$watch.Child.Exit()};$watch.RetireThreads();$cleanup+=@{kind='helper';identity=(Identity $watch.Child);actualExited=$true;exitCode=$code};$watch.Child.Dispose()}}
 foreach($owned in @($fresh,$source)) {if($owned) {if($owned.Running()) {$code=$owned.Kill(0x53430001)}else{$code=$owned.Exit()};$cleanup+=@{kind='app';identity=(Identity $owned);actualExited=$true;exitCode=$code};$owned.Dispose()}}
 if($p -and !$p.HasExited) {$p.Kill();$p.WaitForExit();$cleanup+=@{kind='unopened-app';pid=$p.Id;actualExited=$p.HasExited;exitCode=$p.ExitCode}}
 Event 'cleanup' @{processes=$cleanup;workerThreadJoined=$true}
 & (Join-Path $root 'collect.ps1') ('installed-interruption-'+$stamp+'.zip')
 [IO.File]::WriteAllText((Join-Path $root 'session-terminal.txt'),'operator finished after actual handle cleanup')
}
