﻿# SPDX-License-Identifier: GPL-3.0-only
$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
if((Get-CimInstance Win32_ComputerSystemProduct).UUID.ToLowerInvariant() -ne '670168f5-4e3f-4e7f-b218-3583db31f0f8') {throw 'Wrong independent clone'}
if(Get-Process -Name soundcurrent-daw,sc-stretch-render-worker -ErrorAction SilentlyContinue) {throw 'An actual product process is already live'}
$root=Join-Path $env:USERPROFILE 'SoundCurrent-Installed-Interruption-4fb8-2'
if(Test-Path $root) {throw 'Existing fixture root refused'}
New-Item -ItemType Directory $root|Out-Null;$records=Join-Path $root 'records';New-Item -ItemType Directory $records|Out-Null
foreach($name in @('collect.ps1','private-transport.json')) {Copy-Item -LiteralPath (Join-Path $PSScriptRoot $name) -Destination (Join-Path $root $name)}
$project=Join-Path $root 'project-été-Κиїв';Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'fixture') -Destination $project -Recurse
$prior=Join-Path $env:USERPROFILE 'SoundCurrent-Restart-4fb8-2';$original=Join-Path $prior 'project-été-Κиїв'
$receipt=Get-Content -LiteralPath (Join-Path $prior 'receipt.json') -Raw -Encoding UTF8|ConvertFrom-Json
if($receipt.sourceHead -ne '4fb8c1cdf1b1365e5834256f4b39b51566dbed52' -or $receipt.sequence -ne '20261010183111') {throw 'Unqualified installed preview identity'}
Copy-Item -LiteralPath (Join-Path $prior 'receipt.json') -Destination (Join-Path $records 'installed-receipt.json')
$install=Join-Path $env:LOCALAPPDATA ('Programs\SoundCurrent DAW Preview\'+$receipt.sequence+'-'+$receipt.sourceHead.Substring(0,12))
foreach($f in $receipt.payload.PSObject.Properties) {if((Get-FileHash -LiteralPath (Join-Path $install $f.Name) -Algorithm SHA256).Hash.ToLowerInvariant() -ne $f.Value.sha256) {throw ('Installed payload changed: '+$f.Name)}}
function Files($Path) {return @(Get-ChildItem -LiteralPath $Path -Recurse -File|ForEach-Object {@{path=$_.FullName.Substring($Path.Length+1);bytes=$_.Length;sha256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()}}|Sort-Object path)}
$before=Files $project;$before|ConvertTo-Json -Depth 6|Set-Content (Join-Path $records 'fixture-before.json') -Encoding UTF8
$originalBefore=Files $original;$originalBefore|ConvertTo-Json -Depth 6|Set-Content (Join-Path $records 'original-before.json') -Encoding UTF8
$env:PATH=$install+';'+$env:SystemRoot+'\System32;'+$env:SystemRoot+';'+$env:SystemRoot+'\System32\WindowsPowerShell\v1.0'
foreach($name in @('cl.exe','clang++.exe','cmake.exe','qmake6.exe')) {if(Get-Command $name -ErrorAction SilentlyContinue) {throw 'Developer SDK on runtime PATH'}}
$env:QT_QPA_PLATFORM='windows';$env:QT_QPA_PLATFORM_PLUGIN_PATH=Join-Path $install 'platforms'
Add-Type -AssemblyName UIAutomationClient,UIAutomationTypes,System.Windows.Forms
Add-Type 'using System;using System.Runtime.InteropServices;public class SCForeground { [DllImport("user32.dll")]public static extern bool SetForegroundWindow(IntPtr h); [DllImport("user32.dll")]public static extern IntPtr GetForegroundWindow(); [DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint pid); }'
Add-Type -TypeDefinition ([IO.File]::ReadAllText((Join-Path $PSScriptRoot 'native.cs')))
$stamp=[DateTime]::UtcNow.ToString('yyyyMMddHHmmssfff');$events=@();$p=$null;$source=$null;$watch=$null;$fresh=$null
function Event($Name,$Data) {$script:events+=,@{utc=[DateTime]::UtcNow.ToString('o');name=$Name;data=$Data};$script:events|ConvertTo-Json -Depth 12|Set-Content (Join-Path $records ('interruption-'+$stamp+'.json')) -Encoding UTF8}
function Identity($Process) {return @{pid=$Process.Pid;creationFileTime=$Process.CreationFileTime;exe=$Process.Image;sha256=(Get-FileHash -LiteralPath $Process.Image -Algorithm SHA256).Hash.ToLowerInvariant()}}
