// SPDX-License-Identifier: GPL-3.0-only
using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.ComponentModel;
using System.Diagnostics;
using System.Threading;
public static class SCNative {
 [StructLayout(LayoutKind.Sequential,CharSet=CharSet.Unicode)] public struct PE {
  public uint size,usage,pid;public UIntPtr heap;public uint module,threads,parent;public int priority;public uint flags;
  [MarshalAs(UnmanagedType.ByValTStr,SizeConst=260)]public string exe;
 }
 [StructLayout(LayoutKind.Sequential)]public struct TE {public uint size,usage,tid,pid;public int priority,delta;public uint flags;}
 [DllImport("kernel32",SetLastError=true)]public static extern IntPtr OpenProcess(uint access,bool inherit,uint pid);
 [DllImport("kernel32",SetLastError=true)]public static extern bool CloseHandle(IntPtr h);
 [DllImport("kernel32",CharSet=CharSet.Unicode,SetLastError=true)]public static extern bool QueryFullProcessImageName(IntPtr h,uint flags,StringBuilder name,ref uint size);
 [DllImport("kernel32",SetLastError=true)]public static extern bool GetProcessTimes(IntPtr h,out ulong creation,out ulong exit,out ulong kernel,out ulong user);
 [DllImport("kernel32",SetLastError=true)]public static extern uint WaitForSingleObject(IntPtr h,uint timeout);
 [DllImport("kernel32",SetLastError=true)]public static extern bool GetExitCodeProcess(IntPtr h,out uint code);
 [DllImport("kernel32",SetLastError=true)]public static extern bool TerminateProcess(IntPtr h,uint code);
 [DllImport("kernel32",SetLastError=true)]public static extern IntPtr CreateToolhelp32Snapshot(uint flags,uint pid);
 [DllImport("kernel32",CharSet=CharSet.Unicode,SetLastError=true)]public static extern bool Process32First(IntPtr h,ref PE e);
 [DllImport("kernel32",CharSet=CharSet.Unicode,SetLastError=true)]public static extern bool Process32Next(IntPtr h,ref PE e);
 [DllImport("kernel32",SetLastError=true)]public static extern bool Thread32First(IntPtr h,ref TE e);
 [DllImport("kernel32",SetLastError=true)]public static extern bool Thread32Next(IntPtr h,ref TE e);
 [DllImport("kernel32",SetLastError=true)]public static extern IntPtr OpenThread(uint access,bool inherit,uint tid);
 [DllImport("kernel32",SetLastError=true)]public static extern uint GetProcessIdOfThread(IntPtr h);
 [DllImport("kernel32",SetLastError=true)]public static extern uint SuspendThread(IntPtr h);
 [DllImport("kernel32",SetLastError=true)]public static extern uint ResumeThread(IntPtr h);
 public static void Check(bool yes){if(!yes)throw new Win32Exception(Marshal.GetLastWin32Error());}
 public static IntPtr Snapshot(uint flags){IntPtr h=CreateToolhelp32Snapshot(flags,0);if(h==IntPtr.Zero||h==new IntPtr(-1))throw new Win32Exception(Marshal.GetLastWin32Error());return h;}
 public static uint Child(uint parent){IntPtr h=Snapshot(2);try{PE e=new PE();e.size=(uint)Marshal.SizeOf(typeof(PE));bool good=Process32First(h,ref e);uint found=0;while(good){if(e.parent==parent && e.exe=="sc-stretch-render-worker.exe"){if(found!=0)throw new Exception("Ambiguous owned helper");found=e.pid;}good=Process32Next(h,ref e);}return found;}finally{Check(CloseHandle(h));}}
}
public class SCProcess:IDisposable {
 public uint Pid;public ulong CreationFileTime;public string Image;public IntPtr Handle;
 public SCProcess(uint pid,string expected){Pid=pid;Handle=SCNative.OpenProcess(0x100000|0x1000|1,false,pid);if(Handle==IntPtr.Zero)throw new Win32Exception(Marshal.GetLastWin32Error());try{StringBuilder name=new StringBuilder(32768);uint n=(uint)name.Capacity;SCNative.Check(SCNative.QueryFullProcessImageName(Handle,0,name,ref n));Image=name.ToString();if(!String.Equals(Path.GetFullPath(Image),Path.GetFullPath(expected),StringComparison.OrdinalIgnoreCase))throw new Exception("Wrong owned image");ulong exit,kernel,user;SCNative.Check(SCNative.GetProcessTimes(Handle,out CreationFileTime,out exit,out kernel,out user));}catch{Dispose();throw;}}
 public bool Running(){uint r=SCNative.WaitForSingleObject(Handle,0);if(r!=0 && r!=258)throw new Win32Exception(Marshal.GetLastWin32Error());return r==258;}
 public uint Exit(){if(Running())throw new Exception("Actual process is still running");uint c;SCNative.Check(SCNative.GetExitCodeProcess(Handle,out c));return c;}
 public uint Kill(uint code){if(!Running())throw new Exception("Owned termination boundary already passed");SCNative.Check(SCNative.TerminateProcess(Handle,code));uint r=SCNative.WaitForSingleObject(Handle,10000);if(r!=0)throw new Exception("Owned termination requested; no terminal observation yet");uint c=Exit();if(c!=code)throw new Exception("Unexpected actual exit");return c;}
 public void Dispose(){if(Handle!=IntPtr.Zero){SCNative.Check(SCNative.CloseHandle(Handle));Handle=IntPtr.Zero;}}
}
public class SCThreadRecord {public uint Tid,Previous;public IntPtr Handle;public bool Closed;public uint ResumeResult;}
public class SCWatch {
 public uint Parent;public string Expected,Jobs;public SCProcess Child;public string Partial,Error;public long PartialBytes;
 public volatile bool Done,Cancel;public List<SCThreadRecord> Threads=new List<SCThreadRecord>();public Thread Thread;
 public SCWatch(uint parent,string expected,string jobs){Parent=parent;Expected=expected;Jobs=jobs;Thread=new Thread(Run);Thread.IsBackground=true;Thread.Start();}
 void Pause(){HashSet<uint> seen=new HashSet<uint>();for(int pass=0;pass<3;++pass){bool added=false;IntPtr snap=SCNative.Snapshot(4);try{SCNative.TE e=new SCNative.TE();e.size=(uint)Marshal.SizeOf(typeof(SCNative.TE));bool good=SCNative.Thread32First(snap,ref e);while(good){if(e.pid==Child.Pid&&!seen.Contains(e.tid)){IntPtr h=SCNative.OpenThread(2|0x40,false,e.tid);if(h==IntPtr.Zero)throw new Win32Exception(Marshal.GetLastWin32Error());try{if(SCNative.GetProcessIdOfThread(h)!=Child.Pid)throw new Exception("Unrelated thread refused");uint prior=SCNative.SuspendThread(h);if(prior==0xffffffff)throw new Win32Exception(Marshal.GetLastWin32Error());Threads.Add(new SCThreadRecord{Tid=e.tid,Previous=prior,Handle=h});seen.Add(e.tid);added=true;}catch{SCNative.Check(SCNative.CloseHandle(h));throw;}}good=SCNative.Thread32Next(snap,ref e);}}finally{SCNative.Check(SCNative.CloseHandle(snap));}if(!added&&Threads.Count>0&&Child.Running())return;}throw new Exception("Owned helper thread set did not stabilize");}
 void Run(){try{Stopwatch timer=Stopwatch.StartNew();while(Child==null){if(Cancel||timer.Elapsed.TotalSeconds>30)throw new Exception("Helper observation expired");uint pid=SCNative.Child(Parent);if(pid!=0)Child=new SCProcess(pid,Expected);else System.Threading.Thread.Sleep(1);}while(true){if(Cancel||timer.Elapsed.TotalSeconds>30)throw new Exception("Partial observation expired");if(!Child.Running())throw new Exception("Helper completed before interruption witness");string[] files=Directory.Exists(Jobs)?Directory.GetFiles(Jobs,"audio.partial",SearchOption.AllDirectories):new string[0];if(files.Length>1)throw new Exception("Ambiguous partial");if(files.Length==1&&new FileInfo(files[0]).Length>4096){Partial=files[0];Pause();PartialBytes=new FileInfo(Partial).Length;if(File.Exists(Path.Combine(Path.GetDirectoryName(Partial),"complete.json"))||File.Exists(Path.Combine(Path.GetDirectoryName(Partial),"audio.wav")))throw new Exception("Missed partial boundary");break;}System.Threading.Thread.Sleep(1);}}catch(Exception e){Error=e.ToString();}finally{Done=true;}}
 public void RetireThreads(){bool live=Child!=null&&Child.Running();for(int i=Threads.Count-1;i>=0;--i){SCThreadRecord r=Threads[i];if(r.Closed)continue;try{if(live){r.ResumeResult=SCNative.ResumeThread(r.Handle);if(r.ResumeResult!=r.Previous+1)throw new Exception("Suspend count mismatch");}}finally{SCNative.Check(SCNative.CloseHandle(r.Handle));r.Closed=true;}}}
 public bool Join(){Cancel=true;return Thread.Join(35000);}
}
