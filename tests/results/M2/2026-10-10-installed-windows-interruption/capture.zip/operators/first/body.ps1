﻿# SPDX-License-Identifier: GPL-3.0-only
try {
 Launch 'source';$source=New-Object SCProcess ([uint32]$p.Id),(Join-Path $install 'soundcurrent-daw.exe')
 Event 'source-identity' (Identity $source)
 $combo=Find-Id 'timelineClips';$combo.SetFocus();Keys '{END}';Button 'clipStretchButton'
 Await {return (Find-Id 'stretchNumerator').Current.IsEnabled} 'actual stretch controls'
 foreach($pair in @(@('stretchNumerator',3),@('stretchDenominator',2))) {
  ([Windows.Automation.RangeValuePattern](Find-Id $pair[0]).GetCurrentPattern([Windows.Automation.RangeValuePattern]::Pattern)).SetValue($pair[1])
 }
 Tree 'configured-source'
 $watch=New-Object SCWatch ([uint32]$p.Id),(Join-Path $install 'sc-stretch-render-worker.exe'),(Join-Path $project 'media\derived')
 Button 'renderStretch';Await {return $watch.Done} 'actual helper partial pause'
 if($watch.Error) {throw $watch.Error}
 if(!$watch.Child.Running() -or $watch.Threads.Count -lt 1) {throw 'No live paused owned helper'}
 $partialHash=(Get-FileHash -LiteralPath $watch.Partial -Algorithm SHA256).Hash.ToLowerInvariant()
 $cim=Get-CimInstance Win32_Process -Filter ('ProcessId='+$watch.Child.Pid)
 if($cim.ParentProcessId -ne $source.Pid -or !$cim.CommandLine.Contains($project)) {throw 'Observed helper is not bound to source GUI/fixture'}
 $operation=Split-Path -Leaf (Split-Path -Parent $watch.Partial)
 Event 'helper-observed' @{identity=(Identity $watch.Child);parentPid=$cim.ParentProcessId;commandLine=$cim.CommandLine;operation=$operation;partialBytes=$watch.PartialBytes;partialSha256=$partialHash;threads=@($watch.Threads|ForEach-Object {@{tid=$_.Tid;previousSuspendCount=$_.Previous}})}
 Tree 'partial-source'
 $parentCode=$source.Kill(0x53430001);Event 'source-terminal' @{identity=(Identity $source);actualExited=$true;exitCode=$parentCode}
 if(!$watch.Child.Running()) {throw 'Helper did not survive the parent interruption'}
 Launch 'recovery';$fresh=New-Object SCProcess ([uint32]$p.Id),(Join-Path $install 'soundcurrent-daw.exe');Event 'fresh-identity' (Identity $fresh)
 $inventory=Scan 'active'
 if(!$inventory.Contains('Renderer still owns this job') -or (Find-Id 'reviewRetainedStretch').Current.IsEnabled -or !$watch.Child.Running()) {throw 'Live writer admitted or not observed'}
 if((Get-FileHash -LiteralPath $watch.Partial -Algorithm SHA256).Hash.ToLowerInvariant() -ne $partialHash) {throw 'Paused partial changed'}
 Event 'active-refused' @{identity=(Identity $watch.Child);running=$true;inventory=$inventory;selectedReviewEnabled=$false;partialSha256=$partialHash}
 $helperCode=$watch.Child.Kill(0x53430002);Event 'helper-terminal' @{identity=(Identity $watch.Child);actualExited=$true;exitCode=$helperCode}
 $watch.RetireThreads();Event 'threads-retired' @{threads=@($watch.Threads|ForEach-Object {@{tid=$_.Tid;previousSuspendCount=$_.Previous;closed=$_.Closed}});helperRunning=$watch.Child.Running()}
 $scanButtons=@(Elements|Where-Object {$_.Current.ControlType -eq [Windows.Automation.ControlType]::Button -and $_.Current.Name -eq 'Scan again' -and $_.Current.IsEnabled})
 if($scanButtons.Count -ne 1) {throw 'No unique actual Scan again'}
 ([Windows.Automation.InvokePattern]$scanButtons[0].GetCurrentPattern([Windows.Automation.InvokePattern]::Pattern)).Invoke()
 Await {return @(Elements|Where-Object {$_.Current.ControlType -eq [Windows.Automation.ControlType]::ListItem -and $_.Current.AutomationId.EndsWith('.stretchRecoveryList') -and $_.Current.Name.Contains('Incomplete render')}).Count -eq 1} 'actual incomplete scan'
 (Find-Id 'stretchRecoveryList').SetFocus();Keys '{HOME}';Tree 'scan-incomplete'
 if((Find-Id 'reviewRetainedStretch').Current.IsEnabled) {throw 'Incomplete render admitted'}
 if((Get-FileHash -LiteralPath $watch.Partial -Algorithm SHA256).Hash.ToLowerInvariant() -ne $partialHash -or (Get-Item -LiteralPath $watch.Partial).Length -ne $watch.PartialBytes) {throw 'Partial bytes not preserved'}
 $job=Split-Path -Parent $watch.Partial
 if((Test-Path (Join-Path $job 'audio.wav')) -or (Test-Path (Join-Path $job 'complete.json'))) {throw 'Unexpected completed output'}
 Event 'incomplete-refused' @{operation=$operation;selectedReviewEnabled=$false;partialSha256=$partialHash;partialBytes=$watch.PartialBytes;noFinalOrCompletion=$true}
 (Find-Id 'stretchRecoveryDialog').SetFocus();Keys '{ESC}';Snapshot 'final-recovery';Normal-Quit 'recovery'
 if($fresh.Running() -or $fresh.Exit() -ne 0) {throw 'Fresh process not actually terminal0'}
 $after=Files $project;$after|ConvertTo-Json -Depth 6|Set-Content (Join-Path $records 'fixture-after.json') -Encoding UTF8
 foreach($f in $before) {$actual=@($after|Where-Object {$_.path -eq $f.path});if($actual.Count -ne 1 -or $actual[0].bytes -ne $f.bytes -or $actual[0].sha256 -ne $f.sha256) {throw 'Saved fixture or raw changed'}}
 $originalAfter=Files $original;$originalAfter|ConvertTo-Json -Depth 6|Set-Content (Join-Path $records 'original-after.json') -Encoding UTF8
 if(($originalBefore|ConvertTo-Json -Depth 6 -Compress) -ne ($originalAfter|ConvertTo-Json -Depth 6 -Compress)) {throw 'Proven original changed'}
 Event 'completed' @{sourceHead=$receipt.sourceHead;sequence=$receipt.sequence;projectAndRawUnchanged=$true;originalUnchanged=$true;parentExit=$parentCode;helperExit=$helperCode;freshExit=0;powerLossQualified=$false;playRequested=$false;fullGoalComplete=$false}
} catch {
 Event 'operator-failure' @{message=$_.Exception.Message;stack=$_.ScriptStackTrace}
 throw
} finally {
 $cleanup=@()
 if($watch) {if(!$watch.Join()) {throw 'Native watcher remains live; cleanup unresolved'};if($watch.Child) {if($watch.Child.Running()) {$code=$watch.Child.Kill(0x53430002)}else{$code=$watch.Child.Exit()};$watch.RetireThreads();$cleanup+=@{kind='helper';identity=(Identity $watch.Child);actualExited=$true;exitCode=$code};$watch.Child.Dispose()}}
 foreach($owned in @($fresh,$source)) {if($owned) {if($owned.Running()) {$code=$owned.Kill(0x53430001)}else{$code=$owned.Exit()};$cleanup+=@{kind='app';identity=(Identity $owned);actualExited=$true;exitCode=$code};$owned.Dispose()}}
 if($p -and !$p.HasExited) {$p.Kill();$p.WaitForExit();$cleanup+=@{kind='unopened-app';pid=$p.Id;actualExited=$p.HasExited;exitCode=$p.ExitCode}}
 Event 'cleanup' @{processes=$cleanup;workerThreadJoined=$true}
 & (Join-Path $root 'collect.ps1') ('installed-interruption-'+$stamp+'.zip')
 [IO.File]::WriteAllText((Join-Path $root 'session-terminal.txt'),'operator finished after actual handle cleanup')
}
