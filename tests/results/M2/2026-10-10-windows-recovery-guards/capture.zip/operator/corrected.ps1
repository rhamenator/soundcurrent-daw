﻿$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
if((Get-CimInstance Win32_ComputerSystemProduct).UUID.ToLowerInvariant() -ne '670168f5-4e3f-4e7f-b218-3583db31f0f8') {throw 'Wrong independent clone'}
if(Get-Process -Name soundcurrent-daw -ErrorAction SilentlyContinue) {throw 'Actual main already live'}
$root=Join-Path $env:USERPROFILE 'SoundCurrent-Recovery-Guards-4fb8';$records=Join-Path $root 'records'
$project=Join-Path $root 'project-invalid-utf8-été-Κиїв';if(Test-Path $project) {throw 'Corrected fixture already exists'}
Copy-Item -LiteralPath (Join-Path $root 'project-ready-été-Κиїв') -Destination $project -Recurse
$operation='eee85921-5fd6-497f-88be-ecfd1a260bca';$manifest=Join-Path $project ('media\stretch-selections\'+$operation+'.json')
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'corrected-selection.json') -Destination $manifest -Force
Copy-Item -LiteralPath $manifest -Destination (Join-Path $records 'corrected-selection.json')
$receipt=Get-Content -LiteralPath (Join-Path $env:USERPROFILE 'SoundCurrent-Restart-4fb8-2\receipt.json') -Raw -Encoding UTF8|ConvertFrom-Json
$install=Join-Path $env:LOCALAPPDATA ('Programs\SoundCurrent DAW Preview\'+$receipt.sequence+'-'+$receipt.sourceHead.Substring(0,12))
foreach($f in $receipt.payload.PSObject.Properties) {if((Get-FileHash -LiteralPath (Join-Path $install $f.Name) -Algorithm SHA256).Hash.ToLowerInvariant() -ne $f.Value.sha256) {throw ('Installed payload changed: '+$f.Name)}}
$env:PATH=$install+';'+$env:SystemRoot+'\System32;'+$env:SystemRoot+';'+$env:SystemRoot+'\System32\WindowsPowerShell\v1.0'
$env:QT_QPA_PLATFORM='windows';$env:QT_QPA_PLATFORM_PLUGIN_PATH=Join-Path $install 'platforms'
Add-Type -AssemblyName UIAutomationClient,UIAutomationTypes,System.Windows.Forms
Add-Type 'using System;using System.Runtime.InteropServices;public class SCForeground { [DllImport("user32.dll")]public static extern bool SetForegroundWindow(IntPtr h); [DllImport("user32.dll")]public static extern IntPtr GetForegroundWindow(); [DllImport("user32.dll")]public static extern uint GetWindowThreadProcessId(IntPtr h,out uint pid); }'
$stamp=[DateTime]::UtcNow.ToString('yyyyMMddHHmmssfff');$events=@();$p=$null
function Event($Name,$Data) {$script:events+=,@{utc=[DateTime]::UtcNow.ToString('o');name=$Name;data=$Data};$script:events|ConvertTo-Json -Depth 12|Set-Content (Join-Path $records ('guards-'+$stamp+'.json')) -Encoding UTF8}
function Files($Path) {return @(Get-ChildItem -LiteralPath $Path -Recurse -File|ForEach-Object {@{path=$_.FullName.Substring($Path.Length+1);bytes=$_.Length;sha256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()}}|Sort-Object path)}
$before=Files $project;$before|ConvertTo-Json -Depth 6|Set-Content (Join-Path $records 'fixture-invalid-utf8-before.json') -Encoding UTF8

function Elements {
 $condition=New-Object Windows.Automation.PropertyCondition ([Windows.Automation.AutomationElement]::ProcessIdProperty),$p.Id
 return [Windows.Automation.AutomationElement]::RootElement.FindAll([Windows.Automation.TreeScope]::Descendants,$condition)
}
function Find-Id($Id) {
 $all=@(Elements|Where-Object {($_.Current.AutomationId -eq $Id -or $_.Current.AutomationId.EndsWith('.'+$Id)) -and $_.Current.ClassName -ne ''})
 if($all.Count -ne 1) {throw ('No unique actual control: '+$Id)};return $all[0]
}
function Await($Check,$Name) {$end=[DateTime]::UtcNow.AddSeconds(15);do {if(& $Check) {return};Start-Sleep -Milliseconds 100} while([DateTime]::UtcNow -lt $end);throw ('Observation deadline: '+$Name)}
function Assert-Foreground {[uint32]$owner=0;[SCForeground]::GetWindowThreadProcessId([SCForeground]::GetForegroundWindow(),[ref]$owner)|Out-Null;if($owner -ne $p.Id) {throw 'Foreground changed; keys refused'}}
function Keys($Keys) {Assert-Foreground;[Windows.Forms.SendKeys]::SendWait($Keys);Start-Sleep -Milliseconds 200}
function Focus-App {$p.Refresh();if(![SCForeground]::SetForegroundWindow($p.MainWindowHandle)) {throw 'Cannot focus owned app'};Start-Sleep -Milliseconds 300;Assert-Foreground}
function Button($Id) {$e=Find-Id $Id;if(!$e.Current.IsEnabled) {throw ('Disabled button: '+$Id)};([Windows.Automation.InvokePattern]$e.GetCurrentPattern([Windows.Automation.InvokePattern]::Pattern)).Invoke();Start-Sleep -Milliseconds 250}
function Menu($Name) {
 Focus-App;Keys '%e'
 $all=@(Elements|Where-Object {$_.Current.ControlType -eq [Windows.Automation.ControlType]::MenuItem -and $_.Current.Name.Contains($Name)})
 if($all.Count -ne 1 -or !$all[0].Current.IsEnabled) {throw ('No enabled menu item: '+$Name)}
 ([Windows.Automation.InvokePattern]$all[0].GetCurrentPattern([Windows.Automation.InvokePattern]::Pattern)).Invoke();Start-Sleep -Milliseconds 250;if(!$Name.StartsWith('Review retained')) {Keys '{ESC}'}
}
function Tree($Name) {
 $rows=@();foreach($e in (Elements)) {$c=$e.Current;$v=$null;$vp=$null;if($e.TryGetCurrentPattern([Windows.Automation.ValuePattern]::Pattern,[ref]$vp)) {$v=([Windows.Automation.ValuePattern]$vp).Current.Value};$rows+=@{name=$c.Name;id=$c.AutomationId;class=$c.ClassName;type=$c.ControlType.ProgrammaticName;enabled=$c.IsEnabled;value=$v;patterns=@($e.GetSupportedPatterns()|ForEach-Object {$_.ProgrammaticName})}}
 $rows|ConvertTo-Json -Depth 6|Set-Content (Join-Path $records ('uia-restart-'+$stamp+'-'+$Name+'.json')) -Encoding UTF8
}
function Snapshot($Name) {Copy-Item -LiteralPath (Join-Path $project 'project.json') -Destination (Join-Path $records ('project-restart-'+$stamp+'-'+$Name+'.json'));Tree $Name;Event $Name @{projectSha256=(Get-FileHash (Join-Path $project 'project.json') -Algorithm SHA256).Hash.ToLowerInvariant()}}
function Launch($Phase) {
 $script:p=Start-Process -FilePath (Join-Path $install 'soundcurrent-daw.exe') -ArgumentList '--language','en' -WorkingDirectory $install -PassThru -RedirectStandardOutput (Join-Path $records ('restart-'+$stamp+'-'+$Phase+'.stdout')) -RedirectStandardError (Join-Path $records ('restart-'+$stamp+'-'+$Phase+'.stderr'))
 $script:actualHandle=$p.Handle;$p.PriorityClass='BelowNormal'
 Await {$p.Refresh();return $p.MainWindowHandle -ne 0 -and !$p.HasExited} 'actual installed window'
 if($p.SessionId -eq 0 -or !$p.MainWindowTitle.StartsWith('SoundCurrent DAW')) {throw 'No interactive installed app'}
 $modules=@($p.Modules|ForEach-Object {@{name=$_.ModuleName;path=$_.FileName}})
 foreach($name in @('Qt6Core.dll','Qt6Gui.dll','Qt6Widgets.dll','sndfile.dll','qwindows.dll')) {$found=@($modules|Where-Object {$_.name -eq $name});if($found.Count -ne 1 -or !$found[0].path.StartsWith($install+'\',[StringComparison]::OrdinalIgnoreCase)) {throw ('Wrong installed module: '+$name)}}
 [IO.File]::WriteAllText((Join-Path $root 'main-pid.txt'),$p.Id)
 Event ('launch-'+$Phase) @{pid=$p.Id;startUtc=$p.StartTime.ToUniversalTime().ToString('o');sessionId=$p.SessionId;exe=$p.Path;sha256=(Get-FileHash $p.Path -Algorithm SHA256).Hash.ToLowerInvariant();modules=$modules;developerSdkUsed=$false;nativeAudioActivated=$false}

 Focus-App;Keys '^o';Start-Sleep -Milliseconds 500
 [Windows.Forms.Clipboard]::SetText($project);Keys '^l';Keys '^v';Keys '{ENTER}';Start-Sleep -Milliseconds 400
 $button=@(Elements|Where-Object {$_.Current.Name -eq 'Select Folder' -and $_.Current.ControlType -eq [Windows.Automation.ControlType]::Button -and !$_.Current.IsOffscreen})
 if($button.Count -ne 1) {throw 'No unique actual folder button'};$button[0].SetFocus();Keys '{ENTER}'
 Await {return (Find-Id 'clipStretchButton').Current.IsEnabled -or (Find-Id 'timelineClips').Current.IsEnabled} 'opened owned project'
 Start-Sleep -Milliseconds 500;Snapshot ('opened-'+$Phase)
}
function Scan($Phase) {
 Menu 'Review retained pitch/stretch renders'
 Await {return @(Elements|Where-Object {$_.Current.ControlType -eq [Windows.Automation.ControlType]::ListItem -and $_.Current.AutomationId.EndsWith('.stretchRecoveryList')}).Count -eq 1} 'specific retained job inventory'
 $list=Find-Id 'stretchRecoveryList';$list.SetFocus();Keys '{HOME}';Start-Sleep -Milliseconds 250;Tree ('scan-'+$Phase)
 $item=@(Elements|Where-Object {$_.Current.ControlType -eq [Windows.Automation.ControlType]::ListItem -and $_.Current.AutomationId.EndsWith('.stretchRecoveryList')})[0]
 Event ('inventory-'+$Phase) @{name=$item.Current.Name;reviewEnabled=(Find-Id 'reviewRetainedStretch').Current.IsEnabled}
 return $item.Current.Name
}
function Normal-Quit($Phase) {$start=$p.StartTime.ToUniversalTime().ToString('o');$normal=$p.CloseMainWindow();$exited=$p.WaitForExit(10000);Event ('quit-'+$Phase) @{pid=$p.Id;startUtc=$start;normalCloseRequested=$normal;actualExited=$exited;exitCode=$(if($exited){$p.ExitCode}else{$null});forced=$false};if(!$exited -or $p.ExitCode -ne 0) {throw 'Actual main did not quit normally'}}

try {
 Launch 'invalid-utf8';$inventory=Scan 'invalid-utf8'
 if(!$inventory.Contains('Invalid or missing files') -or (Find-Id 'reviewRetainedStretch').Current.IsEnabled) {throw 'Corrected ratio-only fixture admitted'}
 Event 'corrected-invalid-refused' @{pid=$p.Id;inventory=$inventory;sourceHead=$receipt.sourceHead;operation=$operation;utf8PathPreserved=$true;onlyRequestRatiosChanged=$true}
 (Find-Id 'stretchRecoveryDialog').SetFocus();Keys '{ESC}';Snapshot 'final-invalid-utf8';Normal-Quit 'invalid-utf8'
 $after=Files $project;$after|ConvertTo-Json -Depth 6|Set-Content (Join-Path $records 'fixture-invalid-utf8-after.json') -Encoding UTF8
 if(($before|ConvertTo-Json -Depth 6 -Compress) -ne ($after|ConvertTo-Json -Depth 6 -Compress)) {throw 'Corrected fixture mutated'}
 Event 'completed' @{sourceHead=$receipt.sourceHead;fixtureUnchanged=$true;playRequested=$false;newRenderRequested=$false;fullGoalComplete=$false}
 & (Join-Path $root 'collect.ps1') ('guards-corrected-'+$stamp+'.zip')
} catch {
 Event 'operator-failure' @{message=$_.Exception.Message;stack=$_.ScriptStackTrace;pid=$(if($p){$p.Id}else{$null});actualExited=$(if($p){$p.HasExited}else{$null})}
 try {Tree 'failure'; & (Join-Path $root 'collect.ps1') ('guards-corrected-failed-'+$stamp+'.zip')} catch {Write-Error $_ -ErrorAction Continue}
 throw
}
