from pathlib import Path
import json,zipfile,re,subprocess
root=Path('.cache/comp-protected-pair/pr194-protected-pair-review');load=lambda p:json.loads(p.read_text())
a=load(root/'audit.json');assert a['conclusion']=='success' and a['linuxAllChecksPassed'] and a['linuxInventoryCount']==197
assert all(j['conclusion']=='success' and not j['testFailures'] for j in a['jobs'])
for name,n in [('Linux synthetic shard 0',99),('Linux synthetic shard 1',98),('Windows desktop import and localization tests',27)]:
 j=next(j for j in a['jobs'] if j['name']==name);assert any(f'out of {n}' in x for x in j['testSummary'])
j=next(j for j in a['jobs'] if j['name']=='Windows native packet ownership tests');assert all(any(f'out of {n}' in x for x in j['testSummary']) for n in [23,93])
raw=(root/f"job-{j['id']}.log").read_text();assert re.search(r'comp-protected-span-render .*Passed',raw)
arts=load(root/'artifacts-api.json')['artifacts'];desktop=next(x for x in arts if x['name']=='windows-desktop-import-test-log')
with zipfile.ZipFile(root/f"artifact-{desktop['id']}.zip") as z:
 name=next(n for n in z.namelist() if re.search(r'/comp-repeat-ui-evidence/run-[^/]+/report.json$',n));d=json.loads(z.read(name));prefix=name[:-len('report.json')]
 observations=[json.loads(z.read(n)) for n in z.namelist() if n.startswith(prefix) and n.endswith('render-observation.json')]
 assert len(observations)==14 and all(not x['deadlineFailed'] for x in observations)
 assert d['actualAdoptions']==9 and d['mixedRetained']==3 and d['successfulAdoptionWorkers']==15
 cases=[c for r in d['reports'] for c in r['cases']];assert len(cases)==8 and all(c['assemblyCreditsReleased'] for c in cases)
 generations=[g for c in cases if c['case']==0 for g in c['generations']];assert len(generations)==9
 assert all(g['noAudioBeforeApply'] and g['undoRedoSaveReopen'] for g in generations)
 children=[w for g in generations for w in g['children']];assert len(children)==15 and all(w['reaped'] and w['exitCode']==0 for w in children)
 r=dict(adoptions=9,retainedMixed=3,reapedSuccessfulWorkers=15,failureAndCloseCases=5,observations=14,maximumStageMilliseconds=max(x['elapsedMilliseconds'] for x in observations),unchangedOuterSamples=sum(g['unchangedSamples'] for g in generations),liveExportSamples=sum(g['liveExportSamples'] for g in generations),legacyUnboundLedgerAssertionPassed=True,actualProjectCreditsReleasedQualified=False,actualNativeQtScreenshotsInspected=['case-96000/case-0/generation-1-review.png','case-96000/case-0/generation-2-applied.png'],installedAudio=False)
 (root/'native-repeat-audit.json').write_text(json.dumps(r,indent=2)+'\n')
reports=load(root/'selected-reports.json');native=[x for x in reports if x['artifact']=='windows-native-packet-unit-log']
core=next(x for x in native if '/audit.json' in x['path'] and 'comp-protected-span-' in x['path'])
worker=next(x for x in native if 'comp-protected-worker-' in x['path'])['report']
pair=next(x for x in native if 'comp-protected-pair-' in x['path'])['report']
c=core['report'];assert c['renders']==18 and c['exactMapQueries']==264 and c['bitExactProtectedSamples']==34560 and c['sourceAndExecutableStable']
assert len(c['refusals'])==12 and not c['processingQualityQualified']
assert worker['successfulSpanRenders']==6 and worker['completePcmSamples']==622848 and worker['protectedSamples']==12800
ws=[x for x in worker['processes'] if x['kind']=='worker'];ps=[x for x in pair['processes'] if x['kind']=='worker']
assert len(ws)==69 and sum(x['exitCode']==0 for x in ws)==6
assert len(ps)==8 and sum(x['exitCode']==0 for x in ps)==6 and pair['pairedCandidatesRecovered'] and pair['protectedPolicy']
assert all(not x.get('retirementPending',False) and not x.get('observationTimedOut',False) and not x.get('outputLimited',False) for x in ws+ps)
artifact=next(x for x in arts if x['name']=='windows-native-packet-unit-log')
import hashlib
verifiedCore=completed=0;completionHashes=[]
with zipfile.ZipFile(root/f"artifact-{artifact['id']}.zip") as z:
 prefix=core['path'][:-len('audit.json')]
 for n,f in c['files'].items():
  data=z.read(prefix+n);assert len(data)==f['bytes'] and hashlib.sha256(data).hexdigest()==f['sha256'];verifiedCore+=1
 for n in z.namelist():
  if n.startswith(('comp-protected-worker-evidence/','comp-protected-pair-evidence/')) and n.endswith('/complete.json'):
   d=json.loads(z.read(n));assert d['protocol']=='sc-comp-span-protected-v1' and d['complete']
   folder=n[:-len('complete.json')];wav=[k for k in z.namelist() if k.startswith(folder) and k.endswith('.wav')];assert len(wav)==1
   assert hashlib.sha256(z.read(wav[0])).hexdigest()==d['audioSha256'];completed+=1;completionHashes.append(d['audioSha256'])
assert completed>=12
nativeProtected=dict(coreRenders=18,coreMapQueries=264,coreProtectedSamples=34560,coreRefusals=12,coreManifestFilesVerified=verifiedCore,workerSuccesses=6,workerRefusals=63,workerCompletePcmSamples=622848,workerProtectedSamples=12800,pairWorkers=8,pairSuccesses=6,pairCancelOrDeadline=2,allObservedChildrenRetired=True,completedAudioFilesVerified=completed,detailedCoreCorpusRetained=True,processingQualityQualified=False,newAssemblyOrDesktopBankIncluded=False)
(root/'native-protected-audit.json').write_text(json.dumps(nativeProtected,indent=2)+'\n')
a['nativeFollowup']=dict(nativeCompTestsPassed=23,nativeOtherTestsPassed=93,desktopTestsPassed=27,wholeDesktopJob='success',wholeNativeJob='success',resourceEvidenceGap='Legacy repeated desktop ledger assertion observed an unused options ledger, not the actual project ledger. Corrected in 9d040f8; native rerun pending.',protected=nativeProtected,installedNativeAudioQualified=False)
(root/'audit.json').write_text(json.dumps(a,indent=2)+'\n')
bundle=next(x for x in arts if x['name']=='windows-preview-build-inputs')
subprocess.run(['python3','.cache/comp-transition-ui/audit-windows-bundle-15.py',str(root/f"artifact-{bundle['id']}.zip"),a['head'],str(root/'windows-bundle-audit.json')],check=True)
print(json.dumps(dict(run=a['run'],head=a['head'],native=a['nativeFollowup'],repeatedDesktop=r,allAvailableOriginalsRetainedAndAudited=True)))
