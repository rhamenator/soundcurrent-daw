from pathlib import Path
import hashlib,json,zipfile
repo=Path.cwd();ret=repo/'.cache/comp-protected-pair/pr194-protected-pair-review';out=repo/'tests/results/M2/2026-10-15-protected-comp-desktop';out.mkdir(parents=True,exist_ok=True)
files=[p for p in ret.rglob('*') if p.is_file() and p.suffix in ('.json','.log','.png')]
archive=out/'original-ci-review.zip';a=json.loads((ret/'audit.json').read_text());art=json.loads((ret/'artifacts-api.json').read_text())['artifacts'];native=next(x for x in art if x['name']=='windows-native-packet-unit-log');manifest=[]
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(files):z.write(p,p.relative_to(ret).as_posix())
 with zipfile.ZipFile(ret/f"artifact-{native['id']}.zip") as n:
  for path in n.namelist():
   if not path.endswith('/') and path.startswith(('comp-protected-span-evidence/','comp-protected-worker-evidence/','comp-protected-pair-evidence/')):
    b=n.read(path);target='native-protected/'+path;z.writestr(target,b);manifest.append(dict(originalArtifact=native['id'],originalPath=path,archivePath=target,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
 z.writestr('native-protected-files.json',json.dumps(manifest,indent=2)+'\n')
 for name in ['audit-ci.py','archive-ci.py','correct-ledger-audit.py']:z.write(repo/'.cache/comp-protected-ui'/name,'audit-tools/'+name)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for p in files:assert z.read(p.relative_to(ret).as_posix())==p.read_bytes()
 for item in manifest:
  b=z.read(item['archivePath']);assert len(b)==item['bytes'] and hashlib.sha256(b).hexdigest()==item['sha256']
index=dict(run=a['run'],head=a['head'],conclusion=a['conclusion'],archive=archive.name,bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),fullJobLogs=6,originalArtifacts=art,allOriginalArtifactZipsRetainedLocally=True,allOriginalArtifactBytesAndDigestsVerified=True,pngCount=a['pngCount'],linuxUniqueTests=197,linuxPartitionCompleteAndDisjoint=True,windowsDesktopTests=27,windowsNativeCompTests=23,windowsNativeOtherTests=93,nativeProtectedOriginalFiles=len(manifest),nativeProtectedAudit=json.loads((ret/'native-protected-audit.json').read_text()),nativeInstalledAudioQualified=False,fullDawParity=False)
(out/'original-ci-index.json').write_text(json.dumps(index,indent=2)+'\n');print(json.dumps({k:v for k,v in index.items() if k!='originalArtifacts'}))
