from pathlib import Path
import json
root=Path('.cache/comp-protected-pair/pr194-protected-pair-review')
p=root/'native-repeat-audit.json';r=json.loads(p.read_text());assert r.pop('assemblyCreditsReleased') is True
r['legacyUnboundLedgerAssertionPassed']=True;r['actualProjectCreditsReleasedQualified']=False
p.write_text(json.dumps(r,indent=2)+'\n')
p=root/'audit.json';a=json.loads(p.read_text());a['nativeFollowup']['resourceEvidenceGap']='Legacy repeated desktop ledger assertion observed an unused options ledger, not the actual project ledger. Corrected in 9d040f8; native rerun pending.'
p.write_text(json.dumps(a,indent=2)+'\n')
print('Corrected derived audit only; original CI files unchanged')
