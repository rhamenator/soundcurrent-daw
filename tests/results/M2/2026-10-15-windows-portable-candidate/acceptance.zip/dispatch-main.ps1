$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$root=Join-Path $env:USERPROFILE 'soundcurrent-portable-324';$out=Join-Path $root 'observed';$name='SoundCurrent-Owned-Portable-324-20261015'
$q=Get-Content -Raw (Join-Path $out 'qualification-terminal.json')|ConvertFrom-Json
if($q.exitCode -ne 0 -or $q.sourceCommit -ne '61bcaa3439ac0ec9a9856d893e5c0b10fee23e72') {throw 'Native helper qualification not complete'}
if(Get-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue) {throw 'Owned task already exists'}
$body=Get-Content -Raw (Join-Path $root 'main-once.ps1');$encoded=[Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($body))
$action=New-ScheduledTaskAction -Execute 'powershell.exe' -Argument ('-NoProfile -EncodedCommand '+$encoded)
$principal=New-ScheduledTaskPrincipal -UserId 'claude' -LogonType Interactive -RunLevel Limited
$settings=New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Minutes 1)
Register-ScheduledTask -TaskName $name -Action $action -Principal $principal -Settings $settings|Out-Null
Start-ScheduledTask -TaskName $name
@{taskName=$name;sourceCommit=$q.sourceCommit;scriptSha256=(Get-FileHash (Join-Path $root 'main-once.ps1') -Algorithm SHA256).Hash.ToLowerInvariant()}|ConvertTo-Json|Set-Content (Join-Path $out 'main-dispatch.json') -Encoding UTF8
