from pathlib import Path
import subprocess, json, shutil, hashlib, datetime
repo=Path.cwd();base=repo/'.cache/windows-portable-comp-324';original=repo/'.cache/installed-comp-323/app/project-été-Κиїв';target=base/'reverse-context-project-été-Κиїв'
assert not subprocess.check_output(['virsh','-c','qemu:///system','list','--name'],text=True).strip()
assert not target.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs={str(p.relative_to(original)):sha(p) for p in original.rglob('*') if p.is_file()}
shutil.copytree(original,target)
exe=repo/'.cache/take-preview-linux/build/sc-comp-repeat-fixture';digest=sha(exe)
worker=json.loads((repo/'.cache/installed-comp-323/windows-bundle/deploy-manifest.json').read_text())
worker=next(r['sha256'] for r in worker['files'] if r['path']=='sc-comp-span-worker.exe')
request=dict(root=str(target),workerSha256=worker,generation=1,protected=True,clocked=True,originalContext=True)
(base/'reverse-context-prepare-input.json').write_text(json.dumps(request,indent=2)+'\n')
proc=subprocess.Popen([str(exe),'prepare'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
try:out,err=proc.communicate(json.dumps(request),timeout=30)
except BaseException:
 proc.kill();out,err=proc.communicate();(base/'reverse-context-prepare-interrupted.stdout').write_text(out);(base/'reverse-context-prepare-interrupted.stderr').write_text(err);raise
(base/'reverse-context-prepare.stdout').write_text(out);(base/'reverse-context-prepare.stderr').write_text(err)
assert inputs=={str(p.relative_to(original)):sha(p) for p in original.rglob('*') if p.is_file()}
assert sha(exe)==digest
record=dict(pid=proc.pid,exitCode=proc.returncode,fixtureExe=str(exe),fixtureExeSha256=digest,originalFiles=len(inputs),originalUnchanged=True,originalHashes=inputs,workerSha256=worker,fixturePreparationOnly=True,windowsExecution=False)
if proc.returncode==0:record['prepared']=json.loads(out)
(base/'reverse-context-prepare.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='originalHashes'}));raise SystemExit(proc.returncode)
