from pathlib import Path
import subprocess,json,shutil,datetime
root=Path.cwd();base=root/'.cache/windows-portable-comp-324';bundle=root/'.cache/installed-comp-323/windows-bundle';native=base/'observed';producer=root/'.cache/installed-comp-323/windows-producer-checkout'
assert subprocess.check_output(['virsh','-c','qemu:///system','domstate','soundcurrent-win11-dev'],text=True).strip()=='shut off'
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
sequence='20261015144332';output=root/('.cache/p324-windows-package-'+sequence)
sbom=bundle/'sbom-root/sbom';sbom.mkdir(parents=True,exist_ok=False);shutil.copy2(bundle/'qtbase-6.12.0.spdx.json',sbom/'qtbase-6.12.0.spdx.json')
args={'deploy-zip':bundle/'deploy.zip','deploy-manifest':bundle/'deploy-manifest.json','build-inputs':bundle/'build-inputs.json','main-qualification':native/'main-qualification.json','qt-source':bundle/'dependency-source/qtbase-everywhere-src-6.12.0.tar.xz','sndfile-source':bundle/'dependency-source/libsndfile-1.2.2.tar.gz','runtime':bundle/'runtime-review/vc_redist.x64.exe','qt-sdk':sbom.parent,'output':output,'compiler-qualification':bundle/'compiler.json','build-collection':bundle/'collection.json','worker-qualification':native/'inspection-worker-qualification.json','media-worker-qualification':native/'media-worker-qualification.json','copy-worker-qualification':native/'copy-worker-qualification.json','stretch-worker-qualification':native/'stretch-worker-qualification.json','protected-warp-qualification':native/'protected-warp-qualification.json','sequence':sequence}
argv=['python3',str(producer/'tools/package_windows_preview.py'),*[v for k,p in args.items() for v in ['--'+k,str(p)]]]
r=dict(argv=argv,sequence=sequence,output=str(output),sourceHead=subprocess.check_output(['git','rev-parse','HEAD'],cwd=producer,text=True).strip(),cwd=str(producer),startedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(base/'windows-package-invocation.json').write_text(json.dumps(r,indent=2)+'\n')
with (base/'windows-package-run.log').open('x') as log:
 child=subprocess.Popen(argv,cwd=producer,stdout=log,stderr=subprocess.STDOUT);r['pid']=child.pid;r['exitCode']=child.wait()
r['endedUtc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(base/'windows-package-command.json').write_text(json.dumps(r,indent=2)+'\n');print('Windows package exit',r['exitCode']);raise SystemExit(r['exitCode'])
