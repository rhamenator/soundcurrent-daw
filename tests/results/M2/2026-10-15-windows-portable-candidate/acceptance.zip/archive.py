from pathlib import Path
import hashlib,json,zipfile
r=Path(__file__).resolve().parent;repo=r.parents[1];out=repo/'tests/results/M2/2026-10-15-windows-portable-candidate';out.mkdir(parents=True,exist_ok=True)
sha=lambda data:hashlib.sha256(data).hexdigest();files={}
for pattern in ['*.py','*.ps1','*.log','*.json','*.stdout','*.stderr']:
 for p in r.glob(pattern):files[p.name]=p.read_bytes()
files['native-observed.zip']=(r/'observed.zip').read_bytes()
package=repo/'.cache/p324-windows-package-20261015144332'
for n in ['receipt.json','SHA256SUMS','makensis.log']:files['package/'+n]=(package/n).read_bytes()
baseArchive=repo/'tests/results/M2/2026-10-15-installed-portable-comp/acceptance.zip'
baseManifest=repo/'tests/results/M2/2026-10-15-installed-portable-comp/manifest.json'
baseHash=json.loads(baseManifest.read_text())['sha256'];assert sha(baseArchive.read_bytes())==baseHash
source=repo/'.cache/installed-comp-323/app/project-été-Κиїв';target=r/'reverse-context-project-été-Κиїв';members={}
for p in target.rglob('*'):
 if not p.is_file():continue
 name=str(p.relative_to(target));data=p.read_bytes();v=dict(bytes=len(data),sha256=sha(data))
 if (source/name).is_file() and (source/name).read_bytes()==data:v['baseProjectFile']=name
 else:v['entry']='reverse-project/'+name;files[v['entry']]=data
 members[name]=v
reference=dict(baseArchive=str(baseArchive.relative_to(repo)),baseSha256=baseHash,baseProjectManifest='project-members.json',files=members)
files['reverse-project-members.json']=(json.dumps(reference,indent=2)+'\n').encode()
files['RECONSTRUCT.txt']=b'Reconstruct the base project using its project-members.json and hash-pinned predecessor. For each reverse-project-members.json file, use baseProjectFile from that reconstructed base, or entry from this archive. Verify every byte count and SHA-256. Only owned synthetic media; never overlay a user project. Requests are prepared, NOT executed on Windows.\n'
ci=r/'ci'
for pattern in ['*.json','*.log']:
 for p in ci.glob(pattern):files['ci/'+p.name]=p.read_bytes()
index={n:dict(bytes=len(b),sha256=sha(b)) for n,b in files.items()};files['payload-manifest.json']=(json.dumps(index,indent=2)+'\n').encode()
p=out/'acceptance.zip'
with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,b in files.items():z.writestr(n,b)
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 for n,v in index.items():assert sha(z.read(n))==v['sha256']
 for n,v in members.items():
  data=(source/v['baseProjectFile']).read_bytes() if 'baseProjectFile' in v else z.read(v['entry']);assert len(data)==v['bytes'] and sha(data)==v['sha256']
report=dict(archive=p.name,bytes=p.stat().st_size,sha256=sha(p.read_bytes()),entries=len(files),sourceHead='61bcaa3439ac0ec9a9856d893e5c0b10fee23e72',originalCiHead='d81edf36b4360b7798659ea14761b134c31d8195',reverseProjectFiles=len(members),reverseProjectReconstructionVerified=True,reverseWindowsExecution=False,initialProtectedFailureUnresolved=True,applicationBinariesIncluded=False,credentialsIncluded=False)
(out/'manifest.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
