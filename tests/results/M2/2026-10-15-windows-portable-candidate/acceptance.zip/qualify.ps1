$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
[Diagnostics.Process]::GetCurrentProcess().PriorityClass='BelowNormal'
$root=Join-Path $env:USERPROFILE 'soundcurrent-portable-324';$out=Join-Path $root 'observed';$payload=Join-Path $root 'payload';$source=Join-Path $root 'source'
$setup=Get-Content -Raw (Join-Path $out 'setup.json')|ConvertFrom-Json
if($setup.exitCode -ne 0) {throw 'Setup not qualified'}
$env:PATH=(Join-Path $payload 'deploy')+';'+(Join-Path $payload 'verification')+';'+$env:PATH
$commands=@()
function Invoke-Qualified([string]$name,[string[]]$arguments) {
 $watch=[Diagnostics.Stopwatch]::StartNew()
 & python @arguments 1> (Join-Path $out ($name+'.stdout')) 2> (Join-Path $out ($name+'.stderr'))
 $script:commands+=@{name=$name;arguments=$arguments;exitCode=$LASTEXITCODE;seconds=$watch.Elapsed.TotalSeconds}
 $script:commands|ConvertTo-Json -Depth 8|Set-Content (Join-Path $out 'qualification-commands.json') -Encoding UTF8
 if($LASTEXITCODE -ne 0) {throw ('Native qualification failed: '+$name)}
}
Invoke-Qualified 'helpers' @((Join-Path $payload 'qualify-helpers.py'))
Invoke-Qualified 'stretch-v4' @((Join-Path $source 'tests/stretch_worker_tests.py'),(Join-Path $payload 'deploy/sc-stretch-render-worker.exe'),(Join-Path $payload 'verification/sc-stretch-artifact-tests.exe'),'--qualification',(Join-Path $out 'stretch-worker-qualification.json'))
Invoke-Qualified 'protected-v5' @((Join-Path $source 'tests/protected_warp_worker_tests.py'),(Join-Path $payload 'deploy/sc-stretch-render-worker.exe'),(Join-Path $payload 'verification/sc-stretch-artifact-tests.exe'),(Join-Path $payload 'verification/sc-protected-warp-probe.exe'),'--qualification',(Join-Path $out 'protected-warp-qualification.json'))
@{exitCode=0;sourceCommit=(git -C $source rev-parse HEAD);sourceTree=(git -C $source rev-parse 'HEAD^{tree}');nativeAudio=$false;commands=$commands}|ConvertTo-Json -Depth 8|Set-Content (Join-Path $out 'qualification-terminal.json') -Encoding UTF8
