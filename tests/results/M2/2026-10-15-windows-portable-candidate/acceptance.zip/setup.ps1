$ErrorActionPreference='Stop'
[Diagnostics.Process]::GetCurrentProcess().PriorityClass='BelowNormal'
$root=Join-Path $env:USERPROFILE 'soundcurrent-portable-324'
if(Test-Path $root) {throw 'Owned qualification folder already exists'}
New-Item -ItemType Directory $root|Out-Null
$out=Join-Path $root 'observed';New-Item -ItemType Directory $out|Out-Null
try {
 Expand-Archive -LiteralPath (Join-Path $env:USERPROFILE 'soundcurrent-portable-324-inputs.zip') -DestinationPath (Join-Path $root 'payload')
 $payload=Join-Path $root 'payload'
 $signature=Get-AuthenticodeSignature (Join-Path $payload 'runtime-review/vc_redist.x64.exe')
 $hash=(Get-FileHash (Join-Path $payload 'runtime-review/vc_redist.x64.exe') -Algorithm SHA256).Hash.ToLowerInvariant()
 if($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Thumbprint -ne '1D77A9B9E8FE2075D9AD15123257FB90DB0DA4A1' -or $hash -ne '843068991daaa1f73ad9f6239bce4d0f6a07a51f18c37ea2a867e9beca71295c') {throw 'Reviewed runtime signature/hash differs'}
 $runtime=Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64'
 if($runtime.Installed -ne 1 -or $runtime.Version -ne 'v14.51.36247.0') {throw ('Required installed runtime differs: '+$runtime.Version)}
 @{alreadyInstalled=$true;version=$runtime.Version;installed=$runtime.Installed;sha256=$hash;signature=$signature.Status.ToString();signerThumbprint=$signature.SignerCertificate.Thumbprint}|ConvertTo-Json|Set-Content (Join-Path $out 'runtime-existing.json') -Encoding UTF8
 $source=Join-Path $root 'source'
 git clone --config core.autocrlf=true --filter=blob:none --no-checkout --depth 1 --branch backup/portable-render-history-2026-10-15 https://github.com/rhamenator/soundcurrent-daw.git $source
 if($LASTEXITCODE -ne 0) {throw 'Source clone failed'}
 git -C $source sparse-checkout set --no-cone '/*' '!/tests/results/'
 if($LASTEXITCODE -ne 0) {throw 'Source sparse inventory failed'}
 git -C $source checkout --detach 61bcaa3439ac0ec9a9856d893e5c0b10fee23e72
 if($LASTEXITCODE -ne 0) {throw 'Exact source checkout failed'}
 $inputs=Get-Content -Raw (Join-Path $payload 'build-inputs.json')|ConvertFrom-Json
 foreach($file in $inputs.files) {
  $found=(Get-FileHash (Join-Path $source $file.name) -Algorithm SHA256).Hash.ToLowerInvariant()
  if($found -ne $file.sha256) {throw ('Native source bytes differ: '+$file.name)}
 }
 $manifest=Get-Content -Raw (Join-Path $payload 'deploy-manifest.json')|ConvertFrom-Json
 foreach($file in $manifest.files) {
  $found=(Get-FileHash (Join-Path (Join-Path $payload 'deploy') $file.path) -Algorithm SHA256).Hash.ToLowerInvariant()
  if($found -ne $file.sha256) {throw ('Native deployment differs: '+$file.path)}
 }
 @{exitCode=0;sourceCommit=(git -C $source rev-parse HEAD);sourceTree=(git -C $source rev-parse 'HEAD^{tree}');sourceFilesVerified=$inputs.files.Count;deploymentFilesVerified=$manifest.files.Count;nativeAudio=$false}|ConvertTo-Json|Set-Content (Join-Path $out 'setup.json') -Encoding UTF8
} catch {
 @{exitCode=1;error=$_.Exception.Message}|ConvertTo-Json|Set-Content (Join-Path $out 'setup-failed.json') -Encoding UTF8
 throw
}
