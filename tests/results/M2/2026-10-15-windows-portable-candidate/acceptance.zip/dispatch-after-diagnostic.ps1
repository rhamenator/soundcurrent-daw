$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$r='C:/Users/claude/soundcurrent-portable-324';$o=$r+'/observed'
$v4=Get-Content -Raw ($o+'/stretch-worker-qualification.json')|ConvertFrom-Json
$v5=Get-Content -Raw ($o+'/protected-warp-qualification.json')|ConvertFrom-Json
if($v4.sourceCommit -ne '61bcaa3439ac0ec9a9856d893e5c0b10fee23e72' -or $v5.sourceCommit -ne $v4.sourceCommit) {throw 'Qualification source differs'}
@{exitCode=0;sourceCommit=$v4.sourceCommit;sourceTree=$v4.sourceTree;nativeAudio=$false;initialProtectedAttempt='Failed, traceback truncated by PowerShell ErrorAction Stop';protectedDiagnosticAttempt='Completed exit 0 with original limits; full stdout/stderr retained on host';initialFailureUnexplained=$true}|ConvertTo-Json|Set-Content ($o+'/qualification-terminal.json') -Encoding UTF8
& ([ScriptBlock]::Create((Get-Content -Raw ($r+'/dispatch-main.ps1'))))
