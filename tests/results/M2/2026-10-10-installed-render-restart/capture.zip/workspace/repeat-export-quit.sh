set -eu
cd /home/preview
xdotool mousemove 450 161 click 1 key ctrl+a type --clearmodifiers /home/preview/reopened-mix.wav
xdotool mousemove 721 492 click 1
n=0
while test ! -f reopened-mix.wav; do test "$n" -lt 200; n=$((n+1)); sleep .02; done
sleep .3
import -window root reopened-exported.png
xdotool windowfocus "$(head -n1 window-id.txt)" key ctrl+q
