set -eu
cd /home/preview
xdotool windowfocus "$(head -n1 recovery-id.txt)"
xdotool mousemove 400 122 click 1
sleep .2
import -window root ready-selected.png
xdotool mousemove 480 466 click 1
sleep .8
xdotool search --onlyvisible --name "^Clip pitch and stretch" > dialog-id.txt
import -window root review-restored.png
