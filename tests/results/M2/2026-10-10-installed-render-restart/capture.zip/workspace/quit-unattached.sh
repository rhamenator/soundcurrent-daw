set -eu
cd /home/preview
xdotool windowfocus "$(head -n1 dialog-id.txt)"
xdotool mousemove 820 658 click 1
xdotool windowfocus "$(head -n1 window-id.txt)" key ctrl+q
