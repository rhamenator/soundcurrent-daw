set -eu
cd /home/preview
xdotool windowfocus "$(head -n1 window-id.txt)"
xdotool mousemove 120 9 click 1
sleep .2
import -window root edit-menu-2.png
