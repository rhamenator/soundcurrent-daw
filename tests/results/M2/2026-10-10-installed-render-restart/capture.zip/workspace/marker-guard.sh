set -eu
cd /home/preview
xdotool windowfocus "$(head -n1 dialog-id.txt)"
xdotool mousemove 700 274 click 1 key F2 ctrl+a type --clearmodifiers 6145
xdotool key Return
sleep .2
import -window root changed-marker-guard.png
xdotool mousemove 700 274 click 1 key F2 ctrl+a type --clearmodifiers 6144
xdotool key Return
sleep .2
import -window root restored-marker-guard.png
