set -eu
cd /home/preview
xdotool windowfocus "$(head -n1 window-id.txt)"
xdotool mousemove 120 9 click 1
xdotool mousemove 260 97 click 1
sleep .7
xdotool search --onlyvisible --name "^Retained pitch/stretch renders" > recovery-id.txt
xdotool mousemove 400 122 click 1
sleep .2
import -window root attached-selected.png
xdotool mousemove 763 466 click 1
xdotool windowfocus "$(head -n1 window-id.txt)" key ctrl+shift+e
sleep .2
import -window root export-reopened.png
