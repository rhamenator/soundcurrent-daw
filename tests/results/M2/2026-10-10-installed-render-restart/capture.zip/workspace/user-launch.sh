#!/bin/sh
set -eu
cd /home/preview
export DISPLAY=:94 XDG_RUNTIME_DIR=/home/preview/run XDG_CONFIG_HOME=/home/preview/config
id > identity.txt
cat /proc/self/status > user-process-status.txt
test ! -e /dev/snd
pipewire -c /home/preview/pipewire.conf > pipewire.log 2>&1 &
pw_pid=$!
Xvfb :94 -screen 0 1280x720x24 -nolisten tcp > xvfb.log 2>&1 &
xvfb_pid=$!
app_pid=
cleanup() {
  if test -n "$app_pid"; then kill "$app_pid" 2>/dev/null || true; fi
  kill "$pw_pid" "$xvfb_pid" 2>/dev/null || true
}
trap cleanup EXIT
sleep 1
pw-dump > graph-before.json
for stage in 1 2 3 4 5; do
  if test "$stage" -gt 1; then
    n=0
    while test ! -f "start-$stage"; do
      test ! -f finish
      test "$n" -lt 18000
      n=$((n+1)); sleep .1
    done
  fi
  /usr/bin/soundcurrent-daw --language en /home/preview/project-été-Κиїв > "application-$stage.log" 2>&1 &
  app_pid=$!
  echo "$app_pid" > "app-pid-$stage.txt"
  cat "/proc/$app_pid/status" > "app-status-$stage.txt"
  sleep 2
  xdotool search --onlyvisible --name '^SoundCurrent DAW' > window-id.txt
  import -window root "opened-$stage.png"
  touch "ready-$stage"
  set +e
  wait "$app_pid"
  result=$?
  set -e
  app_pid=
  echo "$result" > "exit-$stage.txt"
  pw-dump > "graph-after-$stage.json"
  touch "closed-$stage"
  test "$result" -eq 0
done
