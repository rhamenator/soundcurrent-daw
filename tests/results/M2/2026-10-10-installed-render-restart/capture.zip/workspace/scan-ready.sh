set -eu
cd /home/preview
xdotool mousemove 260 97 click 1
sleep 1
xdotool search --onlyvisible --name "^Retained pitch/stretch renders" > recovery-id.txt
import -window root recovered-ready.png
