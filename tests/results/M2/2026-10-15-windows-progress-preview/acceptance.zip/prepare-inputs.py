from pathlib import Path
import json,zipfile,hashlib
r=Path(__file__).resolve().parent;old=r.parent/'windows-portable-comp-324';head='b5dc2568dbf0e1e623dbaa7d42dcd38fd1eed3ab';tree='77930c033f8bd409142731aa9d046154ed83f0f8'
for name in ['setup.ps1','qualify-helpers.py','main-once.ps1','dispatch-main.ps1','collect.ps1']:
 s=(old/name).read_text().replace('soundcurrent-portable-324','soundcurrent-progress-332').replace('SoundCurrent-Owned-Portable-324','SoundCurrent-Owned-Progress-332').replace('61bcaa3439ac0ec9a9856d893e5c0b10fee23e72',head).replace('2063a1e2778eb855d789516e61f1188869d86a63',tree)
 s=s.replace("$runtime.Version -ne 'v14.51.36247.0'","[version]$runtime.Version.TrimStart('v') -ne [version]'14.51.36247.0'")
 s=s.replace('backup/portable-render-history-2026-10-15','codex/windows-rendered-comp-handles')
 (r/name).write_text(s)
b=r/'windows-bundle';names=['build-inputs.json','deploy-manifest.json','runtime-review/vc_redist.x64.exe']
files={n:b/n for n in names}
for sub in ['deploy','verification']:
 for p in (b/sub).rglob('*'):
  if p.is_file():files[p.relative_to(b).as_posix()]=p
files['qualify-helpers.py']=r/'qualify-helpers.py'
a=r/'soundcurrent-progress-332-inputs.zip';assert not a.exists()
with zipfile.ZipFile(a,'x',zipfile.ZIP_DEFLATED) as z:
 for n,p in files.items():z.write(p,n)
with zipfile.ZipFile(a) as z:assert z.testzip() is None
report=dict(sourceCommit=head,zipBytes=a.stat().st_size,zipSha256=hashlib.file_digest(a.open('rb'),'sha256').hexdigest(),members=len(files))
(r/'inputs.json').write_text(json.dumps(report,indent=2)+'\n');print(report)
