from pathlib import Path
import subprocess,json,hashlib
r=Path(__file__).resolve().parent;repo=r.parents[1];bundle=r/'windows-bundle';producer=r/'windows-producer-checkout';head='b5dc2568dbf0e1e623dbaa7d42dcd38fd1eed3ab';assert not producer.exists()
for cmd in [['git','clone','--shared','--no-checkout',str(repo),str(producer)],['git','-C',str(producer),'config','core.autocrlf','true'],['git','-C',str(producer),'sparse-checkout','set','--no-cone','/*','!/tests/results/'],['git','-C',str(producer),'checkout','--detach',head]]:subprocess.run(cmd,check=True)
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();collection=load(bundle/'collection.json');inputs=load(bundle/'build-inputs.json');terminal=load(bundle/'terminal.json')
assert inputs['sourceCommit']==collection['sourceCommit']==head and terminal['exitCode']==0
assert collection['sourceInputsUnchanged'] and collection['productDependenciesQualified'] and not collection['productDependencyMismatches']
assert inputs['sourceTree']==collection['sourceTree']==subprocess.check_output(['git','rev-parse',head+'^{tree}'],cwd=repo,text=True).strip()
for row in inputs['files']:assert sha(producer/row['name'])==row['sha256'],row['name']
for name,row in collection['deploymentFiles'].items():
 p=bundle/'deploy'/name;assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],name
assert not subprocess.check_output(['git','status','--porcelain'],cwd=producer,text=True).strip()
out=dict(sourceHead=head,sourceTree=inputs['sourceTree'],nativeInputFiles=len(inputs['files']),deploymentFiles=len(collection['deploymentFiles']),allNativeInputAndDeploymentHashesMatch=True,localWindowsExecution=False,installerPrepared=False,nativeArtifact=11994639528,producerCheckout=str(producer),coreAutocrlf=True)
(r/'windows-input-verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
