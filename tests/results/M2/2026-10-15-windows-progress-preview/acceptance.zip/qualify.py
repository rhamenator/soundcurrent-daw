from pathlib import Path
import subprocess,json,os,time,sys
r=Path.home()/'soundcurrent-progress-332';out=r/'observed';source=r/'source';payload=r/'payload'
setup=json.loads((out/'setup.json').read_text(encoding='utf-8-sig'));assert setup['exitCode']==0
assert setup['sourceCommit']=='b5dc2568dbf0e1e623dbaa7d42dcd38fd1eed3ab'
env=dict(os.environ);env['PATH']=str(payload/'deploy')+';'+str(payload/'verification')+';'+env['PATH']
worker=payload/'deploy/sc-stretch-render-worker.exe';artifact=payload/'verification/sc-stretch-artifact-tests.exe'
commands=[('helpers',[payload/'qualify-helpers.py']),('stretch-v4',[source/'tests/stretch_worker_tests.py',worker,artifact,'--qualification',out/'stretch-worker-qualification.json']),('protected-v5',[source/'tests/protected_warp_worker_tests.py',worker,artifact,payload/'verification/sc-protected-warp-probe.exe','--qualification',out/'protected-warp-qualification.json'])]
records=[]
for name,args in commands:
 start=time.monotonic();argv=[sys.executable,*map(str,args)]
 with (out/(name+'.stdout')).open('xb') as stdout,(out/(name+'.stderr')).open('xb') as stderr:
  p=subprocess.Popen(argv,env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS);code=p.wait()
 records.append(dict(name=name,arguments=argv,pid=p.pid,exitCode=code,seconds=time.monotonic()-start))
 (out/'qualification-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 if code:raise SystemExit(code)
report=dict(exitCode=0,sourceCommit=setup['sourceCommit'],sourceTree=setup['sourceTree'],nativeAudio=False,commands=records)
(out/'qualification-terminal.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
