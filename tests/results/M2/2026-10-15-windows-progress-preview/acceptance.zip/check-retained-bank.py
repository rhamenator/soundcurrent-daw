from pathlib import Path
import subprocess,json,time,yaml,os
r=Path(__file__).resolve().parent;repo=r.parents[1];assert not (repo/'build').exists()
steps=yaml.safe_load((repo/'.github/workflows/ci.yml').read_text())['jobs']['linux-retained-evidence']['steps'][1:]
records=[];out=r/'retained-bank';out.mkdir(exist_ok=False)
env=dict(os.environ,QT_QPA_PLATFORM='offscreen');start=time.monotonic()
for step in steps:
 for line in step['run'].splitlines():
  args=line.split()
  if not args:continue
  if args[:2]==['git','fetch']:
   subprocess.run(['git','cat-file','-e',args[-1]+'^{commit}'],cwd=repo,check=True);records.append(dict(command=line,alreadyPresentCommitVerified=True));continue
  assert args[0]=='python3'
  log=out/f'{len(records):02d}.log';before=time.monotonic()
  with log.open('x') as f:p=subprocess.run(args,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT)
  records.append(dict(command=line,exitCode=p.returncode,seconds=time.monotonic()-before,log=log.name))
  (r/'retained-bank-qualification.json').write_text(json.dumps(dict(commands=records,complete=False),indent=2)+'\n')
  if p.returncode:raise SystemExit(p.returncode)
report=dict(commands=records,complete=True,pythonInvocations=sum('exitCode' in a for a in records),noRootBuildDirectory=True,seconds=time.monotonic()-start,nativeAudio=False)
(r/'retained-bank-qualification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='commands'}))
