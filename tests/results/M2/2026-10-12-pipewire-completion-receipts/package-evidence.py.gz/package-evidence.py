from pathlib import Path
import gzip,hashlib,json,subprocess
r=Path('.cache/pipewire-completion-receipts');d=Path('tests/results/M2/2026-10-12-pipewire-completion-receipts');d.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();f=json.loads((r/'frozen-inputs.json').read_text());members={}
for x in f['selectedInputs']:assert sha(Path(x['path']).read_bytes())==x['checkoutSha256']
def add(name,b):
 z=gzip.compress(b,mtime=0);p=d/(name+'.gz');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z);members[name+'.gz']={'bytes':len(z),'sha256':sha(z),'originalBytes':len(b),'originalSha256':sha(b)}
for name in ['frozen-inputs.json','source-delta.diff','configure.log','build.log','current-build.log','tests.log','native-build.log','private-pipewire.conf','recording-owned-runtime.log','recording-owned-runtime.json','recording-owned-wrapper.log','recording-owned-daemon.log','run-owned-recording.py','windows-qualification.json','windows-qualification.log','qualify-windows.py','freeze-inputs.py','pr165-live-run.json','pr165-live-jobs.json','plan.md','retain165.py','package-evidence.py']:
 add(name,(r/name).read_bytes())
for p in r.glob('windows-compile-*.log'):add(p.name,p.read_bytes())
for p in (r/'initial-build-failure').iterdir():add('initial-build-failure/'+p.name,p.read_bytes())
for n in ['CMakeCache.txt','Testing/Temporary/LastTest.log']:add('release/'+n,(r/'release'/n).read_bytes())
add('release/generated-commands.log',subprocess.check_output(['ninja','-C',str(r/'release'),'-t','commands']))
outputs={p.name:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in list((r/'release').glob('*.a'))+list((r/'release').glob('sc-*-tests'))+list((r/'release').glob('sc-*-fixture')) if p.is_file()};add('local-build-output-hashes.json',json.dumps(outputs,indent=2).encode())
summary={'source':f['source'],'tree':f['tree'],'inputs':len(f['selectedInputs']),'release':{'tests':4,'passed':4,'seconds':2.49},'currentSanitizer':'pending','windows':json.loads((r/'windows-qualification.json').read_text()),'privatePipeWire':{'sdk':'1.6.2','rawFrames':99072,'monitorSinkFrames':8192,'captureReceipts':387,'renderReceipts':408,'callbackAllocateFreeLock':0,'durableReopen':True,'physical':False},'originalPr165':{'run':38321227921,'state':'live at retained observation; original terminal still required'},'oldFailures':'local clock rejection/PR164owner/PR163pool pressure unresolved; no causal fix claim','scope':'completion and clock diagnostics, not controller/UI/verified alignment/full parity','payload':'text/log/config/metadata/hash only; no binary/audio','members':members}
(d/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for name,row in members.items():
 b=(d/name).read_bytes();assert sha(b)==row['sha256'];raw=gzip.decompress(b);assert sha(raw)==row['originalSha256'] and len(raw)==row['originalBytes']
print('Verified',len(members),'evidence members; source inputs unchanged')
