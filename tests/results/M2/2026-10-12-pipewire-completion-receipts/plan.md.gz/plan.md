# Completion receipts qualification

Source branch codex/pipewire-completion-receipts from d7e369d.
Previous goal turn PROGRESS: state/code/evidence/backups changed; full scope ACTIVE.

Implementation: retain first successful final native return before publishing complete.
Later callback receipts and lastContent remain independent original facts.
Inspector streams existing hashed render log and captures first allQueued/finalContent
receipt including generation and sequence; current terminal claims must exactly
match canonical native receipt bytes. Uncommitted tails never supply completion.
Schema1.1 adds this receipt and original clock lane faults/counts;1.0 retains strict
old field sets and conservative legacy validation, with absent new facts preserved.
No queue slots/cadence/deadline changes or inferred audible drain/alignment.

Tests: actual render late EOF/extra callback, actual journal checkpoint/tail exclusion,
owner durable reopen/clock counts, adjusted synthetic terminal metadata with silent
final/later callback and mutated native return refusal; state exact rejected clock
reading/widths/counts/legacy version/refusal plus four actual publication crashes.

Fresh Release build session46068 (j1/nice15/ionice2:7). Old caches read-only.
Original PR165 run38321227921 live at start, four jobs; must retain terminal before
correction. Extra tests above do not explain original local clock or Windows owner
rejection/PR163 pool pressure.
