$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$root=Join-Path $env:USERPROFILE 'soundcurrent-batched-338';$out=Join-Path $root 'observed';$name='SoundCurrent-Owned-Batched-338-20261015'
$main=Get-Content -Raw (Join-Path $out 'main-qualification.json')|ConvertFrom-Json
if(!$main.normalClose -or $main.forcedRetirement -or $main.exitCode -ne 0 -or $main.sessionId -le 0) {throw 'Native main did not close normally'}
$active=@(Get-CimInstance Win32_Process|Where-Object {$_.ExecutablePath -and $_.ExecutablePath.StartsWith($root,[StringComparison]::OrdinalIgnoreCase)})
if($active.Count -ne 0) {throw 'Owned deployment process still running'}
$task=Get-ScheduledTask -TaskName $name
if($task.State -eq 'Running') {throw 'Interactive task still running'}
Unregister-ScheduledTask -TaskName $name -Confirm:$false
@{ownedProcessesRemaining=$active.Count;ownedTaskRemoved=$true;nativeAudio=$false}|ConvertTo-Json|Set-Content (Join-Path $out 'retirement.json') -Encoding UTF8
$archive=Join-Path $env:USERPROFILE 'soundcurrent-batched-338-observed.zip'
if(Test-Path $archive) {throw 'Evidence archive already exists'}
Compress-Archive -Path (Join-Path $out '*') -DestinationPath $archive
@{bytes=(Get-Item $archive).Length;sha256=(Get-FileHash $archive -Algorithm SHA256).Hash.ToLowerInvariant()}|ConvertTo-Json
