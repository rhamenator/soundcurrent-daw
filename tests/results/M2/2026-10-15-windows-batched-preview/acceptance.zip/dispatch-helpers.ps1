$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
[Diagnostics.Process]::GetCurrentProcess().PriorityClass='BelowNormal'
& python.exe (Join-Path $env:USERPROFILE 'soundcurrent-batched-338/qualify.py')
exit $LASTEXITCODE
