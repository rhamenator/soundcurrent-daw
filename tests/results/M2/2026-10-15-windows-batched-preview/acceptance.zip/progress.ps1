$ProgressPreference='SilentlyContinue'
$r=Join-Path $env:USERPROFILE 'soundcurrent-batched-338/observed'
Get-Content (Join-Path $r 'setup.json')
if(Test-Path (Join-Path $r 'qualification-commands.json')){Get-Content (Join-Path $r 'qualification-commands.json')}
if(Test-Path (Join-Path $r 'qualification-terminal.json')){Get-Content (Join-Path $r 'qualification-terminal.json')}
if(Test-Path (Join-Path $r 'main-terminal.json')){Get-Content (Join-Path $r 'main-terminal.json')}
