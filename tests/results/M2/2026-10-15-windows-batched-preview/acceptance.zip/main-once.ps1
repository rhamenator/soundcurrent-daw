$ErrorActionPreference='Stop'
$root=Join-Path $env:USERPROFILE 'soundcurrent-batched-338'
$out=Join-Path $root 'observed'
$payload=Join-Path $root 'payload'
$env:PATH=(Join-Path $payload 'deploy')+';'+$env:PATH
$env:QT_QPA_PLATFORM='windows'
Remove-Item Env:\QT_STYLE_OVERRIDE -ErrorAction SilentlyContinue
$exe=Join-Path $payload 'deploy/soundcurrent-daw.exe'
Add-Type -AssemblyName System.Drawing
Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public class SC319Window { [StructLayout(LayoutKind.Sequential)] public struct RECT {public int Left,Top,Right,Bottom;} [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h,out RECT r); }'
$watch=[Diagnostics.Stopwatch]::StartNew()
$p=Start-Process -FilePath $exe -ArgumentList '--language','en' -WorkingDirectory $root -PassThru -RedirectStandardOutput (Join-Path $out 'main.stdout') -RedirectStandardError (Join-Path $out 'main.stderr')
$handle=$p.Handle
$p.PriorityClass='BelowNormal'
$record=[ordered]@{exeBytes=(Get-Item $exe).Length;nativeAudioActivated=$false;pid=$p.Id;exeSha256=(Get-FileHash $exe -Algorithm SHA256).Hash.ToLowerInvariant();sourceCommit='97e9ecdc32cfaddca03e4c8df9829fbdcb68c0aa';sourceTree='c67ab640e8210624700807aa641a98979f687855';styleOverride=$false;nativeAudio=$false;seconds=$null;windowHandle=0;title='';sessionId=$p.SessionId;normalClose=$false;forcedRetirement=$false;exitCode=$null}
try {
 $until=[DateTime]::UtcNow.AddSeconds(20)
 do {$p.Refresh();if($p.HasExited -or $p.MainWindowHandle -ne 0) {break};Start-Sleep -Milliseconds 100} while([DateTime]::UtcNow -lt $until)
 $record.windowHandle=$p.MainWindowHandle.ToInt64();$record.title=$p.MainWindowTitle
 if(!$p.HasExited -and $record.windowHandle -ne 0) {
  Start-Sleep -Milliseconds 1500
 $rect=New-Object SC319Window+RECT
 if(![SC319Window]::GetWindowRect($p.MainWindowHandle,[ref]$rect)) {throw 'Owned window rectangle unavailable'}
 $width=$rect.Right-$rect.Left;$height=$rect.Bottom-$rect.Top
 if($width -le 0 -or $width -gt 5120 -or $height -le 0 -or $height -gt 2160) {throw 'Unexpected owned window extent'}
 $bitmap=New-Object Drawing.Bitmap($width,$height);$graphics=[Drawing.Graphics]::FromImage($bitmap)
 try {$graphics.CopyFromScreen($rect.Left,$rect.Top,0,0,$bitmap.Size);$bitmap.Save((Join-Path $out 'main-window.png'),[Drawing.Imaging.ImageFormat]::Png)} finally {$graphics.Dispose();$bitmap.Dispose()}
 $record['windowWidth']=$width;$record['windowHeight']=$height
 $record.normalClose=$p.CloseMainWindow()
  if(!$p.WaitForExit(5000)) {$p.Kill();$record.forcedRetirement=$true;$p.WaitForExit(5000)|Out-Null}
 } elseif(!$p.HasExited) {
  $record.modules=@($p.Modules|ForEach-Object {$_.ModuleName})
  $record.cpuSeconds=$p.TotalProcessorTime.TotalSeconds
  $p.Kill();$record.forcedRetirement=$true;$p.WaitForExit(5000)|Out-Null
 }
 $p.Refresh();$record.exitCode=$p.ExitCode
} finally {
 if(!$p.HasExited) {$p.Kill();$p.WaitForExit(5000)|Out-Null;$record.forcedRetirement=$true}
 $record.seconds=$watch.Elapsed.TotalSeconds
 $record['executable_sha256']=@{'sc-comp-span-worker.exe'=(Get-FileHash (Join-Path $payload 'deploy/sc-comp-span-worker.exe') -Algorithm SHA256).Hash.ToLowerInvariant()}
 $record|ConvertTo-Json -Depth 5|Set-Content (Join-Path $out 'main-terminal.json') -Encoding UTF8
 if($record.normalClose -and !$record.forcedRetirement -and $record.exitCode -eq 0) {$record|ConvertTo-Json -Depth 5|Set-Content (Join-Path $out 'main-qualification.json') -Encoding UTF8}
}
