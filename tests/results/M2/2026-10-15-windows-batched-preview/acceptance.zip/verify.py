from pathlib import Path
import json,hashlib,subprocess
r=Path(__file__).resolve().parent;load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));head='97e9ecdc32cfaddca03e4c8df9829fbdcb68c0aa'
setup=load(r/'observed/setup.json');terminal=load(r/'observed/qualification-terminal.json');main=load(r/'observed/main-qualification.json');bundle=load(r/'windows-bundle/collection.json')
assert setup['exitCode']==terminal['exitCode']==main['exitCode']==0
assert setup['sourceCommit']==terminal['sourceCommit']==main['sourceCommit']==bundle['sourceCommit']==head
assert main['normalClose'] and not main['forcedRetirement'] and main['sessionId']>0
assert main['exeSha256']==bundle['deploymentFiles']['soundcurrent-daw.exe']['sha256']
assert main['executable_sha256']['sc-comp-span-worker.exe']==bundle['deploymentFiles']['sc-comp-span-worker.exe']['sha256']
assert all(c['exitCode']==0 for c in terminal['commands']) and len(terminal['commands'])==3
assert load(r/'observed/retirement.json')['ownedProcessesRemaining']==0 and load(r/'observed/retirement.json')['ownedTaskRemoved']
assert load(r/'cleanup.json')['allVmsOff'] and not subprocess.check_output(['virsh','list','--name'],text=True).strip()
assert 'FileNotFoundError' in (r/'helpers-dispatch.log').read_text() and 'setup.json' in (r/'helpers-dispatch.log').read_text()
ci=load(r/'ci/retention.json');assert ci['conclusion']=='success' and len(ci['jobs'])==15 and all(j['conclusion']=='success' for j in ci['jobs'])
assert ci['head']==head and ci['allFullLogsRetained'] and ci['allAvailableOriginalArchivesRetained']
inv=load(r/'windows-input-verification.json');assert inv['allNativeInputAndDeploymentHashesMatch'] and inv['nativeInputFiles']==setup['sourceFilesVerified']==1810
package=Path(load(r/'windows-package-invocation.json')['output']);receipt=load(package/'receipt.json');assert load(r/'windows-package-command.json')['exitCode']==0
source=load(r/'source-archive-verification.json')[0];assert source['sourceHead']==head and source['files']==8101 and source['completeTrackedMembership'] and source['gzipCrcVerified']
for n,item in receipt['artifacts'].items():
 p=package/n
 assert p.stat().st_size==item['bytes'],n
 if n.endswith('-source.tar.gz'):
  assert source['bytes']==item['bytes'] and source['sha256']==item['sha256'],n
 else:assert hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==item['sha256'],n
report=dict(passed=True,sourceHead=head,nativeMainNormalClose=True,nativeMainExitCode=main['exitCode'],nativeHelperGroupsPassed=3,initialDispatchOrderingFailureRetained=True,originalCiRun=ci['run'],originalCiJobs=15,originalCiArtifacts=len(ci['artifacts']),allOriginalCiRetained=True,nativeInputFiles=1810,sourceArchiveFiles=8101,installerPrepared=True,installerTested=False,installedWindowsPreviewChanged=False,allVmsOff=True,physicalAudio=False)
(r/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
