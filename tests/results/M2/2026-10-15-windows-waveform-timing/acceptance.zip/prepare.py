from pathlib import Path
import json, shutil, secrets, hashlib, subprocess, os
r=Path(__file__).resolve().parent;old=r.parent/'windows-installed-waveform-354';older=r.parent/'windows-installed-timing-340';iso=r/'iso';iso.mkdir(exist_ok=False)
for n in ['receipt.json','project.zip']:shutil.copyfile(old/'iso'/n,iso/n)
shutil.copyfile(old/'original-project.json',r/'original-project.json')
s=(older/'iso/begin.ps1').read_text(encoding='utf-8-sig').replace('SoundCurrent-Installed-340','SoundCurrent-Installed-355').replace('SoundCurrent-Installed-339','SoundCurrent-Installed-354').replace('setup-340.zip','setup-355.zip')
(iso/'begin.ps1').write_text(s,encoding='utf-8-sig')
shutil.copyfile(older/'iso/begin.cmd',iso/'begin.cmd')
shutil.copyfile(old/'next-workflow-355-draft.ps1',iso/'workflow.ps1')
for n in ['collect.ps1','end.ps1']:(iso/n).write_text((old/'iso'/n).read_text(encoding='utf-8-sig').replace('354','355'),encoding='utf-8-sig')
key=secrets.token_hex(32)
for p,v in [(r/'receiver-private.json',dict(ip='192.168.122.4',key=key)),(iso/'private-transport.json',dict(key=key))]:
 p.write_text(json.dumps(v));p.chmod(0o600)
for n in ['receiver.py','extract.py']:shutil.copyfile(old/n,r/n)
v=(old/'verify-original-timing-gates.py').read_text().replace('retired-354','retired-355').replace("setup['installerInvoked']", "not setup['installerInvoked'] and setup['existingInstallation']")
(r/'verify.py').write_text(v)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(iso/'project.zip')=='097aae7426e25be68bfc54ec40056af99710e893e7b9fd44aff9ceb2d6f73eea'
receipt=json.loads((iso/'receipt.json').read_text());assert receipt['sourceHead']=='f2f9f7c8916e34582db9f289f62bda2019d1c330' and len(receipt['payload'])==66
subprocess.run(['genisoimage','-quiet','-J','-r','-o',str(r/'private.iso'),str(iso)],check=True)
(r/'private.iso').chmod(0o600)
report=dict(sourceHead=receipt['sourceHead'],existingInstallationOnly=True,projectSha256=sha(iso/'project.zip'),isoSha256=sha(r/'private.iso'),files={n:sha(iso/n) for n in ['begin.ps1','workflow.ps1','end.ps1','collect.ps1','receipt.json']})
(r/'prepared-inputs.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
