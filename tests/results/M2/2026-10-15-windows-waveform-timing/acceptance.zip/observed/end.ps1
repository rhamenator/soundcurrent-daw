﻿$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$root=Join-Path $env:USERPROFILE 'SoundCurrent-Installed-355'
$r=Get-Content -Raw (Join-Path $root 'receipt.json')|ConvertFrom-Json
$install=Join-Path $env:LOCALAPPDATA ('Programs\SoundCurrent DAW Preview\'+$r.sequence+'-'+$r.sourceHead.Substring(0,12))
if((Get-CimInstance Win32_ComputerSystemProduct).UUID.ToLowerInvariant() -ne '670168f5-4e3f-4e7f-b218-3583db31f0f8'){throw 'Wrong clone'}
$active=@(Get-CimInstance Win32_Process|Where-Object {$_.ExecutablePath -and $_.ExecutablePath.StartsWith($install+'\',[StringComparison]::OrdinalIgnoreCase)})
if($active.Count -ne 0){throw 'Owned installed processes remain'}
$count=0
foreach($f in $r.payload.PSObject.Properties){$p=Join-Path $install $f.Name;if((Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant() -ne $f.Value.sha256){throw ('Payload changed: '+$f.Name)};$count++}
$previous=0
foreach($inventory in @((Join-Path $root 'previous-files.json'))){
 foreach($f in (Get-Content -Raw $inventory|ConvertFrom-Json)){if((Get-FileHash -LiteralPath $f.path -Algorithm SHA256).Hash -ne $f.sha256){throw 'Earlier preview changed'};$previous++}
}
$priorCount=0
foreach($f in (Get-Content -Raw (Join-Path $root 'previous-workflow-files.json')|ConvertFrom-Json)){if((Get-FileHash -LiteralPath $f.path -Algorithm SHA256).Hash -ne $f.sha256){throw 'Previous workflow evidence changed'};$priorCount++}
@{priorWorkflowFilesVerified=$priorCount;ownedProcessesRemaining=$active.Count;installedPayloadFilesVerified=$count;earlierPreviewFilesVerified=$previous;nativeAudioActivated=$false;shutdownRequested=$true}|ConvertTo-Json|Set-Content (Join-Path $root 'retirement.json') -Encoding UTF8
& (Join-Path $root 'collect.ps1') 'retired-355.zip'
shutdown.exe /s /t 0
