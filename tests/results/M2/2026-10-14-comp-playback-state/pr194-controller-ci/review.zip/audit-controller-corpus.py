from pathlib import Path
import hashlib, json, zipfile
root=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
review={'run':38630299802,'head':'b38969a91b91c1b88ff2efcf74f4f14d5b18dfdd',
        'kind':'retained original native reports and byte audit, not native replay','platforms':[]}
for platform,aid in [('Linux',11927880462),('Windows',11926566841)]:
    z=zipfile.ZipFile(root/f'artifact-{aid}.zip')
    names=z.namelist();assert len(names)==len(set(names))
    n=next(n for n in names if 'comp-assembly-controller-evidence/' in n and n.endswith('/report.json') and '/case-' not in n and '/inputs/' not in n)
    prefix=n.rsplit('/',1)[0]+'/'
    report=json.loads(z.read(n))
    workers=[p for p in report['inputWorkflow']['processes'] if p['kind'] in ['worker','nominal-worker']]
    assert len(workers)==12 and all(p['exitCode']==0 and not p['retirementPending'] and not p['observationTimedOut'] for p in workers)
    assert len(report['controllerProcesses'])==3 and all(p['exitCode']==0 for p in report['controllerProcesses'])
    cases=[c for r in report['reports'] for c in r['cases']]
    assert len(cases)==15 and sum(r['checks'] for r in report['reports'])==171
    assert all(c['closed']['closed'] and c['joinedMemoryReleased'] for c in cases)
    assert all(c['guiTicks']>0 for c in cases if c['stages']>0)
    normal=[c for c in cases if c['case']==0]
    assert len(normal)==3 and all(c['terminal']['published'] and c['terminal']['phase']==5 and c['review']['recovery']==4 and c['reuse']['recovery']==4 and not c['reuse']['published'] for c in normal)
    for c in cases:
        if c['case'] in [2,4,5]:assert c['terminal']['stale'] and not c['terminal']['published']
        if c['case']==8:assert c['review']['recovery']==4
    completed=[n for n in names if n.startswith(prefix) and '/media/comp-assemblies/' in n and n.endswith('/complete.json')]
    intents=[n for n in names if n.startswith(prefix) and '/media/comp-assemblies/' in n and n.endswith('/intent.json')]
    canceled=[n for n in names if n.startswith(prefix) and '/media/comp-assemblies/' in n and n.endswith('/cancel.request')]
    assert len(completed)==4 and len(intents)==10 and len(canceled)==3
    outputs=[]
    for n in completed:
        complete=json.loads(z.read(n));base=n.split('/media/comp-assemblies/')[0]+'/'
        intent=n.rsplit('/',1)[0]+'/intent.json'
        assert complete['complete'] and sha(z.read(intent))==complete['requestDigest']
        for out in complete['outputs']:
            if out is None:continue
            data=z.read(base+out['path']);assert sha(data)==out['sha256']
            outputs.append({'path':base+out['path'],'bytes':len(data),'sha256':out['sha256']})
    assert len(outputs)==8
    review['platforms'].append({'platform':platform,'artifact':aid,'cases':15,'checks':171,
        'retiredSourceWorkers':12,'retiredControllerProcesses':3,'ownedIntents':10,
        'pairedCompletions':4,'cancellationMarkers':3,'allControllersClosedAndReleasedMemory':True,
        'allPublicationBarriersHadGuiTimerProgress':True,'sourceOutputHashesVerified':outputs,
        'mainWindowQualified':False,'audioAdoptionQualified':False,'hardDeadlineQualified':False})
(root/'controller-corpus-audit.json').write_text(json.dumps(review,indent=2)+'\n')
print('PASS: both original controller corpora; 30 cases and 16 completed output WAV hashes')
