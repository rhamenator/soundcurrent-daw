from pathlib import Path
import json,subprocess,shlex,hashlib,shutil
r=Path('.cache/native-original-export');b=(r/'diagnostic-release').resolve();prefix=['nice','-n','15','ionice','-c','2','-n','7'];commands=[];objects={};archives={};borrowed={};borrowedObjects={}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
g=json.loads(Path('.cache/native-device-selection/qualified-gui.json').read_text())
oldroot=Path('.cache/native-original-export/release').resolve();oldhash=json.loads((r/'initial-quota-fixture-failure/built-input-hashes.json').read_text())
def run(stage,args,cwd=None):

 for x in json.loads((r/'frozen-inputs.json').read_text())['selectedInputs']:assert sha(x['path'])==x['checkoutSha256']
 cmd=prefix+args;commands.append({'stage':stage,'argv':cmd,'cwd':str(cwd or Path.cwd())});(r/'diagnostic-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 with (r/('diagnostic-'+stage+'.log')).open('w') as out:proc=subprocess.run(cmd,cwd=cwd,stdout=out,stderr=subprocess.STDOUT)
 assert proc.returncode==0,(stage,proc.returncode)
 print(stage+' passed',flush=True)
run('configure',['cmake','-S','.','-B',str(b),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DSC_BUILD_DESKTOP=ON','-DSC_BUILD_MEDIA=ON'])
targets=['sc-native-panel-tests','sc-native-original-recording-tests','sc-localization-tests','soundcurrent-daw']
gen=subprocess.check_output(['ninja','-C',str(b),'-t','commands',*targets],text=True);(r/'diagnostic-generated-commands.txt').write_text(gen)
for line in gen.splitlines():
 if False and 'rcc' in line and ' -c ' not in line:
  a=shlex.split(line);assert a[0]=='cd' and a[2]=='&&';run('resource-'+str(len(commands)),a[3:],b)
for line in gen.splitlines():
 if ' -c ' not in line:continue
 a=shlex.split(line);obj=a[a.index('-o')+1]
 if any(x in obj for x in ['sc-native-original-export.dir/','sc-native-original-recording-tests.dir/','sc-native-panel-tests.dir/']):
  (b/obj).parent.mkdir(parents=True,exist_ok=True);run('compile-'+str(len(objects)),a,b);objects[obj]={'bytes':(b/obj).stat().st_size,'sha256':sha(b/obj)}
for target in sorted({n.split('/')[1][:-4] for n in objects if n.split('/')[1].startswith(('sc-ui-','sc-native-monitor-controller','sc-native-original-export'))}):
 name='lib'+target+'.a';run(target+'-archive',['ar','r',name,*[n for n in objects if target+'.dir/' in n]],b);run(target+'-index',['ranlib',name],b);archives[name]=sha(b/name)
for i,line in enumerate(x for x in gen.splitlines() if any(' -o '+n+' ' in x for n in targets)):
 a=shlex.split(line)[2:-2]
 for n,x in enumerate(a):
  if x.endswith('.a') and not Path(x).is_absolute() and x not in archives:
   if (oldroot/x).is_file():p=oldroot/x;expected=oldhash[str(p)]
   else:rec=g['readOnlyArchives'][x];p=Path(rec['path']);expected=rec['sha256']
   assert sha(p)==expected,x;a[n]=str(p.resolve());borrowed[x]={'path':a[n],'sha256':expected}

  if x.endswith('.o') and x not in objects:
   p=oldroot/x;expected=oldhash[str(p)];assert sha(p)==expected;a[n]=str(p);borrowedObjects[x]={'path':str(p),'sha256':expected}
 run('link-'+str(i),a,b)
run('tests',['env','QT_QPA_PLATFORM=offscreen','ctest','--test-dir',str(b),'-R','^(desktop-native-recording-panel|original-native-outcomes|desktop-localization)$','--output-on-failure','--no-tests=error'])
for x in borrowed.values():assert sha(x['path'])==x['sha256']
shutil.copyfile(b/'Testing/Temporary/LastTest.log',r/'diagnostic-LastTest.log');shutil.copyfile(b/'CMakeCache.txt',r/'diagnostic-CMakeCache.txt')
(r/'diagnostic-qualification.json').write_text(json.dumps({'objects':objects,'privateArchives':archives,'readOnlyArchives':borrowed,'readOnlyObjects':borrowedObjects,'exeHashes':{n:sha(b/n)for n in targets},'windowsRuntimeQualified':False},indent=2)+'\n')
