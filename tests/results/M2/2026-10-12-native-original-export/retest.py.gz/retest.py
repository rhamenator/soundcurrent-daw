from pathlib import Path
import json,subprocess,shlex,hashlib,shutil
r=Path('.cache/native-original-export');b=(r/'corrected-release').resolve();old=(r/'release').resolve();prefix=['nice','-n','15','ionice','-c','2','-n','7'];commands=[];fresh={};borrowed={};g=json.loads(Path('.cache/native-device-selection/qualified-gui.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
f=json.loads((r/'frozen-inputs.json').read_text());first=json.loads((r/'initial-quota-fixture-failure/frozen-inputs.json').read_text());oldhash=json.loads((r/'initial-quota-fixture-failure/built-input-hashes.json').read_text())
assert [x['path']for x,y in zip(first['selectedInputs'],f['selectedInputs']) if x['checkoutSha256']!=y['checkoutSha256']]==['tests/native_original_recording_tests.cpp']
def run(stage,args,cwd=None):
 for x in f['selectedInputs']:assert sha(x['path'])==x['checkoutSha256']
 cmd=prefix+args;commands.append({'stage':stage,'argv':cmd,'cwd':str(cwd or Path.cwd())});(r/'corrected-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 with (r/('corrected-'+stage+'.log')).open('w') as out:p=subprocess.run(cmd,cwd=cwd,stdout=out,stderr=subprocess.STDOUT)
 assert p.returncode==0,(stage,p.returncode)
 print(stage+' passed',flush=True)
run('configure',['cmake','-S','.','-B',str(b),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DSC_BUILD_DESKTOP=ON','-DSC_BUILD_MEDIA=ON'])
gen=subprocess.check_output(['ninja','-C',str(b),'-t','commands','sc-native-original-recording-tests'],text=True);(r/'corrected-generated-commands.txt').write_text(gen)
for line in gen.splitlines():
 if ' -c ' not in line:continue
 a=shlex.split(line);obj=a[a.index('-o')+1]
 if 'sc-native-original-recording-tests.dir/' in obj:
  (b/obj).parent.mkdir(parents=True,exist_ok=True);run('compile-'+str(len(fresh)),a,b);fresh[obj]={'bytes':(b/obj).stat().st_size,'sha256':sha(b/obj)}
line=next(x for x in gen.splitlines() if ' -o sc-native-original-recording-tests ' in x);a=shlex.split(line)[2:-2]
for i,x in enumerate(a):
 if x.endswith('.a') and not Path(x).is_absolute():
  if (old/x).is_file():p=old/x;expected=oldhash[str(p)]
  else:rec=g['readOnlyArchives'][x];p=Path(rec['path']);expected=rec['sha256']
  assert sha(p)==expected;a[i]=str(p.resolve());borrowed[x]={'path':a[i],'sha256':expected}
run('link',a,b)
run('core-tests',['ctest','--test-dir',str(b),'-R','^original-native-outcomes$','--output-on-failure','--no-tests=error'])
for x in borrowed.values():assert sha(x['path'])==x['sha256']
shutil.copyfile(b/'Testing/Temporary/LastTest.log',r/'corrected-LastTest.log')
(r/'corrected-qualification.json').write_text(json.dumps({'source':f['source'],'tree':f['tree'],'freshObjects':fresh,'readOnlyArchives':borrowed,'executableSha256':sha(b/'sc-native-original-recording-tests'),'initialGuiAndMainObjectsUnchanged':True,'onlyChangedInput':'tests/native_original_recording_tests.cpp','originalFailureRetained':True},indent=2)+'\n')
