﻿$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
$receipt=Get-Content -Raw (Join-Path $root 'receipt.json')|ConvertFrom-Json
$uuid=(Get-CimInstance Win32_ComputerSystemProduct).UUID.ToLowerInvariant()
if($uuid -ne '670168f5-4e3f-4e7f-b218-3583db31f0f8') {throw 'Wrong acceptance clone'}
$install=Join-Path $env:LOCALAPPDATA ('Programs\SoundCurrent DAW Preview\'+$receipt.sequence+'-'+$receipt.sourceHead.Substring(0,12))
$exe=Join-Path $install 'soundcurrent-daw.exe'
$project=Join-Path $root 'project-été-Κиїв'
$env:PATH=$install+';'+$env:SystemRoot+'\System32;'+$env:SystemRoot+';'+$env:SystemRoot+'\System32\WindowsPowerShell\v1.0'
$env:QT_QPA_PLATFORM='windows';$env:QT_QPA_PLATFORM_PLUGIN_PATH=Join-Path $install 'platforms'
Add-Type -AssemblyName UIAutomationClient,UIAutomationTypes,System.Windows.Forms,System.Drawing
Add-Type 'using System;using System.Runtime.InteropServices;public class SC321Focus { [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h); [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow(); [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h,out uint pid); }'
function Require($condition,$message) {if(!$condition) {throw $message}}
function Capture($name) {
 $rect=[Windows.Forms.SystemInformation]::VirtualScreen
 $bitmap=New-Object Drawing.Bitmap $rect.Width,$rect.Height
 $graphics=[Drawing.Graphics]::FromImage($bitmap)
 try {$graphics.CopyFromScreen($rect.Left,$rect.Top,0,0,$rect.Size);$bitmap.Save((Join-Path $root ($name+'.png')),[Drawing.Imaging.ImageFormat]::Png)} finally {$graphics.Dispose();$bitmap.Dispose()}
}
function Focus($process) {
 $process.Refresh();Require (!$process.HasExited -and $process.SessionId -gt 0) 'Actual main not running interactively'
 [SC321Focus]::SetForegroundWindow($process.MainWindowHandle)|Out-Null
 Start-Sleep -Milliseconds 400
 [uint32]$owner=0;[SC321Focus]::GetWindowThreadProcessId([SC321Focus]::GetForegroundWindow(),[ref]$owner)|Out-Null
 Require ($owner -eq $process.Id) 'Foreground belongs to another process; refuse keys'
}
function Elements($process) {
 $condition=New-Object Windows.Automation.PropertyCondition ([Windows.Automation.AutomationElement]::ProcessIdProperty),$process.Id
 return [Windows.Automation.AutomationElement]::RootElement.FindAll([Windows.Automation.TreeScope]::Descendants,$condition)
}
function Tree($process,$name) {
 $rows=@();foreach($e in (Elements $process)) {$c=$e.Current;$rows+=@{name=$c.Name;id=$c.AutomationId;type=$c.ControlType.ProgrammaticName;enabled=$c.IsEnabled;offscreen=$c.IsOffscreen}}
 $rows|ConvertTo-Json -Depth 5|Set-Content (Join-Path $root ($name+'.json')) -Encoding UTF8
}
function Open-Main($stage) {
 $p=Start-Process -FilePath $exe -ArgumentList ('--language en "'+$project+'"') -WorkingDirectory $install -PassThru -RedirectStandardOutput (Join-Path $root ($stage+'.stdout')) -RedirectStandardError (Join-Path $root ($stage+'.stderr'))
 $handle=$p.Handle;$deadline=[DateTime]::UtcNow.AddSeconds(30)
 do {$p.Refresh();if($p.MainWindowHandle -ne 0) {break};Start-Sleep -Milliseconds 100} while([DateTime]::UtcNow -lt $deadline)
 Require (!$p.HasExited -and $p.MainWindowHandle -ne 0 -and $p.MainWindowTitle.StartsWith('SoundCurrent DAW') -and $p.SessionId -gt 0) 'Actual installed main unavailable'
 $modules=@($p.Modules|ForEach-Object {@{name=$_.ModuleName;path=$_.FileName}})
 foreach($name in @('Qt6Core.dll','Qt6Gui.dll','Qt6Widgets.dll','sndfile.dll','qwindows.dll')) {
  $found=@($modules|Where-Object {$_.name -eq $name})
  Require ($found.Count -eq 1 -and $found[0].path.StartsWith($install+'\',[StringComparison]::OrdinalIgnoreCase)) ('Dependency loaded outside install: '+$name)
 }
 $record=@{pid=$p.Id;sessionId=$p.SessionId;window=$p.MainWindowHandle.ToInt64();title=$p.MainWindowTitle;exe=$exe;sha256=(Get-FileHash $exe -Algorithm SHA256).Hash.ToLowerInvariant();modules=$modules}
 $record|ConvertTo-Json -Depth 6|Set-Content (Join-Path $root ($stage+'-launch.json')) -Encoding UTF8
 Set-Content (Join-Path $root 'main-pid.txt') $p.Id
 Start-Sleep -Milliseconds 1200
 Focus $p;Capture ($stage+'-opened');Tree $p ($stage+'-tree')
 return $p
}
function Save-Close($p,$stage) {
 Focus $p;[Windows.Forms.SendKeys]::SendWait('^s');Start-Sleep -Milliseconds 500
 $requested=$p.CloseMainWindow();Require $requested 'Main rejected normal close'
 $exited=$p.WaitForExit(30000);$p.Refresh()
 @{pid=$p.Id;normalCloseRequested=$requested;exited=$exited;forced=$false;exitCode=$(if($exited){$p.ExitCode}else{$null})}|ConvertTo-Json|Set-Content (Join-Path $root ($stage+'-close.json')) -Encoding UTF8
 Require ($exited -and $p.ExitCode -eq 0) 'Normal close incomplete; retain live process identity'
}
$result=[ordered]@{sourceHead=$receipt.sourceHead;vmUuid=$uuid;phase='started';passed=$false;nativeAudioActivated=$false;cleanOs=$false}
try {
 $before=(Get-FileHash (Join-Path $project 'project.json') -Algorithm SHA256).Hash
 $p=Open-Main 'first';Save-Close $p 'first'
 $p=Open-Main 'reopen'
 Focus $p;[Windows.Forms.SendKeys]::SendWait('^+e');Start-Sleep -Milliseconds 800
 Tree $p 'export-tree';Capture 'export-dialog'
 $buttons=@((Elements $p)|Where-Object {$_.Current.ControlType -eq [Windows.Automation.ControlType]::Button -and $_.Current.Name -eq 'Export' -and $_.Current.IsEnabled -and !$_.Current.IsOffscreen})
 Require ($buttons.Count -eq 1) 'No unique visible Export action'
 ([Windows.Automation.InvokePattern]$buttons[0].GetCurrentPattern([Windows.Automation.InvokePattern]::Pattern)).Invoke()
 $output=Join-Path $root 'project-été-Κиїв-mix.wav';$deadline=[DateTime]::UtcNow.AddSeconds(30)
 while(!(Test-Path -LiteralPath $output)) {Require ([DateTime]::UtcNow -lt $deadline) 'Export incomplete; preserve process';Start-Sleep -Milliseconds 100}
 Start-Sleep -Milliseconds 700;Capture 'export-finished'
 Save-Close $p 'reopen'
 $after=(Get-FileHash (Join-Path $project 'project.json') -Algorithm SHA256).Hash
 $result.projectBefore=$before;$result.projectAfter=$after
 Require ($before -eq $after) 'Project changed unexpectedly'
 $result.export=@{path=$output;bytes=(Get-Item -LiteralPath $output).Length;sha256=(Get-FileHash -LiteralPath $output -Algorithm SHA256).Hash.ToLowerInvariant()}
 foreach($old in (Get-Content -Raw (Join-Path $root 'previous-files.json')|ConvertFrom-Json)) {Require ((Get-FileHash -LiteralPath $old.path -Algorithm SHA256).Hash -eq $old.sha256) 'Previous preview changed'}
 $result.previousPreviewPreserved=$true;$result.phase='installed-save-reopen-export-normal-close';$result.passed=$true
} catch {$result.error=$_.Exception.Message;$_|Out-String|Set-Content (Join-Path $root 'workflow-error.txt') -Encoding UTF8}
$result|ConvertTo-Json -Depth 8|Set-Content (Join-Path $root 'workflow-result.json') -Encoding UTF8
& (Join-Path $root 'collect.ps1') 'workflow-321.zip'
if(!$result.passed) {throw $result.error}
