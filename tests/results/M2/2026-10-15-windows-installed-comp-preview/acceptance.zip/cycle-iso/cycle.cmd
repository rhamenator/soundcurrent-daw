@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0cycle.ps1"
pause
