﻿$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$root=Join-Path $env:USERPROFILE 'SoundCurrent-Installed-321'
if((Get-CimInstance Win32_ComputerSystemProduct).UUID -ne '670168F5-4E3F-4E7F-B218-3583DB31F0F8') {throw 'Wrong owned clone'}
if(Test-Path (Join-Path $root 'cycle-result.json')) {throw 'Cycle already observed; preserve result'}
$receipt=Get-Content -Raw (Join-Path $root 'receipt.json')|ConvertFrom-Json
$install=Join-Path $env:LOCALAPPDATA ('Programs\SoundCurrent DAW Preview\'+$receipt.sequence+'-'+$receipt.sourceHead.Substring(0,12))
if(Get-Process -Name 'soundcurrent-daw' -ErrorAction SilentlyContinue) {throw 'Close actual main before removal'}
$volumes=@(Get-Volume|Where-Object {$_.FileSystemLabel -eq 'SC321CYCLE'})
if($volumes.Count -ne 1) {throw 'Ambiguous owned test ISO'}
$setup=$volumes[0].DriveLetter+':\setup.exe'
$sentinel=Join-Path $install 'User project must survive.txt'
[IO.File]::WriteAllText($sentinel,'Owned installer sentinel; preserve exactly')
$prefs='HKCU:\Software\SoundCurrent\SoundCurrent DAW'
New-Item -Path $prefs -Force|Out-Null
New-ItemProperty -Path $prefs -Name 'comp321Acceptance' -Value 'preserve-321' -PropertyType String -Force|Out-Null
function Hashes {
 return @(Get-ChildItem (Join-Path $root 'project-été-Κиїв') -Recurse -File|ForEach-Object {@{path=$_.FullName;bytes=$_.Length;sha256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()}}|Sort-Object path)|ConvertTo-Json -Depth 5 -Compress
}
$before=Hashes
$report=[ordered]@{format='sc-windows-stretch-install-cycle-v1';sourceHead=$receipt.sourceHead;exitCode=1;installedWorkflowClaimed=$false;dataBefore=$before}
try {
 $p=Start-Process -FilePath (Join-Path $install 'Uninstall.exe') -ArgumentList '/S' -PassThru;$handle=$p.Handle;$report.uninstallPid=$p.Id
 if(!$p.WaitForExit(60000)) {throw 'Removal still live; preserve process'}
 $p.Refresh();$report.uninstallExit=$p.ExitCode
 if($p.ExitCode -ne 0) {throw 'Actual removal failed'}
 $deadline=[DateTime]::UtcNow.AddSeconds(25)
 do {if(!(Test-Path (Join-Path $install 'soundcurrent-daw.exe'))) {break};Start-Sleep -Milliseconds 100} while([DateTime]::UtcNow -lt $deadline)
 foreach($f in $receipt.payload.PSObject.Properties) {if(Test-Path -LiteralPath (Join-Path $install $f.Name)) {throw ('Owned payload remains: '+$f.Name)}}
 $reg='HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\SoundCurrentDAW-'+$receipt.sequence+'-'+$receipt.sourceHead.Substring(0,12)
 if(Test-Path $reg) {throw 'Removal retained registration'}
 $title='SoundCurrent DAW Preview '+$receipt.sequence+'-'+$receipt.sourceHead.Substring(0,12)
 foreach($link in @((Join-Path ([Environment]::GetFolderPath('Desktop')) ($title+'.lnk')),(Join-Path ([Environment]::GetFolderPath('Programs')) ('SoundCurrent DAW Preview\'+$title+'.lnk')))) {if(Test-Path $link) {throw 'Removal retained shortcut'}}
 if([IO.File]::ReadAllText($sentinel) -ne 'Owned installer sentinel; preserve exactly' -or (Get-ItemProperty $prefs).comp321Acceptance -ne 'preserve-321') {throw 'Removal changed sentinel/settings'}
 if((Hashes) -ne $before) {throw 'Removal changed project/media/export bytes'}
 $report.removalPreserved=$true
 $expected=@($receipt.artifacts.PSObject.Properties|Where-Object {$_.Name.EndsWith('-setup.exe')})
 if((Get-FileHash $setup -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expected[0].Value.sha256) {throw 'Setup changed'}
 $p=Start-Process -FilePath $setup -ArgumentList '/S' -PassThru;$handle=$p.Handle;$report.reinstallPid=$p.Id
 if(!$p.WaitForExit(90000)) {throw 'Reinstallation still live; preserve process'}
 $p.Refresh();$report.reinstallExit=$p.ExitCode
 if($p.ExitCode -ne 0) {throw 'Reinstallation failed'}
 foreach($f in $receipt.payload.PSObject.Properties) {if((Get-FileHash -LiteralPath (Join-Path $install $f.Name) -Algorithm SHA256).Hash.ToLowerInvariant() -ne $f.Value.sha256) {throw ('Reinstalled payload differs: '+$f.Name)}}
 if((Hashes) -ne $before -or [IO.File]::ReadAllText($sentinel) -ne 'Owned installer sentinel; preserve exactly' -or (Get-ItemProperty $prefs).comp321Acceptance -ne 'preserve-321') {throw 'Reinstall changed user data'}
 if((Get-ItemProperty $reg).InstallLocation -ne $install) {throw 'Reinstalled registration differs'}
 foreach($link in @((Join-Path ([Environment]::GetFolderPath('Desktop')) ($title+'.lnk')),(Join-Path ([Environment]::GetFolderPath('Programs')) ('SoundCurrent DAW Preview\'+$title+'.lnk')))) {
  if(!(Test-Path $link) -or (New-Object -ComObject WScript.Shell).CreateShortcut($link).TargetPath -ne (Join-Path $install 'soundcurrent-daw.exe')) {throw 'Reinstalled shortcut differs'}
 }
 $report.dataAfter=Hashes;$report.reinstallPreserved=$true;$report.exitCode=0
} catch {$report.error=$_.Exception.Message;$_|Out-String|Set-Content (Join-Path $root 'cycle-failure.txt') -Encoding UTF8} finally {$report|ConvertTo-Json -Depth 8|Set-Content (Join-Path $root 'cycle-result.json') -Encoding UTF8}
& (Join-Path $root 'collect.ps1') 'cycle-321.zip'
if($report.exitCode -ne 0) {throw $report.error}
foreach($old in (Get-Content -Raw (Join-Path $root 'previous-files.json')|ConvertFrom-Json)) {if((Get-FileHash -LiteralPath $old.path -Algorithm SHA256).Hash -ne $old.sha256) {throw 'Prior preview changed'}}
@{previousPreviewPreserved=$true;ownedAppProcesses=@(Get-Process -Name 'soundcurrent-daw' -ErrorAction SilentlyContinue).Count}|ConvertTo-Json|Set-Content (Join-Path $root 'cycle-final.json') -Encoding UTF8
& (Join-Path $root 'collect.ps1') 'cycle-final-321.zip'

