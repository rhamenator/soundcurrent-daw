from pathlib import Path
from http.server import BaseHTTPRequestHandler, HTTPServer
import json, time
ROOT = Path(__file__).resolve().parent
config = json.loads((ROOT / 'receiver-private.json').read_text())
OUT = ROOT / 'received'
OUT.mkdir(exist_ok=True)
class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args): pass
    def do_POST(self):
        import re, hmac
        if self.client_address[0] != config['ip'] or not hmac.compare_digest(self.headers.get('X-SoundCurrent-Capture-Key', ''), config['key']):
            self.send_error(403); return
        if not re.fullmatch(r'/[a-z0-9-]{1,70}\.zip', self.path):
            self.send_error(400); return
        path = OUT / self.path[1:]
        try: size = int(self.headers.get('Content-Length', '0'))
        except ValueError: self.send_error(400); return
        if not 0 < size < 30 * 1024 * 1024 or path.exists():
            self.send_error(400); return
        self.connection.settimeout(30)
        temporary = path.with_suffix('.partial')
        try:
            with temporary.open('xb') as f:
                left = size
                while left:
                    b = self.rfile.read(min(left, 1024 * 1024))
                    if not b: raise ValueError('Short owned upload')
                    f.write(b); left -= len(b)
            temporary.rename(path)
        except Exception:
            self.send_error(400); return
        self.send_response(201); self.end_headers(); self.wfile.write(b'accepted')
        print('Owned capture received:', path.name, size, flush=True)
server = HTTPServer(('192.168.122.1', 18771), Handler)
server.timeout = 1
print('Bounded private acceptance receiver started', flush=True)
deadline = time.monotonic() + 1200
while time.monotonic() < deadline and not (ROOT/'stop-receiver').exists(): server.handle_request()
server.server_close()
