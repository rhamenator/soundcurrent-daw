from pathlib import Path
import subprocess,json,hashlib,shlex,shutil,re
r=Path('.cache/native-monitor-recording-owner');prior=Path('.cache/owned-native-monitor-route');q=json.loads((prior/'qualified-profiles.json').read_text());old=json.loads((prior/'frozen-inputs.json').read_text());f=json.loads((r/'frozen-inputs.json').read_text());head=f['source'];prefix=['nice','-n','15','ionice','-c','2','-n','7'];commands=[];profiles={}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def checked():
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head and not subprocess.check_output(['git','status','--porcelain'],text=True)
 for x in f['selectedInputs']:assert sha(x['path'])==x['checkoutSha256']
checked();assert q['source']==old['source']=='2c38699e04900176b43e7da249756b8c65af5b16'
for x in old['selectedInputs']:
 if x['path'] not in {'CMakeLists.txt','tests/native_monitor_startup_tests.cpp','include/soundcurrent/monitor_processing.hpp','src/monitor_processing.cpp'}:assert sha(x['path'])==x['checkoutSha256']
for label,ctype,flags,linkflags in [('release','Release','',''),('sanitizer','Debug','-fsanitize=address,undefined -fno-omit-frame-pointer','-fsanitize=address,undefined'),('tsan','Debug','-fsanitize=thread -fno-omit-frame-pointer -O1','-fsanitize=thread')]:
 b=(r/('build-'+label)).resolve();previous=(prior/('build-'+label)).resolve();archives={}
 def run(stage,argv,cwd=None):
  checked();cmd=prefix+argv;commands.append({'profile':label,'stage':stage,'cwd':str(cwd or Path.cwd()),'argv':cmd});(r/'qualification-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
  with (r/(label+'-'+stage+'.log')).open('w') as out:p=subprocess.run(cmd,cwd=cwd,stdout=out,stderr=subprocess.STDOUT)
  if p.returncode:raise SystemExit(label+' '+stage+' failed; original log retained')
 print('Starting',label,flush=True)
 assert sha(previous/'sc-native-monitor-startup-tests')==q['profiles'][label]['exeSha256']
 run('configure',['cmake','-S','.','-B',str(b),'-G','Ninja','-DCMAKE_BUILD_TYPE='+ctype,'-DSC_BUILD_DESKTOP=OFF','-DSC_BUILD_MEDIA=ON','-DCMAKE_CXX_FLAGS='+flags,'-DCMAKE_EXE_LINKER_FLAGS='+linkflags])
 gen=subprocess.check_output(['ninja','-C',str(b),'-t','commands','sc-native-monitor-startup-tests'],text=True);(r/(label+'-generated-commands.txt')).write_text(gen)
 names=['/src/native_monitor_recording.cpp','/tests/native_monitor_startup_tests.cpp','/tests/native_monitor_route_tests.cpp','/tests/native_monitor_recording_tests.cpp','/tests/rt_audit.cpp']
 compiles=[shlex.split(s) for s in gen.splitlines() if ' -c ' in s and (any(n in s for n in names) or 'CMakeFiles/sc-monitor-processing.dir/' in s)];assert len(compiles)==13;objects={}
 for n,argv in enumerate(compiles):
  assert argv[0]=='/usr/bin/c++' and '-std=c++20' in argv
  obj=Path(argv[argv.index('-o')+1]);(b/obj).parent.mkdir(parents=True,exist_ok=True);run('compile-'+str(n),argv,b)
  assert 'warning:' not in (r/(label+'-compile-'+str(n)+'.log')).read_text();objects[str(obj)]={'bytes':(b/obj).stat().st_size,'sha256':sha(b/obj)}
 group=[str(Path(a[a.index('-o')+1])) for a in compiles if 'CMakeFiles/sc-monitor-processing.dir/' in a[a.index('-o')+1]]
 run('processing-archive',['/usr/bin/ar','r','libsc-monitor-processing.a',*group],b);run('processing-index',['/usr/bin/ranlib','libsc-monitor-processing.a'],b)
 run('owner-archive',['/usr/bin/ar','r','libsc-native-monitor-recording.a','CMakeFiles/sc-native-monitor-recording.dir/src/native_monitor_recording.cpp.o'],b);run('owner-index',['/usr/bin/ranlib','libsc-native-monitor-recording.a'],b)
 argv=shlex.split(gen.splitlines()[-1]);assert argv[:2]==[':','&&'] and argv[-2:]==['&&',':'];argv=argv[2:-2];assert '-Wl,--wrap=pthread_mutex_lock' in argv
 for n,a in enumerate(argv):
  if not a.startswith('-') and a.endswith('.a') and not Path(a).is_absolute() and a not in {'libsc-native-monitor-recording.a','libsc-monitor-processing.a'}:
   p=previous/a
   if not p.is_file():
    original=q['profiles'][label]['productionArchivesReadOnly'][a];p=Path(original['path']);assert sha(p)==original['sha256']
   archives[a]={'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)};argv[n]=str(p)
 assert 'libsc-native-original-recording.a' in archives and len(archives)>19
 run('link',argv,b)
 for x in archives.values():assert sha(x['path'])==x['sha256']
 run('tests',['ctest','--test-dir',str(b),'-R','^native-monitor-startup$','--output-on-failure','--no-tests=error'])
 assert '100% tests passed, 0 tests failed out of 1' in (r/(label+'-tests.log')).read_text()
 shutil.copyfile(b/'Testing/Temporary/LastTest.log',r/(label+'-LastTest.log'));shutil.copyfile(b/'CMakeCache.txt',r/(label+'-CMakeCache.txt'))
 log=(r/(label+'-LastTest.log')).read_text();rows=re.findall(r'^owned_native_recording[^\r\n]*',log,re.M);assert len(rows)==5 and 'packet_bound=2048' in rows[-1]
 assert 'owned_native_pressure accepted_requests=' in log and 'original_queue_full=true raw_bits_exact=true' in log
 own=int(re.search(r'(\d+) owned native recording checks passed',log)[1]);total=int(re.search(r'(\d+) composed native monitor startup checks passed; guarded allocate/free/lock=0',log)[1]);assert own>500000 and total==4606535+own
 profiles[label]={'exeSha256':sha(b/'sc-native-monitor-startup-tests'),'ownerArchiveSha256':sha(b/'libsc-native-monitor-recording.a'),'processingArchiveSha256':sha(b/'libsc-monitor-processing.a'),'objects':objects,'readOnlyArchives':archives,'ownedRows':rows,'ownedChecks':own,'totalComposedChecks':total}
 (r/'qualified-profiles.json').write_text(json.dumps({'source':head,'tree':f['tree'],'profiles':profiles,'nativeWindowsRuntimeExecuted':False},indent=2)+'\n');print('Passed',label,own,total,flush=True)
print('All three profiles passed',flush=True)
