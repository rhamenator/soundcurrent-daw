from pathlib import Path
import json,subprocess,hashlib,gzip,re,shutil
r=Path('.cache/native-monitor-recording-owner');out=Path('tests/results/M2/2026-10-11-native-monitor-recording-owner');f=json.loads((r/'frozen-inputs.json').read_text());q=json.loads((r/'qualified-profiles.json').read_text());w=json.loads((r/'windows-qualification.json').read_text());assert f['source']==q['source']==w['source'] and len(f['selectedInputs'])==643 and set(q['profiles'])=={'release','sanitizer','tsan'}
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==f['source'] and not subprocess.check_output(['git','status','--porcelain'],text=True)
for x in f['selectedInputs']:assert hashlib.sha256(Path(x['path']).read_bytes()).hexdigest()==x['checkoutSha256']
names=['freeze-inputs.py','qualify.py','qualify-windows.py','retain.py','frozen-inputs.json','qualified-profiles.json','windows-qualification.json','qualification-commands.json','qualification.log','source-delta.diff']
for label,p in q['profiles'].items():
 b=r/('build-'+label);assert hashlib.sha256((b/'sc-native-monitor-startup-tests').read_bytes()).hexdigest()==p['exeSha256']
 for x in p['readOnlyArchives'].values():assert hashlib.sha256(Path(x['path']).read_bytes()).hexdigest()==x['sha256']
 for n in ['configure','tests','LastTest','owner-archive','owner-index','processing-archive','processing-index','link']:names.append(label+'-'+n+'.log')
 names += [label+'-generated-commands.txt',label+'-CMakeCache.txt']+[label+'-compile-'+str(n)+'.log' for n in range(13)]
 log=(r/(label+'-LastTest.log')).read_text();assert log.count('owned_native_recording source_rate=')==5 and log.count('owned_native_route source_rate=')==7
 assert 'original_queue_full=true raw_bits_exact=true' in log and 'composed native monitor startup checks passed; guarded allocate/free/lock=0' in log
for p in r.glob('windows-compile-*.log'):names.append(p.name)
names.append('windows-qualification.log')
for tag in ['first-owner-test-failure','second-owner-test-failure','third-owner-test-empty-cancel-failure','first-tsan-native-pace-failure']:
 for n in ['development.log','release-tests.log','tsan-tests.log','failed-native-run.json','failed-journal.json','native_monitor_recording.cpp','native_monitor_recording_tests.cpp','native_monitor_recording.hpp']:
  p=r/tag/n
  if p.is_file():dest=tag+'--'+n;shutil.copyfile(p,r/dest);names.append(dest)
out.mkdir(exist_ok=False);members={}
for name in sorted(set(names)):
 raw=(r/name).read_bytes();packed=gzip.compress(raw,mtime=0);dest=name+'.gz';assert gzip.decompress(packed)==raw;(out/dest).write_bytes(packed);members[dest]={'bytes':len(packed),'sha256':hashlib.sha256(packed).hexdigest(),'originalBytes':len(raw),'originalSha256':hashlib.sha256(raw).hexdigest(),'lossless':True}
summary={'source':f['source'],'tree':f['tree'],'sourceInputs':643,'ownedChecks':{k:p['ownedChecks']for k,p in q['profiles'].items()},'totalComposedChecks':{k:p['totalComposedChecks']for k,p in q['profiles'].items()},'originalSourceInputsUnchangedExceptProcessingReceiptAndNativeTestMain':True,'realProcessingDiskWorkersExecuted':True,'sdkOperationsSimulated':True,'sevenCurrentWindowsObjectsCompiled':True,'currentWindowsNativeLinkOrRuntimeExecuted':False,'monitoringEqIntegrated':False,'physicalAudioQualified':False,'desktopFactoryEnabled':False,'fullGoalComplete':False,'binariesOrMediaIncluded':False}
raw=(json.dumps(summary,indent=2)+'\n').encode();(out/'summary.json').write_bytes(raw);members['summary.json']={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()};(out/'manifest.json').write_text(json.dumps({'members':members,'scope':'Expanded native startup/recording owner suite, Release, ASan/UBSan, TSan; current Windows source compilation only; failure/source/log/config/command/hash assets only'},indent=2)+'\n');print('Retained',len(members),'bound files;',sum(p.stat().st_size for p in out.iterdir()),'bytes',flush=True)
