from pathlib import Path
import hashlib, json, re, zipfile

root = Path(__file__).parent
sha = lambda b: hashlib.sha256(b).hexdigest()
result = {'run': 38626732345, 'source': '54c7276a0f0ab9d3a77635ecf201987c092acf90',
          'kind': 'independent retained-byte audit, not a DSP or native replay', 'platforms': []}
for platform, artifact in [('Linux',11925516941), ('Windows',11925042371)]:
    z = zipfile.ZipFile(root / f'artifact-{artifact}.zip')
    names = set(z.namelist())
    assert len(names) == len(z.namelist())
    read = lambda n: json.loads(z.read(n))
    top = next(n for n in names if n.startswith('comp-assembly-job-evidence/') and n.endswith('/report.json') and n.count('/') == 2)
    workflow = read(top)
    workers = [p for p in workflow['inputWorkflow']['processes'] if p['kind'] in ['worker','nominal-worker']]
    assert len(workers) == 12 and all(p['exitCode'] == 0 and not p['retirementPending'] and not p['observationTimedOut'] for p in workers)
    assert len(workflow['publicationProcesses']) == 3 and all(p['exitCode'] == 0 for p in workflow['publicationProcesses'])
    states = [n for n in names if n.startswith('comp-assembly-state-evidence/') and n.endswith('/report.json')]
    assert len(states) == 1
    state = read(states[0])
    assert state == {'audioAdoption':False,'checks':119,'collisionIdentities':13,'missingSidecarProjectReadable':True,'saveReopenRelocation':True,'schema':'1.22','undoRedo':True}
    reports = sorted(n for n in names if n.startswith('comp-assembly-job-evidence/') and n.endswith('/assembly-job-report.json'))
    assert len(reports) == 3
    outputs = []
    for name in reports:
        base = name.rsplit('/',1)[0] + '/'
        relocated = base.rsplit('/project-',1)[0] + '/relocated-assembly/'
        report = read(name)
        assert report['requestReferenceInProject'] and report['requestSidecarReopenRelocation'] and report['sourceBasedFullPcmRefusal']
        assert report['checks'] == 89 and report['completedJobs'] == 1 and report['canceledJobs'] == 1 and report['interruptedJobs'] == 2
        assert not report['modelAdoptionChanged'] and not report['qualityAdmission']
        project = read(base+'project.json')
        assert project['schemaMinor'] == 22
        ref, = project['compAssemblies']
        op = ref['operation']
        request = base + f'media/comp-assembly-requests/{op}.json'
        assert sha(z.read(request)) == ref['requestSha256']
        assert z.read(request) == z.read(relocated + request[len(base):])
        assert read(relocated+'project.json')['compAssemblies'] == [ref]
        complete = base+f'media/comp-assemblies/{op}/complete.json'
        record = read(complete)
        assert record['requestDigest'] == ref['requestSha256'] and record['complete']
        assert record['protocol'] == 'sc-comp-assembly-v1'
        assert z.read(complete) == z.read(relocated+complete[len(base):])
        assert [o['id'] for o in record['outputs']] == ref['outputs']
        for out in record['outputs']:
            pcm = z.read(base+out['path'])
            assert sha(pcm) == out['sha256']
            assert pcm == z.read(relocated+out['path'])
            outputs.append({**out,'retained_file_bytes':len(pcm)})
    assert sum(read(n)['comparedSamples'] for n in reports) == 202716
    result['platforms'].append({'platform':platform,'artifact':artifact,'source_workers_retired':12,
        'publication_processes_retired':3,'original_complete_jobs':3,'injected_interrupted_jobs':6,'canceled_jobs':3,
        'native_test_compared_samples':202716,'state_checks':119,'publication_checks':267,
        'saved_request_and_relocated_bytes_verified':True,'outputs':outputs})
(root/'state-corpus-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='platforms'}))
print('PASS: both platform corpora; 12 original output files and relocated copies')
