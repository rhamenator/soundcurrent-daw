﻿$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$media=Split-Path -Parent $MyInvocation.MyCommand.Path
$root=Join-Path $env:USERPROFILE 'SoundCurrent-Stretch-Installed-f9'
if(!(Test-Path $root)) {throw 'Previous observation folder missing'}
if((Get-CimInstance Win32_ComputerSystemProduct).UUID -ne '670168F5-4E3F-4E7F-B218-3583DB31F0F8') {throw 'Wrong owned clone'}
if(Test-Path (Join-Path $root 'retry-setup-result.json')) {throw 'Retry already observed'}
foreach($name in @('receipt.json','project.zip','private-transport.json','open-main.ps1','collect.ps1','cycle.ps1')) {Copy-Item -LiteralPath (Join-Path $media $name) $root}
function Require($value,$message) {if(!$value) {throw $message}}
$receipt=Get-Content -Raw (Join-Path $root 'receipt.json')|ConvertFrom-Json
$install=Join-Path $env:LOCALAPPDATA ('Programs\SoundCurrent DAW Preview\'+$receipt.sequence+'-'+$receipt.sourceHead.Substring(0,12))
$report=[ordered]@{format='sc-windows-stretch-install-observation-v1';sourceHead=$receipt.sourceHead;sequence=$receipt.sequence;phase='setup';exitCode=1;sessionId=(Get-Process -Id $PID).SessionId;vmUuid=(Get-CimInstance Win32_ComputerSystemProduct).UUID;os=[Environment]::OSVersion.Version.ToString();compilerOnPath=[bool](Get-Command cl.exe -ErrorAction SilentlyContinue);qtSdkOnPath=[bool](Get-Command qmake.exe -ErrorAction SilentlyContinue);nativeAudioActivated=$false;installLocation=$install}
try {
 Require ($report.sessionId -gt 0 -and !$report.compilerOnPath -and !$report.qtSdkOnPath) 'Not a clean interactive acceptance environment'
 Require (!(Test-Path $install)) 'Preview already installed in clean clone'
 $expected=@($receipt.artifacts.PSObject.Properties|Where-Object {$_.Name.EndsWith('-setup.exe')})
 Require ($expected.Count -eq 1) 'No exact installer identity'
 $setup=Join-Path $media 'setup.exe'
 $report.installerSha256=(Get-FileHash $setup -Algorithm SHA256).Hash.ToLowerInvariant()
 Require ($report.installerSha256 -eq $expected[0].Value.sha256) 'Installer bytes differ'
 $runtime='HKLM:\SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64'
 $report.runtimeBefore=Get-ItemProperty $runtime -ErrorAction SilentlyContinue|Select-Object Installed,Version
 $process=Start-Process -FilePath $setup -ArgumentList '/S' -PassThru
 $handle=$process.Handle;$report.setupPid=$process.Id
 Require ($process.WaitForExit(360000)) 'Setup observation deadline; retain live process for diagnosis'
 $process.Refresh();$report.setupExit=$process.ExitCode
 Require ($process.ExitCode -eq 0) 'Actual setup failed'
 $report.runtimeAfter=Get-ItemProperty $runtime -ErrorAction SilentlyContinue|Select-Object Installed,Version
 $count=0
 foreach($f in $receipt.payload.PSObject.Properties) {
  $path=Join-Path $install $f.Name
  Require ((Get-Item -LiteralPath $path).Length -eq $f.Value.bytes -and (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -eq $f.Value.sha256) ('Installed payload differs: '+$f.Name)
  $count++
 }
 Require ($count -eq 64) 'Incorrect payload count';$report.verifiedPayloadFiles=$count
 $title='SoundCurrent DAW Preview '+$receipt.sequence
 $shell=New-Object -ComObject WScript.Shell;$links=@()
 foreach($link in @((Join-Path ([Environment]::GetFolderPath('Desktop')) ($title+'.lnk')),(Join-Path ([Environment]::GetFolderPath('Programs')) ('SoundCurrent DAW Preview\'+$title+'.lnk')))) {
  Require (Test-Path -LiteralPath $link) 'Shortcut missing'
  $target=$shell.CreateShortcut($link).TargetPath
  Require ($target -eq (Join-Path $install 'soundcurrent-daw.exe')) 'Shortcut target differs'
  $links+=@{path=$link;target=$target}
 }
 $report.shortcuts=$links
 $reg='HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\SoundCurrentDAW-'+$receipt.sequence+'-'+$receipt.sourceHead.Substring(0,12)
 Require ((Get-ItemProperty $reg).InstallLocation -eq $install) 'Apps uninstall registration missing'
 Expand-Archive -LiteralPath (Join-Path $root 'project.zip') -DestinationPath $root
 $report.registry=$reg;$report.phase='installed-and-staged';$report.exitCode=0
} catch {
 $report.error=$_.Exception.Message
 $_|Out-String|Set-Content (Join-Path $root 'retry-setup-failure.txt') -Encoding UTF8
} finally {
 $report|ConvertTo-Json -Depth 12|Set-Content (Join-Path $root 'retry-setup-result.json') -Encoding UTF8
}
& (Join-Path $root 'collect.ps1') 'retry-setup.zip'
if($report.exitCode -ne 0) {throw $report.error}
& (Join-Path $root 'open-main.ps1')
