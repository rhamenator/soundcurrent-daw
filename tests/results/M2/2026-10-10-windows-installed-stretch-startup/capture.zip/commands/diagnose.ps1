﻿$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$root=Join-Path $env:USERPROFILE 'SoundCurrent-Stretch-Installed-f9'
if((Get-CimInstance Win32_ComputerSystemProduct).UUID -ne '670168F5-4E3F-4E7F-B218-3583DB31F0F8') {throw 'Wrong owned clone'}
$stamp=[DateTime]::UtcNow.ToString('yyyyMMddHHmmssfff')
$logs=Join-Path $root ('runtime-diagnostic-'+$stamp)
New-Item -ItemType Directory $logs|Out-Null
$result=[ordered]@{format='sc-windows-runtime-diagnostic-v1';utc=[DateTime]::UtcNow.ToString('o');sessionId=(Get-Process -Id $PID).SessionId;vmUuid=(Get-CimInstance Win32_ComputerSystemProduct).UUID;processes=@(Get-Process -ErrorAction SilentlyContinue|Where-Object {$_.ProcessName -match '^(setup|vc_redist.x64|SoundCurrent.*setup)$'}|Select-Object Id,ProcessName,SessionId,MainWindowTitle);runtime64=(Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64' -ErrorAction SilentlyContinue|Select-Object Installed,Version);runtime32=(Get-ItemProperty 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\VisualStudio\14.0\VC\Runtimes\x64' -ErrorAction SilentlyContinue|Select-Object Installed,Version);logs=@()}
foreach($dir in @($env:TEMP,(Join-Path $env:WINDIR 'Temp'))) {
 foreach($f in @(Get-ChildItem -LiteralPath $dir -Filter 'dd_vcredist_amd64*.log' -ErrorAction SilentlyContinue|Where-Object {$_.Length -lt 5MB}|Sort-Object LastWriteTime -Descending|Select-Object -First 12)) {
  $dest=Join-Path $logs (($result.logs.Count.ToString())+'-'+$f.Name)
  Copy-Item -LiteralPath $f.FullName -Destination $dest
  $result.logs+=@{source=$f.FullName;captured=(Split-Path -Leaf $dest);bytes=$f.Length;sha256=(Get-FileHash $dest -Algorithm SHA256).Hash.ToLowerInvariant()}
 }
}
$result|ConvertTo-Json -Depth 10|Set-Content (Join-Path $logs 'diagnostic.json') -Encoding UTF8
& (Join-Path $root 'collect.ps1') ('runtime-diagnostic-'+$stamp+'.zip')
