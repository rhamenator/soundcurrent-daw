﻿$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$root=Join-Path $env:USERPROFILE 'SoundCurrent-Stretch-Installed-f9'
if((Get-CimInstance Win32_ComputerSystemProduct).UUID -ne '670168F5-4E3F-4E7F-B218-3583DB31F0F8') {throw 'Wrong owned clone'}
if(Test-Path (Join-Path $root 'installed-verification.json')) {throw 'Installed verification already observed'}
$receipt=Get-Content -Raw (Join-Path $root 'receipt.json')|ConvertFrom-Json
$install=Join-Path $env:LOCALAPPDATA ('Programs\SoundCurrent DAW Preview\'+$receipt.sequence+'-'+$receipt.sourceHead.Substring(0,12))
$original=Get-Content -Raw (Join-Path $root 'retry-setup-result.json')|ConvertFrom-Json
if($original.setupExit -ne 0) {throw 'No actual normal setup exit'}
$count=0
foreach($f in $receipt.payload.PSObject.Properties) {
 $path=Join-Path $install $f.Name
 if((Get-Item -LiteralPath $path).Length -ne $f.Value.bytes -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $f.Value.sha256) {throw ('Installed payload differs: '+$f.Name)}
 $count++
}
if($count -ne 64) {throw 'Payload count differs'}
$title='SoundCurrent DAW Preview '+$receipt.sequence+'-'+$receipt.sourceHead.Substring(0,12)
$shell=New-Object -ComObject WScript.Shell;$links=@()
foreach($link in @((Join-Path ([Environment]::GetFolderPath('Desktop')) ($title+'.lnk')),(Join-Path ([Environment]::GetFolderPath('Programs')) ('SoundCurrent DAW Preview\'+$title+'.lnk')))) {
 if(!(Test-Path -LiteralPath $link)) {throw 'Actual build-named shortcut missing'}
 $target=$shell.CreateShortcut($link).TargetPath
 if($target -ne (Join-Path $install 'soundcurrent-daw.exe')) {throw 'Shortcut target differs'}
 $links+=@{path=$link;target=$target}
}
$reg='HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\SoundCurrentDAW-'+$receipt.sequence+'-'+$receipt.sourceHead.Substring(0,12)
if((Get-ItemProperty $reg).InstallLocation -ne $install) {throw 'Registration differs'}
Expand-Archive -LiteralPath (Join-Path $root 'project.zip') -DestinationPath $root
$result=[ordered]@{format='sc-installed-payload-verification-v1';sourceHead=$receipt.sourceHead;installerSha256=$original.installerSha256;setupPid=$original.setupPid;setupExit=$original.setupExit;verifiedPayloadFiles=$count;shortcuts=$links;registration=$reg;vmUuid=(Get-CimInstance Win32_ComputerSystemProduct).UUID;sessionId=(Get-Process -Id $PID).SessionId;runtimeAfter=$original.runtimeAfter;compilerOnPath=[bool](Get-Command cl.exe -ErrorAction SilentlyContinue);qtSdkOnPath=[bool](Get-Command qmake.exe -ErrorAction SilentlyContinue);nativeAudioActivated=$false;fullStretchAcceptance=$false}
$result|ConvertTo-Json -Depth 10|Set-Content (Join-Path $root 'installed-verification.json') -Encoding UTF8
Copy-Item -LiteralPath $MyInvocation.MyCommand.Path (Join-Path $root 'verify-installed.ps1')
& (Join-Path $root 'collect.ps1') 'installed-payload.zip'
& (Join-Path $root 'open-main.ps1')
