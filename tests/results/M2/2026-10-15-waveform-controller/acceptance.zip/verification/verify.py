import os,subprocess,json,time
from pathlib import Path
root=Path('.cache/waveform-controller-344');rows=[]
for label,build in [('release','.cache/take-preview-linux/build'),('asan-ubsan',str(root/'asan'))]:
 extra={} if label=='release' else {'ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'}
 env=os.environ.copy();env.update(extra)
 phases=[]
 if label=='asan-ubsan':phases.append(('configure',['cmake','-S','.','-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Debug','-DSC_BUILD_DESKTOP=ON','-DSC_BUILD_PIPEWIRE=OFF','-DSC_BUILD_MEDIA=ON','-DCMAKE_CXX_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer']))
 phases.extend([('build',['cmake','--build',build,'--parallel','1','--target','sc-waveform-controller-tests','sc-waveform-protocol-tests','sc-waveform-tests','sc-wave-validation-tests']),('tests',['ctest','--test-dir',build,'-R','^(desktop-waveform-controller|waveform-source-pyramid|waveform-reply-protocol|waveform-worker-workflows|approved-wave-content)$','--output-on-failure','-V'])])
 for phase,cmd in phases:
  argv=['nice','-n','15','ionice','-c','3']+cmd;start=time.monotonic()
  with (root/(label+'-'+phase+'.log')).open('wb') as f:r=subprocess.run(argv,stdout=f,stderr=subprocess.STDOUT,env=env)
  rows.append(dict(label=label,phase=phase,argv=argv,environment=extra,exitCode=r.returncode,seconds=time.monotonic()-start))
  (root/'verification-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,phase,r.returncode,flush=True)
  if r.returncode:raise SystemExit(r.returncode)
