from pathlib import Path
import hashlib,json,zipfile
root=Path('.cache/comp-protected-ui/pr194-protected-desktop-review');src=root/'artifact-11949471558.zip';out=Path('tests/results/M2/2026-10-15-protected-comp-history')
sha=lambda b:hashlib.sha256(b).hexdigest()
assert src.stat().st_size==332762564 and hashlib.file_digest(src.open('rb'),'sha256').hexdigest()=='ba20b703cdebc6f2b73b1657d8f99f6282a37129c860cb925847b18da9d2d429'
prefix='manual-owner-failure-projects/651625b9-b67b-4351-be95-da4639f6d7d3/'
with zipfile.ZipFile(src) as z:
 retention=json.loads(z.read(prefix+'retention.json'));files=[];missing=[]
 for f in retention['originalFiles']:
  n=prefix+f['path'].replace('\\','/')
  if n not in z.namelist():
   assert f['path']=='.save.lock' and f['bytes']==0 and f['sha256']==sha(b'');missing.append(f);continue
  b=z.read(n);assert len(b)==f['bytes'] and sha(b)==f['sha256'];files.append((n,b))
 outcome=json.loads(next(b for n,b in files if '/pw-outcome-' in n));owner=json.loads(next(b for n,b in files if n.endswith('/pipewire-owner.json')))
 assert outcome['disposition']==2 and outcome['render']['fault']['cause']==19 and outcome['render']['consumed']==0 and outcome['render']['queued']==0
 assert outcome['startup']['finiteFrames']==1 and outcome['startup']['published']==1 and outcome['stop']['generated']==1
 assert outcome['capture']['joined'] and outcome['render']['joined'] and owner['prefix']['rawFrames']==96480 and owner['prefix']['finalized']
 assert not outcome['failures']['disk'] and not outcome['failures']['storage'] and outcome['processing'] is None
 files.append((prefix+'retention.json',z.read(prefix+'retention.json')))
log=Path('.cache/comp-protected-history/original-native-job.log').read_bytes();assert b'Short PipeWire output failed finite completion' in log and b'1 tests failed out of 93' in log
files.append(('original-native-job.log',log));files.append(('audit-native-failure.py',Path(__file__).read_bytes()))
archive=out/'preceding-native-failure.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for n,b in files:z.writestr(n,b)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,b in files:assert z.read(n)==b
summary=dict(run=38681796679,head='9a3cd5b8dba1b7287ae42138344b6e372e317c6f',job=116247770666,jobConclusion='failure',test='pipewire-owned-recording',check=2,retainedOriginalProjectFiles=len(retention['originalFiles'])-len(missing),originalManifestFiles=len(retention['originalFiles']),missingOriginalFiles=missing,originalArtifact=dict(id=11949471558,bytes=src.stat().st_size,sha256=hashlib.file_digest(src.open('rb'),'sha256').hexdigest()),archive=archive.name,bytes=archive.stat().st_size,sha256=hashlib.file_digest(archive.open('rb'),'sha256').hexdigest(),observed=dict(disposition='Failed',renderCause='Startup',rawFramesFinalized=96480,monitorFramesDelivered=0,finiteFramesPublished=1,captureAndRenderJoined=True,diskFailure=False,processingFault=None),inference='Possible stale pre-readiness accepted count or caller clock snapshot; exact branch not instrumented. Reproduce before selecting fix.',fullRunTerminal=False,wholeRunAuditComplete=False)
(out/'preceding-native-failure.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
