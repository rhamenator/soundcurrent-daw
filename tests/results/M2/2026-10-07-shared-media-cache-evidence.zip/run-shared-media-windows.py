from pathlib import Path
import datetime,hashlib,json,subprocess,shutil
root=Path.cwd();folder=root/'.cache/shared-media-windows';folder.mkdir();source={}
for d in ['src','include','tests']:
 for p in (root/d).rglob('*'):
  if p.is_file() and p.suffix in ['.cpp','.hpp','.h']:
   n=str(p.relative_to(root));t=folder/'source'/n;t.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,t);source[n]=hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['CMakeLists.txt','cmake/toolchains/windows-mingw.cmake','third_party/libsndfile/sndfile.h']:
 p=root/n;t=folder/'source'/n;t.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,t);source[n]=hashlib.sha256(p.read_bytes()).hexdigest()
cmd=['cmake','--build','.cache/build-windows-media','--parallel','2','--target','sc-media','sc-media-cache-tests','sc-export-tool','sc-play-tool']
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_parent':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_sha256':source,'command':cmd,'runtime_qualified':False,'desktop_built':False,'scope':'Fresh Windows MinGW Release media library, shared media test executable and playback/export CLI cross-compile/link; no runtime/ABI/installer qualification'}
(folder/'launch.json').write_text(json.dumps(result,indent=2)+'\n')
with (root/'.cache/shared-media-windows-build.log').open('w') as out:r=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
result['exit_code']=r.returncode;result['ended_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();result['artifact_sha256']={}
if not r.returncode:
 for n in ['libsc-media.a','sc-media-cache-tests.exe','sc-export-tool.exe','sc-play-tool.exe']:
  p=root/'.cache/build-windows-media'/n;shutil.copy2(p,folder/n);result['artifact_sha256'][n]=hashlib.sha256(p.read_bytes()).hexdigest()
(folder/'launch.json').write_text(json.dumps(result,indent=2)+'\n');(root/'.cache/shared-media-windows-compile.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'exit_code':r.returncode,'scope':result['scope']}));raise SystemExit(r.returncode)
