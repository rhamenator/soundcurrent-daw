from pathlib import Path
import subprocess,json,hashlib
r=Path('.cache/pipewire-capture-returns');f=json.loads((r/'frozen-inputs.json').read_text());head=f['source'];prefix=['nice','-n','15','ionice','-c','2','-n','7'];objects={}
sources=['src/pipewire_monitor_capture.cpp','src/pipewire_monitor_render.cpp','src/pipewire_receipt_queues.cpp','src/pipewire_receipt_codec.cpp','tests/pipewire_receipt_tests.cpp','tests/pipewire_receipt_codec_tests.cpp']
for n,src in enumerate(sources):
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head and not subprocess.check_output(['git','status','--porcelain'],text=True)
 for x in f['selectedInputs']:assert hashlib.sha256(Path(x['path']).read_bytes()).hexdigest()==x['checkoutSha256']
 obj=r/('windows-current-'+str(n)+'.obj');cmd=prefix+['x86_64-w64-mingw32-g++','-std=c++20','-O2','-Wall','-Wextra','-Wpedantic','-Wconversion','-DSC_NATIVE_STARTUP_STATE','-Iinclude','-Isrc','-Iui','-isystem','third_party','-isystem','third_party/libsndfile','-c',src,'-o',str(obj)]
 with (r/('windows-compile-'+str(n)+'.log')).open('w') as out:p=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
 if p.returncode:raise SystemExit('Windows current object '+str(n)+' failed; original retained')
 assert 'warning:' not in (r/('windows-compile-'+str(n)+'.log')).read_text()
 objects[src]={'argv':cmd,'bytes':obj.stat().st_size,'sha256':hashlib.sha256(obj.read_bytes()).hexdigest()}
(r/'windows-qualification.json').write_text(json.dumps({'source':head,'tree':f['tree'],'objects':objects,'sdkAdapterCompiled':False,'nativeWindowsLinkExecuted':False,'nativeWindowsRuntimeExecuted':False,'physicalEndpointsTested':False},indent=2)+'\n');print('Six current portable receipt/capture/render objects warning-free; no SDK link/runtime claim',flush=True)
