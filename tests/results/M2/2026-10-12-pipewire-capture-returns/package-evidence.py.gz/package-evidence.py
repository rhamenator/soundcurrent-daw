from pathlib import Path
import hashlib,json,gzip,subprocess
r=Path('.cache/pipewire-capture-returns');d=Path('tests/results/M2/2026-10-12-pipewire-capture-returns');d.mkdir(parents=True,exist_ok=True)
f=json.loads((r/'frozen-inputs.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
for x in f['selectedInputs']:assert sha(Path(x['path']).read_bytes())==x['checkoutSha256']
members={}
def put(name,b):
 p=d/(name+'.gz');p.parent.mkdir(parents=True,exist_ok=True);z=gzip.compress(b,mtime=0);p.write_bytes(z)
 members[name+'.gz']={'bytes':len(z),'sha256':sha(z),'originalBytes':len(b),'originalSha256':sha(b)}
for name in ['frozen-inputs.json','source-delta.diff','configure.log','release-build.log','codec-build.log','development-tests.log','final-build.log','final-tests.log','final-queue-build.log','final-queue-tests.log','native-build.log','sanitizer-configure.log','sanitizer-build.log','sanitizer-tests.log','tsan-configure.log','tsan-build.log','tsan-tests.log','private-pipewire.conf','windows-qualification.json','windows-qualification.log','freeze-inputs.py','qualify-windows.py','retain160.py']:
 put(name,(r/name).read_bytes())
for p in r.glob('windows-compile-*.log'):put(p.name,p.read_bytes())
for role in ['capture','render']:
 for name in [role+'-owned-runtime.log',role+'-owned-runtime.json',role+'-owned-daemon.log',role+'-owned-wrapper.log', 'sanitizer-'+role+'-owned-runtime.log','sanitizer-'+role+'-owned-runtime.json','sanitizer-'+role+'-owned-daemon.log','sanitizer-'+role+'-owned-wrapper.log','run-owned-'+role+'.py','run-owned-'+role+'-sanitizer.py']:
  put(name,(r/name).read_bytes())
for p in sorted((r/'initial-build-and-test').iterdir()):
 if p.is_file():put('initial-build-and-test/'+p.name,p.read_bytes())
for p in sorted((r/'pr160-review').iterdir()):
 if p.is_file() and p.suffix in ['.json','.log']:put('preceding-pr160/'+p.name,p.read_bytes())
put('preceding-pr160/tested-merge.json',Path('.cache/pipewire-monitor-render/pr160-tested-merge.json').read_bytes())
hashes={}
for profile in ['release','sanitizer','thread-sanitizer']:
 p=r/profile;put(profile+'-CMakeCache.txt',(p/'CMakeCache.txt').read_bytes());put(profile+'-LastTest.log',(p/'Testing/Temporary/LastTest.log').read_bytes());put(profile+'-generated-commands.log',subprocess.check_output(['ninja','-C',str(p),'-t','commands']))
 files=list(p.glob('*.a'))+[q for q in p.glob('sc-*-tests') if q.is_file()]+list(p.glob('sc-pipewire-monitor-*-fixture'))
 hashes[profile]={str(q.relative_to(p)):{'bytes':q.stat().st_size,'sha256':sha(q.read_bytes())} for q in files}
put('build-output-hashes.json',json.dumps(hashes,indent=2).encode())
commands={'releaseAndAsanRegex':'^(pipewire-native-receipt-handoffs|pipewire-native-receipt-codec|pipewire-monitor-planar-render|pipewire-monitor-planar-capture)$','tsanRegex':'^pipewire-native-receipt-handoffs$','ctestArgs':['--output-on-failure','--parallel','1'],'asanEnvironment':{'ASAN_OPTIONS':'detect_leaks=0:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'},'tsanEnvironment':{'TSAN_OPTIONS':'halt_on_error=1'},'priority':['nice','-n','15','ionice','-c','2','-n','7'],'nativeWrappers':'run-owned-{capture,render}{,-sanitizer}.py, owner-only private dummy daemon, no physical routes','windows':'Exact argv/object hashes in windows-qualification.json'}
put('qualification-commands.json',json.dumps(commands,indent=2).encode());put('package-evidence.py',Path(__file__).read_bytes())
summary={'implementation':f['source'],'tree':f['tree'],'sourceInputs':len(f['selectedInputs']),'release':{'passed':4,'tests':4,'seconds':.07,'codecChecks':5537,'receiptChecksScheduleDependent':3246},'asanUbsan':{'passed':4,'tests':4,'seconds':.62,'leakDetection':False},'threadSanitizer':{'passed':1,'tests':1,'seconds':.35,'scope':'Portable receipt lanes, two actual producer threads and one consumer/final publication; no GUI/native framework claim','suppressions':False},'ownedNative':{'releaseCapturePassed':True,'asanCapturePassed':True,'captureFramesEach':96000,'captureNativeReturnedEach':96000,'captureReceiptCyclesEach':375,'releaseRenderPassed':True,'asanRenderPassed':True,'renderMonitorFramesEach':96123,'renderReceiptCyclesEach':376,'allNativeCyclesCodecRoundtrip':True,'auditedCallbackAllocateFreeLock':0,'physicalDevices':False},'windows':json.loads((r/'windows-qualification.json').read_text()),'previousCi':{'pr':160,'run':38304377056,'head':'41547abcc8cc6d76eb08829958029b6a3970aeef','jobs':'All4success original run','linux':'146/360.90s','desktop':'20/75.43s','native':'73/226.77s','additionalOwnerDiagnostics':'All3complete20takes, original5sdeadline','historicalFailuresCausallyResolved':False},'persistence':'Versioned bounded codec only; no completed project journal/checkpoint/recovery binding or complete native UI adapter','payloadPolicy':'Text/log/configuration/metadata and local binary hashes only; no binaries/audio/ZIP','members':members}
(d/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for name,row in members.items():
 b=(d/name).read_bytes();assert sha(b)==row['sha256'];raw=gzip.decompress(b);assert sha(raw)==row['originalSha256'] and len(raw)==row['originalBytes']
print('Verified',len(members),'bound text/log/metadata members; all807 qualified inputs unchanged')
