set -eu
cd /home/preview
xdotool mousemove 423 438 click 1
sleep .3
import -window root applied-review.png
xdotool mousemove 688 438 click 1
sleep .2
window=$(head -n1 window-id.txt)
xdotool windowfocus "$window" mousemove 800 200 click 1 key ctrl+s
sleep .4
cp project-été-Κиїв/project.json applied-project.json
import -window root applied.png
xdotool key ctrl+z
sleep .3
xdotool key ctrl+s
sleep .4
cp project-été-Κиїв/project.json undone-project.json
import -window root undone.png
xdotool key ctrl+shift+z
sleep .3
xdotool key ctrl+s
sleep .4
cp project-été-Κиїв/project.json redone-project.json
import -window root redone.png
