set -eu
cd /home/preview
xdotool mousemove 688 438 click 1
window=$(head -n1 reopened-window-id.txt)
xdotool windowfocus "$window" key ctrl+shift+e
sleep .3
xdotool mousemove 500 161 click 1 key ctrl+a type --clearmodifiers /home/preview/reopened.wav
import -window root reopened-export-dialog.png
xdotool mousemove 721 492 click 1
n=0
while test ! -f reopened.wav && test "$n" -lt 200; do n=$((n+1)); sleep .02; done
test -f reopened.wav
sleep .3
import -window root reopened-exported.png
cmp project-été-Κиїв-mix.wav reopened.wav
xdotool windowfocus "$window" key ctrl+q
