set -eu
cd /home/preview
xdotool mousemove 721 492 click 1
n=0
while test ! -f project-été-Κиїв-mix.wav && test "$n" -lt 200; do n=$((n+1)); sleep .02; done
test -f project-été-Κиїв-mix.wav
sleep .3
import -window root exported.png
cp project-été-Κиїв/project.json before-reopen-project.json
sha256sum project-été-Κиїв/media/raw-été.wav > raw-before-reopen.sha256
window=$(head -n1 window-id.txt)
xdotool windowfocus "$window" key ctrl+q
n=0
while test ! -f reopened-ready && test "$n" -lt 300; do n=$((n+1)); sleep .02; done
test -f reopened-ready
cmp before-reopen-project.json project-été-Κиїв/project.json
window=$(head -n1 reopened-window-id.txt)
xdotool windowfocus "$window" mousemove 460 344 click 1 key Down Return
xdotool mousemove 420 594 click 1
sleep .2
import -window root reopened-stretch.png
