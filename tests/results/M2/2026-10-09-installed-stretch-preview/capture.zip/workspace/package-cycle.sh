#!/bin/sh
set -eu
cd /home/preview
dpkg -i package.deb > cycle-install.log 2>&1
find project-été-Κиїв -type f -exec sha256sum {} + | sort > cycle-data-before.sha256
sha256sum project-été-Κиїв-mix.wav reopened.wav >> cycle-data-before.sha256
dpkg --remove soundcurrent-daw > cycle-remove.log 2>&1
test ! -e /usr/bin/soundcurrent-daw
test ! -e /usr/bin/sc-stretch-render-worker
find project-été-Κиїв -type f -exec sha256sum {} + | sort > cycle-data-after.sha256
sha256sum project-été-Κиїв-mix.wav reopened.wav >> cycle-data-after.sha256
cmp cycle-data-before.sha256 cycle-data-after.sha256
dpkg -i package.deb > cycle-reinstall.log 2>&1
test -x /usr/bin/soundcurrent-daw
test -x /usr/bin/sc-stretch-render-worker
sha256sum /usr/bin/soundcurrent-daw /usr/bin/sc-stretch-render-worker > cycle-reinstalled-binaries.sha256
setpriv --reuid=1000 --regid=1000 --init-groups --bounding-set=-all --inh-caps=-all --ambient-caps=-all --no-new-privs env QT_QPA_PLATFORM=offscreen HOME=/home/preview XDG_RUNTIME_DIR=/home/preview/run /usr/bin/soundcurrent-daw --version > cycle-reinstalled-version.txt 2>&1
