#!/bin/sh
set -eu
cd /home/preview
dpkg-query -W -f='${Version}\n' soundcurrent-daw > prior-version.txt
dpkg -i package.deb > install.log 2>&1
dpkg-query -W -f='${Version}\n' soundcurrent-daw > installed-version.txt
sha256sum /usr/bin/soundcurrent-daw /usr/bin/sc-stretch-render-worker /usr/bin/sc-import-inspect-worker /usr/bin/sc-approved-wave-probe /usr/bin/sc-media-import-worker > installed-binaries.sha256
command -v g++ || true
exec setpriv --reuid=preview --regid=preview --init-groups --bounding-set=-all --inh-caps=-all --ambient-caps=-all --no-new-privs /usr/bin/dbus-run-session /bin/sh /home/preview/user-launch.sh
