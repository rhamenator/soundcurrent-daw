set -eu
cd /home/preview
window=$(head -n1 window-id.txt)
xdotool windowfocus "$window"
xdotool mousemove 460 344 click 1 key Down Return
sleep .2
xdotool mousemove 420 594 click 1
sleep .3
xdotool search --onlyvisible --name '^Clip pitch and stretch' > dialog-id.txt
import -window root stretch-opened.png
