set -eu
cd /home/preview
window=$(head -n1 dialog-id.txt)
xdotool windowfocus "$window"
xdotool mousemove 540 122 click 1 key ctrl+a type --clearmodifiers '3'
xdotool mousemove 540 151 click 1 key ctrl+a type --clearmodifiers '2'
xdotool mousemove 540 180 click 1 key ctrl+a type --clearmodifiers '7.00007'
xdotool mousemove 238 206 click 1
import -window root before-render.png
(
  n=0
  while test "$n" -lt 1000; do
    pid=$(pgrep -f '^/usr/bin/sc-stretch-render-worker' | head -n1 || true)
    if test -n "$pid" && test -r "/proc/$pid/status"; then
      echo "$pid" > helper-pid.txt
      cat "/proc/$pid/status" > helper-status.txt
      tr '\000' '\n' < "/proc/$pid/cmdline" > helper-command.txt
      readlink "/proc/$pid/exe" > helper-executable.txt
      exit 0
    fi
    n=$((n+1)); sleep .001
  done
  exit 1
) &
observer=$!
xdotool mousemove 290 438 click 1
wait "$observer"
sleep 1
import -window root render-verified.png
test "$(find project-été-Κиїв/media/derived -name complete.json | wc -l)" -eq 1
