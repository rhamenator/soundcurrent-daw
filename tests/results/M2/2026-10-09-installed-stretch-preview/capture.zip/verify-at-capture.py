from pathlib import Path
import hashlib,json,struct,math,subprocess,zipfile,datetime
base=Path('.cache/stretch-installed-overlay');w=base/'workspace';pkg=Path('.cache/stretch-preview-package-20261009220811');sha=lambda b:hashlib.sha256(b).hexdigest()
def load(n):return json.loads((w/n).read_bytes())
def wave(p):
 b=p.read_bytes();assert b[:4] in (b'RIFF',b'RF64') and b[8:12]==b'WAVE';o=12;fmt=None;data=None;d64=None
 while o+8<=len(b):
  tag,n=struct.unpack_from('<4sI',b,o);o+=8
  if tag==b'ds64':d64=struct.unpack_from('<QQQ',b,o)
  if tag==b'data' and n==0xffffffff:assert d64;n=d64[1]
  assert o+n<=len(b)
  chunk=b[o:o+n]
  if tag==b'fmt ':fmt=struct.unpack_from('<HHIIHH',chunk);assert fmt[0]==3 or (fmt[0]==65534 and struct.unpack_from('<I',chunk,24)[0]==3)
  if tag==b'data':assert data is None;data=chunk
  o+=n+(n&1)
 assert o==len(b) and fmt and data is not None
 assert fmt[5]==32 and fmt[4]==fmt[1]*4 and fmt[3]==fmt[2]*fmt[4]
 samples=struct.unpack('<'+'f'*(len(data)//4),data);assert all(math.isfinite(s) for s in samples)
 return {'channels':fmt[1],'rate':fmt[2],'frames':len(data)//fmt[4],'peak':max(abs(s) for s in samples),'fileSha256':sha(b),'sampleSha256':sha(data)},data
initial=load('initial-project.json');applied=load('applied-project.json');undone=load('undone-project.json');redone=load('redone-project.json');reopened=load('project-été-Κиїв/project.json')
assert undone==initial and redone==applied and reopened==applied
assert (w/'before-reopen-project.json').read_bytes()==(w/'project-été-Κиїв/project.json').read_bytes()
clip=applied['tracks'][0]['clips'][0];anchor=clip['stretch'];assert clip['lengthFrames']==12288
assert anchor['settings']=={'timeNumerator':3,'timeDenominator':2,'pitchMilliCents':700007,'formantPreserved':True}
assert anchor['sourceOrigin']=={'frame':17,'fraction':1,'denominator':2,'algorithm':'soundcurrent.src-positioned-best-v1'} and anchor['sourceFrames']==8192
assert initial['assets'][0]==applied['assets'][0] and len(applied['assets'])==2
raw,rawdata=wave(w/'project-été-Κиїв/media/raw-été.wav');assert raw['fileSha256']==anchor['sourceSha256']==initial['assets'][0]['sha256']
asset=applied['assets'][1];derived,dd=wave(w/'project-été-Κиїв'/asset['path']);marker=load(str(Path('project-été-Κиїв')/asset['path']).replace('audio.wav','complete.json'))
assert marker['complete'] is True and marker['audioSha256']==derived['fileSha256']==asset['sha256'] and marker['sampleSha256']==derived['sampleSha256']
assert derived['frames']==marker['writtenFrames']==marker['target']==12288 and derived['channels']==2 and derived['rate']==48000 and derived['peak']>1
assert marker['first']==17 and marker['firstFraction']==1 and marker['firstDenominator']==2 and marker['sourceSha256']==raw['fileSha256']
export,ed=wave(w/'project-été-Κиїв-mix.wav');again,ad=wave(w/'reopened.wav');assert dd==ed==ad and export==again
assert (w/'project-été-Κиїв-mix.wav').read_bytes()==(w/'reopened.wav').read_bytes()
for n in ['first-exit.txt','second-exit.txt']:assert (w/n).read_text().strip()=='0'
for n in ['user-process-status.txt','helper-status.txt']:
 s=(w/n).read_text();assert 'CapEff:\t0000000000000000' in s and 'NoNewPrivs:\t1' in s and 'Uid:\t1000\t1000\t1000\t1000' in s
assert (w/'helper-executable.txt').read_text().strip()=='/usr/bin/sc-stretch-render-worker'
assert '--memory-mib\n256' in (w/'helper-command.txt').read_text()
for n in ['graph-before.json','graph-after-first.json','graph-after.json']:
 nodes=[x['info']['props']['node.name'] for x in load(n) if x['type']=='PipeWire:Interface:Node'];assert sorted(nodes)==sorted(['sc-preview-source','sc-preview-sink','Dummy-Driver','Freewheel-Driver'])
assert (w/'cycle-data-before.sha256').read_bytes()==(w/'cycle-data-after.sha256').read_bytes()
receipt=json.loads((pkg/'receipt.json').read_bytes());assert sha((w/'package.deb').read_bytes())==receipt['artifacts'][(w/'package.deb').resolve().name if False else next(k for k in receipt['artifacts'] if k.endswith('.deb'))]['sha256']
installed=dict((line.split()[1],line.split()[0]) for line in (w/'installed-binaries.sha256').read_text().splitlines());assert installed['/usr/bin/soundcurrent-daw']==receipt['packaged_executable_sha256']
for name,digest in installed.items():
 if name!='/usr/bin/soundcurrent-daw':assert digest==receipt['install_input_sha256'][name.lstrip('/')]
for line in (w/'cycle-reinstalled-binaries.sha256').read_text().splitlines():h,n=line.split();assert installed[n]==h
prior=subprocess.check_output(['sudo','-n','dpkg-query','--admindir='+str(Path('.cache/preview-fresh-runtime/rootfs/var/lib/dpkg').resolve()),'-W','-f=${Version}\n','soundcurrent-daw'],text=True).strip();assert prior==(w/'prior-version.txt').read_text().strip()
assert not Path('/proc/1972408').exists()
for p in base.glob('*-command.json'):assert json.loads(p.read_bytes())['exit_code']==0
out=base/'qualification.json';out.write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceCommit':receipt['source_head'],'sourceTree':receipt['source_tree'],'packageSha256':sha((w/'package.deb').read_bytes()),'version':(w/'installed-version.txt').read_text().strip(),'priorVersion':prior,'raw':raw,'derived':derived,'export':export,'exactPcmEquality':True,'repeatedExportByteEquality':True,'undoRedoSemanticEquality':True,'reopenedSavedByteEquality':True,'packageManagerUpgradeRemoveReinstall':True,'userMediaPreservedOnRemove':True,'normalQuitExits':[0,0],'normalUserHelperCapabilities':0,'physicalAudio':False,'vmStarted':False,'hostPackageInstalled':False,'fullParity':False,'limitations':['Owned synthetic media only; isolated Ubuntu Base overlay with private PipeWire and Xvfb','No physical endpoint, listening, hard real-time, Windows installed, or release qualification']},indent=2)+'\n')
print('Installed render/apply/Undo/Redo/reopen/export/remove/reinstall independently verified; peak',derived['peak'])
