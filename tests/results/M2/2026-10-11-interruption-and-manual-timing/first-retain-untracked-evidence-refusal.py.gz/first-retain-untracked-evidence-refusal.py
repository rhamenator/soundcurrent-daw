from pathlib import Path
import json,hashlib,gzip,subprocess,re
r=Path('.cache/parent-interruption-timing');out=Path('tests/results/M2/2026-10-11-interruption-and-manual-timing');f=json.loads((r/'frozen-inputs.json').read_text());initial=json.loads((r/'initial-probe-frozen-inputs.json').read_text());probe=json.loads((r/'initial-probe-qualified-linux.json').read_text());manual=json.loads((r/'qualified-manual.json').read_text());win=json.loads((r/'windows-manual-qualification.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==f['source'] and not subprocess.check_output(['git','status','--porcelain'],text=True)
assert len(f['selectedInputs'])==780 and manual['source']==win['source']==f['source'] and probe['source']==initial['source']
for x in f['selectedInputs']:assert sha(x['path'])==x['checkoutSha256']
changed=[x['path']for x in initial['selectedInputs'] if sha(x['path'])!=x['checkoutSha256']];assert changed==['tests/manual_recording_tests.cpp']
# The final followup changed only the unrelated manual fixture and the source
# inventory. No compiled probe/worker/library dependency changed between epochs.
delta=subprocess.check_output(['git','diff','--name-only',initial['source'],f['source']],text=True).splitlines();assert delta==['localization/source-inventory.json','tests/manual_recording_tests.cpp']
for n,h in probe['exeHashes'].items():assert sha(r/'build-release'/n)==h
for n,x in probe['currentObjects'].items():assert sha(r/'build-release'/n)==x['sha256']
for n,h in probe['privateArchives'].items():assert sha(r/'build-release'/n)==h
for x in probe['readOnlyArchives'].values():assert sha(x['path'])==x['sha256']
assert set(manual['profiles'])=={'release','sanitizer','tsan'}
names=['freeze-inputs.py','qualify-linux.py','qualify-manual.py','qualify-windows-manual.py','qualify-probe-clock.py','retain.py','frozen-inputs.json','initial-probe-frozen-inputs.json','qualified-linux.json','initial-probe-qualified-linux.json','qualified-manual.json','windows-manual-qualification.json','qualification-commands.json','manual-qualification-commands.json','qualification.log','manual-qualification.log','generated-commands.txt','CMakeCache.txt','original-linux-interruption.log','LastTest.log','clock-tests.log','probe-clock-runtime.json','probe-clock-runtime.log','windows-current-manual.log','windows-qualification.log','catalog-update.log','catalog-refusals.log','original-assertion-audit.json','manual-original-call-audit.json']
names += ['compile-'+str(n)+'.log'for n in range(9)]+['configure.log','link-0.log','link-1.log']
for n in probe['privateArchives']:names += [n+'-archive.log',n+'-index.log']
times={}
for label,p in manual['profiles'].items():
 b=r/('manual-'+label);assert sha(b/'sc-manual-recording-tests')==p['exeSha256']
 for n,x in p['objects'].items():assert sha(b/n)==x['sha256']
 for x in p['readOnlyArchives'].values():assert sha(x['path'])==x['sha256']
 names += ['manual-'+label+'-'+n+'.log'for n in ['configure','compile-0','compile-1','link','tests','standalone','LastTest']]+['manual-'+label+'-generated-commands.txt','manual-'+label+'-CMakeCache.txt']
 log=(r/('manual-'+label+'-LastTest.log')).read_text();assert log.count('manual_case begin=')==log.count('manual_case end=')==22 and '"rt_violations":0' in log
 times[label]=float(re.search(r'Total Test time \(real\) =\s+([0-9.]+)',(r/('manual-'+label+'-tests.log')).read_text())[1])
assert sha(r/'windows-current-manual.obj')==win['objectSha256']
for p in (r/'first-manual-retention-count-refusal').iterdir():names.append(str(p.relative_to(r)))
out.mkdir(exist_ok=False);members={}
for n in sorted(set(names)):
 raw=(r/n).read_bytes();data=gzip.compress(raw,mtime=0);dest=n.replace('/','--')+'.gz';(out/dest).write_bytes(data);members[dest]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'originalBytes':len(raw),'originalSha256':hashlib.sha256(raw).hexdigest(),'lossless':True}
summary={'source':f['source'],'tree':f['tree'],'sourceInputs':780,'probeOriginalSource':initial['source'],'probeInputsUnchangedAtFinalExceptUnrelatedManualFixture':True,'probeCurrentGeneratedObjects':9,'linuxOriginalFourInterruptionCasesSeconds':7.43,'cppProbeTimestampDomainRuntimeVerified':True,'pythonObservationChecks':16,'manualOriginalCases':22,'manualTestTimesSeconds':times,'manualThreeOriginalStandaloneCompletions':True,'guardedViolations':0,'windowsManualCurrentObjectCompiled':True,'windowsTimingDriverExecuted':False,'originalWatchdogSeconds':5,'originalManualOuterCtestSeconds':60,'originalManualConcurrentTakes':20,'uiInventoryAddedSourceFiles':3,'catalogs':34,'catalogSourceKeys':917,'catalogRefusalWorkflows':13,'nativeLanguageReviewOrUiQualificationPromoted':False,'productionWorkerControllerOrDeadlinesChanged':False,'binariesOrMediaIncluded':False,'fullGoalComplete':False}
raw=(json.dumps(summary,indent=2)+'\n').encode();(out/'summary.json').write_bytes(raw);members['summary.json']={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()};(out/'manifest.json').write_text(json.dumps({'members':members,'scope':'Original interruption and manual acceptance cases with bounded observation/case timings and UI source-inventory repair; exact source epochs/commands/logs/config/hashes; no binary/audio'},indent=2)+'\n');print('Retained215',len(members),'bound files',sum(p.stat().st_size for p in out.iterdir()),'bytes')
