from pathlib import Path
import subprocess,json,time,os,signal,hashlib,uuid
r=Path('.cache/parent-interruption-timing');b=(r/'build-release').resolve();d=(r/('probe-clock-'+str(uuid.uuid4()))).resolve();d.mkdir();root=d/'project-é-Κиїв';ticket=d/'boundary.json';prefix=['nice','-n','15','ionice','-c','2','-n','7'];probe=b/'sc-stretch-parent-probe';helper=b/'sc-stretch-render-worker'
subprocess.run(prefix+[str(probe),'--init',str(root)],check=True,timeout=10)
with (d/'parent.log').open('wb') as log:
 parent=subprocess.Popen(prefix+[str(probe),'--render',str(root),'after-complete',str(ticket),str(helper)],stdout=log,stderr=log)
 fd=os.pidfd_open(parent.pid)
 try:
  deadline=time.monotonic()+12
  while not ticket.exists():
   assert parent.poll() is None
   if time.monotonic()>=deadline:raise RuntimeError('Same owned probe did not publish within original observation budget')
   time.sleep(.001)
  boundary=json.loads(ticket.read_text());assert boundary['pid']==parent.pid and boundary['point']=='after-child-before-verification'
  t=boundary['timing'];assert t['steadyDomain']=='cpp-probe-steady-clock-ns' and t['utcDomain']=='cpp-probe-unix-utc-ns'
  assert 0<t['mainEntry']['probeSteadyNs']<=t['sourceReady']['probeSteadyNs']<=t['holdEntry']['probeSteadyNs']
  Path(str(ticket)+'.release').write_text('release\n');assert parent.wait(timeout=5)==0
 finally:
  if parent.poll() is None:signal.pidfd_send_signal(fd,signal.SIGKILL);parent.wait(timeout=5)
  os.close(fd)
result=subprocess.run(prefix+[str(probe),'--scan',str(root)],capture_output=True,text=True,check=True,timeout=10);scan=json.loads(result.stdout);assert scan['status']=='Ready' and scan['reviewed'] and not scan['attached']
t=scan['timing'];names=['mainEntry','sourceReady','controllerBegin','controllerReady','scanSubmitted','scanComplete','projectHashBegin','projectHashComplete','reportReady'];stamps=[t[n]['probeSteadyNs'] for n in names];assert all(isinstance(n,int) and n>0 for n in stamps) and stamps==sorted(stamps)
assert all(isinstance(t[n]['probeUtcNs'],int) and t[n]['probeUtcNs']>0 for n in names)
(r/'probe-clock-runtime.json').write_text(json.dumps({'platform':'Linux','boundary':boundary,'scan':scan,'sameCppDomainOrderingVerified':True,'utcNotUsedForDuration':True,'parentActuallyExited':parent.returncode,'probeSha256':hashlib.sha256(probe.read_bytes()).hexdigest(),'helperSha256':hashlib.sha256(helper.read_bytes()).hexdigest(),'audioEndpointActivated':False,'windowsDriverExecuted':False},indent=2)+'\n');print('Actual C++ probe boundary and scan timestamps validated in their own domain; no Windows timing execution claim',flush=True)
