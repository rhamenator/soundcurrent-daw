from pathlib import Path
import json,subprocess,hashlib
r=Path('.cache/parent-interruption-timing');f=json.loads((r/'frozen-inputs.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==f['source'] and not subprocess.check_output(['git','status','--porcelain'],text=True)
for x in f['selectedInputs']:assert sha(x['path'])==x['checkoutSha256']
obj=r/'windows-current-manual.obj';cmd=['nice','-n','15','ionice','-c','2','-n','7','x86_64-w64-mingw32-g++','-std=c++20','-O2','-Wall','-Wextra','-Wpedantic','-Wconversion','-DSC_NATIVE_PROCESSING_STAGES','-DSC_NATIVE_MANUAL_STAGES','-Iinclude','-Itests','-Isrc','-isystem','third_party','-isystem','third_party/libsndfile','-c','tests/manual_recording_tests.cpp','-o',str(obj)]
with (r/'windows-current-manual.log').open('w') as out:p=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
assert p.returncode==0 and 'warning:' not in (r/'windows-current-manual.log').read_text()
(r/'windows-manual-qualification.json').write_text(json.dumps({'source':f['source'],'tree':f['tree'],'argv':cmd,'objectBytes':obj.stat().st_size,'objectSha256':sha(obj),'nativeStagesCompiled':True,'windowsLinkExecuted':False,'windowsRuntimeExecuted':False,'windowsTimingDriverExecuted':False},indent=2)+'\n');print('Current original manual trace fixture Windows object warning-free; no new Windows timing execution claim',flush=True)
