from pathlib import Path
import subprocess,json,shlex,hashlib,shutil
r=Path('.cache/parent-interruption-timing');f=json.loads((r/'frozen-inputs.json').read_text());prior=json.loads(Path('.cache/native-monitor-eq/qualified-profiles.json').read_text());old=json.loads(Path('.cache/native-monitor-controller/frozen-inputs.json').read_text());head=f['source'];prefix=['nice','-n','15','ionice','-c','2','-n','7'];profiles={};commands=[]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
changed=set(subprocess.check_output(['git','diff','--name-only',old['source'],head],text=True).splitlines())
for x in old['selectedInputs']:
 if x['path'] not in changed:assert sha(x['path'])==x['checkoutSha256']
def checked():
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head and not subprocess.check_output(['git','status','--porcelain'],text=True)
 for x in f['selectedInputs']:assert sha(x['path'])==x['checkoutSha256']
for label,ctype,flags in [('release','Release',''),('sanitizer','Debug','-fsanitize=address,undefined -fno-omit-frame-pointer'),('tsan','Debug','-fsanitize=thread -fno-omit-frame-pointer -O1')]:
 b=(r/('manual-'+label)).resolve();archives={};objects={}
 def run(stage,argv,cwd=None):
  checked();cmd=prefix+argv;commands.append({'profile':label,'stage':stage,'argv':cmd,'cwd':str(cwd or Path.cwd())});(r/'manual-qualification-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
  with (r/('manual-'+label+'-'+stage+'.log')).open('w') as out:p=subprocess.run(cmd,cwd=cwd,stdout=out,stderr=subprocess.STDOUT)
  if p.returncode:raise SystemExit(label+' '+stage+' failed; original retained')
 print('Starting manual',label,flush=True)
 run('configure',['cmake','-S','.','-B',str(b),'-G','Ninja','-DCMAKE_BUILD_TYPE='+ctype,'-DSC_BUILD_DESKTOP=OFF','-DSC_BUILD_MEDIA=ON','-DCMAKE_CXX_FLAGS='+flags,'-DCMAKE_EXE_LINKER_FLAGS='+flags])
 gen=subprocess.check_output(['ninja','-C',str(b),'-t','commands','sc-manual-recording-tests'],text=True);(r/('manual-'+label+'-generated-commands.txt')).write_text(gen)
 for line in gen.splitlines():
  if ' -c ' not in line:continue
  argv=shlex.split(line);obj=argv[argv.index('-o')+1]
  if 'sc-manual-recording-tests.dir/' not in obj:continue
  (b/obj).parent.mkdir(parents=True,exist_ok=True);run('compile-'+str(len(objects)),argv,b);assert 'warning:' not in (r/('manual-'+label+'-compile-'+str(len(objects))+'.log')).read_text();objects[obj]={'sha256':sha(b/obj),'bytes':(b/obj).stat().st_size}
 assert len(objects)==2
 argv=shlex.split(next(x for x in gen.splitlines() if ' -o sc-manual-recording-tests ' in x))[2:-2]
 for n,a in enumerate(argv):
  if a.endswith('.a') and not Path(a).is_absolute():
   x=prior['profiles'][label]['readOnlyArchives'][a];assert sha(x['path'])==x['sha256'];argv[n]=x['path'];archives[a]=x
 run('link',argv,b);run('tests',['ctest','--test-dir',str(b),'-R','^manual-recording-control$','--output-on-failure','--no-tests=error'])
 run('standalone',[str(b/'sc-manual-recording-tests'),'--concurrent-owner-diagnostics'])
 assert '100% tests passed, 0 tests failed out of 1' in (r/('manual-'+label+'-tests.log')).read_text()
 shutil.copyfile(b/'Testing/Temporary/LastTest.log',r/('manual-'+label+'-LastTest.log'));shutil.copyfile(b/'CMakeCache.txt',r/('manual-'+label+'-CMakeCache.txt'))
 log=(r/('manual-'+label+'-LastTest.log')).read_text();assert log.count('manual_case begin=')==log.count('manual_case end=')==24 and '"rt_violations":0' in log
 assert 'original_concurrent_owner_diagnostic completed20takes; original5sdeadline; native_audio=false' in (r/('manual-'+label+'-standalone.log')).read_text()
 for x in archives.values():assert sha(x['path'])==x['sha256']
 profiles[label]={'objects':objects,'readOnlyArchives':archives,'exeSha256':sha(b/'sc-manual-recording-tests')}
 (r/'qualified-manual.json').write_text(json.dumps({'source':head,'tree':f['tree'],'profiles':profiles,'windowsRuntimeExecuted':False},indent=2)+'\n');print('Passed manual',label,flush=True)
print('All three manual profiles passed',flush=True)
