from pathlib import Path
import subprocess,json,shlex,hashlib,shutil,re
r=Path('.cache/parent-interruption-timing');f=json.loads((r/'frozen-inputs.json').read_text());prior=json.loads(Path('.cache/native-monitor-eq/qualified-profiles.json').read_text())['profiles']['release'];old=json.loads(Path('.cache/native-monitor-controller/frozen-inputs.json').read_text());head=f['source'];b=(r/'build-release').resolve();prefix=['nice','-n','15','ionice','-c','2','-n','7'];commands=[];objects={};borrowed={};private={}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
changed=set(subprocess.check_output(['git','diff','--name-only',old['source'],head],text=True).splitlines())
for x in old['selectedInputs']:
 if x['path'] not in changed:assert sha(x['path'])==x['checkoutSha256']
def checked():
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head and not subprocess.check_output(['git','status','--porcelain'],text=True)
 for x in f['selectedInputs']:assert sha(x['path'])==x['checkoutSha256']
def run(stage,argv,cwd=None):
 checked();cmd=prefix+argv;commands.append({'stage':stage,'argv':cmd,'cwd':str(cwd or Path.cwd())});(r/'qualification-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 with (r/(stage+'.log')).open('w') as out:p=subprocess.run(cmd,cwd=cwd,stdout=out,stderr=subprocess.STDOUT)
 if p.returncode:raise SystemExit(stage+' failed; original retained')
run('configure',['cmake','-S','.','-B',str(b),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DSC_BUILD_DESKTOP=ON','-DSC_BUILD_MEDIA=ON'])
gen=subprocess.check_output(['ninja','-C',str(b),'-t','commands','sc-stretch-parent-probe'],text=True);(r/'generated-commands.txt').write_text(gen)
# Fresh Qt/controller/recovery/protocol/vendor/worker/probe objects; only the
# previously qualified unchanged engine/media archives may be borrowed read-only.
for line in gen.splitlines():
 if ' -c ' not in line:continue
 argv=shlex.split(line);obj=argv[argv.index('-o')+1];target=obj.split('/')[1].replace('.dir','');lib='lib'+target+'.a'
 if lib in prior['readOnlyArchives']:continue
 (b/obj).parent.mkdir(parents=True,exist_ok=True);run('compile-'+str(len(objects)),argv,b);assert 'warning:' not in (r/('compile-'+str(len(objects))+'.log')).read_text();objects[obj]={'bytes':(b/obj).stat().st_size,'sha256':sha(b/obj)}
assert len(objects)==9
for line in gen.splitlines():
 if '/usr/bin/ar qc ' not in line:continue
 argv=shlex.split(line);at=argv.index('/usr/bin/ar');name=argv[at+2]
 if name in prior['readOnlyArchives']:continue
 members=[x for x in argv[at+3:] if x.endswith('.o')];assert members and all(x in objects for x in members)
 run(name+'-archive',['ar','r',name,*members],b);run(name+'-index',['ranlib',name],b);private[name]=sha(b/name)
for n,line in enumerate(x for x in gen.splitlines() if ' -o sc-stretch-parent-probe ' in x or ' -o sc-stretch-render-worker ' in x):
 argv=shlex.split(line)[2:-2]
 for k,a in enumerate(argv):
  if a.endswith('.a') and not Path(a).is_absolute() and a not in private:
   x=prior['readOnlyArchives'][a];assert sha(x['path'])==x['sha256'];borrowed[a]=x;argv[k]=x['path']
 run('link-'+str(n),argv,b)
run('clock-tests',['python3','tests/parent_observation_timing_tests.py'])
run('original-linux-interruption',['ctest','--test-dir',str(b),'-R','^desktop-stretch-parent-interruption$','--output-on-failure','--no-tests=error'])
assert '100% tests passed, 0 tests failed out of 1' in (r/'original-linux-interruption.log').read_text();shutil.copyfile(b/'Testing/Temporary/LastTest.log',r/'LastTest.log');shutil.copyfile(b/'CMakeCache.txt',r/'CMakeCache.txt')
for x in borrowed.values():assert sha(x['path'])==x['sha256']
(r/'qualified-linux.json').write_text(json.dumps({'source':head,'tree':f['tree'],'sourceInputs':len(f['selectedInputs']),'currentObjects':objects,'privateArchives':private,'readOnlyArchives':borrowed,'exeHashes':{n:sha(b/n)for n in ['sc-stretch-parent-probe','sc-stretch-render-worker']},'linuxFourOriginalInterruptionCasesPassed':True,'windowsDriverExecuted':False,'newWindowsObservationTimingQualified':False,'productionWorkerSourceChanged':False},indent=2)+'\n')
print('Nine fresh generated-command objects; original four Linux interruption cases PASS; Windows timing execution pending',flush=True)
