from pathlib import Path
import hashlib,json,os,subprocess,tempfile,time,zipfile
repo=Path.cwd();build=repo/'.cache/comp-pair-recovery/build';public=repo/'tests/results/M2/2026-10-14-comp-regeneration-plans'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
engine=json.loads((repo/'.cache/comp-regeneration-plans/qualified-c0fbw5c2/qualification.json').read_text())
engineSources={n:h for n,h in engine['sourceInputs'].items() if n.startswith(('src/','include/','third_party/'))};assert all(sha(repo/n)==h for n,h in engineSources.items())
engineBinaries={n:h for n,h in engine['binaryInputs'].items() if 'sc-ui-' not in Path(n).name and Path(n).name!='sc-comp-transition-ui-tests'};assert all(sha(Path(n))==h for n,h in engineBinaries.items())
files=[n for n in subprocess.check_output(['git','ls-files'],text=True).splitlines() if n.startswith(('ui/','localization/')) or n in ['tests/crossfade_ui_tests.cpp','tests/comp_transition_ui_tests.cpp','tests/comp_transition_ui_tests.py','tools/localization.py','CMakeLists.txt']]
sources={n:sha(repo/n) for n in files};binaryPaths=[build/'sc-crossfade-ui-tests',build/'sc-comp-transition-ui-tests']+sorted(build.glob('libsc-ui*.a'));binaries={str(p):sha(p) for p in binaryPaths}
scope=Path(tempfile.mkdtemp(prefix='layout-',dir=repo/'.cache/comp-regeneration-plans'));runs=build/'comp-transition-ui-evidence';before=set(runs.iterdir());env=dict(os.environ,QT_QPA_PLATFORM='offscreen',SC_CROSSFADE_CAPTURE=str(scope/'default-font'));processes=[]
def run(command,name,environment):
 start=time.monotonic()
 with (scope/(name+'.stdout')).open('w') as out,(scope/(name+'.stderr')).open('w') as err:
  p=subprocess.Popen(command,stdout=out,stderr=err,env=environment);code=p.wait()
 processes.append(dict(command=command,pid=p.pid,exitCode=code,seconds=time.monotonic()-start));assert code==0,(scope,name,code)
run(['ctest','--test-dir',str(build),'--output-on-failure','--no-tests=error','-R','^(desktop-comp-transition-create|desktop-paired-crossfade)$'],'tests',env)
(scope/'LastTest.log').write_bytes((build/'Testing/Temporary/LastTest.log').read_bytes())
fontEnv=dict(env,SC_CROSSFADE_FONT='DejaVu Sans',SC_CROSSFADE_FONT_POINTS='12',SC_CROSSFADE_CAPTURE=str(scope/'dejavu-12'))
run([str(build/'sc-crossfade-ui-tests')],'dejavu-12',fontEnv)
new=set(runs.iterdir())-before;assert len(new)==1;workflow=new.pop();report=json.loads((workflow/'report.json').read_text());rows=[c for r in report['reports'] for c in r['cases']]
assert len(rows)==8 and sum(r['checks'] for r in report['reports'])==180
assert all(p['exitCode']==0 for p in report['controllerProcesses']) and all(c['asynchronousClose'] for c in rows)
assert all(c['noAudioBeforeApply'] and c['undoRedoSaveReopen'] and all(p['reaped'] and p['exitCode']==0 for p in c['newChildren']) for c in rows if c['case']==0)
assert all(c['noChildLaunch'] for c in rows if c['case']!=0)
assert [c['exportFileSha256'] for c in rows if c['case']==0]==[r['adoption']['exportFileSha256'] for r in engine['report']['inputs']['reports']]
assert all(sha(repo/n)==h for n,h in sources.items()) and all(sha(Path(n))==h for n,h in binaries.items())
assert all(sha(repo/n)==h for n,h in engineSources.items()) and all(sha(Path(n))==h for n,h in engineBinaries.items())
receipt=dict(sourceHead=head,engineQualifiedHead=engine['sourceHead'],engineSourcesAndBinariesUnchanged=True,engineSources=engineSources,engineBinaries=engineBinaries,sources=sources,binaries=binaries,processes=processes,workflow=str(workflow),report=report,transitionCases=8,transitionChecks=180,exportFilesMatchEngineQualification=True,fonts=['application default','DejaVu Sans 12 pt'],sourceAndBinariesUnchanged=True,physicalAudio=False,nativeWindowsQualified=False,qualityAdmission=False)
(scope/'qualification.json').write_text(json.dumps(receipt,indent=2)+'\n');(scope/'qualify-layout.py').write_bytes(Path(__file__).read_bytes())
archive=public/'layout-acceptance.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for root,prefix in [(scope,''),(workflow,'workflow/')]:
  for p in sorted(root.rglob('*')):
   if p.is_file():z.write(p,prefix+p.relative_to(root).as_posix())
with zipfile.ZipFile(archive) as z:assert z.testzip() is None;entries={n:dict(bytes=len(z.read(n)),sha256=hashlib.sha256(z.read(n)).hexdigest()) for n in z.namelist()}
index={k:v for k,v in receipt.items() if k not in ['engineSources','engineBinaries','sources','binaries','report']};index['archive']=dict(bytes=archive.stat().st_size,sha256=sha(archive),entries=entries)
(public/'layout-index.json').write_text(json.dumps(index,indent=2)+'\n');print(json.dumps(dict(scope=str(scope),sourceHead=head,entries=len(entries),bytes=archive.stat().st_size,seconds=sum(p['seconds'] for p in processes))))
