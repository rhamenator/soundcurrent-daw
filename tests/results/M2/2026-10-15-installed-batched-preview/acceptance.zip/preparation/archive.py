from pathlib import Path
import hashlib,json,zipfile
r=Path(__file__).resolve().parent;repo=r.parents[1];dest=repo/'tests/results/M2/2026-10-15-installed-batched-preview';dest.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(p.read_text());files={};inventory=[]
q=load(r/'native-linux-test-qualification.json');assert q['exit_code']==0 and len(q['selected_tests'])==27
installed=load(r/'installed/qualification.json');assert installed['bitExactToIndependentReference'] and installed['normalQuitBothLaunches']
assert load(r/'installed/menu-qualification.json')['passed']
for p in r.iterdir():
 if p.is_file() and p.suffix in ['.py','.json','.log']:files['preparation/'+p.name]=p.read_bytes()
package=Path(load(r/'package-invocation.json')['output'])
for n in ['receipt.json','commands.json']:files['package/'+n]=(package/n).read_bytes()
for folder in q['new_evidence_runs']:
 root=Path(folder)
 for p in sorted(root.rglob('*')):
  if not p.is_file():continue
  n=root.parent.name+'/'+root.name+'/'+p.relative_to(root).as_posix();b=p.read_bytes();published=p.suffix in ['.json','.png','.stdout','.stderr']
  inventory.append(dict(path=n,bytes=len(b),sha256=sha(b),published=published))
  if published:files['workflow/'+n]=b
media=[]
for p in (r/'installed').rglob('*'):
 if not p.is_file() or 'preferences' in p.relative_to(r/'installed').parts or '__pycache__' in p.parts:continue
 n=p.relative_to(r/'installed').as_posix()
 if p.name=='active.json' or p.name in ['launch-driver.log','reopen-driver.log','menu-driver.log']:continue
 b=p.read_bytes()
 if p.suffix=='.wav':media.append(dict(path=n,bytes=len(b),sha256=sha(b)));continue
 if p.suffix not in ['.json','.png','.log','.py','.txt','.conf']:continue
 if p.name.endswith('-launch.json'):
  d=json.loads(b);d.pop('bus',None);d.pop('runtime',None);b=(json.dumps(d,indent=2)+'\n').encode()
 files['installed/'+n]=b
files['generated-workflow-inventory.json']=(json.dumps(inventory,indent=2)+'\n').encode()
files['installed-media-inventory.json']=(json.dumps(media,ensure_ascii=False,indent=2)+'\n').encode()
index={n:dict(bytes=len(b),sha256=sha(b)) for n,b in files.items()};files['payload-manifest.json']=(json.dumps(index,indent=2)+'\n').encode();a=dest/'acceptance.zip'
with zipfile.ZipFile(a,'x',zipfile.ZIP_DEFLATED) as z:
 for n,b in files.items():z.writestr(n,b)
with zipfile.ZipFile(a) as z:
 assert z.testzip() is None
 for n,v in index.items():assert len(z.read(n))==v['bytes'] and sha(z.read(n))==v['sha256']
report=dict(archive=a.name,bytes=a.stat().st_size,sha256=sha(a.read_bytes()),entries=len(files),sourceHead=q['source_head'],linuxTestsPassed=27,installedWorkflowPassed=True,normalApplicationsLauncherQualified=True,renderMilliseconds=installed['renderMilliseconds'],bitExactIndependentExport=installed['bitExactToIndependentReference'],sourceArchiveVerified=True,sourceArchiveFiles=load(r/'source-archive-verification.json')[0]['files'],binariesIncluded=False,privatePreferencesIncluded=False,physicalAudio=False,vmUsed=False,cleanInstallQualified=False)
(dest/'manifest.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
