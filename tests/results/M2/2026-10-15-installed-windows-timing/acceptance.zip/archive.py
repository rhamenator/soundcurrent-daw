from pathlib import Path
import hashlib,json,zipfile
r=Path(__file__).resolve().parent;repo=r.parents[1];scope=r/'observed/retired-340';out=repo/'tests/results/M2/2026-10-15-installed-windows-timing';out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));files={}
retirement=load(scope/'retirement.json');assert retirement['ownedProcessesRemaining']==0 and retirement['installedPayloadFilesVerified']==65 and retirement['earlierPreviewFilesVerified']>=334 and not retirement['nativeAudioActivated']
assert load(r/'cleanup.json')['allVmsOff'];assert load(r/'qualification.json')['bitExactToIndependentReference']
for p in scope.iterdir():
 if p.is_file():files['observed/'+p.name]=p.read_bytes()
for n in ['verify.py','archive.py','extract.py','qualification.json','cleanup.json','original-project.json','prepared-inputs.json','ci-status.json','verification.log']:
 files[n]=(r/n).read_bytes()
for n in ['begin.ps1','begin.cmd','workflow.ps1','collect.ps1']:
 files['setup/'+n]=(r/'iso'/n).read_bytes()
for p in (r/'ci').iterdir():
 if p.suffix in ['.json','.log']:files['ci/'+p.name]=p.read_bytes()
for p in (r/'native-parent-observations').glob('*.json'):files['native-parent-observations/'+p.name]=p.read_bytes()
for n in ['review-native.py','native-parent-review.json','ci-retention.log']:files[n]=(r/n).read_bytes()
baseArchive=repo/'tests/results/M2/2026-10-15-installed-portable-comp/acceptance.zip';baseHash=load(baseArchive.parent/'manifest.json')['sha256'];assert sha(baseArchive.read_bytes())==baseHash
original=repo/'.cache/installed-comp-323/app/project-été-Κиїв';target=scope/'project-été-Κиїв';members={}
for p in target.rglob('*'):
 if not p.is_file():continue
 n=str(p.relative_to(target));b=p.read_bytes();v=dict(bytes=len(b),sha256=sha(b))
 if (original/n).is_file() and (original/n).read_bytes()==b:v['baseProjectFile']=n
 else:v['entry']='project/'+n;files[v['entry']]=b
 members[n]=v
files['project-members.json']=(json.dumps(dict(baseArchive=str(baseArchive.relative_to(repo)),baseSha256=baseHash,baseProjectManifest='project-members.json',files=members),indent=2)+'\n').encode()
files['RECONSTRUCT.txt']=b'Reconstruct the checkpoint 323 base using its project-members.json and hash-pinned predecessor. For each file in project-members.json here, use baseProjectFile from that reconstructed base, or entry from this archive. Verify every byte count and SHA-256. Only owned synthetic media; never overlay a user project. observed/ contains final guest files including all earlier failure reports. verify.py is the original host-side checker and expects the original cache directory layout.\n'
captures=[]
for p in sorted((r/'received').glob('*.zip')):
 with zipfile.ZipFile(p) as z:assert z.testzip() is None
 captures.append(dict(name=p.name,bytes=p.stat().st_size,sha256=sha(p.read_bytes())))
files['original-captures.json']=(json.dumps(captures,indent=2)+'\n').encode()
# Transport credentials may be referenced by filename in scripts, never embedded.
private=load(r/'receiver-private.json')
def strings(v):
 if isinstance(v,dict):
  for k,x in v.items():
   if any(w in k.lower() for w in ['key','token','secret']):
    if isinstance(x,str) and len(x)>15:yield x
   else:yield from strings(x)
 elif isinstance(v,list):
  for x in v:yield from strings(x)
secrets=list(strings(private));assert secrets,'Expected transport key to screen'
for n,b in files.items():
 assert not any(s.encode() in b for s in secrets),n
 assert not any(w in n for w in ['private-transport','receiver-private','.iso','.exe']),n
index={n:dict(bytes=len(b),sha256=sha(b)) for n,b in files.items()};files['payload-manifest.json']=(json.dumps(index,indent=2)+'\n').encode()
p=out/'acceptance.zip'
with zipfile.ZipFile(p,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,b in files.items():z.writestr(n,b)
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 for n,v in index.items():assert sha(z.read(n))==v['sha256']
 for n,v in members.items():
  b=(original/v['baseProjectFile']).read_bytes() if 'baseProjectFile' in v else z.read(v['entry']);assert len(b)==v['bytes'] and sha(b)==v['sha256']
qualification=load(r/'qualification.json')
report=dict(archive=p.name,bytes=p.stat().st_size,sha256=sha(p.read_bytes()),entries=len(files),sourceHead='97e9ecdc32cfaddca03e4c8df9829fbdcb68c0aa',ciRun=38797374241,ciConclusion='success',originalFullJobLogsRetained=15,originalArtifactArchivesRetained=12,projectFiles=len(members),projectReconstructionVerified=True,windowsInstalledWorkflow=True,independentExportBitExact=True,originalRenderObservationMilliseconds=qualification['originalRenderObservationMilliseconds'],originalRenderWaitPassed=qualification['originalRenderWaitPassed'],renderMilliseconds=qualification['renderMilliseconds'],terminalElapsed=qualification['terminalElapsed'],elapsedFrozenAtTerminal=True,initialProtectedFailureUnresolved=True,applicationBinariesIncluded=False,credentialsIncluded=False)
(out/'manifest.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
