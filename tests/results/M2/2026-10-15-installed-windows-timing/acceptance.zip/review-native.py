from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parent;d=r/'native-parent-observations';load=lambda p:json.loads(p.read_text());report=load(d/'report.json');retention=load(r/'ci/retention.json')
assert retention['head']=='cae1cb1e805dc8cd03e0c0caf60bffe4814265d6' and retention['conclusion']=='success'
assert len(retention['jobs'])==15 and all(j['conclusion']=='success' for j in retention['jobs'])
expected={'before-ack':'Incomplete','during-processing':'Ready','during-processing-helper-death':'Incomplete','after-complete':'Ready'}
assert len(report['cases'])==4 and {c['stage'] for c in report['cases']}==set(expected)
rows=[]
for c in report['cases']:
 stage=c['stage'];cleanup=load(d/(stage+'-cleanup-report.json'))
 assert c['terminalRecovery']['status']==expected[stage]
 assert c['savedProjectAndRawUnchanged'] and not c['audioEndpointActivated']
 assert c['parentTerminal']['exitCode']==0x53430001
 assert cleanup['allOwnedTerminalsObserved'] and not cleanup['errors'] and not cleanup['primaryFailurePresent']
 if stage=='during-processing-helper-death':assert c['helperTerminal']['exitCode']==0x53430002
 elif stage=='during-processing':assert c['helperTerminal']['exitCode']==0
 elif stage=='before-ack':assert c['helperTerminal']['exitCode']==2
 e={v['event']:v['monotonicNs'] for v in c['timing']['events']}
 row=dict(stage=stage,recovery=expected[stage],cleanupErrors=cleanup['errors'],allOwnedTerminalsObserved=True)
 if 'partial-boundary-wait.end' in e:
  row['partialBoundaryWaitMilliseconds']=(e['partial-boundary-wait.end']-e['partial-boundary-wait.begin'])/1e6
  row['launchToPartialSuspensionMilliseconds']=(e['partial-suspension.begin']-e['parent-launch.begin'])/1e6
 rows.append(row)
result=dict(ciRun=retention['run'],sourceHead=retention['head'],artifact=12003432028,probeSha256=report['probeSha256'],helperSha256=report['helperSha256'],cases=rows,nativeSuccessfulCleanupQualified=True,originalMissedBoundaryCausallyResolved=False,originalProtectedFailureResolved=False)
(r/'native-parent-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
