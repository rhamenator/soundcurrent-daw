@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0begin.ps1"
pause
