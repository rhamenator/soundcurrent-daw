from pathlib import Path
import zipfile,sys,hashlib,json
base=Path(__file__).resolve().parent
for archive in (base/'received').glob('*.zip'):
 out=base/'observed'/archive.stem
 if out.exists():continue
 out.mkdir(parents=True)
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None
  names=[i.filename.replace('\\','/').split('/') for i in z.infolist()];prefix=names[0][0];assert all(n[0]==prefix for n in names)
  for item,parts in zip(z.infolist(),names):
   assert '..' not in parts and not item.filename.startswith(('/','\\'));p=out.joinpath(*parts[1:])
   if item.filename.endswith(('/','\\')):p.mkdir(parents=True,exist_ok=True)
   else:p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(item))
 print(archive.name,'SHA256',hashlib.sha256(archive.read_bytes()).hexdigest())
 for name in ['setup-result.json','workflow-result.json','continuation-result.json','retirement.json']:
  if (out/name).exists():print(name,(out/name).read_text(encoding='utf-8-sig'))
