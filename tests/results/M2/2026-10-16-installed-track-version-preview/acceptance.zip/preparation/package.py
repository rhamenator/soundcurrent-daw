from pathlib import Path
import json,subprocess,datetime
r=Path(__file__).resolve().parent;repo=r.parents[1];q=json.loads((r/'native-linux-test-qualification.json').read_text());assert q['exit_code']==0 and q['source_head']=='931289108e7396979264320c2b6f9040ff7aa364'
assert not (r/'package-invocation.json').exists(), 'Preserve an existing packaging attempt'
sequence=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d%H%M%S');output=repo/('.cache/p360-package-'+sequence)
args=['python3','tools/package_linux_preview.py','--build-dir',str(repo/'.cache/take-preview-linux/build'),'--qualification',str(r/'native-linux-test-qualification.json'),'--stretch-worker-qualification',str(r/'native-v4-worker.json'),'--protected-warp-qualification',str(r/'native-v5-worker.json'),'--output',str(output),'--preview-sequence',sequence,'--previous-version','0.1.0~preview.20261015223130.f2f9f7c8916e']
(r/'package-invocation.json').write_text(json.dumps(dict(sequence=sequence,output=str(output),argv=args),indent=2)+'\n')
with (r/'package.log').open('w') as f:subprocess.run(args,cwd=repo,stdout=f,stderr=subprocess.STDOUT,check=True)
print(output)
