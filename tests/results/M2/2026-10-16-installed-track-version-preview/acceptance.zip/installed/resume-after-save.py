from access import *
s=json.loads((Path(d['project'])/'project.json').read_text());clips=s['tracks'][0]['clips']
assert [c['startFrame'] for c in clips]==[10000,14000]
assert all(c['lengthFrames']==4000 and c['playbackRate']['numerator']==3 and c['playbackRate']['denominator']==2 for c in clips)
(base/'before-render.json').write_text(json.dumps(s,indent=2)+'\n')
snapshot('range-saved-confirmed')
click(find('Clip 2 · 4000 frames','combo box'));subprocess.run(['xdotool','key','Home','Down','Return'],check=True);time.sleep(.2)
click(find('Crossfade clips…','button'));time.sleep(.2);snapshot('crossfade-open')
print('Saved edits confirmed; opened crossfade without repeating edits',flush=True)
