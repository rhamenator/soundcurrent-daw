from access import *
original=json.loads((base/'applied.json').read_text());current=json.loads((Path(d['project'])/'project.json').read_text());assert current==original
snapshot('reopened');click(find('Export WAV…','menu item'));time.sleep(.4);snapshot('export-dialog')
output=(app/'edited-roundtrip.wav').resolve();assert not output.exists()
assert Atspi.EditableText.set_text_contents(find('WAV destination','text'),str(output))
assert Atspi.EditableText.set_text_contents(find('Start frame','text'),'0')
assert Atspi.EditableText.set_text_contents(find('End frame (exclusive)','text'),'18032')
snapshot('export-settings');click(find('Export','button'))
end=time.monotonic()+30
while time.monotonic()<end:
 if output.exists() and output.stat().st_size>100:break
 time.sleep(.1)
else:raise TimeoutError('Export did not publish')
time.sleep(.4);snapshot('exported')
save_project()
assert json.loads((Path(d['project'])/'project.json').read_text())==original
click(find('File','menu item'));time.sleep(.1);(app/'reopen-finish').touch();click(find('Quit','menu item'))
print('Reopened exact state, exported and public Quit requested',flush=True)
