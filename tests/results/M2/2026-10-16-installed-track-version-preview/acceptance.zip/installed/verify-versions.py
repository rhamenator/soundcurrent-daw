from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parent;load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
original=load(r/'versions-before.json');duplicate=load(r/'versions-duplicated.json');edited=load(r/'versions-edited.json');switched=load(r/'versions-switched.json')
assert len(original['tracks'])==len(duplicate['tracks'])==2
assert duplicate['schemaMajor']==1 and duplicate['schemaMinor']==25
newgroups={t['activeVersion']['groupId'] for t in duplicate['tracks']};oldgroups={t['inactiveVersions'][0]['groupId'] for t in duplicate['tracks']}
assert len(newgroups)==len(oldgroups)==1 and None not in newgroups|oldgroups and newgroups!=oldgroups
ids=set()
for initial,created in zip(original['tracks'],duplicate['tracks']):
 assert len(created['inactiveVersions'])==1
 assert created['inactiveVersions'][0]['clips']==initial['clips']
 assert created['inactiveVersions'][0]['name']=='Original'
 assert created['activeVersion']['name']=='Alternative été — Київ'
 assert {k:v for k,v in created.items() if k not in ['clips','activeVersion','inactiveVersions']}=={k:v for k,v in initial.items() if k!='clips'}
 for a,b in zip(initial['clips'],created['clips']):
  assert a['id']!=b['id']
  assert {k:v for k,v in a.items() if k!='id'}=={k:v for k,v in b.items() if k!='id'}
 for c in created['clips']+created['inactiveVersions'][0]['clips']:
  assert c['id'] not in ids;ids.add(c['id'])
assert edited['tracks'][0]['clips'][0]['processing']['muted'] is True
assert duplicate['tracks'][0]['clips'][0]['processing']['muted'] is False
expected=json.loads(json.dumps(duplicate));expected['tracks'][0]['clips'][0]['processing']['muted']=True
assert expected==edited
for initial,alternative,restored in zip(original['tracks'],edited['tracks'],switched['tracks']):
 assert restored['clips']==initial['clips']
 assert restored['activeVersion']=={k:v for k,v in alternative['inactiveVersions'][0].items() if k!='clips'}
 assert restored['inactiveVersions']==[dict(alternative['activeVersion'],clips=alternative['clips'])]
 assert {k:v for k,v in restored.items() if k not in ['clips','activeVersion','inactiveVersions']}=={k:v for k,v in initial.items() if k!='clips'}
assert load(r/'versions-undone.json')==edited
assert load(r/'versions-redone.json')==switched==load(r/'app/versions-été-Κиїв/project.json')
assert load(r/'versions-reopened.json')==switched
installation=load(r/'user-installation.json')
for tag in ['versions-edit','versions-reopen']:
 l=load(r/'app'/f'{tag}-launch.json')
 assert l['exit_code']==0 and l['quitRequestedByPublicMenuAction'] and not l['menu_launch']
 assert l['running_executable_sha256']==installation['payload_sha256']['usr/bin/soundcurrent-daw']
 assert not Path('/proc',str(l['pid'])).exists() and not Path('/proc',str(l['private_daemon_pid'])).exists()
for name,h in installation['payload_sha256'].items():assert sha(Path(installation['installation'])/name)==h
fixture=load(r/'versions-fixture-provenance.json')
assert all(sha(Path(fixture['source'])/n)==h for n,h in fixture['sourceFiles'].items())
assert all(sha(Path(fixture['target'])/n)==h for n,h in fixture['preparedFiles'].items() if n not in ['project.json','project.previous.json'])
assert load(Path(fixture['target'])/'project.previous.json')==switched
report=dict(sourceHead=installation['source_head'],version=installation['version'],groupedSaveReopenUndoRedo=True,tracks=2,distinctAlternativeEdit=True,groupIdentityPreserved=True,nonClipTrackStateUnchanged=True,immutableMediaUnchanged=True,normalQuitBothLaunches=True,originalOneTrackFixtureUnchanged=True,installedBytesUnchanged=True,physicalAudio=False,nativeWindows=False,allTrackTypesQualified=False)
(r/'versions-qualification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
