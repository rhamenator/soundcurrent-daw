from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parent;load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
i=load(r/'user-installation.json');l=load(r/'app/menu-launch.json');promotion=load(r/'launcher-promotion.json')
assert l['exit_code']==0 and l['menu_launch'] and l['quitRequestedByPublicMenuAction']
assert l['running_executable_sha256']==i['payload_sha256']['usr/bin/soundcurrent-daw']
assert sha(Path(promotion['launcher']))==promotion['launcherSha256']
assert all(sha(Path(i['installation'])/n)==h for n,h in i['payload_sha256'].items())
assert all(sha(Path(i['previous_installation'])/n)==h for n,h in load(r/'preserved-preview-before.json').items())
for tag in ['edit','reopen','versions-edit','versions-reopen','menu']:
 launch=load(r/'app'/f'{tag}-launch.json');assert launch['exit_code']==0
 assert not Path('/proc',str(launch['pid'])).exists() and not Path('/proc',str(launch['private_daemon_pid'])).exists()
assert load(r/'qualification.json')['bitExactToIndependentReference']
assert load(r/'versions-qualification.json')['groupedSaveReopenUndoRedo']
report=dict(passed=True,sourceHead=i['source_head'],version=i['version'],normalApplicationsLauncher=True,normalQuitAllFiveLaunches=True,allOwnedAppAndDaemonProcessesRetired=True,packagedPayloadUnchanged=True,previousPreviewPreserved=True,rollbackLauncher=promotion['rollbackLauncher'],physicalAudio=False,systemInstall=False,cleanInstallQualified=False)
(r/'menu-qualification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
