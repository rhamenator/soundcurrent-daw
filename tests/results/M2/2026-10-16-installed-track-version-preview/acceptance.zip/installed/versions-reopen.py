from access import *
s=json.loads((Path(d['project'])/'project.json').read_text());assert s==json.loads((base/'versions-switched.json').read_text())
click(find('Track versions…','button'));time.sleep(.2)
versions=find('Track versions','list');assert versions.get_child_count()==2
assert [versions.get_child_at_index(i).get_name() for i in range(2)]==['Original','Alternative été — Київ']
tracks=find('Tracks to change','list');assert tracks.get_child_count()==2
assert [tracks.get_child_at_index(i).get_name() for i in range(2)]==['Version Mic A — active: Original','Version Mic B — active: Original']
click(find('Select matching tracks','button'));assert Atspi.Selection.get_n_selected_children(tracks)==2
snapshot('versions-reopened-dialog');click(find('Cancel','button'));time.sleep(.2)
save_project()
assert json.loads((Path(d['project'])/'project.json').read_text())==s
(base/'versions-reopened.json').write_text(json.dumps(s,indent=2,ensure_ascii=False)+'\n')
click(find('File','menu item'));time.sleep(.1);(app/'versions-reopen-finish').touch();click(find('Quit','menu item'))
print('Grouped versions reopened intact, Unicode names and matching tracks confirmed',flush=True)
