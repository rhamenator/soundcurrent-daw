from access import *
click(find('Track versions…','button'));time.sleep(.3)
snapshot('versions-dialog-before')
tracks=find('Tracks to change','list')
assert tracks.get_child_count()==2 and tracks.get_child_at_index(0).get_name()=='Version Mic A — active: Original' and tracks.get_child_at_index(1).get_name()=='Version Mic B — active: Original'
assert Atspi.Selection.select_child(tracks,1)
assert Atspi.Selection.get_n_selected_children(tracks)==2
assert Atspi.EditableText.set_text_contents(find('Version name','text'),'Alternative été — Київ')
snapshot('versions-group-create-settings');click(find('Duplicate active','button'));time.sleep(.3)
save_project()
s=json.loads((Path(d['project'])/'project.json').read_text());assert s['schemaMinor']==25
assert len({t['activeVersion']['groupId'] for t in s['tracks']})==1
assert all(t['activeVersion']['name']=='Alternative été — Київ' for t in s['tracks'])
(base/'versions-duplicated.json').write_text(json.dumps(s,indent=2,ensure_ascii=False)+'\n')
snapshot('versions-duplicated')
print('Created grouped Unicode alternative on both tracks',flush=True)
