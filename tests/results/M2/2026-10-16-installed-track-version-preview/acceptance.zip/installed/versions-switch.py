from access import *
def save(name):
 save_project()
 s=json.loads((Path(d['project'])/'project.json').read_text());(base/(name+'.json')).write_text(json.dumps(s,indent=2,ensure_ascii=False)+'\n');return s
# The first clip is selected using the observed public combo before this step.
click(find('Clip gain and fades','check box'));time.sleep(.2)
muted=find('Mute clip','check box');assert not muted.get_state_set().contains(Atspi.StateType.CHECKED)
click(muted);click(find('Apply clip processing','button'));time.sleep(.2)
edited=save('versions-edited');assert edited['tracks'][0]['clips'][0]['processing']['muted']
click(find('Track versions…','button'));time.sleep(.2)
snapshot('versions-switch-dialog')
versions=find('Track versions','list');assert versions.get_child_count()==2
original=versions.get_child_at_index(1);assert original.get_name()=='Original'
# Public pointer input on the observed accessible row sets both current and selected.
extent=Atspi.Component.get_extents(original,Atspi.CoordType.SCREEN)
assert extent.width>0 and extent.height>0
subprocess.run(['xdotool','mousemove',str(extent.x+extent.width//2),str(extent.y+extent.height//2),'click','1'],check=True)
time.sleep(.2)
assert Atspi.Text.get_text(find('Version name','text'),0,-1)=='Original'
click(find('Select matching tracks','button'))
assert Atspi.Selection.get_n_selected_children(find('Tracks to change','list'))==2
snapshot('versions-switch-settings');click(find('Activate selected','button'));time.sleep(.2)
switched=save('versions-switched');assert all(t['activeVersion']['name']=='Original' for t in switched['tracks'])
click(find('Undo project edit','menu item'));time.sleep(.2);assert save('versions-undone')==edited
click(find('Redo project edit','menu item'));time.sleep(.2);assert save('versions-redone')==switched
snapshot('versions-redone-saved')
click(find('File','menu item'));time.sleep(.1);(app/'versions-edit-finish').touch();click(find('Quit','menu item'))
print('Two-track switch, exact Undo/Redo and Save passed; normal Quit requested',flush=True)
