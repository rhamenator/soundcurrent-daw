from access import *
s=json.loads((Path(d['project'])/'project.json').read_text());assert s==json.loads((base/'versions-switched.json').read_text())
tracks=find('Tracks to change','list');assert Atspi.Selection.get_n_selected_children(tracks)==2
snapshot('versions-reopened-dialog')
dialog=find('Track versions','dialog');cancels=[a for _,a in walk(dialog) if a.get_name()=='Cancel' and a.get_role_name()=='button'];assert len(cancels)==1
click(cancels[0]);time.sleep(.2);assert save_project()==s
(base/'versions-reopened.json').write_text(json.dumps(s,indent=2,ensure_ascii=False)+'\n')
click(find('File','menu item'));time.sleep(.1);(app/'versions-reopen-finish').touch();click(find('Quit','menu item'))
print('Reopened persisted groups, matching two-track selection, saved exact state; normal Quit requested',flush=True)
