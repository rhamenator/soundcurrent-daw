from pathlib import Path
import json,hashlib,shutil,copy,uuid
r=Path(__file__).resolve().parent;source=r/'app/project-été-Κиїв';target=r/'app/versions-été-Κиїв'
assert json.loads((r/'qualification.json').read_text())['reviewApplyUndoRedoSaveReopen']
assert not target.exists()
def inventory(root):
 result={}
 for p in root.rglob('*'):
  assert not p.is_symlink()
  if p.is_file():result[p.relative_to(root).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
 return result
before=inventory(source);shutil.copytree(source,target);assert inventory(target)==before
s=json.loads((target/'project.json').read_text());assert len(s['tracks'])==1 and s['master'] is None
s['tracks'][0]['name']='Version Mic A';other=copy.deepcopy(s['tracks'][0]);other['id']=str(uuid.uuid4());other['name']='Version Mic B';other['takeLanes']=[]
for processor in other['processors']:
 processor['id']=str(uuid.uuid4())
 for band in processor['bands']:band['id']=str(uuid.uuid4())
for clip in other['clips']:clip['id']=str(uuid.uuid4())
s['tracks'].append(other)
# Portable project copy keeps its project ID and immutable provenance. The new
# track owns fresh object/clip/processor IDs and shares immutable source assets;
# retained origins intentionally continue pointing to the first track's takes.
(target/'project.json').write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n')
(r/'versions-before.json').write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n')
(r/'versions-fixture-provenance.json').write_text(json.dumps(dict(source=str(source),target=str(target),sourceFiles=before,preparedFiles=inventory(target),sharedImmutableAssets=True),indent=2)+'\n')
assert inventory(source)==before
print('Prepared owned two-track version fixture; original project/media unchanged')
