from pathlib import Path
import json,hashlib,subprocess,os
r=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
i=load(r/'user-installation.json');q=load(r/'qualification.json');render=load(r/'render-observation.json')
assert load(r/'waveform-qualification.json')['missingRestoredMediaRetry']
assert load(r/'versions-qualification.json')['groupedSaveReopenUndoRedo']
assert q['bitExactToIndependentReference'] and q['normalQuitBothLaunches'] and render['elapsedFrozenAtTerminal']
launcher=Path(i['launcher']);old=(r/'previous-launcher.desktop.txt').read_bytes();assert launcher.read_bytes()==old and sha(launcher)==i['launcher_sha256']
prior=load(r/'preserved-launchers-before.json');assert all(sha(launcher.parent/n)==h for n,h in prior.items())
rollback=launcher.with_name('soundcurrent-daw-preview-before-track-versions-20261016.desktop');assert not rollback.exists()
rollback_text=old.decode().replace('Name=SoundCurrent DAW Preview\n','Name=SoundCurrent DAW Preview (before track versions)\n')
with rollback.open('x') as f:f.write(rollback_text)
new=old.decode().replace(i['previous_installation'],i['installation']);assert new!=old.decode()
temp=launcher.with_name('soundcurrent-daw-preview-candidate-360.desktop');assert not temp.exists()
with temp.open('x') as f:f.write(new);f.flush();os.fsync(f.fileno())
subprocess.run(['desktop-file-validate',str(temp),str(rollback)],check=True)
assert launcher.read_bytes()==old
os.replace(temp,launcher)
subprocess.run(['update-desktop-database',str(launcher.parent)],check=True)
assert all(sha(launcher.parent/n)==h for n,h in prior.items() if n!=launcher.name)
report=dict(sourceHead=i['source_head'],version=i['version'],launcher=str(launcher),launcherSha256=sha(launcher),previousLauncherSha256=i['launcher_sha256'],rollbackLauncher=str(rollback),rollbackLauncherSha256=sha(rollback),workflowPassedBeforePromotion=True,previousLaunchersUnchanged=True)
(r/'launcher-promotion.json').write_text(json.dumps(report,indent=2)+'\n')
(r/'promoted-launcher.desktop.txt').write_bytes(launcher.read_bytes());print(json.dumps(report))
