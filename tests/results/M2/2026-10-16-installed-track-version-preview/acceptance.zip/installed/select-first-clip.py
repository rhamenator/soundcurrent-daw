from access import *
click(find('Select a clip','combo box'))
subprocess.run(['xdotool','key','Home','Down','Return'],check=True);time.sleep(.2)
snapshot(sys.argv[1] if len(sys.argv)>1 else 'first-clip-selected')
assert any('Clip 1 ·' in a.get_name() for _,a in walk(root) if a.get_role_name()=='combo box')
print('Selected first clip using public combo',flush=True)
