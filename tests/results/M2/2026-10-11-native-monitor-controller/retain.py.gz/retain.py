from pathlib import Path
import json,hashlib,gzip,subprocess
r=Path('.cache/native-monitor-controller');out=Path('tests/results/M2/2026-10-11-native-monitor-controller');f=json.loads((r/'frozen-inputs.json').read_text());q=json.loads((r/'qualified-profiles.json').read_text());w=json.loads((r/'windows-qualification.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert f['source']==q['source']==w['source'] and len(f['selectedInputs'])==702 and set(q['profiles'])=={'release','sanitizer','tsan'}
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==f['source'] and not subprocess.check_output(['git','status','--porcelain'],text=True)
for x in f['selectedInputs']:assert sha(x['path'])==x['checkoutSha256']
names=['freeze-inputs.py','qualify.py','qualify-windows.py','retain.py','frozen-inputs.json','qualified-profiles.json','windows-qualification.json','qualification-commands.json','qualification.log','windows-qualification.log','source-delta.diff']
times={}
for label,p in q['profiles'].items():
 b=r/('qualified-'+label);assert sha(b/'sc-native-monitor-startup-tests')==p['exeSha256']
 for n,x in p['objects'].items():assert sha(b/n)==x['sha256']
 for x in list(p['readOnlyArchives'].values())+list(p['readOnlyObjects'].values()):assert sha(x['path'])==x['sha256']
 for n,h in p['privateArchives'].items():assert sha(b/n)==h
 names += [label+'-'+n+'.log' for n in ['configure','tests','LastTest','compile-0','compile-1','compile-2','sc-native-monitor-recording-archive','sc-native-monitor-recording-index','sc-native-monitor-controller-archive','sc-native-monitor-controller-index','link']]+[label+'-generated-commands.txt',label+'-CMakeCache.txt']
 import re
 times[label]=float(re.search(r'Total Test time \(real\) =\s+([0-9.]+)',(r/(label+'-tests.log')).read_text())[1])
 assert (r/(label+'-LastTest.log')).read_text().count('native_desktop_controller ')==3
names+=['windows-compile-'+str(n)+'.log'for n in range(4)]
for x in w['objects'].values():assert sha(x['argv'][-1])==x['sha256']
out.mkdir(exist_ok=False);members={}
for n in names:
 raw=(r/n).read_bytes();data=gzip.compress(raw,mtime=0);(out/(n+'.gz')).write_bytes(data);members[n+'.gz']={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'originalBytes':len(raw),'originalSha256':hashlib.sha256(raw).hexdigest(),'lossless':True}
summary={'source':f['source'],'tree':f['tree'],'sourceInputs':702,'linuxTestTimesSeconds':times,'currentObjectsPerLinuxProfile':3,'windowsCurrentObjects':4,'realControlProcessingDiskWorkers':True,'sdkOperationsSimulated':True,'queueCapacity':16,'urgentCancelAndResultRetention':True,'monitorEqAndRawBitExactReopen':True,'terminalWorkerFaultPublicationAcquiredBeforeRead':True,'nativeWindowsLinkOrRuntimeExecuted':False,'physicalEndpointsTested':False,'desktopPanelEnabled':False,'binariesOrMediaIncluded':False,'fullGoalComplete':False}
raw=(json.dumps(summary,indent=2)+'\n').encode();(out/'summary.json').write_bytes(raw);members['summary.json']={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()};(out/'manifest.json').write_text(json.dumps({'members':members,'scope':'Expanded existing native startup suite with real desktop control worker and simulated SDK; Linux Release/ASanUBSan/TSan and four current Windows objects; source/commands/config/logs/hashes only'},indent=2)+'\n');print('Retained controller',len(members),'bound files',sum(p.stat().st_size for p in out.iterdir()),'bytes')
