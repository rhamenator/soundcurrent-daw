from pathlib import Path
import datetime, hashlib, json, subprocess, shutil, sys, re
root=Path.cwd();label=sys.argv[1];build=root/sys.argv[2];folder=root/'.cache'/label;folder.mkdir()
source={}
for d in ['src','include','ui','tests']:
 for p in (root/d).rglob('*'):
  if p.is_file() and p.suffix in ['.cpp','.hpp','.h','.qrc']:
   name=str(p.relative_to(root));target=folder/'source'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target);source[name]=hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['CMakeLists.txt','third_party/nlohmann/json.hpp']:
 p=root/name;t=folder/'source'/name;t.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,t);source[name]=hashlib.sha256(p.read_bytes()).hexdigest()
exe={}
for p in build.glob('sc-*'):
 if p.is_file() and p.stat().st_mode&0o111:
  shutil.copy2(p,folder/p.name);exe[p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
cmd=['ctest','--test-dir',str(build),'--output-on-failure','--parallel','1']+sys.argv[3:]
launch={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_parent':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_sha256':source,'executable_sha256':exe,'command':cmd,'native_audio':False}
(folder/'launch.json').write_text(json.dumps(launch,indent=2)+'\n')
with (folder/'ctest.log').open('w') as out:r=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
shutil.copy2(build/'Testing/Temporary/LastTest.log',folder/'LastTest.log')
projects=build/'shared-media-projects'
if projects.exists():shutil.copytree(projects,folder/'generated-projects')
for original in re.findall(r'Retained offline export fixture: \"([^\"]+)\"',(folder/'LastTest.log').read_text()):
 p=Path(original);shutil.copytree(p,folder/'export-projects'/p.name)
launch['exit_code']=r.returncode;launch['ended_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(folder/'launch.json').write_text(json.dumps(launch,indent=2)+'\n')
print(json.dumps({'exit_code':r.returncode,'log':str(folder/'ctest.log')}));raise SystemExit(r.returncode)
