from pathlib import Path
import os,subprocess,tempfile,time,json,hashlib
r=Path('.cache/pipewire-monitor-capture');cfg=(r/'private-pipewire.conf').resolve()
with tempfile.TemporaryDirectory(prefix='sc-owned-native-pw-') as directory:
 os.chmod(directory,0o700);env=dict(os.environ,PIPEWIRE_RUNTIME_DIR=directory,XDG_RUNTIME_DIR=directory,PIPEWIRE_REMOTE='pipewire-0',SC_OWNED_PIPEWIRE_CAPTURE='1')
 with (r/'owned-daemon.log').open('w') as log:
  daemon=subprocess.Popen(['pipewire','-c',str(cfg)],env=env,stdout=log,stderr=subprocess.STDOUT)
  try:
   for _ in range(100):
    if daemon.poll() is not None:raise RuntimeError('Private daemon exited before socket readiness')
    if (Path(directory)/'pipewire-0').is_socket():break
    time.sleep(.02)
   else:raise RuntimeError('Private socket did not become ready')
   argv=['nice','-n','15','ionice','-c','2','-n','7',str((r/'release/sc-pipewire-monitor-capture-fixture').resolve())]
   with (r/'owned-runtime.log').open('w') as out:result=subprocess.run(argv,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=20)
   (r/'owned-runtime.json').write_text(json.dumps({'argv':argv,'fixtureExit':result.returncode,'privateDaemonPid':daemon.pid,'socketOwnerOnly':True,'configurationSha256':hashlib.sha256(cfg.read_bytes()).hexdigest(),'physicalDevices':False,'modules':'protocol-native/spa-node-factory/client-node/link-factory; dummy driver only','parentEnvironmentUnchanged':True},indent=2)+'\n')
   if result.returncode:raise RuntimeError('Owned native fixture failed; original log retained')
  finally:
   daemon.terminate()
   try:daemon.wait(timeout=5)
   except subprocess.TimeoutExpired:daemon.kill();daemon.wait(timeout=5)
print('Private daemon native fixture passed; owned daemon joined, no physical device routes')
