from pathlib import Path
import hashlib,json,gzip,subprocess
r=Path('.cache/pipewire-monitor-capture');d=Path('tests/results/M2/2026-10-12-pipewire-monitor-capture');d.mkdir(parents=True,exist_ok=True)
f=json.loads((r/'frozen-inputs.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
for x in f['selectedInputs']:assert sha(Path(x['path']).read_bytes())==x['checkoutSha256']
members={}
def put(name,b):
 p=d/(name+'.gz');p.parent.mkdir(parents=True,exist_ok=True);z=gzip.compress(b,mtime=0);p.write_bytes(z)
 members[name+'.gz']={'bytes':len(z),'sha256':sha(z),'originalBytes':len(b),'originalSha256':sha(b)}
for name in ['frozen-inputs.json','source-delta.diff','configure.log','release-build.log','release-tests.log','diagnostic-build.log','final-capture-build.log','final-capture-tests.log','domain-regression-build.log','final-build.log','final-tests.log','sanitizer-configure.log','sanitizer-build.log','sanitizer-tests.log','owned-runtime.log','owned-runtime.json','owned-wrapper.log','owned-daemon.log','sanitizer-owned-runtime.log','sanitizer-owned-runtime.json','sanitizer-owned-wrapper.log','sanitizer-owned-daemon.log','private-pipewire.conf','run-owned.py','run-owned-sanitizer.py','reference-inputs.json','windows-qualification.json','windows-qualification.log','freeze-inputs.py','qualify-windows.py','retain158.py']:
 put(name,(r/name).read_bytes())
for p in r.glob('windows-compile-*.log'):put(p.name,p.read_bytes())
for folder in ['initial-private-permission-failure','initial-native-fault','original-cycle-refusal']:
 for p in sorted((r/folder).iterdir()):
  if p.is_file():put(folder+'/'+p.name,p.read_bytes())
for p in sorted((r/'pr158-review').iterdir()):
 if p.is_file() and p.suffix in ['.json','.log']:put('preceding-pr158/'+p.name,p.read_bytes())
put('preceding-pr158/tested-merge.json',Path('.cache/native-take-admission/pr158-tested-merge.json').read_bytes())
hashes={}
for profile in ['release','sanitizer']:
 p=r/profile;put(profile+'-CMakeCache.txt',(p/'CMakeCache.txt').read_bytes());put(profile+'-LastTest.log',(p/'Testing/Temporary/LastTest.log').read_bytes());put(profile+'-generated-commands.log',subprocess.check_output(['ninja','-C',str(p),'-t','commands']))
 files=list(p.glob('*.a'))+[q for q in p.glob('sc-*-tests') if q.is_file()]+[p/'sc-pipewire-monitor-capture-fixture']
 hashes[profile]={str(q.relative_to(p)):{'bytes':q.stat().st_size,'sha256':sha(q.read_bytes())} for q in files}
put('build-output-hashes.json',json.dumps(hashes,indent=2).encode())
commands={'releaseRegex':'^(pipewire-monitor-planar-capture|original-monitor-clock-handoffs|wasapi-monitor-capture-binding|wasapi-monitor-render-binding|native-monitor-startup)$','sanitizerRegex':'^(pipewire-monitor-planar-capture|original-monitor-clock-handoffs)$','ctestArgs':['--output-on-failure','--parallel','1'],'sanitizerEnvironment':{'ASAN_OPTIONS':'detect_leaks=0:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'},'priority':['nice','-n','15','ionice','-c','2','-n','7'],'nativeFixture':'Explicit owned private-daemon wrapper, no CTest physical/default routes','configuration':'release/sanitizer cache and generated commands retained','windows':'Exact argv/object receipts in windows-qualification.json'}
put('qualification-commands.json',json.dumps(commands,indent=2).encode());put('package-evidence.py',Path(__file__).read_bytes())
summary={'implementation':f['source'],'tree':f['tree'],'sourceInputs':len(f['selectedInputs']),'release':{'passed':5,'tests':5,'seconds':19.66,'planarChecks':62657},'sanitizers':{'passed':2,'tests':2,'seconds':.11,'leakDetection':False},'ownedPipeWire':{'version':'1.6.2','releasePassed':True,'sanitizerPassed':True,'framesEach':96000,'channels':3,'packetsEach':375,'bitChecksEach':576000,'auditedCallbackAllocateFreeLock':0,'physicalDevices':False,'completeMonitorAdapter':False},'windows':json.loads((r/'windows-qualification.json').read_text()),'precedingCi':{'pr':158,'run':38295051968,'head':'1ab28cc7e5a1b4dde04cc045362e7ce5ceafefe6','linux':'144/367.91 seconds success','desktop':'20/79.15 seconds success; actual native-take admission','cross':'success','native':'cancelled after70/71 passes at15minute envelope; final test not qualified','alwaysRunDiagnostics':'2completed / third failed with retained capture pool exhaustion and command refusal; underlying cause unresolved'},'payloadPolicy':'Only text/logs/configuration/metadata and local binary hash receipts; no binaries/audio/ZIP','members':members}
(d/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for name,row in members.items():
 b=(d/name).read_bytes();assert sha(b)==row['sha256'];raw=gzip.decompress(b);assert sha(raw)==row['originalSha256'] and len(raw)==row['originalBytes']
print('Verified',len(members),'bound text/log/metadata members; all794 qualified inputs unchanged')
