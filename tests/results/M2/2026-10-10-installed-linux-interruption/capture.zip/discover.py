from pathlib import Path
import subprocess,json
p=Path('.cache/linux-installed-interruption');start=int((p/'launcher-pid.txt').read_text());expected=(p/'workspace/namespace-identity.txt').read_text();entries={}
for d in Path('/proc').iterdir():
 if d.name.isdigit():
  try:entries[int(d.name)]=int((d/'stat').read_text().rsplit(')',1)[1].split()[1])
  except OSError:pass
found=[]
for pid in entries:
 at=pid;seen=set()
 while at in entries and at not in seen and at!=start:seen.add(at);at=entries[at]
 if at!=start or pid==start:continue
 try:cmd=Path('/proc/'+str(pid)+'/cmdline').read_bytes()
 except OSError:continue
 if b'/home/preview/manager.py' not in cmd:continue
 exe=subprocess.check_output(['sudo','-n','readlink','/proc/'+str(pid)+'/exe'],text=True).strip()
 if not exe.endswith('/usr/bin/python3.14'):continue
 r=subprocess.run(['sudo','-n','cat','/proc/'+str(pid)+'/root/home/preview/namespace-identity.txt'],text=True,capture_output=True)
 if r.returncode==0 and r.stdout==expected:found.append(pid)
assert len(found)==1,found
(p/'namespace-target.txt').write_text(str(found[0])+'\n');print('Owned manager',found[0], 'GUI ready',(p/'workspace/ready-source').exists())
