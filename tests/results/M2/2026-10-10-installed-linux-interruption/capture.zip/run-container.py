from pathlib import Path
import subprocess,json,datetime
root=Path.cwd();folder=root/'.cache/linux-installed-interruption';work=folder/'workspace'
command=['sudo','-n','systemd-nspawn','--quiet','--console=pipe','--settings=no','--register=no','--as-pid2','--private-network','--timezone=off','--volatile=overlay','--machine=sc-render-interrupt-5300010','--directory='+str(root/'.cache/preview-fresh-runtime/rootfs'),'--bind='+str(work)+':/home/preview','--setenv=HOME=/home/preview','--setenv=LANG=C.UTF-8','--','/bin/sh','/home/preview/root-launch.sh']
(folder/'container-command.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'physicalAudioExposed':False,'hostPackageChanges':False},indent=2)+'\n')
with (folder/'container.log').open('x') as f:
 child=subprocess.Popen(command,stdout=f,stderr=subprocess.STDOUT)
 (folder/'launcher-pid.txt').write_text(str(child.pid)+'\n');result=child.wait()
(folder/'container-exit.json').write_text(json.dumps({'exit':result,'endedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()})+'\n')
raise SystemExit(result)
