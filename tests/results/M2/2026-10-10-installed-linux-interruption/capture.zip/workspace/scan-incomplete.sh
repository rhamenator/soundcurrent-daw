set -eu
cd /home/preview
python3.14 - <<'PYI'
import json,time
from pathlib import Path
w=Path('/home/preview');until=time.monotonic()+10
while not (w/'helper-exit.json').exists():
 assert time.monotonic()<until;time.sleep(.01)
r=json.loads((w/'helper-exit.json').read_text());assert r['exitCode']==-9
PYI
xdotool mousemove 342 467 click 1
sleep 1
xdotool mousemove 430 122 click 1
sleep .2
import -window root selected-incomplete.png
