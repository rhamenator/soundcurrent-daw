# SPDX-License-Identifier: GPL-3.0-only
import ctypes,datetime,json,os,signal,subprocess,time
from pathlib import Path
W=Path('/home/preview');os.chdir(W)
assert os.getuid()==1000 and not Path('/dev/snd').exists()
assert ctypes.CDLL(None).prctl(36,1,0,0,0)==0
os.environ.update(DISPLAY=':94',XDG_RUNTIME_DIR=str(W/'run'),XDG_CONFIG_HOME=str(W/'config'))
def write(n,d):
 p=W/n;t=W/(n+'.partial');t.write_text(json.dumps(d,indent=2)+'\n');t.rename(p)
def identity(pid):
 s=Path('/proc/'+str(pid)+'/stat').read_text().rsplit(')',1)[1].split()
 return {'pid':pid,'startTicks':int(s[19]),'parentPid':int(s[1]),'exe':os.readlink('/proc/'+str(pid)+'/exe'),'cmdline':Path('/proc/'+str(pid)+'/cmdline').read_bytes().decode().split('\0')[:-1]}
def wait_for(fn,seconds=15):
 deadline=time.monotonic()+seconds
 while True:
  x=fn()
  if x:return x
  if time.monotonic()>deadline:raise RuntimeError('Observation deadline expired; actual processes require cleanup')
  time.sleep(.01)
(W/'user-process-status.txt').write_text(Path('/proc/self/status').read_text())
services=[];apps=[];helper=None;helper_reaped=False
try:
 for name,args in [('pipewire',['pipewire','-c',str(W/'pipewire.conf')]),('xvfb',['Xvfb',':94','-screen','0','1280x720x24','-nolisten','tcp'])]:
  log=(W/(name+'.log')).open('wb');p=subprocess.Popen(args,stdout=log,stderr=log);services.append((p,log))
 time.sleep(1)
 with (W/'graph-before.json').open('wb')as f:subprocess.run(['pw-dump'],stdout=f,check=True,timeout=10)
 for stage in ['source','recovery']:
  log=(W/('app-'+stage+'.log')).open('wb');app=subprocess.Popen(['/usr/bin/soundcurrent-daw','--language','en',str(W/'project-été-Κиїв')],stdout=log,stderr=log);apps.append((app,log))
  wait_for(lambda:os.readlink('/proc/'+str(app.pid)+'/exe')=='/usr/bin/soundcurrent-daw')
  write('app-'+stage+'.json',identity(app.pid));(W/('app-'+stage+'-status.txt')).write_text(Path('/proc/'+str(app.pid)+'/status').read_text())
  time.sleep(2)
  window=subprocess.check_output(['xdotool','search','--onlyvisible','--pid',str(app.pid),'--name','^SoundCurrent DAW'],text=True).splitlines()[0]
  assert int(subprocess.check_output(['xdotool','getwindowpid',window],text=True))==app.pid
  (W/'window-id.txt').write_text(window+'\n');subprocess.run(['import','-window','root',str(W/('opened-'+stage+'.png'))],check=True)
  (W/('ready-'+stage)).touch();started=time.monotonic()
  while app.poll() is None:
   if stage=='recovery' and (W/'helper-observed.json').exists():
    helper=json.loads((W/'helper-observed.json').read_text())['pid']
    if not helper_reaped:
     found,status=os.waitpid(helper,os.WNOHANG)
     if found:write('helper-exit.json',{'pid':found,'waitStatus':status,'exitCode':os.waitstatus_to_exitcode(status)});helper_reaped=True
   if time.monotonic()-started>900:raise RuntimeError('Installed app session deadline expired')
   time.sleep(.01)
  write('app-'+stage+'-exit.json',{'pid':app.pid,'exitCode':app.returncode})
  assert app.returncode==(-9 if stage=='source' else 0)
  if stage=='source':assert (W/'helper-observed.json').exists()
 if not helper_reaped:
  helper=json.loads((W/'helper-observed.json').read_text())['pid'];found,status=os.waitpid(helper,0);write('helper-exit.json',{'pid':found,'waitStatus':status,'exitCode':os.waitstatus_to_exitcode(status)});helper_reaped=True
 with (W/'graph-after.json').open('wb')as f:subprocess.run(['pw-dump'],stdout=f,check=True,timeout=10)
 write('session-complete.json',{'apps':2,'helperReaped':True,'installedGuiInterruption':True,'audioEndpointActivated':False,'powerLossQualified':False})
finally:
 cleanup=[]
 for app,log in apps:
  if app.poll() is None:app.kill()
  cleanup.append({'kind':'app','pid':app.pid,'exitCode':app.wait(timeout=5)});log.close()
 if (W/'helper-observed.json').exists() and not helper_reaped:
  helper=json.loads((W/'helper-observed.json').read_text())['pid']
  try:
   fd=os.pidfd_open(helper);signal.pidfd_send_signal(fd,signal.SIGKILL);os.close(fd);found,status=os.waitpid(helper,0);cleanup.append({'kind':'helper','pid':found,'exitCode':os.waitstatus_to_exitcode(status)})
  except ProcessLookupError:pass
 for p,log in services:
  if p.poll() is None:p.terminate()
  cleanup.append({'kind':'service','pid':p.pid,'exitCode':p.wait(timeout=5)});log.close()
 write('manager-cleanup.json',cleanup)
