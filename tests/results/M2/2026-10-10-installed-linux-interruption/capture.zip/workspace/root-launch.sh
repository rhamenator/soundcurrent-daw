#!/bin/sh
set -eu
cd /home/preview
export DEBIAN_FRONTEND=noninteractive TZ=Etc/UTC
dpkg -i runtime-debs/libpython3.14-minimal_*.deb > python-install.log 2>&1
dpkg -i runtime-debs/python3.14-minimal_*.deb >> python-install.log 2>&1
dpkg -i runtime-debs/media-types_*.deb runtime-debs/netbase_*.deb runtime-debs/tzdata_*.deb >> python-install.log 2>&1
dpkg -i runtime-debs/libpython3.14-stdlib_*.deb runtime-debs/python3.14_*.deb >> python-install.log 2>&1
dpkg -i package.deb > install.log 2>&1
dpkg-query -W -f='${Version}\n' soundcurrent-daw > installed-version.txt
sha256sum /usr/bin/soundcurrent-daw /usr/bin/sc-stretch-render-worker > installed-binaries.sha256
for program in g++ clang++ cmake qmake6; do
 if command -v "$program" >> developer-tools.txt 2>/dev/null; then exit 31; fi
done
exec setpriv --reuid=preview --regid=preview --init-groups --bounding-set=-all --inh-caps=-all --ambient-caps=-all --no-new-privs /usr/bin/dbus-run-session /usr/bin/python3.14 /home/preview/manager.py
