set -eu
cd /home/preview
xdotool mousemove 540 32 click 1 key ctrl+a type 3
xdotool mousemove 540 62 click 1 key ctrl+a type 2
import -window root configured-source.png
python3.14 watch-helper.py > watcher.log 2>&1 &
watcher=$!
while test ! -f watcher-ready; do sleep .01; done
xdotool mousemove 210 630 click 1
wait "$watcher"
import -window root frozen-helper-source.png
