import os,sys,json,signal,time,datetime
from pathlib import Path
W=Path('/home/preview');kind=sys.argv[1];assert kind in ['parent','helper']
f='app-source.json'if kind=='parent'else'helper-observed.json';r=json.loads((W/f).read_text());pid=r['pid']
def ident():
 s=Path('/proc/'+str(pid)+'/stat').read_text().rsplit(')',1)[1].split();return {'pid':pid,'state':s[0],'startTicks':int(s[19]),'exe':os.readlink('/proc/'+str(pid)+'/exe'),'cmdline':Path('/proc/'+str(pid)+'/cmdline').read_bytes().decode().split('\0')[:-1]}
fd=os.pidfd_open(pid);i=ident();assert all(i[k]==r[k]for k in ['pid','startTicks','exe','cmdline'])
if kind=='helper':assert i['state']=='T'
signal.pidfd_send_signal(fd,signal.SIGKILL);os.close(fd)
(W/(kind+'-signal.json')).write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'identity':i,'signal':'SIGKILL','requestedOnly':True},indent=2)+'\n')
