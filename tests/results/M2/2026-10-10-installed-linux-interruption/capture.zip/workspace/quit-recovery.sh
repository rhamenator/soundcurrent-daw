set -eu
cd /home/preview
python3.14 - <<'PYI'
import json,hashlib
from pathlib import Path
w=Path('/home/preview');r=json.loads((w/'helper-observed.json').read_text());p=Path(r['job'])/'audio.partial'
assert p.stat().st_size==r['partialBytes']and hashlib.sha256(p.read_bytes()).hexdigest()==r['partialSha256']
assert not (p.parent/'audio.wav').exists()and not (p.parent/'complete.json').exists()
base=json.loads((w/'fixture-before.json').read_text());root=w/'project-été-Κиїв'
for n,d in base.items():
 b=(root/n).read_bytes();assert len(b)==d['bytes']and hashlib.sha256(b).hexdigest()==d['sha256']
(w/'fixture-after.json').write_text(json.dumps(base,indent=2)+'\n')
PYI
xdotool mousemove 760 467 click 1
xdotool windowfocus "$(head -n1 window-id.txt)" key ctrl+q
