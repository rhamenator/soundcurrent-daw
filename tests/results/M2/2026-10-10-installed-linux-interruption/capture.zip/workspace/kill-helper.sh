set -eu
cd /home/preview
python3.14 terminate-owned.py helper
