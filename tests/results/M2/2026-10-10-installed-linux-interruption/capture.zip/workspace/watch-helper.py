import os,json,time,signal,hashlib
from pathlib import Path
W=Path('/home/preview');parent=json.loads((W/'app-source.json').read_text())
def ident(pid):
 s=Path('/proc/'+str(pid)+'/stat').read_text().rsplit(')',1)[1].split()
 return {'pid':pid,'state':s[0],'parentPid':int(s[1]),'startTicks':int(s[19]),'exe':os.readlink('/proc/'+str(pid)+'/exe'),'cmdline':Path('/proc/'+str(pid)+'/cmdline').read_bytes().decode().split('\0')[:-1]}
def wait(fn):
 until=time.monotonic()+30
 while True:
  r=fn()
  if r:return r
  assert time.monotonic()<until,'Missed observed boundary';time.sleep(.001)
def candidates():
 result=[]
 for d in Path('/proc').iterdir():
  if not d.name.isdigit():continue
  try:i=ident(int(d.name))
  except OSError:continue
  if i['exe']=='/usr/bin/sc-stretch-render-worker' and i['parentPid']==parent['pid']:result.append(i)
 assert len(result)<=1
 return result[0]if result else None
(W/'watcher-ready').touch()
observed=wait(candidates);pid=observed['pid'];fd=os.pidfd_open(pid)
assert ident(parent['pid'])['startTicks']==parent['startTicks']
assert observed['cmdline'][2]==str(W/'project-été-Κиїв')
root=Path(observed['cmdline'][4]);assert root.is_relative_to(W/'project-été-Κиїв')
def partial():
 files=list(root.glob('*/audio.partial'));assert len(files)<=1
 return files[0]if files and files[0].stat().st_size>4096 else None
p=wait(partial);signal.pidfd_send_signal(fd,signal.SIGSTOP)
wait(lambda:ident(pid)['state']=='T')
assert not (p.parent/'complete.json').exists() and not (p.parent/'audio.wav').exists()
observed.update(job=str(p.parent),partialBytes=p.stat().st_size,partialSha256=hashlib.sha256(p.read_bytes()).hexdigest(),stoppedIdentity=ident(pid))
(W/'helper-status.txt').write_text(Path('/proc/'+str(pid)+'/status').read_text())
(W/'helper-observed.json').write_text(json.dumps(observed,indent=2)+'\n');os.close(fd)
