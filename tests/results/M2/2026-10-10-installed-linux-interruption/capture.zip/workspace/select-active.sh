set -eu
cd /home/preview
xdotool mousemove 430 122 click 1
sleep .2
import -window root selected-active.png
python3.14 - <<'PYI'
import json,os,hashlib
from pathlib import Path
w=Path('/home/preview');r=json.loads((w/'helper-observed.json').read_text());pid=r['pid'];s=Path('/proc/'+str(pid)+'/stat').read_text().rsplit(')',1)[1].split();assert s[0]=='T'and int(s[19])==r['startTicks'];assert os.readlink('/proc/'+str(pid)+'/exe')==r['exe']
p=Path(r['job'])/'audio.partial';assert p.stat().st_size==r['partialBytes'];assert hashlib.sha256(p.read_bytes()).hexdigest()==r['partialSha256'];assert not (p.parent/'complete.json').exists()
(w/'active-inspection.json').write_text(json.dumps({'helperPid':pid,'state':s[0],'startTicks':int(s[19]),'parentPid':int(s[1]),'partialSha256':r['partialSha256'],'partialBytes':r['partialBytes'],'noComplete':True},indent=2)+'\n')
PYI
