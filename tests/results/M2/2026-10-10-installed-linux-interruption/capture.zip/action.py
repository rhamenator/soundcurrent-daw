from pathlib import Path
import subprocess,sys,json,datetime,re
root=Path.cwd();out=root/'.cache/linux-installed-interruption';name=sys.argv[1];assert re.fullmatch('[a-z0-9-]+',name)
script=out/'workspace'/(name+'.sh');assert script.is_file()
pid=int((out/'namespace-target.txt').read_text());assert Path('/proc/'+str(pid)).exists()
expected=(out/'workspace/namespace-identity.txt').read_text()
assert subprocess.check_output(['sudo','-n','cat','/proc/'+str(pid)+'/root/home/preview/namespace-identity.txt'],text=True)==expected
cmd=['sudo','-n','nsenter','--target',str(pid),'--mount','--pid','--net','--ipc','--uts','--root','--wd=/','--','/usr/bin/setpriv','--reuid=preview','--regid=preview','--init-groups','--bounding-set=-all','--inh-caps=-all','--ambient-caps=-all','--no-new-privs','/usr/bin/env','HOME=/home/preview','XDG_RUNTIME_DIR=/home/preview/run','XDG_CONFIG_HOME=/home/preview/config','DISPLAY=:94','/bin/sh','-c',script.read_text()]
d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'script':str(script.relative_to(root))}
with (out/(name+'.log')).open('x') as f:
 p=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT);d['pid']=p.pid;r=p.wait()
d['exit_code']=r;(out/(name+'-command.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'name':name,'exit_code':r}));raise SystemExit(r)
