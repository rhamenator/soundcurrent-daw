#!/bin/sh
set -eu
cd /home/preview
dpkg -i package.deb > install.log 2>&1
dpkg-query -W -f='${Version}\n' soundcurrent-daw > installed-version.txt
sha256sum /usr/bin/soundcurrent-daw /usr/bin/sc-stretch-render-worker > installed-binaries.sha256
for program in g++ clang++ cmake qmake6; do
 if command -v "$program" >> developer-tools.txt 2>/dev/null; then exit 31; fi
done
exec setpriv --reuid=preview --regid=preview --init-groups --bounding-set=-all --inh-caps=-all --ambient-caps=-all --no-new-privs /usr/bin/dbus-run-session /usr/bin/python3 /home/preview/manager.py
