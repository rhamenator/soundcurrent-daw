from pathlib import Path
import hashlib,json,gzip,subprocess
r=Path('.cache/pipewire-owned-recording');d=Path('tests/results/M2/2026-10-12-pipewire-owned-recording');d.mkdir(parents=True,exist_ok=True)
f=json.loads((r/'frozen-inputs.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
for x in f['selectedInputs']:assert sha(Path(x['path']).read_bytes())==x['checkoutSha256']
members={}
def put(name,b):
 p=d/(name+'.gz');p.parent.mkdir(parents=True,exist_ok=True);z=gzip.compress(b,mtime=0);p.write_bytes(z)
 members[name+'.gz']={'bytes':len(z),'sha256':sha(z),'originalBytes':len(b),'originalSha256':sha(b)}
for name in ['frozen-inputs.json', 'engine-frozen-inputs.json', 'engine-source-binding.json', 'source-delta.diff', 'configure.log', 'build.log', 'owner-test-build.log', 'corrected-build.log', 'initial-tests.log', 'native-build.log', 'fixed-native-build.log', 'final-tests.log', 'private-pipewire.conf', 'recording-owned-runtime.log', 'recording-owned-runtime.json', 'recording-owned-daemon.log', 'recording-owned-wrapper.log', 'run-owned-recording.py', 'sanitizer-configure.log', 'sanitizer-build.log', 'sanitizer-tests.log', 'sanitizer-recording-owned-runtime.log', 'sanitizer-recording-owned-runtime.json', 'sanitizer-recording-owned-daemon.log', 'sanitizer-recording-owned-wrapper.log', 'run-owned-recording-sanitizer.py', 'tsan-configure.log', 'tsan-build.log', 'tsan-tests.log', 'windows-qualification.json', 'windows-qualification.log', 'freeze-inputs.py', 'qualify-windows.py', 'retain163.py', 'retain163.log', 'pr163-tested-merge.json', 'test-retention.ps1', 'retention-tests.log', 'retention-final-tests.log']:
 put(name,(r/name).read_bytes())
for p in r.glob('windows-compile-*.log'):put(p.name,p.read_bytes())
for folder in ['initial-build-warnings','initial-native-compile-failure','pr163-review']:
 for p in sorted((r/folder).iterdir()):
  if p.is_file() and p.suffix in ['.json','.log','.cpp']:put(folder+'/'+p.name,p.read_bytes())
hashes={}
for profile in ['release','sanitizer','thread-sanitizer']:
 p=r/profile
 for name in ['CMakeCache.txt','Testing/Temporary/LastTest.log']:put(profile+'/'+name,(p/name).read_bytes())
 put(profile+'/generated-commands.log',subprocess.check_output(['ninja','-C',str(p),'-t','commands']))
 files=list(p.glob('*.a'))+[q for q in p.glob('sc-*-tests') if q.is_file()]
 hashes[profile]={str(q.relative_to(p)):{'bytes':q.stat().st_size,'sha256':sha(q.read_bytes())} for q in files}
put('build-output-hashes.json',json.dumps(hashes,indent=2).encode())
commands={'releaseAndAsanRegex':'^(pipewire-owned-recording|pipewire-shared-processing-handoffs|pipewire-recording-durable-prefix|pipewire-native-receipt-handoffs)$','tsanRegex':'^pipewire-owned-recording$','ctestArgs':['--output-on-failure','--parallel','1'],'asanEnvironment':{'ASAN_OPTIONS':'detect_leaks=0:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'},'tsanEnvironment':{'TSAN_OPTIONS':'halt_on_error=1'},'priority':['nice','-n','15','ionice','-c','2','-n','7'],'buildWorkers':1,'windows':'Exact argv/object hashes in windows-qualification.json, unchanged C++ binding to current source','native':'Owner-only dummy daemon; native+processing+disk workers; no physical routes'}
put('qualification-commands.json',json.dumps(commands,indent=2).encode());put('package-evidence.py',Path(__file__).read_bytes())
summary={'implementation':f['source'],'tree':f['tree'],'sourceInputs':len(f['selectedInputs']),'engineSourceBinding':json.loads((r/'engine-source-binding.json').read_text()),'release':{'passed':4,'tests':4,'seconds':2.47,'ownerChecksScheduleDependent':98141},'asanUbsan':{'passed':4,'tests':4,'seconds':3.49,'leakDetection':False},'threadSanitizer':{'passed':1,'tests':1,'seconds':2.62,'suppressions':False,'scope':'Owned native-role threads+processing+disk, simulated SDK, no GUI/opaque framework claim'},'windows':json.loads((r/'windows-qualification.json').read_text()),'ownedNative':{'releasePassed':True,'asanPassed':True,'sdk':'1.6.2','releaseRawFrames':99072,'asanRawFrames':100352,'monitorAndSinkFramesEach':8192,'releaseCaptureReceipts':387,'releaseRenderReceipts':408,'asanCaptureReceipts':392,'asanRenderReceipts':412,'rawBitChecksEach':'Every original sample','callbackAllocateFreeLockEach':0,'physicalDevices':False},'previousCi':{'pr':163,'run':38313719137,'head':'770e43ea72c7535470639904fe8c30899bb14cc3','linux':'151/433.20s success','desktop':'20/75.64s success','native':'78/286.12s units pass; jobFAILURE additional diagnostic attempt3/take6/identity7 submit-out full8192framepool whilewriteinflight','cross':'success','failureCause':'Underlying I/O/OS/scheduling cause unknown; original limits unchanged','actualFailedTempTakeUploaded':False},'ciFailureRetention':{'boundedGeneratedTempProjects':True,'linuxPowerShellBytesUnicodeForeignPathReparsePassed':True,'windowsExecutionPending':True,'atomicProjectSnapshot':False},'scope':'Owned inactive endpoints/native callback workers, shared processing+disk workers, join/fault rollback and paired checkpoint recovery; durable intent/terminal state/controller/Qt integration pending','retainedNativeCompileFailure':True,'physicalAudio':False,'vmUsed':False,'windowsRuntimeForCurrentRevision':False,'payloadPolicy':'Text/log/configuration/metadata and local binary hashes only; no binary/audio/ZIP payload','members':members}
(d/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for name,row in members.items():
 b=(d/name).read_bytes();assert sha(b)==row['sha256'];raw=gzip.decompress(b);assert sha(raw)==row['originalSha256'] and len(raw)==row['originalBytes']
print('Verified',len(members),'bound text/log/metadata members;',len(f['selectedInputs']),'qualified inputs unchanged')
