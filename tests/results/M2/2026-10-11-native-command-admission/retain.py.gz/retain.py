from pathlib import Path
import json,hashlib,gzip,subprocess,re
r=Path('.cache/native-command-admission');out=Path('tests/results/M2/2026-10-11-native-command-admission');f=json.loads((r/'frozen-inputs.json').read_text());initial=json.loads((r/'initial-frozen-inputs.json').read_text());q=json.loads((r/'corrected-qualified-profiles.json').read_text());w=json.loads((r/'windows-qualification.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==f['source'] and subprocess.check_output(['git','status','--porcelain'],text=True).splitlines()==['?? tests/results/M2/2026-10-11-original-timing-windows-runtime/']
assert f['source']==q['source']==w['source'] and len(f['selectedInputs'])==780 and set(q['profiles'])=={'release','sanitizer','tsan'}
for x in f['selectedInputs']:assert sha(x['path'])==x['checkoutSha256']
for x in initial['selectedInputs']:
 if x['path']!='tests/native_monitor_recording_tests.cpp':assert sha(x['path'])==x['checkoutSha256']
names=['freeze-inputs.py','qualify.py','qualify-corrected.py','qualify-windows.py','retain.py','frozen-inputs.json','initial-frozen-inputs.json','qualified-profiles.json','corrected-qualified-profiles.json','windows-qualification.json','qualification-commands.json','corrected-qualification-commands.json','initial-admission-archive-hashes.json','qualification.log','corrected-qualification.log','windows-qualification.log','catalog-update.log','catalog-refusals.log']
times={}
for label,p in q['profiles'].items():
 b=r/('corrected-'+label);assert sha(b/'sc-native-monitor-startup-tests')==p['exeSha256']
 for n,x in p['objects'].items():assert sha(b/n)==x['sha256']
 for x in list(p['readOnlyArchives'].values())+list(p['readOnlyObjects'].values()):assert sha(x['path'])==x['sha256']
 for n,h in p['unchangedCurrentAdmissionArchives'].items():assert sha(r/('qualified-'+label)/n)==h
 log=(r/('corrected-'+label+'-LastTest.log')).read_text();assert 'native_command_payload aggregate_credit=true' in log and 'guarded allocate/free/lock=0' in log
 times[label]=float(re.search(r'Total Test time \(real\) =\s+([0-9.]+)',(r/('corrected-'+label+'-tests.log')).read_text())[1])
 names += ['corrected-'+label+'-'+n+'.log'for n in ['configure','compile-0','link','tests','LastTest']]+['corrected-'+label+'-generated-commands.txt','corrected-'+label+'-CMakeCache.txt']
for x in w['objects'].values():assert sha(x['argv'][-1])==x['sha256']
names+=['windows-compile-'+str(n)+'.log'for n in range(4)]
for tag in ['initial-profile-logs','first-tsan-snapshot-identity-failure','first-development-link-path-refusal']:
 for p in (r/tag).iterdir():
  if p.is_file():names.append(str(p.relative_to(r)))
out.mkdir(exist_ok=False);members={}
for n in sorted(set(names)):
 raw=(r/n).read_bytes();data=gzip.compress(raw,mtime=0);dest=n.replace('/','--')+'.gz';(out/dest).write_bytes(data);members[dest]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'originalBytes':len(raw),'originalSha256':hashlib.sha256(raw).hexdigest(),'lossless':True}
summary={'source':f['source'],'tree':f['tree'],'initialImplementationSource':initial['source'],'sourceInputs':780,'linuxTestTimesSeconds':times,'correctedFixtureObjectsPerProfile':1,'unchangedCurrentProductionArchivesReused':True,'queuedAndInFlightCommandPayloadCredit':True,'reserveBeforeOwnedCopyWitnessVerified':True,'aggregateParentChildRefusal':True,'structuralBoundsAndUtf8NulValidation':True,'urgentCancelAtQuota':True,'firstTsanFailureRetained':True,'snapshotIdentityAssertionCorrectedToSemanticState':True,'guardedViolations':0,'fourCurrentWindowsObjectsCompiled':True,'windowsRuntimeExecuted':False,'fullGuiSnapshotMemoryQualified':False,'binariesOrMediaIncluded':False,'fullGoalComplete':False}
raw=(json.dumps(summary,indent=2)+'\n').encode();(out/'summary.json').write_bytes(raw);members['summary.json']={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()};(out/'manifest.json').write_text(json.dumps({'members':members,'scope':'Existing native controller command payload admission; Linux Release/ASanUBSan/TSan corrected copy-witness acceptance, original failure retained, current Windows compilation; source/log/hash/commands only'},indent=2)+'\n');print('Retained admission',len(members),'bound files',sum(p.stat().st_size for p in out.iterdir()),'bytes')
