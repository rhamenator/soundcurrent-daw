from pathlib import Path
import subprocess,json,shlex,hashlib,shutil
r=Path('.cache/native-command-admission');old=Path('.cache/native-monitor-controller');q=json.loads((old/'qualified-profiles.json').read_text());f=json.loads((r/'frozen-inputs.json').read_text());oldf=json.loads((old/'frozen-inputs.json').read_text());head=f['source'];prefix=['nice','-n','15','ionice','-c','2','-n','7'];commands=[];profiles={};admissionHashes=json.loads((r/'initial-admission-archive-hashes.json').read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
changed=set(subprocess.check_output(['git','diff','--name-only',oldf['source'],head],text=True).splitlines())
admission=json.loads((r/'initial-frozen-inputs.json').read_text())
for x in admission['selectedInputs']:
 if x['path']!='tests/native_monitor_recording_tests.cpp':assert sha(x['path'])==x['checkoutSha256']
for x in oldf['selectedInputs']:
 if x['path'] not in changed:assert sha(x['path'])==x['checkoutSha256']
def checked():
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head and not subprocess.check_output(['git','status','--porcelain'],text=True)
 for x in f['selectedInputs']:assert sha(x['path'])==x['checkoutSha256']
for label,ctype,flags in [('release','Release',''),('sanitizer','Debug','-fsanitize=address,undefined -fno-omit-frame-pointer'),('tsan','Debug','-fsanitize=thread -fno-omit-frame-pointer -O1')]:
 b=(r/('corrected-'+label)).resolve();prev=(old/('qualified-'+label)).resolve();objects={};archives={};reusedObjects={}
 def run(stage,argv,cwd=None):
  checked();cmd=prefix+argv;commands.append({'profile':label,'stage':stage,'argv':cmd,'cwd':str(cwd or Path.cwd())});(r/'corrected-qualification-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
  with (r/('corrected-'+label+'-'+stage+'.log')).open('w') as out:p=subprocess.run(cmd,cwd=cwd,stdout=out,stderr=subprocess.STDOUT)
  if p.returncode:raise SystemExit(label+' '+stage+' failed; original retained')
 print('Starting',label,flush=True)
 assert sha(prev/'sc-native-monitor-startup-tests')==q['profiles'][label]['exeSha256']
 run('configure',['cmake','-S','.','-B',str(b),'-G','Ninja','-DCMAKE_BUILD_TYPE='+ctype,'-DSC_BUILD_DESKTOP=OFF','-DSC_BUILD_MEDIA=ON','-DCMAKE_CXX_FLAGS='+flags,'-DCMAKE_EXE_LINKER_FLAGS='+flags])
 gen=subprocess.check_output(['ninja','-C',str(b),'-t','commands','sc-native-monitor-startup-tests'],text=True);(r/('corrected-'+label+'-generated-commands.txt')).write_text(gen)
 for line in gen.splitlines():
  if ' -c ' not in line:continue
  argv=shlex.split(line);obj=argv[argv.index('-o')+1]
  if 'tests/native_monitor_recording_tests.cpp.o' in obj:
   (b/obj).parent.mkdir(parents=True,exist_ok=True);run('compile-'+str(len(objects)),argv,b);assert 'warning:' not in (r/('corrected-'+label+'-compile-'+str(len(objects))+'.log')).read_text();objects[obj]={'sha256':sha(b/obj),'bytes':(b/obj).stat().st_size}
 assert len(objects)==1
 argv=shlex.split(next(x for x in gen.splitlines() if ' -o sc-native-monitor-startup-tests ' in x))[2:-2]
 assert '-Wl,--wrap=pthread_mutex_lock' in argv
 for n,a in enumerate(argv):
  if a.endswith('.o') and a not in objects:
   p=prev/a
   if not p.is_file():p=Path(q['profiles'][label]['readOnlyObjects'][a]['path'])
   expected=q['profiles'][label]['objects'].get(a,q['profiles'][label]['readOnlyObjects'].get(a))['sha256'];assert sha(p)==expected;argv[n]=str(p);reusedObjects[a]={'path':str(p),'sha256':sha(p)}
  if a.endswith('.a') and not Path(a).is_absolute():
   p=prev/a
   if a in ['libsc-native-monitor-controller.a','libsc-native-monitor-recording.a']:
    p=(r/('qualified-'+label)/a).resolve();expected=admissionHashes[label][a]
   else:expected=q['profiles'][label]['privateArchives'].get(a)
   if not p.is_file():p=Path(q['profiles'][label]['readOnlyArchives'][a]['path'])
   if not expected:expected=q['profiles'][label]['readOnlyArchives'][a]['sha256']
   assert sha(p)==expected;argv[n]=str(p);archives[a]={'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
 run('link',argv,b);run('tests',['ctest','--test-dir',str(b),'-R','^native-monitor-startup$','--output-on-failure','--no-tests=error'])
 assert '100% tests passed, 0 tests failed out of 1' in (r/('corrected-'+label+'-tests.log')).read_text()
 shutil.copyfile(b/'Testing/Temporary/LastTest.log',r/('corrected-'+label+'-LastTest.log'));shutil.copyfile(b/'CMakeCache.txt',r/('corrected-'+label+'-CMakeCache.txt'))
 log=(r/('corrected-'+label+'-LastTest.log')).read_text();assert log.count('native_desktop_controller ')==3 and 'active_shutdown=true' in log and 'native_command_payload aggregate_credit=true' in log and 'guarded allocate/free/lock=0' in log
 for x in archives.values():assert sha(x['path'])==x['sha256']
 profiles[label]={'exeSha256':sha(b/'sc-native-monitor-startup-tests'),'objects':objects,'readOnlyArchives':archives,'readOnlyObjects':reusedObjects,'privateArchives':{},'unchangedCurrentAdmissionArchives':{n:sha(r/('qualified-'+label)/n)for n in ['libsc-native-monitor-controller.a','libsc-native-monitor-recording.a']}}
 (r/'corrected-qualified-profiles.json').write_text(json.dumps({'source':head,'tree':f['tree'],'profiles':profiles,'nativeWindowsRuntimeExecuted':False},indent=2)+'\n');print('Passed',label,flush=True)
print('All three profiles passed',flush=True)
