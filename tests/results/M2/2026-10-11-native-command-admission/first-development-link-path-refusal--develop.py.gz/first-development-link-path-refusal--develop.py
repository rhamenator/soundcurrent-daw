from pathlib import Path
import subprocess,json,shlex,hashlib
r=Path('.cache/native-command-admission');old=Path('.cache/native-monitor-controller');q=json.loads((old/'qualified-profiles.json').read_text());label='release';b=(r/('build-'+label)).resolve();prev=(old/('qualified-'+label)).resolve();prefix=['nice','-n','15','ionice','-c','2','-n','7'];cmds=[]
def run(name,argv,cwd=None):
 cmds.append({'stage':name,'argv':prefix+argv,'cwd':str(cwd or Path.cwd())});(r/'development-commands.json').write_text(json.dumps(cmds,indent=2)+'\n')
 with (r/(name+'.log')).open('w') as f:p=subprocess.run(prefix+argv,cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
 if p.returncode:raise SystemExit(name+' failed; original log retained')
run('configure',['cmake','-S','.','-B',str(b),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DSC_BUILD_DESKTOP=OFF','-DSC_BUILD_MEDIA=ON'])
gen=subprocess.check_output(['ninja','-C',str(b),'-t','commands','sc-native-monitor-startup-tests'],text=True);(r/'generated-commands.txt').write_text(gen);objects=[]
for line in gen.splitlines():
 if ' -c ' not in line:continue
 argv=shlex.split(line);obj=argv[argv.index('-o')+1]
 if any(x in obj for x in ['sc-native-monitor-controller.dir/','sc-native-monitor-recording.dir/','tests/native_monitor_recording_tests.cpp.o']):
  (b/obj).parent.mkdir(parents=True,exist_ok=True);run('compile-'+str(len(objects)),argv,b);objects.append(obj)
assert len(objects)==3
for target in ['sc-native-monitor-controller','sc-native-monitor-recording']:
 run(target+'-archive',['ar','r','lib'+target+'.a',*[x for x in objects if target+'.dir/' in x]],b);run(target+'-index',['ranlib','lib'+target+'.a'],b)
argv=shlex.split(next(x for x in gen.splitlines() if ' -o sc-native-monitor-startup-tests ' in x))[2:-2];archives={}
for n,a in enumerate(argv):
 if a.endswith('.o') and a not in objects:
  argv[n]=str(prev/a);assert (prev/a).is_file()
 if a.endswith('.a') and not Path(a).is_absolute() and a not in ['libsc-native-monitor-controller.a','libsc-native-monitor-recording.a']:
  p=prev/a
  if not p.is_file():p=Path(q['profiles'][label]['readOnlyArchives'][a]['path'])
  argv[n]=str(p);archives[a]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(r/'reused-archives.json').write_text(json.dumps(archives,indent=2)+'\n');run('link',argv,b)
run('tests',['ctest','--test-dir',str(b),'-R','^native-monitor-startup$','--output-on-failure','--no-tests=error'])
print('Current native desktop control/owner/test objects linked against read-only qualified unchanged engine archives; expanded suite PASS',flush=True)
