<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1" language="fr" sourcelanguage="en_US">
  <context>
    <name>EquipmentProfiles</name>
    <message>
      <source>Published response and editable correction curves</source>
      <translation>Réponse publiée et courbes de correction modifiables</translation>
    </message>
    <message>
      <source>Equipment profile editor</source>
      <translation>Éditeur de profils d’équipement</translation>
    </message>
    <message>
      <source>Brand</source>
      <translation>Marque</translation>
    </message>
    <message>
      <source>Family</source>
      <translation>Gamme</translation>
    </message>
    <message>
      <source>Equipment subtype</source>
      <translation>Sous-type d’équipement</translation>
    </message>
    <message>
      <source>Active / passive / unknown</source>
      <translation>Actif / passif / inconnu</translation>
    </message>
    <message>
      <source>Model</source>
      <translation>Modèle</translation>
    </message>
    <message>
      <source>Source</source>
      <translation>Source</translation>
    </message>
    <message>
      <source>Conditions</source>
      <translation>Conditions</translation>
    </message>
    <message>
      <source>Type</source>
      <translation>Type</translation>
    </message>
    <message>
      <source>Frequency Hz</source>
      <translation>Fréquence en Hz</translation>
    </message>
    <message>
      <source>Gain dB</source>
      <translation>Gain en dB</translation>
    </message>
    <message>
      <source>Q</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Undo profile edit</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Redo profile edit</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Add filter</source>
      <translation>Ajouter un filtre</translation>
    </message>
    <message>
      <source>Remove selected filter</source>
      <translation>Supprimer le filtre sélectionné</translation>
    </message>
    <message>
      <source>Undo</source>
      <translation>Annuler</translation>
      <extracomment>Reverse the previous editable setting change.</extracomment>
    </message>
    <message>
      <source>Redo</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Save modified profile?</source>
      <translation>Enregistrer le profil modifié ?</translation>
    </message>
    <message>
      <source>This profile has changed. Save a custom copy before leaving?</source>
      <translation>Ce profil a été modifié. Enregistrer une copie personnalisée avant de quitter ?</translation>
    </message>
    <message>
      <source>Profile exceeds the 1 MiB limit.</source>
      <translation>Le profil dépasse la limite de 1 MiB.</translation>
    </message>
    <message>
      <source>Profile is not valid UTF-8.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Profile exceeds nesting limit.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Duplicate JSON field in equipment profile.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Expected a JSON equipment profile.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Invalid equipment JSON.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Expected a JSON equipment profile. Import response text using the response import button.</source>
      <translation>Un profil d’équipement JSON est attendu. Importez un texte de réponse avec le bouton d’importation de réponse.</translation>
    </message>
    <message>
      <source>Unknown profile field; import would lose data.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Profile metadata must be text.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Custom flag must be boolean.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Profile filters and response must be arrays.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Unsupported equipment profile schema (expected 2 or 3).</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Whole-system profiles require DAW schema 3.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Equipment subtype and power type are required (maximum 120 characters each).</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Equipment kind must be speaker, microphone, amplifier or whole_system.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Brand, family and model are required (maximum 120 characters each).</source>
      <translation>La marque, la gamme et le modèle sont obligatoires (120 caractères maximum chacun).</translation>
    </message>
    <message>
      <source>Profile metadata is too long.</source>
      <translation>Les métadonnées du profil sont trop longues.</translation>
    </message>
    <message>
      <source>Profile metadata contains a NUL character.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Measurement conditions are required.</source>
      <translation>Les conditions de mesure sont obligatoires.</translation>
    </message>
    <message>
      <source>Published profiles need an HTTPS measurement source.</source>
      <translation>Les profils publiés nécessitent une source de mesure HTTPS.</translation>
    </message>
    <message>
      <source>Profiles need 1–16 correction filters.</source>
      <translation>Les profils doivent contenir de 1 à 16 filtres de correction.</translation>
    </message>
    <message>
      <source>Invalid filter.</source>
      <translation>Filtre invalide.</translation>
    </message>
    <message>
      <source>Unknown filter field; import would lose data.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Unsupported filter type.</source>
      <translation>Type de filtre non pris en charge.</translation>
    </message>
    <message>
      <source>Filter values must be numbers.</source>
      <translation>Les valeurs des filtres doivent être numériques.</translation>
    </message>
    <message>
      <source>Filters exceed frequency, gain or Q limits.</source>
      <translation>Les filtres dépassent les limites de fréquence, de gain ou de Q.</translation>
    </message>
    <message>
      <source>Response exceeds 4096 points.</source>
      <translation>La réponse dépasse 4096 points.</translation>
    </message>
    <message>
      <source>Invalid response point.</source>
      <translation>Point de réponse invalide.</translation>
    </message>
    <message>
      <source>Response frequencies must increase, with finite bounded values.</source>
      <translation>Les fréquences de réponse doivent être croissantes, avec des valeurs finies dans les limites.</translation>
    </message>
    <message>
      <source>Response exceeds the 1 MiB limit.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Response is not valid UTF-8.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Expected frequency Hz and relative measured response dB on every data line.</source>
      <translation>Chaque ligne de données doit contenir la fréquence en Hz et la réponse mesurée relative en dB.</translation>
    </message>
    <message>
      <source>Invalid or unordered response data.</source>
      <translation>Données de réponse invalides ou non ordonnées.</translation>
    </message>
    <message>
      <source>Response needs at least two measured points.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Response needs 2–4096 measured points.</source>
      <translation>La réponse nécessite de 2 à 4096 points mesurés.</translation>
    </message>
    <message>
      <source>Invalid or unordered measured response.</source>
      <translation>Réponse mesurée invalide ou non ordonnée.</translation>
    </message>
    <message>
      <source>Response has no usable audio range.</source>
      <translation>La réponse ne contient aucune plage audio utilisable.</translation>
    </message>
    <message>
      <source>Cannot read profile library.</source>
      <translation>Impossible de lire la bibliothèque de profils.</translation>
    </message>
    <message>
      <source>Profile library exceeds 16 MiB.</source>
      <translation>La bibliothèque de profils dépasse 16 MiB.</translation>
    </message>
    <message>
      <source>Invalid profile library.</source>
      <translation>Bibliothèque de profils invalide.</translation>
    </message>
    <message>
      <source>Duplicate profile identity in library.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The custom library holds up to 256 profiles.</source>
      <translation>La bibliothèque personnalisée peut contenir jusqu’à 256 profils.</translation>
    </message>
    <message>
      <source>Library exceeds 16 MiB.</source>
      <translation>La bibliothèque dépasse 16 MiB.</translation>
    </message>
    <message>
      <source>Cannot create profile folder.</source>
      <translation>Impossible de créer le dossier des profils.</translation>
    </message>
    <message>
      <source>Cannot save profile library.</source>
      <translation>Impossible d’enregistrer la bibliothèque de profils.</translation>
    </message>
    <message>
      <source>Cannot finish saving profile library.</source>
      <translation>Impossible de terminer l’enregistrement de la bibliothèque de profils.</translation>
    </message>
    <message>
      <source>Equipment resource missing.</source>
      <translation>Ressource d’équipement introuvable.</translation>
    </message>
    <message>
      <source>Save profile</source>
      <translation>Enregistrer le profil</translation>
    </message>
    <message>
      <source>Equipment profiles — brand / family / model</source>
      <translation>Profils d’équipement — marque / gamme / modèle</translation>
    </message>
    <message>
      <source>Edit and save equipment profiles here. Monitoring correction routing is not yet available.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Search brand, family, model or measurement conditions</source>
      <translation>Rechercher une marque, une gamme, un modèle ou des conditions de mesure</translation>
    </message>
    <message>
      <source>Equipment profiles by brand family and model</source>
      <translation>Profils d’équipement par marque, gamme et modèle</translation>
    </message>
    <message>
      <source>All equipment</source>
      <translation>Tous les équipements</translation>
    </message>
    <message>
      <source>Speakers</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Microphones</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Amplifiers / receivers</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Whole system</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Equipment type</source>
      <translation>Type d’équipement</translation>
    </message>
    <message>
      <source>Equipment brand</source>
      <translation>Marque de l’équipement</translation>
    </message>
    <message>
      <source>Equipment family</source>
      <translation>Gamme de l’équipement</translation>
    </message>
    <message>
      <source>Equipment power type</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>All brands</source>
      <translation>Toutes les marques</translation>
    </message>
    <message>
      <source>All families</source>
      <translation>Toutes les gammes</translation>
    </message>
    <message>
      <source>All subtypes</source>
      <translation>Tous les sous-types</translation>
    </message>
    <message>
      <source>All power types</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Subtype: %1; power: %2</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Profile identity already exists; edit a custom copy instead.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Profile</source>
      <translation>Profil</translation>
    </message>
    <message>
      <source>Import JSON</source>
      <translation>Importer un fichier JSON</translation>
    </message>
    <message>
      <source>Import response text</source>
      <translation>Importer un texte de réponse</translation>
    </message>
    <message>
      <source>Create profile</source>
      <translation>Créer un profil</translation>
    </message>
    <message>
      <source>Edit / save copy</source>
      <translation>Modifier / enregistrer une copie</translation>
    </message>
    <message>
      <source>Export JSON</source>
      <translation>Exporter en JSON</translation>
    </message>
    <message>
      <source>Cannot read profile or file exceeds 1 MiB.</source>
      <translation>Impossible de lire le profil, ou le fichier dépasse 1 MiB.</translation>
    </message>
    <message>
      <source>Import</source>
      <translation>Importer</translation>
    </message>
    <message>
      <source>Cannot read response or file exceeds 1 MiB.</source>
      <translation>Impossible de lire la réponse, ou le fichier dépasse 1 MiB.</translation>
    </message>
    <message>
      <source>This imports measured RESPONSE, not already-inverted EQ gains. Confirm equipment type. Absolute SPL needs normalization before import.</source>
      <translation>Cet import concerne la RÉPONSE mesurée, et non des gains d’égalisation déjà inversés. Confirmez le type d’équipement. Un niveau SPL absolu doit être normalisé avant l’importation.</translation>
    </message>
    <message>
      <source>Response import</source>
      <translation>Importation de réponse</translation>
    </message>
    <message>
      <source>Export</source>
      <translation>Exporter</translation>
    </message>
  </context>
  <context>
    <name>ExportDialog</name>
    <message>
      <source>Export audio</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Audio track</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Start frame</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>End frame (exclusive)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Browse…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>WAV destination</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Include the EQ tail</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> seconds</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Use RF64 for this WAV</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Maximum tail</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Float32 WAV keeps levels above 0 dBFS. Large files use RF64 automatically. The export captures accepted project settings when you start; later edits do not change it. Existing files require a separate replacement confirmation.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Export</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Export WAV</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>WAV audio (*.wav)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Choose a destination and a range with end greater than start.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>%1 Hz · %2 seconds selected</source>
      <translation type="unfinished" />
    </message>
  </context>
  <context>
    <name>HistoryResourcesDialog</name>
    <message>
      <source>Project resources</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Limits apply to Undo payload and declared state/edit work. They do not measure total RAM. New edits may retire the oldest Undo commands; reducing limits never clears existing history.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Current limit: %1 bytes. Edited values use whole MiB.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Maximum retained commands</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Retained payload (MiB)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Operation workspace (MiB)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Enter positive whole numbers within this machine's size range.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Resource request sequence exhausted.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The project worker is busy or closing. Try again.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Applying limits…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The shared project budget covers canonical state, snapshots, Undo, declared edit work, list/timeline indices, projections, prepared DSP, readers, media caches, export buffers, capture pools and writer/hash/journal workspace. New preparation follows this trusted budget. Parser/other IO, copied owner sessions and Qt/allocator overhead remain separate.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Shared project budget (MiB)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Retained snapshot budget (MiB)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Apply memory limits</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Applying memory limits…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Project snapshot reservations: %1 owners
%2 / %3 bytes · Peak reservation: %4 bytes</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Shared reservations: %1 / %2 bytes · Peak: %3 bytes
Canonical: %4 bytes · History: %5 bytes</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Memory limits were not changed: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Memory limits applied. Retained state is preserved.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Limits applied, but preferences could not be saved: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Undo: %1 · Redo: %2
Retained: %3 bytes · Active: %4 bytes
Accepted operation peak: %5 bytes · Retired commands: %6</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Limits were not changed: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Limits applied. Existing Undo and Redo are preserved.</source>
      <translation type="unfinished" />
    </message>
  </context>
  <context>
    <name>ImportInspectionDialog</name>
    <message>
      <source>Choose a REAPER project</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>REAPER projects (*.rpp)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Open saved inspection</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>SoundCurrent inspections (*.scinspect)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Save inspection to a new file</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Inspect foreign project</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Choose project…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Open inspection…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Save inspection…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Check media…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Cancel</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Close</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>REAPER project inspection preview. Conversion is not available yet. The original file and current project remain unchanged.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Properties</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Original source</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Stopping inspection…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Saving inspection…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Opening inspection…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Inspecting project…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Inspection saved with the original source bytes. Project properties remain unverified.</source>
      <translation type="unfinished" />
    </message>
    <message numerus="yes">
      <source>%n original property value(s) found. Audio import is not available yet.</source>
      <translation type="unfinished" />
    </message>
    <message numerus="yes">
      <source>%n source line(s) inspected. This saved outline has no property preview.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Inspection canceled.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The inspection could not be saved. Choose a new file name in a writable folder; existing files are preserved.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The inspection could not be opened. It may be unreadable, damaged, unsupported, or too large for the available import memory.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Inspection exceeded its time limit.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>There is not enough import memory, or the file exceeds the inspection limits.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>This project uses invalid or unsupported syntax for this inspector.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The selected project or inspection worker could not be read.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The inspection failed or its result could not be verified.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Choose a project to inspect.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Media check unavailable</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>There is not enough import memory to display the media checklist.</source>
      <translation type="unfinished" />
    </message>
  </context>
  <context>
    <name>ImportMediaDialog</name>
    <message>
      <source>Choose the folder containing this project's media</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Choose a replacement audio file</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>WAVE audio (*.wav);;All files (*)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Choose a destination for the verified media copy</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Choose the copied operation's UUID folder</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Check last copy outcome</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recover copied media…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>No media folder selected. Opening an inspection does not grant access to its media.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Selected media folder: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Copy or recovery in progress. Operation folder: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Media is committed and verified, but directory durability is unconfirmed. Folder: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Media is committed and verified. Folder: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The checked media or inspection changed. Check the copy outcome, then check the source again. Operation folder: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The copy outcome is uncertain. Recover this operation folder before using its media: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>This operation has planned intent but no committed receipt. Partial data is preserved: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>No intent or receipt was found. No completed copy is established: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The copy did not start. Check the selected row, destination and available import memory.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Verified copies preserve the original reference and audio bytes. They are not attached to the current project. Clearing choices leaves copied files intact.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Stopping media jobs…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The media job could not be started. Check the selected path and available import memory.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Checking selected audio…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Choose a media folder and check a reference, or explicitly choose a replacement. Choices stay local to this window.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Check and copy project media</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Project conversion is in development. Check media, then copy checked files to a new destination. The checked snapshot is verified again before copying. The current project stays unchanged.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Maximum file size for this check (MiB):</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Choose media folder…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Check selected reference</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Choose replacement…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Clear local choices</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Cancel</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Close</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Copy checked media…</source>
      <translation type="unfinished" />
    </message>
  </context>
  <context>
    <name>ImportMediaModel</name>
    <message>
      <source>Not copied</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Copying or recovering…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Verified copy; directory durability unconfirmed</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Verified copy</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Outcome uncertain; recover this operation</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Planned copy; no committed receipt</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>No intent or receipt found</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Canceled before copying</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Copy could not start</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Reference unavailable</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Selected replacement: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Selected folder: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Ambiguous or unsupported source; no reference selected</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Not checked</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Checking…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Checked snapshot</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Canceled</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Check exceeded its time limit</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>File not found in the selected folder</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Audio format not supported by this check yet</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>File or check exceeds resource limits</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>File changed during the check</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Invalid audio or a reference requiring an explicit replacement</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Check unavailable or result could not be verified</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>%1 Hz · %2 · %3-bit</source>
      <translation type="unfinished" />
    </message>
    <message numerus="yes">
      <source>%n channel(s)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Silent</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>%1 dBFS</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Original reference</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Local media choice</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Status</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Audio format</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Sample peak</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Copy state</source>
      <translation type="unfinished" />
    </message>
  </context>
  <context>
    <name>ImportPreviewModel</name>
    <message>
      <source>Original file bytes: %1 + %2</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Blank line</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Group</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>End of group</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Property</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Unsupported</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Bytes retained</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Unverified</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Item</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Type</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Line</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Status</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Original line</source>
      <translation type="unfinished" />
    </message>
  </context>
  <context>
    <name>ImportPropertyModel</name>
    <message>
      <source>Project sample rate</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Use project sample rate</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Track identity</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Track name</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Track gain</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Track pan</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Track channels</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Item identity</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Item position</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Item length</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Fade-in length</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Fade-out length</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Take name</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Item gain</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Take gain</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Take pan</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Source offset</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Take rate</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Take pitch</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Source file</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Hz</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>0 / 1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>channels</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>linear gain</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>source pan</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>seconds</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>ratio</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>semitones</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>original bytes</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Value retained</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Converted</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Unsupported</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Missing</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Unverified</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Original value; audio import is not available yet.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Original state has not been interpreted.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Invalid or out-of-range original number.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Unverified original field layout.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Malformed original token.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Repeated field; no occurrence selected.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The source project does not specify this value.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Take selection is ambiguous.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>This processing setting cannot be imported yet.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>This source type is not implemented.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Original file bytes: %1 + %2</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Project</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Track</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Item</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Source</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>%1 · %2</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Unavailable</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Source object</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Property</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Original value</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Units</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Status</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Details</source>
      <translation type="unfinished" />
    </message>
  </context>
  <context>
    <name>Localization</name>
    <message>
      <source>Language preferences could not be saved.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Language and regional settings</source>
      <translation>Langue et région</translation>
    </message>
    <message>
      <source>Interface language</source>
      <translation>Langue de l’interface</translation>
    </message>
    <message>
      <source>Use system language</source>
      <translation>Utiliser la langue du système</translation>
    </message>
    <message>
      <source>Expanded test language</source>
      <translation>Langue de test avec texte étendu</translation>
    </message>
    <message>
      <source>Right-to-left test language</source>
      <translation>Langue de test de droite à gauche</translation>
    </message>
    <message>
      <source>Saved language preference: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Number and date format</source>
      <translation>Format des nombres et des dates</translation>
    </message>
    <message>
      <source>Use system locale</source>
      <translation>Utiliser les paramètres régionaux du système</translation>
      <extracomment>Use the operating system regional number/date formatting settings; independent of interface language.</extracomment>
    </message>
    <message>
      <source>Saved format preference: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Developer test language; no translated language coverage.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Requested: %1. Loaded after restart: %2. Translation coverage: %3 of %4 messages. Missing translations use English. Draft translations await native-speaker review.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Restart the application to apply language and number format changes. Save projects before quitting.</source>
      <translation type="unfinished" />
    </message>
  </context>
  <context>
    <name>Main</name>
    <message>
      <source>Interface language tag (draft catalogs available)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Project folder to open</source>
      <translation type="unfinished" />
    </message>
  </context>
  <context>
    <name>ManualRecordingPanel</name>
    <message>
      <source>Manual recording and repeated takes</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Prepare transport</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Play / monitor</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Prepare next take</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Punch In</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Punch Out</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Stop</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Cancel recording</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> s</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Maximum transport duration</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Disk stall reserve</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Tracks armed for manual recording</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recorded take previews</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Add complete take</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Add verified complete lanes</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Retain as take lanes</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Keep a complete group silent. Choose a take region in the timeline to make it audible.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Keep files for recovery</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recording command could not be queued. Please retry.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Arm at least one track before preparing.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Select every input and output port before playing.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Punch queued; waiting for the audio boundary.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recorded takes</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recorded files have not all been added to the project. Keep them for later recovery, or return to review the previews?</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Keep for recovery and close</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Review takes</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Route change could not be queued. Please retry.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>%1 input %2</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Missing track</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Master output %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Unassigned</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Saved port missing or ambiguous — select a port</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Take %1 — %2</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>canceled; recovery files retained</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>complete</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>partial / failed</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Take previews will appear here. Adding a take changes the project; Save is separate.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Take range: %1 to %2 frames</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>
%1 — %2 captured frames; %3</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>verified complete</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>retained for review / recovery</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Take %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Files kept in the project for later recovery.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Could not prepare recording: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recording command was not completed: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>%1 applied at frame %2</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>transport has changed</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>requested position has passed</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>position is outside the prepared range</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>already recording</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>no active recording</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>take is no longer available</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>transport has stopped</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>capture failed; files retained for recovery</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>unknown recording state</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Punch refused: %1.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Take lanes retained silently. Choose a comp region in the timeline; Save persists the lanes.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Take added. Save to persist the project changes. Reprepare playback to hear new clips.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Could not add the take: %1. Files and preview are retained.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recording failed: %1. Available files are retained.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Manual recording is unavailable on this platform.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Preparing recording…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Ready. Select explicit ports, then Play / monitor.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Playing / monitoring — frame %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Stopping; draining and verifying recordings…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recording worker closed.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Transport stopped.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> · Loop pass %1 · project frame %2</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> EQ changes pending audio acknowledgement.</source>
      <translation type="unfinished" />
    </message>
  </context>
  <context>
    <name>MasterDialog</name>
    <message>
      <source>The desktop editor supports at most 4096 entries. The project API supports 65536.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Source track</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Source channel</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Destination channel</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Linear gain</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Master was not applied: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Master layout and channel matrix</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Each row maps one source channel to a master channel. Gains are linear, including zero or negative polarity. Unlisted tracks are excluded. Changing the output channel count clears saved output assignments.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Mono</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Stereo</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Discrete</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Master layout</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Master channels</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Track</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Master channel</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>This matrix exceeds the 4096-entry desktop editor limit; its saved state is preserved. Use the project API.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Add route</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Remove selected routes</source>
      <translation type="unfinished" />
    </message>
  </context>
  <context>
    <name>NativeMonitorPanel</name>
    <message>
      <source>Recording</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Choose a device</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Capture source</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Monitoring output</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Same native channel order</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Duplicate mono to stereo</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Channel mapping</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Refresh devices</source>
      <translation>Actualiser les périphériques</translation>
    </message>
    <message>
      <source>Monitoring length (seconds)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Monitor EQ</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Prepare</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Record</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Cancel</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Inspect saved take</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Keep take and reset</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Export original WAV…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Export the verified captured WAV at its native rate. EQ and timeline alignment are not printed.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Copy verified audio…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Copy the verified playable audio to a new WAV. The original take and its outcome stay unchanged.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Open saved native take…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Choose an original take directory in this project's media folder. Inspection does not activate audio devices.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Start frame (project rate)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Add to selected track</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Use this explicit timeline position. Captured audio and native timing evidence stay unchanged.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Buffer for disk pauses</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Prepare a finite buffer before recording. Repeated pauses or a slow disk can still stop recording.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> ms</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Choose</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Minimum input block (frames)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Minimum output block (frames)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Enter the smallest block allowed by your audio setup. Recording stops if an actual block is smaller. This is not the maximum block size.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Disk pause budget</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Enter a nonnegative project frame.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Open saved native take</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Export original native take</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>WAV audio (*.wav)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Copy verified audio</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recording settings exceed the panel memory limit.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Monitoring range is too large.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recording controls are busy. Try again.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recording is closing.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recording settings are invalid.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recording settings exceed the control memory limit.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Input: %1 · Output: %2</source>
      <translation type="unfinished" />
    </message>
    <message numerus="yes">
      <source>%1 · %n channel(s) · %2 Hz</source>
      <translation type="unfinished" />
    </message>
    <message numerus="yes">
      <source>%1 · %n channel(s)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Device choices exceed the panel memory limit.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The capture device width must match the selected track.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Choose a matching output width or explicit mono-to-stereo mapping.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Selected devices exceed the panel memory limit.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Prepared: %1 ms · %2 audio slots · %3 bytes of prepared route payload. Output fills are variable.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Saved declaration: %1 ms · %2 audio slots. No audio route is allocated.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Saved declaration: %1 ms · %2 audio slots · %3 receipt slots. No audio route is allocated.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Prepared: %1 ms · %2 audio slots · %3 receipt slots · %4 bytes of prepared route payload.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>No disk-pause duration was declared for this take.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Disk-pause budgeting is not available for this audio route yet.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Using existing buffers. No disk-pause duration is declared.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The input device's actual format and memory cost will be checked during Prepare. Output fills do not set the disk-buffer budget.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Choose the minimum input packet size before preparing.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Choose minimum input and output block sizes before preparing.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Plan: %1 ms · %2 audio slots · %3 receipt slots · %4 bytes of route payload. Block sizes will be checked while recording.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>This disk-pause budget exceeds the buffer or memory limit. Reduce the duration or change the audio setup.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The minimum block sizes do not match the recording setup.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Available to copy: %1 of %2 verified frames · %3 Hz · %4 channels.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> Unverified audio stays in the original take.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> This take was not finalized.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> Audio from the first invalid sample onward will not be copied.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Pending</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Complete</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Cancelled</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Failed</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Interrupted</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>No native outcome</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> Original outcome: %1.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recording is unavailable.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Choose recording settings, then prepare.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Preparing recording…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Opening and verifying saved native take…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Ready to record.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recording and monitoring…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Finishing and saving the original take…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Original take saved.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recording cancelled. The retained take is available for inspection.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recording stopped with an error. Inspect the retained take.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recording closed.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Saved native take opened. Original outcome: %1.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Verifying original take for the timeline…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Exporting original WAV…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Copying verified audio…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Audio copy cancelled. The retained take is unchanged.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The saved audio changed or no longer matches the reviewed take. Open and verify it again.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The recording buffer exceeds the available capacity or memory. Reduce the disk-pause budget.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The recording settings do not match the prepared device format. Check the minimum input packet size.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recording error (%1).</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Original frames: %1 · Monitored frames: %2</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>EQ accepted: %1 · Applied: %2</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> · Saved frames verified: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> · Original WAV exported: %1 frames</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> · Export published with a durability warning.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> · Verified audio copied: %1 frames to %2.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> · Copy published with a durability warning.</source>
      <translation type="unfinished" />
    </message>
  </context>
  <context>
    <name>SessionListModel</name>
    <message>
      <source>Select a take lane</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Select a clip</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>%1 · captured %2–%3 frames</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Clip %1 · %2 frames</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>%1 · %2 channel(s) · %3</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Monitoring off</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Auto during recording</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Post-EQ monitoring</source>
      <translation type="unfinished" />
    </message>
  </context>
  <context>
    <name>StandardActions</name>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Yes</source>
      <translation>Oui</translation>
    </message>
    <message>
      <source>No</source>
      <translation>Non</translation>
    </message>
    <message>
      <source>Yes to All</source>
      <translation>Oui à tout</translation>
    </message>
    <message>
      <source>No to All</source>
      <translation>Non à tout</translation>
    </message>
    <message>
      <source>Open</source>
      <translation>Ouvrir</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Enregistrer</translation>
    </message>
    <message>
      <source>Save All</source>
      <translation>Tout enregistrer</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Fermer</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Annuler</translation>
    </message>
    <message>
      <source>Discard</source>
      <translation>Abandonner les modifications</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Appliquer</translation>
    </message>
    <message>
      <source>Reset</source>
      <translation>Réinitialiser</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation>Rétablir les valeurs par défaut</translation>
    </message>
    <message>
      <source>Retry</source>
      <translation>Réessayer</translation>
    </message>
    <message>
      <source>Abort</source>
      <translation>Abandonner</translation>
    </message>
    <message>
      <source>Ignore</source>
      <translation>Ignorer</translation>
    </message>
    <message>
      <source>Help</source>
      <translation>Aide</translation>
    </message>
  </context>
  <context>
    <name>StretchDialog</name>
    <message>
      <source>Clip pitch and stretch</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Duration multiplier numerator</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Duration multiplier denominator</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Pitch (semitones)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Preserve formants</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Use neighboring source context</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Context before (source frames)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Context after (source frames)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Experimental protected stretch markers</source>
      <translation type="unfinished" />
      <extracomment>Explicit transient-protected offline editing mode. Broader acoustic and sustained multichannel phase quality remain unqualified; preserve the experimental scope.</extracomment>
    </message>
    <message>
      <source>Stretch markers in retained original source frames</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Marker</source>
      <translation type="unfinished" />
      <extracomment>A stable user stretch anchor. Its displayed UUID prefix is not translated. This is not a project navigation marker.</extracomment>
    </message>
    <message>
      <source>Source position</source>
      <translation type="unfinished" />
      <extracomment>Protected stretch marker offset in physical source-sample frames from the retained nominal raw origin; not an absolute project frame or a filename. Integer acoustic positions use ungrouped digits.</extracomment>
    </message>
    <message>
      <source>Target position</source>
      <translation type="unfinished" />
      <extracomment>Protected stretch marker offset in physical frames in the prepared derivative, independent of project sample rate or linked playback speed.</extracomment>
    </message>
    <message>
      <source>Add marker</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Remove selected marker</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Markers use positions relative to the retained original span, at its physical sample rate. Moving a target protects the attack around that marker. Source and target positions must remain ordered. This first renderer requires integer positions, zero pitch and no neighboring context. Sustained multichannel phase quality is still unqualified.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Protected region: %1 source frames before and %2 after each marker; %3-frame blending boundaries. Fades follow the visible clip length.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Not enough Project resources to add a marker. No marker was added.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>This dialog stays bound to the clip selected when it opened. Close it before choosing another clip. Duration can be 0.25 to 4 times the source duration. Pitch and duration are independent. Rendering starts from the retained original audio. Linked playback speed remains a separate control. Closing this dialog leaves rendering in the background.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Context extends the retained original span with real neighboring audio at the source sample rate. The visible duration follows the requested multiplier. Prepare audition, choose playback outputs and play the verified result before Apply. Stop audition to apply it as one undoable edit.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Render</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Apply verified result</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Cancel render</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Close</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Prepare audition</source>
      <translation type="unfinished" />
      <extracomment>Prepare an ephemeral playback model for the verified derivative without modifying the project or playing automatically. Output channels are chosen before Play audition.</extracomment>
    </message>
    <message>
      <source>Stop audition</source>
      <translation type="unfinished" />
      <extracomment>Retire the temporary playback endpoint; keep the pending verified result available for Apply. This does not cancel a render or undo an edit.</extracomment>
    </message>
    <message>
      <source>Check marker positions: use integer source frames, ordered targets and nonoverlapping protected regions. No project edit was made.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Play audition</source>
      <translation type="unfinished" />
      <extracomment>Play the verified pending derivative on the explicitly chosen outputs before committing Apply. Audition output choices do not change saved project routes.</extracomment>
    </message>
    <message>
      <source>Apply reviewed completed result</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Applying the verified result as one undoable edit…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Choose settings, render, then apply the verified result.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Preparing the original audio and reserving render resources…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Rendering pitch and duration in the background…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Checking the completed audio before it can be applied…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>This retained result was independently verified after reopening. Review these settings before choosing Apply. No project edit has been made.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>A complete result was verified after cancellation, a deadline, or an abnormal exit. Review these settings before choosing Apply. No project edit has been made.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Render verified. Choose Apply to replace this clip as one undoable edit.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Canceled before rendering. No project edit was made.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Rendering could not start. Check the source, helper installation, settings, and available memory. No project edit was made.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The renderer stopped without a verified completed result. Its owned job files were retained for inspection. No project edit was made.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>This protected renderer requires an integer retained raw origin. Constant pitch/stretch remains available for this clip.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The duration multiplier must be between 0.25 and 4.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Settings have changed. Render again before audition or Apply.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Not enough Project resources to compare settings. Wait or close this dialog.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Verified result: duration %1/%2, pitch %3 semitones, formants %4.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>preserved</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>shifted</source>
      <translation type="unfinished" />
    </message>
    <message numerus="yes">
      <source>Verified protected marker plan: %n marker(s).</source>
      <translation type="unfinished" />
      <extracomment>Count of original user marker owners in the verified derivative plan. Numerus entry; retain %n and provide the language plural forms when reviewed.</extracomment>
    </message>
    <message>
      <source>Verified source context: %1 frames before, %2 frames after.</source>
      <translation type="unfinished" />
    </message>
  </context>
  <context>
    <name>StudioWindow</name>
    <message>
      <source>SoundCurrent DAW</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>&amp;File</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>&amp;New project…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>&amp;Open project…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Open project folder</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>&amp;Save</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Inspect foreign project…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>&amp;Export WAV…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Cancel export</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>&amp;Quit</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Settings</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Language and regional settings…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>&amp;Edit</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>&amp;Undo project edit</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>&amp;Redo project edit</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Project resources…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Review retained pitch/stretch renders…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Review rendered transitions…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Retry project display</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Equipment</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Profile library and editor…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Equipment profiles</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>&amp;Transport</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Prepare playback</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Play / Stop</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Stop</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Prepare recording</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Record</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recover recording…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Choose a capture job to inspect</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Find recoverable recordings…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Create or open a project to begin.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Track selection could not be updated: %1. Raise Project resources and retry.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Playback</source>
      <translation>Lecture</translation>
    </message>
    <message>
      <source>Play</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Play project mix (saved master or matching layouts)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Use the saved master's channel matrix and output routes. Without a saved master, use the selected track's layout and output routes. Different track layouts require an explicit matrix.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Edit master layout and matrix…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Master change was not admitted. Please retry.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Loop playback</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Repeat the saved loop range until Stop. Stop playback before changing the range.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Set loop range…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>There is no room for a loop range at this position.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Loop settings could not be changed. Stop transport setup and retry.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Output peak level</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recording</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Stop recording</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Arm selected track</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recording monitoring mode</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Monitoring off</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Monitor through track EQ</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Auto — monitor during recording</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Saved monitoring mode takes effect after Stop and preparation.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Selected track input latency:</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Selected track input latency in sample frames</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> samples</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Declared input delay, from zero to 60 seconds. New takes are aligned earlier by this amount. Existing clips and monitor audio are unchanged. Stop recording before editing.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Input latency could not be changed. Stop recording and retry.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Record armed tracks with project playback</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Select tracks below. Every raw input and project output must be chosen explicitly after preparation.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Tracks to arm for simultaneous recording</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recording mode</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Timed recording</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Loop: chosen number of passes</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Loop: until Stop</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Passes</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recording range (seconds)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Maximum shared recording duration in seconds</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recording stops at this range; you can stop earlier. Existing audio plays from the current playhead.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Punch recording</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Record only within the saved punch range while project playback continues.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Set punch range…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>There is no room for a punch range at this position.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Punch settings could not be changed. Stop recording setup and retry.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recording disk-stall reserve</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>2 seconds</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>5 seconds</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>10 seconds</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Uses memory to absorb temporary disk stalls. Applies on Prepare; monitoring latency is unchanged. Preparation refuses a reserve that exceeds the recording memory budget.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Raw input peak level</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Post-EQ monitoring peak level</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Retry adding take</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Keep take for recovery</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Open a project to find stored recordings.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Review recordings…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Refresh</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Take kept for recovery in %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>First pass</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Passes on this page</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Take name prefix</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Include the partial final pass</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Retain this page as takes</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Retain inactive takes for comping. Existing playback stays as it is; Save remains explicit.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recording workflows</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Fixed range / locators</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Manual / repeated takes</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Native input monitoring</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Track equalizer</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Audio export</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Export WAV…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Audio export progress</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Development preview: selected-track recording and shared-clock playback are available on Linux. Captured audio stays raw; track EQ affects monitoring, playback and WAV export.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Transition preparation could not start. Check Project resources and the installed render helper.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The project was reopened or replaced. Rendering stopped; owned job files were retained.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Rendering canceled. Already accepted project changes and saves may have completed; retained jobs remain available for review.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The transition could not be prepared. Check source handles, processing settings, Project resources and the installed helper. No audio was applied.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The edit queue is unavailable. The prepared job files were retained.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The transition sources changed before registration. No render started; prepared files were retained.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The project could not be queued for saving. Save it before rendering the retained job.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The project could not be saved. Rendering did not start; check the save error and retained job references.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The source render queue is unavailable. Saved references were retained.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Source rendering did not finish successfully. No audio was applied; inspect the retained job before retrying.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The assembly queue is unavailable. Rendered source spans were retained.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The transition could not be assembled or verified. No audio was applied; retained files remain available for review.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Transition rendered and verified. Review it, then choose Apply. The timeline audio has not changed.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Render transition</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Cancel rendering</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Review rendered transition</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Canceling rendering and waiting for active work to retire…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Preparing transition sources and owned job files…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Registering the transition against the current project…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Saving the project and render references…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Checking source audio and previous render history…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Verifying rendered source audio…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Rendering the two source spans…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Loading the saved transition and source history…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Verifying transition audio…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Assembling and verifying transition audio…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Elapsed: %1 s</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Transition review could not start. Check Project resources and retry.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Transition verification could not start. Check Project resources and retry.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The transition could not be applied. Review it again; no transition edit was made and retained files were preserved.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The edit queue is unavailable. Review the transition and retry Apply.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The transition was not applied because the project or sources changed. Retained files are available for review.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Transition applied. Undo restores both original clips; save to retain the change.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Transition review needs more Project resources. Close unused previews and retry.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Rendered transitions — preview</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Review a saved transition before applying it. Apply checks the audio again and changes both clips in one Undo step. Save remains explicit. Rendered transitions are experimental. Check for audible artifacts before using them in a final mix.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Previous page</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Next page</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Review selected transition</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Apply reviewed audio</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Cancel operation</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>This review belongs to a previous project opening. Close it and review the current project.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Saved transition %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>%1 · frames %2–%3</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Checking audio before Apply…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Reviewing transition audio…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Applying both clips…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>No saved rendered transitions are awaiting review. Existing timeline crossfades remain available.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Audio verified. Apply will check it again before changing the project.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>This transition is incomplete, canceled, stale or could not be verified. No edit was made; retained files were preserved.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Select a saved transition to review its audio.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Retained render review needs more Project resources. Close unused previews and retry.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Retained pitch/stretch renders</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Scan verifies retained jobs in bounded pages. Next page replaces this list; Scan again starts at the beginning. Select a ready job to review its settings, then choose Apply in the clip dialog. Files are preserved; scanning makes no project edit.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Scan again</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Review selected result</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Cancel verification</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Retained render scan could not start. Check Project resources.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The scan expired or the project changed. Scan again.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Retained render review could not start. Check Project resources.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>This review belongs to a previous project opening. Close it and scan the current project.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Verifying retained jobs in the background…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The selected job could not be reviewed. Its source, target or files may have changed. Scan again.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Verification stopped. Check files and Project resources, then scan again. No project edit was made.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Ready for review</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Already attached</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Target changed or missing</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Incomplete render</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Renderer still owns this job</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Invalid or missing files</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>duration %1/%2, pitch %3 semitones</source>
      <translation type="unfinished" />
    </message>
    <message numerus="yes">
      <source>%n retained job(s) inspected on this page.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Page %1: %2 No project edit was made.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>More entries remain. Choose Next page to continue.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Scan finished.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The render queue is unavailable. Please retry.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Rendering could not start: %1. Check Project resources and retry.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Audition prepared without a project edit. Choose playback outputs, then Play audition. Stop before Apply.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The result could not be applied. The project or clip may have changed; render it again. The owned render files were retained.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Pitch and stretch applied. Undo restores the previous clip; save to retain these settings.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The marker editor needs more Project resources. Close unused previews and retry.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>This dialog belongs to a previous project opening. Close it and select a clip in the current project.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The current render belongs to a different clip. Finish or cancel that render before starting this one.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>A different clip has the retained render result. Rendering this clip replaces that pending preview; its owned files are retained.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>An export is already running or closing. Please retry.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The selected export track no longer exists. Please retry.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Replace existing file?</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Replace this file with the new audio export?
%1
Current size: %2 bytes</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Export a track through its EQ to float32 WAV.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Export queued…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Checking the export destination…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Waiting for replacement confirmation.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Rendering snapshot %1 — %2 frames written</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Export complete: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>
%1 frames · peak %2 dBFS</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>−∞</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>
Float levels exceed 0 dBFS; they were preserved.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>
The tail reached its time limit.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>
File flushed; directory durability is not confirmed.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>
The complete file was published with a warning: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Export canceled; no new file was published.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Export failed: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Closing export…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Export worker closed.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Canceling export; waiting for the current file operation…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Stop recording and resolve its retained takes before changing the project structure.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Too many pending changes. Please retry.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Closing project…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Finish recording, pending take attachment and export before opening another project.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Choose a folder for the new project</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>New project</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Project name:</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Untitled</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Choose a project name without folder separators.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Sample rate (Hz). For Windows native audio, match the device mix rate:</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Project display updated. Retained edits are available.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Project display could not be updated: %1. The previous view is retained and editing is paused. Raise Project resources, then retry the display.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Audio view could not be prepared: %1. Raise Project resources and retry.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Choose an output for every channel.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Playback queue is full or closing. Please retry.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Choose an endpoint…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> · %1 Hz</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Missing endpoint</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Ambiguous endpoint; choose explicitly</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Legacy route; choose explicitly</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Unavailable backend: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Master output was not admitted. Please retry.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The route change was not accepted. Please retry.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Saved routing changes take effect after Stop and preparation.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Output channel %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Output %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The project changed before take audition was prepared.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Playback could not be prepared. Please retry.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Playback could not be prepared: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Native playback is not available in this build.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Prepare the selected track or matching-layout mix, choose outputs, then play.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Preparing playback…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Ready to play.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Playing — EQ changes pending</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Playing — EQ changes acknowledged</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Stopping playback…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Playback complete</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Playback stopped: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Closing playback…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Playback closed</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> · %1 s · %2 missing track-frames</source>
      <translation type="unfinished" />
    </message>
    <message numerus="yes">
      <source> · %n mixed track(s)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> · Saved master output</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> · Shared output routes: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> · Another track is prepared. Stop or prepare the selected track.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> · Loop pass %1 · project frame %2</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Take audition — arrangement unchanged. </source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Audition — project unchanged. </source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Output: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Playback could not be completed: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Choose a track with the original take's channel layout.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The native take could not be added. Its original files are retained.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>These loop takes belong to an earlier project. Keep the raw takes for recovery.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Choose a positive first pass and a take name prefix.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Take retention queue is full. Please retry.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Loop takes could not be retained: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Loop take </source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>%1 complete passes · %2 samples in the partial final pass</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> · Verifying this page…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> · Retention failed; raw takes are preserved. Retry this page or finish.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Choose a positive whole number of loop passes.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Loop recording needs an enabled loop, armed project tracks and punch recording off.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Select at least one track to arm.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Loop %1 to %2 samples. Playback repeats until Stop.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Loop is off. Saved range: %1 to %2 samples.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Punch recording range</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Positions are sample frames at %1 Hz. Input latency is accounted for during preparation.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Enable punch recording</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Punch in (samples)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Punch out (samples)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The project changed. Close this dialog and reopen its punch settings.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Enter nonnegative whole sample positions, with punch out after punch in when enabled.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Playback loop range</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Positions are sample frames at %1 Hz. The loop end is excluded; Stop ends repeated playback.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Enable loop playback</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Loop start (samples)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Loop end (samples)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The project changed. Close this dialog and reopen its loop settings.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Enter nonnegative whole sample positions, with loop end after loop start when enabled.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> · captured %1 / written %2</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> · failed; recovery available</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recording indicators could not be updated: %1. Raise Project resources and retry.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Punch in %1 · punch out %2 samples. Prepared playback end: %3.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>not prepared</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Punch is off. Saved range: %1 to %2 samples.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Choose an endpoint for every required channel.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Device %1 uses %2; this project uses %3. Choose a matching device or change its sample rate in the system audio settings.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Choose all channels from one device for this stream.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Choose each device channel only once for this stream.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The selected device format is unavailable. Prepare again and choose a current device.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Choose an input and every required monitoring output.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recording queue is full or closing. Please retry.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recording route was not admitted. Please retry.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Project mix output %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Monitor output %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Input %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>%1 — input %2</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Selected recording track no longer exists.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>%1 ms</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Keep raw takes and finish</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Windows recording monitoring is not available in this preview. Use monitoring off.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Native recording is not available in this build. Stored takes can still be recovered.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Choose monitoring, prepare, select inputs, arm, then record.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Preparing recording…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Ready to record.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Arm the track, then record.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recording — EQ changes pending</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recording — EQ changes acknowledged</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recording range complete. Stop to add the take.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Finalizing recorded audio…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Verifying recovery checkpoint…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recovering a copy of the verified take…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recording stopped: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Closing recording…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recording closed</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> · Prepared monitoring: %1. Stop and prepare to use the saved mode.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Off</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Auto during recording</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Through track EQ</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Take could not be added. Retry, or keep it for recovery.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Adding verified take to the project…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Loop recording captured. Review the takes below.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> · %1 s · %2 rejected frames</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>
Stored recording: %1</source>
      <translation type="unfinished" />
    </message>
    <message numerus="yes">
      <source> · %n armed track(s)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> · %1 missing playback frames</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> · pass %1 · loop position %2 samples</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>%1: %2</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Input</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Project output</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Monitor</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recording error details could not be saved: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recording could not be completed: %1. Any stored checkpoint remains available for recovery.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recover recording</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Verified %1 frames (%2 seconds). Recover a new copy into this project? The original recording is preserved.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>
This older job has no writer lock; writer activity cannot be confirmed. Only the verified checkpoint will be copied.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recovery queue is full or closing. Please retry.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The audio backend stopped recording.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The audio block size was outside the prepared recording capacity.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The input sample rate changed.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The recording input or output buffer was unavailable.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The audio backend reported a processing overrun.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The audio backend reported a clock discontinuity.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The audio clock position exceeded the supported range.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The recording clock changed while the take was running.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The recording clock position did not follow the previous block.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The recording timing origin could not be established.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The raw recording queue or writer stopped.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The prepared audio processor stopped.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Clock %1 at position %2, block %3 frames; engine frame %4.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Previous clock %1 at position %2, block %3 frames.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Looking for stored recordings…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recording discovery failed: %1</source>
      <translation type="unfinished" />
    </message>
    <message numerus="yes">
      <source>%n recording(s) need review.</source>
      <translation type="unfinished" />
    </message>
    <message numerus="yes">
      <source> %n additional job(s) are listed.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> Saved recording error details are available.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> Discovery limit reached; this list is incomplete.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> Some recovery metadata needs attention.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Stored recordings</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>This list shows checkpoint metadata. Review verifies the audio before offering a recovery copy. Active jobs cannot be reviewed.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Needs audio verification</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Needs verification — writer activity unconfirmed</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Active recording</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>No committed audio</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Different project, track, rate or layout</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Invalid checkpoint: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Matching recovered copy is attached</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> · %1 claimed frames</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Stored recording error metadata is invalid: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Saved recording error — %1: %2</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Metadata warning: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Discovery limit reached. The list is incomplete.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Review audio…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Band</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Frequency (Hz)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Gain (dB)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Gain</source>
      <translation>Gain</translation>
      <extracomment>Audio signal level adjustment in dB, positive or negative. Not financial profit.</extracomment>
    </message>
    <message>
      <source>Q</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Band %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>%1 frequency</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>%1 gain</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>%1 Q</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>%1 gain slider</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The operation could not be completed: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> — unsaved changes</source>
      <translation type="unfinished" />
    </message>
    <message numerus="yes">
      <source>%1 · %2 Hz · %n audio clip(s)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>This project has no audio tracks.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Exporting an immutable project snapshot…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Verifying recorded take…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Saving project…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Opening project…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Creating project…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Unsaved changes</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Ready</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Close project</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Save your changes before closing?</source>
      <translation type="unfinished" />
    </message>
  </context>
  <context>
    <name>TimelineEditor</name>
    <message>
      <source>Tracks and timeline</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Audio tracks</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Retry waveforms</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recheck source files and retry waveform preparation without changing audio or project edits.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Waveform display</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Source waveforms share an overview memory budget. Dense views use coarser peaks; shaded edges need finer detail.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Overview</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Single channel</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Source channel number</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Source channel number; does not change routing or audio.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Channel</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Selected track name</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Mono</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Stereo</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Discrete channels</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>New track channel count</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Track name</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Add track</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Audio %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Rename</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Remove track</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Up</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Down</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Track versions…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Retained take lanes in selected track</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Retained take</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Take lane name</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Comp start frame (inclusive)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Comp end frame (exclusive)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Select matching recorded group across tracks</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Comp source</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Use take region</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Prepare take audition</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Take audition could not be prepared. Stop other transport and retry.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Rename take</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Take up</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Take down</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Remove unused take</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Clips in selected track</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Selected clip</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Timeline start frame</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Source start frame</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Integer source frame; the exact fractional part is preserved. Use project crop for edits between source frames.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Length in project frames</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Split at timeline frame</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Crop offset in project frames</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Positive values remove the beginning; negative values reveal earlier source audio. Timeline start and length are project frames.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Exact source position</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Clip playback speed; pitch follows speed</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>0.250–4.000 times normal speed. Keeps the clip start and source origin; adjusts duration and fades. Export range stays as set. Undo restores the exact previous clip.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Apply speed</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Playback speed (pitch follows)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Apply range</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Apply project crop</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Split</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Duplicate</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Remove clip</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Clip destination track</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Move to track</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Pitch and stretch…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Clip gain and fades</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Clip gain in decibels</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Mute clip</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Invert clip polarity</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Clip gain (dB)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Fade out start frame</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Fade in start frame</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Fade out end frame</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Fade in end frame</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Fade out curve</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Fade in curve</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Linear</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Equal power</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Smoothstep</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Fade out shape</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Fade in shape</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Start</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>End</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Fade out</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Fade in</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Fade windows use clip-relative frames: start is included, end is excluded. Set both to 0 to disable. Signed positions preserve fades after trimming or splitting; raw media stays unchanged.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Apply clip processing</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Crossfade clips…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Recorded media asset</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Insert media clip</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Timeline zoom</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Zoom</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Edit failed: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Crossfade</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Incoming clip</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Equal gain · linear</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Equal gain · smooth</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Start (project frames)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>End (project frames, exclusive)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Paired curve</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Use retained-take handles</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Create overlap from the retained takes without changing source audio.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Render extended processed handles (preview)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Inner blend limit (project frames)</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The clips must overlap. Both fades change in one Undo step; source audio stays unchanged.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Save and render</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>OK</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Save the current project and new job references, then render the transition in the background. Review the result before applying it. Original takes are preserved. This renderer is experimental.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>This creates a transition from retained source handles. Both fades change in one Undo step; source audio stays unchanged.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Crossfade selection changed; reopen the editor.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Transition rendering could not start. Stop playback or recording and retry.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>View could not be updated: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>%1 + %2/%3 source frames · %4 Hz → %5 Hz project · speed %6/%7</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Select a clip to edit its exact frame range. Raw media is preserved.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Stop audio preparation or recording to edit tracks and clips.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Selected clip uses %1. Other retained lanes are silent.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Missing take lane</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Retained lanes are silent. Use a fully covered project frame range to replace the active arrangement; Undo restores it. Stop and reprepare playback to hear the comp.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Track versions</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Each version keeps its own arrangement. Routing, EQ, and retained takes are shared. Stop transport before switching. Removing an inactive version can be undone.</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Active version: %1</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Original</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Version name</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>New empty</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Duplicate active</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Activate selected</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Rename selected</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Remove selected</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>The project changed while track versions were open. Please reopen the dialog.</source>
      <translation type="unfinished" />
    </message>
  </context>
  <context>
    <name>TimelineView</name>
    <message>
      <source>Audio clip timeline</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source> s</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Start %1 · source %2 + %3/%4 · length %5 project frames</source>
      <translation type="unfinished" />
    </message>
  </context>
  <context>
    <name>soundcurrent::daw::ui::TimelineWaveforms</name>
    <message>
      <source>Waveforms unavailable: visible source/resource limit</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Some source waveforms are unavailable; use Retry waveforms</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Preparing source waveforms…</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Source PCM · channel %1 absent from some sources</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Source PCM · channel %1 · shaded edges need finer detail</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>Source PCM · shaded edges need finer detail · &gt;2 channels combined</source>
      <translation type="unfinished" />
    </message>
    <message>
      <source>No channel %1</source>
      <translation type="unfinished" />
    </message>
  </context>
</TS>