# Next native recording controller integration

Existing NativeMonitorController is a bounded worker that owns WASAPI-specific
NativeMonitorRecording, not a backend-independent recording owner. Its immutable
snapshots, cancellation epoch, queue admission and GUI parameter acknowledgements
are reusable. NativeOriginalRecordingSpec/Prefix/Result retain QPC/WASAPI facts and
must not be populated from PipeWire graph/POSIX observations.

Introduce a common control endpoint protocol with typed backend preparation and
result alternatives. Common only: project/raw context, selected stable ports,
monitor range, progress, applied events, control phases and cancellation. Preserve
WASAPI declared original state and PipeWire expected declarations/actual joined
state as separate types. Inventory selection stays on worker and must revalidate
current native ports. GUI shared controls project a common summary without inventing
native negotiation or clock correlation. Keep result unresolved until explicit
release/admission; urgent cancellation remains independent of command capacity.

PipeWire endpoint wraps PipeWireMonitorRecording, explicit inactive port connects,
requestStopAt/service/wait/cancelAndWait/parameter APIs. Worker service may join,
GUI must not call it. Route disposal follows callback/processing/disk joins.
No device/default/volume forcing. Resource admission includes new variant payloads.

Raw take admission/export can share approved-file/WAV/finite-prefix/explicit
placement/atomic-no-overwrite mechanics. State inspections and retained evidence
lists stay backend-specific: native-run/map/eq versus pipewire-owner/run/immutable
intent/outcome/capture/render receipts. Reject foreign roots/tracks/layouts/active
leases, keep exact hashes and use cancel checks during streaming verification.
Monitoring EQ stays separate from raw takes/default exports.

Acceptance: bounded queued prepare/start/finiteStop/cancel/fault/reopen/release;
current project/generation barriers and immutable copies; immediate EQ ack; no UI
blocking SDK/IO. Qt layout/device dropdown/busy and close gates, explicit placement,
Undo/Redo/save/reopen/playback/processed export. Genuine private PipeWire route plus
independent Windows runtime; simulated Qt tests are not native/audio qualification.

## Concrete next change

Add PreparedMonitorControlEndpoint with worker-only prepare/connect/activate/Stop,
service/ready/retain/cancel/parameter/ack methods and backend-specific original
result alternatives. Adapt the existing NativeMonitorController worker to this
interface first, preserving all existing WASAPI acceptance tests. Then add the
PipeWire implementation and shared UI projection. Accept a typed preparation,
not a generic map that can silently confuse expected/negotiated formats. Per-backend
saved-state handling returns typed verified originals. Common summaries never
convert graph ticks or POSIX time to Windows QPC. Required follow-up gates include
result memory charge, cancellation before/while SDK preparation, partial activation
rollback, result release quota, route refresh identity, Save/project-epoch barriers
and exact unchanged older platform behavior. Preserve old tests and add actual
PipeWire controller endpoint fixtures with a private server; no fake native proof.
