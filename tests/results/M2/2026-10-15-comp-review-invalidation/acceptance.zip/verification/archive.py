from pathlib import Path
import json,hashlib,zipfile,subprocess
root=Path('.cache/comp-reopen-343');out=Path('tests/results/M2/2026-10-15-comp-review-invalidation');out.mkdir(parents=True,exist_ok=True)
files={}
def add(name,path):files[name]=Path(path).read_bytes()
def tree(prefix,path):
 for p in sorted(Path(path).rglob('*')):
  if p.is_file():add(prefix+'/'+p.relative_to(path).as_posix(),p)
source=['ui/studio_window.cpp','ui/studio_window.hpp','tests/comp_assembly_ui_tests.cpp']
for name in source:add('source/'+name,name)
for p in root.glob('*.log'):add('logs/'+p.name,p)
for name in ['verification-commands.json','verify.py','archive.py']:add('verification/'+name,root/name)
tree('baseline',root/'baseline');tree('first-repair',root/'first-repair')
for p in (root/'ci').iterdir():
 if p.suffix in ['.json','.log']:add('original-ci/'+p.name,p)
archive=root/'ci/artifact-12004707942.zip'
prefix='build-desktop-native/comp-assembly-ui-evidence/run-zdg32ceb/case-48000/case-2/'
with zipfile.ZipFile(archive) as z:
 for i in z.infolist():
  if not i.is_dir() and i.filename.startswith(prefix):files['original-windows-failed-case/'+i.filename[len(prefix):]]=z.read(i)
build=Path('.cache/take-preview-linux/build')
for label,path in [('baseline-reproduction',build/'comp-assembly-ui-evidence/run-ip3imz0v'),('first-repair-assembly',build/'comp-assembly-ui-evidence/run-3umss0va'),('first-repair-creation',build/'comp-transition-ui-evidence/run-dj_lile9'),('final-assembly',build/'comp-assembly-ui-evidence/run-ywnb2o_v'),('final-creation',build/'comp-transition-ui-evidence/run-vkel8uzr')]:
 for p in sorted(path.rglob('*')):
  if p.is_file() and 'inputs' not in p.relative_to(path).parts and p.suffix in ['.json','.stdout','.stderr','.png']:
   add('workflows/'+label+'/'+p.relative_to(path).as_posix(),p)
for label,path in [('baseline-reproduction',build/'comp-assembly-ui-evidence/run-ip3imz0v/case-48000/case-2'),('final-reproduction',build/'comp-assembly-ui-evidence/run-ywnb2o_v/case-48000/case-2')]:tree(label,path)
checks=json.loads((root/'verification-commands.json').read_text());assert len(checks)==2 and all(c['exitCode']==0 for c in checks)
for path in [build/'comp-assembly-ui-evidence/run-ywnb2o_v/report.json',build/'comp-transition-ui-evidence/run-vkel8uzr/report.json']:assert json.loads(path.read_text())
binaries={}
for name in ['sc-comp-assembly-ui-tests','sc-comp-transition-ui-tests','libsc-ui-window.a']:
 path=build/name
 with path.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
 binaries[name]=dict(bytes=path.stat().st_size,sha256=digest)
files['verification/binaries.json']=(json.dumps(binaries,indent=2)+'\n').encode()
add('verification/CMakeCache.txt',build/'CMakeCache.txt')
files['verification/commands.txt']=subprocess.check_output(['ninja','-C',str(build),'-t','commands','sc-comp-assembly-ui-tests','sc-comp-transition-ui-tests'])
files['verification/implementation.patch']=subprocess.check_output(['git','diff','--']+source)
index={name:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest()) for name,data in files.items()}
files['payload-index.json']=(json.dumps(index,indent=2)+'\n').encode()
zipPath=out/'acceptance.zip'
with zipfile.ZipFile(zipPath,'w',zipfile.ZIP_DEFLATED) as z:
 for name,data in files.items():z.writestr(name,data)
with zipfile.ZipFile(zipPath) as z:
 assert z.testzip() is None
 for name,d in index.items():
  b=z.read(name);assert len(b)==d['bytes'] and hashlib.sha256(b).hexdigest()==d['sha256']
manifest=dict(archive=zipPath.name,bytes=zipPath.stat().st_size,sha256=hashlib.sha256(zipPath.read_bytes()).hexdigest(),entries=len(files),baseHead=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),testedWorkingTreeSource={n:index['source/'+n] for n in source},linuxUiWorkflowsPassed=['desktop-comp-assembly-apply','desktop-comp-transition-create'],baselineReproduced=True,firstRepairRegressionRetained=True,originalWindowsFailureRetained=True,originalCiRun=38801059137,allOriginalCiLogsAndArchivesRetained=True,nativeWindowsRepairQualified=False,installedPreviewsChanged=False,binariesIncluded=False)
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:manifest[k] for k in ['bytes','sha256','entries','baseHead']}))
