import subprocess,time,json
from pathlib import Path
root=Path('.cache/comp-reopen-343');rows=[]
for phase,cmd in [('build',['cmake','--build','.cache/take-preview-linux/build','--parallel','1','--target','sc-comp-assembly-ui-tests','sc-comp-transition-ui-tests']),('tests',['ctest','--test-dir','.cache/take-preview-linux/build','-R','^(desktop-comp-assembly-apply|desktop-comp-transition-create)$','--output-on-failure','-V'])]:
 argv=['nice','-n','15','ionice','-c','3']+cmd;start=time.monotonic()
 with (root/('final-'+phase+'.log')).open('wb') as f:r=subprocess.run(argv,stdout=f,stderr=subprocess.STDOUT)
 rows.append(dict(phase=phase,argv=argv,exitCode=r.returncode,seconds=time.monotonic()-start))
 (root/'verification-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(phase,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
