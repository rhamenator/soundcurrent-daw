from pathlib import Path
import gzip,hashlib,json,subprocess
r=Path('.cache/monitor-control-endpoints');d=Path('tests/results/M2/2026-10-12-monitor-control-endpoints');d.mkdir(parents=True,exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest();f=json.loads((r/'frozen-inputs.json').read_text());members={}
for x in f['selectedInputs']:assert sha(Path(x['path']).read_bytes())==x['checkoutSha256']
def add(n,b):
 z=gzip.compress(b,mtime=0);p=d/(n+'.gz');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z);members[n+'.gz']={'bytes':len(z),'sha256':sha(z),'originalBytes':len(b),'originalSha256':sha(b)}
for n in ['configure.log','build.log','native-configure.log','acceptance-build.log','pipewire-tests.log','acceptance-tests.log','private-pipewire.conf','recording-owned-wrapper.log','recording-owned-runtime.log','recording-owned-runtime.json','recording-owned-daemon.log','run-owned-recording.py','frozen-inputs.json','source-delta.diff','freeze-inputs.py','qualify-windows.py','windows-qualification.json','windows-qualification.log','retain166.py','retain166.log','package-evidence.py']:
 add(n,(r/n).read_bytes())
for p in r.glob('windows-compile-*.log'):add(p.name,p.read_bytes())
for p in sorted((r/'pr166-review').iterdir()):
 if p.is_file() and p.suffix in ['.json','.log']:add('pr166-review/'+p.name,p.read_bytes())
for n in ['CMakeCache.txt','Testing/Temporary/LastTest.log']:add('release/'+n,(r/'release'/n).read_bytes())
add('release/generated-commands.log',subprocess.check_output(['ninja','-C',str(r/'release'),'-t','commands']))
outputs={p.name:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in list((r/'release').glob('*.a'))+list((r/'release').glob('sc-*-tests'))+list((r/'release').glob('sc-*-fixture')) if p.is_file()};add('release/output-hashes.json',json.dumps(outputs,indent=2).encode())
summary={'implementation':f['source'],'inputs':len(f['selectedInputs']),'release':{'tests':2,'passed':2,'seconds':21.95,'nativeControllerSuiteSeconds':19.56},'currentSanitizer':'pending','currentWindowsObjects':json.loads((r/'windows-qualification.json').read_text()),'currentNativeWindowsRuntime':'pending','genuinePipeWire':{'sdk':'1.6.2','sharedEndpoint':True,'raw':99072,'monitorAndSink':8192,'captureReceipts':387,'renderReceipts':408,'callbackAllocateFreeLock':0,'durableReopen':True,'physical':False},'originalPr166':json.loads((r/'pr166-review/terminal-conclusions.json').read_text()),'testedMerge166':json.loads((r/'pr166-review/tested-merge-binding.json').read_text()),'scope':'shared offRT endpoint plus existing WASAPI controller dispatch; PipeWire controller snapshots/Qt/verified placement/export remainnext; fullparity incomplete','oldFailureCauses':'unresolved','payload':'text/log/config/metadata/hash only; no binary/audio/ZIP','members':members}
(d/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for n,row in members.items():
 b=(d/n).read_bytes();assert sha(b)==row['sha256'];raw=gzip.decompress(b);assert len(raw)==row['originalBytes'] and sha(raw)==row['originalSha256']
print('Verified',len(members),'bound evidence members;831 inputs unchanged')
