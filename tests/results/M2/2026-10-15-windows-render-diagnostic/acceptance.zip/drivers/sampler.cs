// SPDX-License-Identifier: GPL-3.0-only
// External, bounded observation of an owned main and its direct span workers.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
public sealed class SC334Sampler : IDisposable {
 [StructLayout(LayoutKind.Sequential)] struct IO { public ulong Reads,Writes,Other,ReadBytes,WriteBytes,OtherBytes; }
 [StructLayout(LayoutKind.Sequential,CharSet=CharSet.Unicode)] struct PE {public uint Size,Usage,Pid;public UIntPtr Heap;public uint Module,Threads,Parent;public int Priority;public uint Flags;[MarshalAs(UnmanagedType.ByValTStr,SizeConst=260)]public string Exe;}
 [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr OpenProcess(uint rights,bool inherit,uint pid);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetProcessTimes(IntPtr h,out long create,out long exit,out long kernel,out long user);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetProcessIoCounters(IntPtr h,out IO io);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetExitCodeProcess(IntPtr h,out uint exit);
 [DllImport("kernel32.dll",SetLastError=true,CharSet=CharSet.Unicode)]static extern bool QueryFullProcessImageName(IntPtr h,uint flags,StringBuilder path,ref uint size);
 [DllImport("kernel32.dll",SetLastError=true)]static extern IntPtr CreateToolhelp32Snapshot(uint flags,uint pid);
 [DllImport("kernel32.dll",SetLastError=true,CharSet=CharSet.Unicode)]static extern bool Process32FirstW(IntPtr h,ref PE p);
 [DllImport("kernel32.dll",SetLastError=true,CharSet=CharSet.Unicode)]static extern bool Process32NextW(IntPtr h,ref PE p);
 [DllImport("kernel32.dll")]static extern bool CloseHandle(IntPtr h);
 public sealed class Row {public long Ms,Created100ns,Kernel100ns,User100ns;public uint Pid,Exit;public ulong Reads,Writes,Other,ReadBytes,WriteBytes,OtherBytes;}
 public sealed class Identity {public uint Pid;public string Path;public long Created100ns;public long FirstMs;}
 sealed class Owned {public IntPtr Handle;public Identity Id;public bool Exited;}
 readonly List<Owned> owned=new List<Owned>(); readonly List<Row> rows=new List<Row>(4096);
 readonly Stopwatch clock=new Stopwatch();readonly ManualResetEvent stop=new ManualResetEvent(false);
 readonly uint main;readonly string worker;readonly Thread thread;public string Error;public bool HitLimit;
 public long ElapsedMilliseconds {get {return clock.ElapsedMilliseconds;}}
 public Identity[] Identities {get {if(thread.IsAlive)throw new InvalidOperationException("Stop first");return owned.ConvertAll(x=>x.Id).ToArray();}}
 public Row[] Rows {get {if(thread.IsAlive)throw new InvalidOperationException("Stop first");return rows.ToArray();}}
 static Exception Fail(string s){return new InvalidOperationException(s+" Win32="+Marshal.GetLastWin32Error());}
 void Add(uint pid,string expected) {
  foreach(var x in owned) if(x.Id.Pid==pid)return;
  if(owned.Count>=4)throw new InvalidOperationException("Process bound");
  IntPtr h=OpenProcess(0x1000,false,pid);if(h==IntPtr.Zero)throw Fail("Open owned process");
  try{var b=new StringBuilder(32768);uint n=32768;long c,e,k,u;
   if(!QueryFullProcessImageName(h,0,b,ref n)||!GetProcessTimes(h,out c,out e,out k,out u))throw Fail("Process identity");
   if(!String.Equals(b.ToString(),expected,StringComparison.OrdinalIgnoreCase))throw new InvalidOperationException("Unexpected owned executable");
   owned.Add(new Owned{Handle=h,Id=new Identity{Pid=pid,Path=b.ToString(),Created100ns=c,FirstMs=clock.ElapsedMilliseconds}});h=IntPtr.Zero;
  }finally{if(h!=IntPtr.Zero)CloseHandle(h);}
 }
 void Discover(){IntPtr h=CreateToolhelp32Snapshot(2,0);if(h==new IntPtr(-1))throw Fail("Process snapshot");
  try{PE p=new PE();p.Size=(uint)Marshal.SizeOf(typeof(PE));bool more=Process32FirstW(h,ref p);int count=0;
   while(more){if(++count>10000)throw new InvalidOperationException("Snapshot bound");
    if(p.Parent==main && String.Equals(p.Exe,"sc-comp-span-worker.exe",StringComparison.OrdinalIgnoreCase))Add(p.Pid,worker);
    more=Process32NextW(h,ref p);
   }
   if(Marshal.GetLastWin32Error()!=18)throw Fail("Process enumeration");
  }finally{CloseHandle(h);}
 }
 void Sample(){foreach(var x in owned){if(x.Exited)continue;long c,e,k,u;uint exit;IO io;
   if(!GetProcessTimes(x.Handle,out c,out e,out k,out u)||!GetProcessIoCounters(x.Handle,out io)||!GetExitCodeProcess(x.Handle,out exit))throw Fail("Owned counters");
   if(c!=x.Id.Created100ns)throw new InvalidOperationException("Creation identity changed");
   if(rows.Count>=4096){HitLimit=true;throw new InvalidOperationException("Sample bound");}
   rows.Add(new Row{Ms=clock.ElapsedMilliseconds,Pid=x.Id.Pid,Created100ns=c,Kernel100ns=k,User100ns=u,Exit=exit,Reads=io.Reads,Writes=io.Writes,Other=io.Other,ReadBytes=io.ReadBytes,WriteBytes=io.WriteBytes,OtherBytes=io.OtherBytes});
   x.Exited=exit!=259;
  }}
 void Run(){try{do{Discover();Sample();if(clock.ElapsedMilliseconds>=90000){HitLimit=true;break;}}while(!stop.WaitOne(100));Sample();}catch(Exception e){Error=e.ToString();}}
 public SC334Sampler(uint pid,string mainPath,string workerPath){main=pid;worker=workerPath;clock.Start();Add(pid,mainPath);Sample();thread=new Thread(Run);thread.IsBackground=true;thread.Start();}
 public void Stop(){stop.Set();if(!thread.Join(5000))throw new InvalidOperationException("Sampler did not stop");}
 public void Dispose(){Stop();foreach(var x in owned)CloseHandle(x.Handle);owned.Clear();stop.Dispose();}
}
