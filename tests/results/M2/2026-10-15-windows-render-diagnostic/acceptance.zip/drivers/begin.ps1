$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$media=Split-Path -Parent $MyInvocation.MyCommand.Path
$root=Join-Path $env:USERPROFILE 'SoundCurrent-Diagnostic-334'
if((Get-CimInstance Win32_ComputerSystemProduct).UUID.ToLowerInvariant() -ne '670168f5-4e3f-4e7f-b218-3583db31f0f8'){throw 'Wrong clone'}
if(Test-Path $root){throw 'Owned diagnostic root already exists'}
New-Item -ItemType Directory $root|Out-Null
foreach($n in @('receipt.json','project.zip','private-transport.json','workflow.ps1','collect.ps1','end.ps1','sampler.cs')){Copy-Item -LiteralPath (Join-Path $media $n) $root}
$r=Get-Content -Raw (Join-Path $root 'receipt.json')|ConvertFrom-Json
$install=Join-Path $env:LOCALAPPDATA ('Programs\SoundCurrent DAW Preview\'+$r.sequence+'-'+$r.sourceHead.Substring(0,12))
foreach($f in $r.payload.PSObject.Properties){if((Get-FileHash -LiteralPath (Join-Path $install $f.Name) -Algorithm SHA256).Hash.ToLowerInvariant() -ne $f.Value.sha256){throw 'Installed bytes changed'}}
$previous=@(Get-ChildItem -LiteralPath (Split-Path -Parent $install) -File -Recurse|ForEach-Object {@{path=$_.FullName;sha256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash}})
$previous|ConvertTo-Json -Depth 5|Set-Content (Join-Path $root 'previous-files.json') -Encoding UTF8
Expand-Archive -LiteralPath (Join-Path $root 'project.zip') -DestinationPath $root
& (Join-Path $root 'workflow.ps1')
& (Join-Path $root 'end.ps1')
