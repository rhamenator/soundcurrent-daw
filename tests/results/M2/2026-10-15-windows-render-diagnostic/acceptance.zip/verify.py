from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parent;s=r/'observed/retired-334';project=s/'project-été-Κиїв';load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ret=load(s/'retirement.json');assert ret['ownedProcessesRemaining']==0 and ret['installedPayloadFilesVerified']==65 and ret['earlierPreviewFilesVerified']==401 and not ret['nativeAudioActivated']
assert load(r/'cleanup.json')['allVmsOff']
state=load(project/'project.json');before=load(r/'original-project.json');previous=r.parent/'windows-installed-progress-333/observed/retired-333/project-été-Κиїв';expected=load(previous/'project.json')
originals=[n for n in before if n not in ['project.json','project.previous.json']]
for n in originals:assert sha(project/n)==before[n]['sha256'],n
# One explicit Save follows Apply here; previous.json retains pre-Apply tracks.
assert load(project/'project.previous.json')['tracks']==load(r.parent/'installed-comp-323/app/project-été-Κиїв/project.json')['tracks']
matched=[]
for actual,reference in zip(state['tracks'][0]['clips'],expected['tracks'][0]['clips'],strict=True):
 for key in ['startFrame','lengthFrames','sourceFrame','sourceTiming','playbackRate','processing']:assert actual[key]==reference[key]
 a=next(a for a in state['assets'] if a['id']==actual['assetId']);b=next(a for a in expected['assets'] if a['id']==reference['assetId'])
 assert a['sha256']==sha(project/a['path'])==b['sha256']==sha(previous/b['path'])
 matched.append(a['sha256'])
assert len(matched)==2
new=[p for p in project.glob('media/comp-spans/*/complete.json') if str(p.relative_to(project)) not in before];assert len(new)==2
assert all(load(p)['memoryMetric']=='process-commit' for p in new)
original=load(s/'workflow-result.json');assert not original['passed'] and original['phase']=='applying' and 'FindAll' in original['error']
assert load(s/'first-launch.json')['sha256']=='3d8f067018db4e4a22edd0fbe68d97af1bdafb5eb4101e6ac67f660e3d88c891'
report=dict(ownedInstalledPayloadsUnchanged=65,earlierPreviewFilesVerified=401,preservedHistoryFiles=len(originals),matchedRenderedWavHashes=matched,actualRenderAndSavedApply=True,originalDriverPassed=False,undoRedoExportNotReached=True,processRetirementVerified=True,normalCloseObserved=True,mainExitCodeCaptured=False)
(r/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
