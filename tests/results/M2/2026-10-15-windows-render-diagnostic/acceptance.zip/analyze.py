from pathlib import Path
import json,collections
r=Path(__file__).resolve().parent;s=r/'observed/workflow-334'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
o=load(s/'process-observations.json');ui=load(s/'render-progress.json');result=load(s/'workflow-result.json')
assert not o['error'] and not o['hitLimit'] and len(o['rows'])<=4096
assert len(o['identities'])==3 and result['elapsedFrozenAtTerminal']
rows=collections.defaultdict(list)
for x in o['rows']:rows[x['Pid']].append(x)
processes=[]
for ident in o['identities']:
 values=rows[ident['Pid']];a,b=values[0],values[-1]
 assert all(v['Created100ns']==ident['Created100ns'] for v in values)
 counters=['Kernel100ns','User100ns','Reads','Writes','Other','ReadBytes','WriteBytes','OtherBytes']
 for prev,nxt in zip(values,values[1:]):
  assert nxt['Ms']>=prev['Ms']
  assert all(nxt[k]>=prev[k] for k in counters)
 child=ident['Path'].endswith('sc-comp-span-worker.exe')
 assert b['Exit']==(0 if child else 259)
 # Child totals include work before discovery. Parent reports window deltas.
 base={k:0 for k in counters} if child else a
 delta={k:b[k]-base[k] for k in counters}
 processes.append(dict(pid=ident['Pid'],path=ident['Path'],firstMs=a['Ms'],lastMs=b['Ms'],samples=len(values),exit=b['Exit'],cpuSeconds=(delta['Kernel100ns']+delta['User100ns'])/1e7,readOps=delta['Reads'],readBytes=delta['ReadBytes'],writeOps=delta['Writes'],writeBytes=delta['WriteBytes'],otherOps=delta['Other'],scope='lifetime' if child else 'observed render window'))
phases=[]
for x in ui:
 assert x['endMs']>=x['startMs']
 if not phases or phases[-1]['status']!=x['status']:phases.append(dict(status=x['status'],firstMs=x['startMs'],lastMs=x['endMs'],samples=1))
 else:phases[-1]['lastMs']=x['endMs'];phases[-1]['samples']+=1
assert ui[-1]['ready']
for a,b in zip(phases,phases[1:]):a['observedUntilNextStageMs']=b['firstMs']-a['firstMs']
report=dict(sourceHead=result['sourceHead'],renderMilliseconds=result['renderMilliseconds'],terminalElapsed=result['terminalElapsed'],original30SecondExpectationMet=result['original30SecondExpectationMet'],processes=processes,phases=phases,maximumUiQueryMs=max(x['endMs']-x['startMs'] for x in ui),physicalDiskMeasurement=False,audioActivated=False)
(r/'analysis.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
