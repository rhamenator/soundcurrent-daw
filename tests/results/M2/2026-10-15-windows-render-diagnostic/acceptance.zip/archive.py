from pathlib import Path
import hashlib,json,zipfile
r=Path(__file__).resolve().parent;repo=r.parents[1];scope=r/'observed/retired-334';out=repo/'tests/results/M2/2026-10-15-windows-render-diagnostic';out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));files={}
assert load(r/'verification.json')['actualRenderAndSavedApply'] and load(r/'cleanup.json')['allVmsOff']
ci=load(r/'ci/retention.json');assert ci['conclusion']=='success' and len(ci['jobs'])==15 and len(ci['artifacts'])==12 and ci['allAvailableOriginalArchivesRetained'] and ci['allFullLogsRetained']
for p in scope.iterdir():
 if p.is_file():files['observed/'+p.name]=p.read_bytes()
for n in ['sampler.cs','begin.ps1','workflow.ps1','collect.ps1','end.ps1']:files['drivers/'+n]=(r/'iso'/n).read_bytes()
for n in ['analyze.py','verify.py','archive.py','analysis.json','verification.json','cleanup.json','original-project.json']:
 files[n]=(r/n).read_bytes()
for n in ['after-failure.png','closed.png','running.png']:files['host-observations/'+n]=(r/n).read_bytes()
for p in (r/'ci').iterdir():
 if p.suffix in ['.json','.log']:files['ci/'+p.name]=p.read_bytes()
files['observer-limitations.txt']=b'Original automation failed during Apply with ElementNotAvailableException, after render measurements completed. Workflow remains failed; Undo/Redo/export were not reached. Host observed completed Apply, closed review with Enter, saved with Ctrl+S, closed main with Alt+F4. Retirement verifies zero processes but no main exit code was captured. Querying the UI tree adds unmeasured observation overhead. Child counters cover lifetime; parent counters cover the observation window and include UI/provider work. Process I/O includes non-disk operations. No causal assignment to physical disk or antivirus is justified. Initial host verifier incorrectly expected previous.json to equal current state (copied from the prior multi-save workflow); corrected to verify pre-Apply original tracks, since this run saved only once after Apply.\n'
baseArchive=repo/'tests/results/M2/2026-10-15-installed-portable-comp/acceptance.zip';baseHash=load(baseArchive.parent/'manifest.json')['sha256'];assert sha(baseArchive.read_bytes())==baseHash
original=repo/'.cache/installed-comp-323/app/project-été-Κиїв';target=scope/'project-été-Κиїв';members={}
for p in target.rglob('*'):
 if not p.is_file():continue
 n=str(p.relative_to(target));b=p.read_bytes();v=dict(bytes=len(b),sha256=sha(b))
 if (original/n).is_file() and (original/n).read_bytes()==b:v['baseProjectFile']=n
 else:v['entry']='project/'+n;files[v['entry']]=b
 members[n]=v
files['project-members.json']=(json.dumps(dict(baseArchive=str(baseArchive.relative_to(repo)),baseSha256=baseHash,baseProjectManifest='project-members.json',files=members),indent=2)+'\n').encode()
files['RECONSTRUCT.txt']=b'Reconstruct checkpoint323 using its project-members.json and hash-pinned predecessor. For each file here use baseProjectFile from that base or entry from this archive. Verify every size/hash. Never overlay a user project. Host verifiers expect the original cache layout.\n'
captures=[]
for p in sorted((r/'received').glob('*.zip')):
 with zipfile.ZipFile(p) as z:assert z.testzip() is None
 captures.append(dict(name=p.name,bytes=p.stat().st_size,sha256=sha(p.read_bytes())))
files['original-captures.json']=(json.dumps(captures,indent=2)+'\n').encode()
key=load(r/'receiver-private.json')['key'].encode()
for n,b in files.items():
 assert key not in b,n
 assert not any(w in n for w in ['private-transport','receiver-private','.iso','.exe']),n
index={n:dict(bytes=len(b),sha256=sha(b)) for n,b in files.items()};files['payload-manifest.json']=(json.dumps(index,indent=2)+'\n').encode();p=out/'acceptance.zip'
with zipfile.ZipFile(p,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,b in files.items():z.writestr(n,b)
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 for n,v in index.items():assert sha(z.read(n))==v['sha256']
 for n,v in members.items():
  b=(original/v['baseProjectFile']).read_bytes() if 'baseProjectFile' in v else z.read(v['entry']);assert len(b)==v['bytes'] and sha(b)==v['sha256']
report=dict(archive=p.name,bytes=p.stat().st_size,sha256=sha(p.read_bytes()),entries=len(files),sourceHead='b5dc2568dbf0e1e623dbaa7d42dcd38fd1eed3ab',ciHead=ci['head'],ciRun=ci['run'],ciConclusion=ci['conclusion'],ciJobs=15,projectFiles=len(members),projectReconstructionVerified=True,renderDiagnosticCompleted=True,originalDriverPassed=False,renderLatencyFindingOpen=True,physicalAudio=False,applicationBinariesIncluded=False,credentialsIncluded=False)
(out/'manifest.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
